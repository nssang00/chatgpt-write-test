# Geo DevTools roadmap (revised 2026-10-12)

## Product principles

1. One `attachGeoDevTools(map)` call for basic runtime diagnostics; no separate settings file.
2. Read-only collection, small bounded event history; never interfere with map rendering.
3. Every finding shows **observed evidence, confidence, and what is not proven**.
4. Basic inspection is open-source, local-first, and can operate without sending GIS data to a service.
5. Avoid competing with existing feature inspectors on UI alone: invest in reproducible diagnosis.

## Current status

| ID | Work | Status | Acceptance evidence |
|---|---|---|---|
| P0-A | Map/layer/source/Grid snapshot | Implemented | Node mock tests |
| P0-B | Tile event recorder | Implemented | Node mock tests |
| P0-C | Findings and Shadow DOM UI | Implemented | Node mock tests |
| P0-D | Zoom boundary correctness | **Fixed v0.2** | `minZoom` inclusive / `maxZoom` exclusive tests |
| P1-A | Read-only MVT metadata parser | **Implemented v0.2** | 16 MVT tests, incl. independent protobuf fixture |
| P1-B | Sample MVT vs MapLibre style expression | **Implemented v0.2 (partial)** | `source-layer`, `get`, `has` sample findings |
| P1-C | One-command local MVT CLI | **Implemented v0.2** | CLI tests |
| P0-E | Real `ol` classes | **Not run here** | Optional test skips until `ol` installed |
| P0-F | Real browser / real `ol/Map` | **Not validated** | Requires browser + actual `ol` app |
| P1-D | OpenLayers native style comparison | Not implemented | Resolve native style expression/function limitations |
| P1-E | Opt-in automatic MVT sample capture | Not implemented | Explicit consent, known ownership, bounded samples |
| P2-A | URL-only scanner | Not implemented | Playwright, restricted diagnostic scope |
| P2-B | MapLibre runtime adapter | Not implemented | Cross-engine schema, public APIs |
| P2-C | CI report / visual regression | Not implemented | Repeatable fixed camera and data fixtures |
| P3 | Cesium, GPU profiling and WASM | Deferred | Build only after user evidence |

## Immediate next engineering milestone: genuine OpenLayers integration

1. On an internet-enabled dev computer install `ol` (`npm install --no-save ol`).
2. Run `npm test` and resolve any failures in `OL-INTEGRATION-01/02` against real classes.
3. Add Vite + Playwright E2E that mounts actual `new ol/Map({target:...})` with local XYZ/MVT fixtures, **no external basemap**.
4. Validate tileloadstart/end/error under HTTP 200, 404, and intentional cancellation; do not equate tileloadend to HTTP success.
5. Validate pan/zoom, layer swap, disposal, Shadow DOM, and privacy in real browser.
6. Keep an integration matrix for the exact OpenLayers versions validated; do not assert compatibility without running it.

## Next functional milestone: avoid extra user work

- After real `ol` tests: include optional `inspectCurrentVectorTileSource(map, {sampleLimit:...})` with explicit opt-in and bounds.
- Need source permission and valid tile bytes; do not silently sniff auth-bearing responses or crawl new areas.
- Support OpenLayers native flat style and expression-based cases where introspection is reliable; mark style-function cases uninspectable.
- Keep `inspectMvt(bytes)` as a pure core API for unit tests and CLI users.
- Surface sample coverage (tileCount, layerCount, zoom levels if known) rather than declaring global missing fields.

## Adoption validation

- Reproduce at least 5 real GIS bug reports with verified repro projects.
- 10 valid-map control fixtures and 10 intentionally faulty fixtures to estimate false positives.
- Compare manual debugging time with tool-assisted debugging for >=5 developers.
- A public demo should load without account/login and provide visible before/after outcomes.
- Defer paid service decisions until an external repo or project uses it repeatedly.

## Risk register

- `ol` API differences across versions → documented compatibility matrix + E2E.
- Source loader/TileGrid missing or custom → unknown status, no fabricated defaults.
- MapLibre expression semantics and conditional fields → informational findings from sample only.
- Browser driver/sandbox failures → separate from Node logic results.
- Public reports may expose internal layer/key names → local-first and redaction support.

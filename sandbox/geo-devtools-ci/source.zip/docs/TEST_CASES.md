# Geo DevTools test cases (v0.2)

## Completed Node tests: 49 passed + 1 optional skipped

### Existing v0.1 suite — TC-01…TC-30 (30 tests)

- Snapshot: public API, stable IDs, no network scraping, unknown/missing source, invalid map/grid.
- Diagnostics: valid map control, projection mismatch remains info, source error, layer hidden, bad grids, correct `minZoom` inclusive / `maxZoom` exclusive boundaries, grouped tile errors.
- Events: loaded/aborted/unknown states, bounded memory.
- Controller: subscription/disposal, layer changes, source sharing, source replacement, observer exception safety.
- Privacy: default export redaction, opt-in verbose export, JSON serializability.
- Panel: tab switching, issues, disposal in a mocked DOM.

### MVT tests — MVT-01…MVT-16 (16 tests)

| ID | Test case |
|---|---|
| 01 | Decode valid tile; key metadata without attribute values |
| 02 | Empty MVT file without fabricated error |
| 03 | Truncated protobuf rejection |
| 04 | Gzip input gives explicit error |
| 05 | Wire-type and byte-limit validation |
| 06 | Odd feature tag array and invalid attribute index |
| 07 | Unsupported MVT layer version flagged |
| 08 | Unknown fields and DataView accepted |
| 09 | Unobserved style source-layer gives only info |
| 10 | Present style attribute causes no false positive |
| 11 | Missing sampled attribute is informational |
| 12 | Different source ignored |
| 13 | Literal expression data not mistaken for property access |
| 14 | Invalid JS input rejected |
| 15 | Independently generated protobuf fixture parses, including unpacked geometry |
| 16 | Independent fixture + style produces expected info finding |

### CLI tests — CLI-01…CLI-03 (3 tests)

- Local file analysis works in a subprocess.
- `--style --source --json` output is valid and omits raw feature attribute values.
- Missing paired options give nonzero exit and clear error.

### Optional real-OpenLayers class tests — OL-INTEGRATION (skipped here)

- `ol/View`, `ol/layer/Tile`, `ol/source/XYZ`, `ol/tilegrid/TileGrid` used with the library's adapter and a fake Map shell.
- Validate source subscriptions removed on disposal.
- **These do not constitute full actual-map browser E2E.**

## Uncompleted E2E cases

| ID | Scenario | Acceptance criterion |
|---|---|---|
| E2E-01 | Actual OL Map with local XYZ tile server | Panel/layer metadata correct |
| E2E-02 | Different projection and tile origins | Correct warning/info severity, no false CRS error |
| E2E-03 | HTTP 200, HTTP 404, cancel | Tile state and error classification correct |
| E2E-04 | Pan, zoom, replace and remove layers | Listeners always detached; findings refresh |
| E2E-05 | Downloaded JSON report | Sensitive coordinates and names absent by default |
| E2E-06 | Dense vector tiles | Small measurable tool overhead, documented |
| E2E-07 | Bad `source-layer` + valid controls | Low confidence when only sample examined |
| E2E-08 | Chromium Shadow DOM interactions | Tabs, footer, close work in real DOM |

## Other quality obligations

- Test real-world MVT files from independent encoders, including compression and unusual protobuf field ordering.
- Keep invalid/healthy fixtures paired to measure false positives.
- Protect users from leaking custom schema keys or coordinate data in GitHub issues.
- Validate against actual OpenLayers official API versions before npm/public release.

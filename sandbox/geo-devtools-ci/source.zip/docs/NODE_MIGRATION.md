# Node.js-only basic diagnosis and Chromium E2E

The supported zero-touch runner and CI are Node.js + Playwright. No Python installation is needed.

```bash
npm install
npx playwright install chromium
node bin/geo-doctor.js scan http://localhost:5173 --output artifacts/local-report.json
npm test
npm run test:e2e
```

The URL scanner observes network metadata, counts JS/console errors, and checks map DOM hints. It does **not** read OpenLayers private objects or claim to diagnose CRS, TileGrid, MVT contents or style semantics by default. Request URLs, credentials and response bodies are deliberately not saved, and screenshots require explicit `--screenshot`. The test runner observes only an isolated local fixture page.

`tests/e2e/zero-touch.js` checks a real OpenLayers healthy map against a 404 tile map with no SDK injected into either. `tests/e2e/real-ol.js` tests opt-in runtime integration. `tests/e2e/visual.js` checks panel interactions using a synthetic map. They run on GitHub Actions with Chromium.

Python scripts are retained temporarily only as historical parity fixtures. They are not installed or invoked in CI.

# Geo Doctor: zero-change default, progressive diagnostics

## Product contract

**Adoption must not require changing application source code.** A user starts with a URL scan; optional deeper levels make *specific extra observations* possible. Optional instrumentation must never be an implicit prerequisite for default results.

| Level | User work | Data available | Must not claim |
|---|---|---|---|
| 0 — Basic (default) | Run scanner with URL / later browser extension | Browser HTTP failures, transport failures, uncaught JS error counts, recognizable map DOM/canvas, optional screenshot | Full layer tree, CRS correctness, TileGrid origin, CSS/render reasons, hidden map objects |
| 1 — Extended no-code | Explicit consent for content inspection, samples or recording; browser extension if available | Bounded MVT sample and response metadata, HTTP bodies, sampled map image | Every tile/zoom covered or auth without permission; all filters evaluated |
| 2 — Runtime adapter | `attachGeoDevTools(map)` for OL; equivalent MapLibre adapter | View, Layer, Source, TileGrid, observable events, source metadata | Automatic identification of the true geographic CRS without external reference |
| 3 — Expert diagnostics | Provide reference CRS, TileMatrixSet, reference coordinate or styles; opt-in replay | Differential rule testing, high-confidence explicit comparison, reusable regression cases | Automatic app-wide source fixes without human review |

The UI must *always* show **Coverage** for each category. Display `not_inspected` rather than a green check when evidence is unavailable. Findings use `rule`, `severity`, `confidence`, `evidence`, `limitations`, `nextAction`, and optional `upgradeReason`.

## Basic scanner now implemented (experimental)

```bash
python -m pip install playwright==1.57.0
python -m playwright install chromium
python scripts/geo_doctor_scan.py http://localhost:5173 --output report.json
```

Generates a sanitized `report.json` and `report.html`, without adding anything to the target application. The scanner uses Playwright (installed in *scanner tooling*, not target app). It records only host/category/status counts. Screenshot is explicitly opt-in (`--screenshot screenshot.png`). It does not record raw URLs, URL query arguments, response bodies or console message text.

**Zero changes to the app does not mean zero user interaction.** The user must provide a reachable URL, have permission to inspect the page and launch the scanner or extension. A URL scan may not authenticate to a protected app without extra setup.

**Safety caveat:** Browser navigation can cause real application side effects (analytics/session writes). Do not scan untrusted or production URLs without appropriate permission; read-only describes the scanner's own inspection, not the application itself.

### Supported level-0 diagnostics

- Tile-like 4xx/5xx status, grouped by host/status/category. Strict matching for tile URL patterns, less certain image-like resources.
- Transport failure (distinct from HTTP 404/503).
- Uncaught JavaScript/console error *counts* without message bodies.
- Recognized map container/canvas presence, treated as weak signal.
- Explicit `coverage` indicating uninspected internal state.

### Not supported in default mode

- Actual CRS correctness, extent sanity relative to intended location, tile grid origins/zoom scheme validity, style-filter evaluation, full MVT content reading.
- Precise GPU timings and layer-by-layer cost accounting.
- Blind hidden map object introspection or project source modification.

## Tested fixture and acceptance criteria

- `healthy`: actual OpenLayers `Map` with no Geo Doctor adapter attached, no HTTP tile errors.
- `broken`: same map requesting `/tests/zero-touch/tiles/{z}/{x}/{y}.png?apiKey=DO_NOT_LEAK`, local test server responds 404.
- Scanner must identify status 404 on a tile without reading OpenLayers map internals; it must not claim CRS inspection.
- Scanner report must contain neither URL query secrets nor response/console bodies.
- Browser screenshot of map and separate HTML diagnostic report for the broken fixture.
- Ensure users can first find a real problem at level 0, then choose level 1-3 via a clear reason. Do not add new permissions automatically.

## Trust metrics

1. **Time to first useful finding** in level 0, independent of any SDK.
2. **False positive rate** on healthy OpenLayers and MapLibre fixtures; must precede marketing claims.
3. **Explained coverage**: how many findings explicitly cite inspected evidence and what was not checked.
4. **Upgrade conversion**: how often a basic finding legitimately needs the user to enable level 1/2 instead of arbitrary upselling.
5. **Reproducibility**: sanitized report + deterministic fixture + CI screenshot; privacy by default.

## Next milestones

- Browser extension UI for click-to-inspect convenience while preserving zero source changes; mind extension host permissions, isolated/main-world execution and user consent.
- Authenticated local-project workflows (user launched browser or signed-in browser context) with opt-in session handling.
- Opt-in bounded MVT response collection; re-use existing `src/mvt/inspect.js` without recording raw feature values.
- Tile URL XYZ/TMS hypothesis checks and OpenLayers adapter integration when low-level evidence is insufficient.
- Gold-standard healthy vs faulty maps across tile servers, WMS/WMTS, CRS, styles, MVT.

/** MapLibre/Mapbox GL style JSON diagnostics against sampled MVT metadata.
 * This is NOT an OpenLayers style parser; no requests or style evaluation take place.
 */
function accessedProperties(expression,keys=new Set()) {
  if(!Array.isArray(expression)) return keys;
  if(expression[0]==='literal') return keys;
  if((expression[0]==='get'||expression[0]==='has') && typeof expression[1]==='string') {
    keys.add(expression[1]);
  }
  for(const item of expression.slice(1)) accessedProperties(item,keys);
  return keys;
}
/**
 * @param {Array<ReturnType<import('./inspect.js').inspectMvt>>} samples
 * @param {object} style MapLibre GL style JSON
 * @param {{sourceId:string}} options exact style source identifier
 */
export function compareMvtStyle(samples,style,{sourceId}={}) {
  if(!Array.isArray(samples)||!style||!Array.isArray(style.layers)) throw new TypeError('Expected tile sample array and style.layers');
  if(typeof sourceId!=='string'||!sourceId) throw new TypeError('sourceId is required to select style source');
  const findings=[];
  const layerIndex=new Map();
  for(const sample of samples){
    for(const layer of sample.layers??[]){
      if(!layerIndex.has(layer.name)) layerIndex.set(layer.name,{featureCount:0,keys:new Set()});
      const entry=layerIndex.get(layer.name);
      entry.featureCount+=layer.featureCount;
      (layer.usedKeys??[]).forEach(k=>entry.keys.add(k));
    }
  }
  for(const styleLayer of style.layers){
    if(styleLayer.source!==sourceId || !styleLayer['source-layer']) continue;
    const target=styleLayer['source-layer'];
    const entry=layerIndex.get(target);
    if(!entry){
      findings.push({rule:'source-layer-not-observed',severity:'info',confidence:'low',
        styleLayerId:styleLayer.id??null,sourceLayer:target,
        title:'스타일의 source-layer가 제공된 타일 표본에서 관측되지 않았습니다.',
        evidence:{samples:samples.length},
        limitations:['표본 밖의 타일이나 줌 수준에는 해당 레이어가 존재할 수 있습니다.']});
      continue;
    }
    if(!entry.featureCount)continue;
    const required=new Set();
    for(const e of Object.values(styleLayer.paint??{}))accessedProperties(e,required);
    for(const e of Object.values(styleLayer.layout??{}))accessedProperties(e,required);
    accessedProperties(styleLayer.filter,required);
    const missing=[...required].filter(key=>!entry.keys.has(key));
    if(missing.length){
      findings.push({rule:'style-attributes-not-observed',severity:'info',confidence:'low',
        styleLayerId:styleLayer.id??null,sourceLayer:target,
        title:'스타일에서 참조하는 일부 속성을 제공된 타일 표본에서 관측하지 못했습니다.',
        evidence:{sampledFeatures:entry.featureCount,unobservedProperties:missing},
        limitations:['조건부 속성, 동적 표현식 및 다른 타일·줌 레벨은 검사하지 않았습니다.']});
    }
  }
  return findings;
}

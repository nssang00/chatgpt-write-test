/**
 * Small, dependency-free, READ-ONLY Mapbox Vector Tile metadata inspector.
 * Supports MVT v1/v2 protobuf wire format: layer names, attribute usage, feature counts.
 * Deliberately does not decode geometries, URLs, or raw attribute values.
 * The public API accepts a decompressed .mvt/.pbf byte buffer, not OSM .pbf.
 */
export class MvtParseError extends Error {
  constructor(message) { super(message); this.name = 'MvtParseError'; }
}
const fail = message => { throw new MvtParseError(message); };
const textDecoder = new TextDecoder('utf-8', {fatal:true});
function bytesOf(input) {
  if (input instanceof Uint8Array) return input;
  if (input instanceof ArrayBuffer) return new Uint8Array(input);
  if (ArrayBuffer.isView(input)) return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  throw new TypeError('MVT input must be Uint8Array, DataView or ArrayBuffer');
}
function readVarint(data, state, end) {
  let value = 0, factor = 1;
  for (let i=0;i<10;i++) {
    if (state.offset >= end) fail('Truncated protobuf varint');
    const b = data[state.offset++];
    // Skip oversized uint64 values gracefully only if caller is skipping a field.
    if (i>7) {
      if (b & 128 || (i===9 && b>1)) {
        if (i===9 || !(b&128)) fail('Invalid uint64 protobuf varint');
      }
      if (!(b&128)) return null; // no number safely representable
      continue;
    }
    value += (b&127)*factor;
    if (!(b&128)) return value;
    factor *= 128;
  }
  fail('Invalid protobuf varint');
}
function walk(data, begin, end, callback) {
  const pos={offset:begin};
  while(pos.offset<end){
    const tag=readVarint(data,pos,end);
    if(!tag || tag>0xffffffff) fail('Invalid protobuf field tag');
    const wire=tag%8, field=Math.floor(tag/8);
    if(!field) fail('Protobuf field number must not be zero');
    let value;
    if (wire===0) value=readVarint(data,pos,end);
    else if (wire===1 || wire===5) {
      const count=wire===1?8:4;
      if(pos.offset+count>end) fail('Truncated fixed-width field');
      value=data.subarray(pos.offset,pos.offset+count);pos.offset+=count;
    } else if(wire===2) {
      const length=readVarint(data,pos,end);
      if(!Number.isSafeInteger(length)||length<0||length>end-pos.offset) fail('Invalid/truncated length-delimited field');
      value=data.subarray(pos.offset,pos.offset+length);pos.offset+=length;
    } else fail('Unsupported protobuf wire type');
    callback(field,wire,value);
  }
  if(pos.offset!==end) fail('Protobuf message boundary exceeded');
}
const u32 = (value) => Number.isSafeInteger(value) && value>=0 && value<=0xffffffff;
function unpackU32(wire, value){
  if(wire===0) return [value];
  if(wire!==2) fail('Packed uint32 field has an invalid wire type');
  const values=[],state={offset:0};
  while(state.offset<value.length){
    const v=readVarint(value,state,value.length);
    if(!u32(v)) fail('Packed uint32 value outside valid range');
    values.push(v);
    if(values.length>1000000) fail('Packed field limit exceeded');
  }
  return values;
}
function parseFeature(data){
  let type=0, tags=[], hasGeometry=false;
  walk(data,0,data.length,(f,w,v)=>{
    if(f===2) tags.push(...unpackU32(w,v));
    else if(f===3 && w===0) type=v;
    else if(f===4){
      if(w!==2 && w!==0) fail('Geometry field has wrong wire type');
      hasGeometry=hasGeometry||(w===0||v.length>0);
    }
  });
  return {type,tags,hasGeometry};
}
function parseLayer(data,maxFeatures){
  const result={name:null,version:null,extent:4096,featureCount:0,
    featureTypes:{point:0,line:0,polygon:0,unknown:0},keys:[],usedKeys:[],issues:[]};
  const keys=[],values=[],features=[];
  walk(data,0,data.length,(f,w,v)=>{
    if(f===1 && w===2){try{result.name=textDecoder.decode(v);}catch{fail('Invalid UTF-8 layer name');}}
    else if(f===2 && w===2){
      if(++result.featureCount>maxFeatures) fail('MVT feature limit exceeded');
      features.push(parseFeature(v));
    } else if(f===3 && w===2){try{keys.push(textDecoder.decode(v));}catch{fail('Invalid UTF-8 attribute key');}}
    else if(f===4 && w===2) values.push(v);
    else if(f===5 && w===0) result.extent=v;
    else if(f===15 && w===0) result.version=v;
  });
  if(!result.name) result.issues.push('missing-layer-name');
  if(result.version===null) result.issues.push('missing-layer-version');
  else if(result.version!==1 && result.version!==2) result.issues.push('unsupported-layer-version');
  if(!Number.isInteger(result.extent)||result.extent<=0) result.issues.push('invalid-layer-extent');
  const seen = new Set();
  for(const f of features){
    if(f.type===1) result.featureTypes.point++;
    else if(f.type===2) result.featureTypes.line++;
    else if(f.type===3) result.featureTypes.polygon++;
    else result.featureTypes.unknown++;
    if(!f.hasGeometry) result.issues.push('missing-feature-geometry');
    if(f.tags.length%2) result.issues.push('odd-feature-tags');
    for(let i=0;i+1<f.tags.length;i+=2){
      const k=f.tags[i],v=f.tags[i+1];
      if(k>=keys.length||v>=values.length) result.issues.push('invalid-attribute-index');
      else seen.add(keys[k]);
    }
  }
  result.issues=[...new Set(result.issues)];
  result.keys=keys; // dictionary keys; may exist without occurrence in sampled features
  result.usedKeys=[...seen];
  return result;
}
/** Metadata only; deliberately no coordinate decoding or feature property values. */
export function inspectMvt(input,{maxBytes=8*1024*1024,maxFeatures=500000,maxLayers=512}={}){
  const data=bytesOf(input);
  if(data.length>maxBytes) fail('MVT exceeds configured byte limit');
  if(data[0]===0x1f&&data[1]===0x8b) fail('Gzip-compressed input: decompress before inspection');
  let layers=[];
  walk(data,0,data.length,(field,wire,value)=>{
    if(field===3 && wire===2){
      if(layers.length>=maxLayers) fail('MVT layer limit exceeded');
      layers.push(parseLayer(value,maxFeatures));
    }
  });
  const names=new Set();
  const issues=[];
  for(const layer of layers){
    if(names.has(layer.name)) issues.push('duplicate-layer-name');
    names.add(layer.name);
  }
  return {format:'mvt',bytes:data.length,layers,issues,scope:'single-tile-sample'};
}

import {readMapSnapshot, IdentityRegistry} from '../core/snapshot.js';
import {analyzeSnapshot, analyzeTileEvents} from '../core/diagnostics.js';
import {createReport} from '../core/report.js';
import {TileEventRecorder} from '../core/events.js';

const TILE_EVENTS = ['tileloadstart', 'tileloadend', 'tileloaderror'];
function listen(target, type, callback) {
  if (typeof target?.on !== 'function') return () => {};
  const key = target.on(type, callback);
  return () => {
    if (typeof target.un === 'function') target.un(type, callback);
    else if (typeof key?.target?.un === 'function') key.target.un(type, callback);
  };
}

/**
 * Attaches only public OpenLayers-like API listeners; no network interception.
 * Returns a controllable, read-only diagnostic session.
 */
export function attachGeoDevTools(map, {maxEvents = 300} = {}) {
  const identities = new IdentityRegistry();
  let disposed = false;
  let observers = new Set();
  let externalUnsubscribers = [];
  let sourceUnsubscribers = new Map();
  let layerUnsubscribers = new Map();
  let snapshot;
  let findings = [];
  let events;
  const publish = () => { if (!disposed) for (const listener of [...observers]) {
    try { listener(); } catch { /* Observers must not break the host map app. */ }
  } };
  events = new TileEventRecorder({maxEvents, notify: () => {updateFindings(); publish();}});

  function updateFindings() {
    findings = [...analyzeSnapshot(snapshot), ...analyzeTileEvents(events.getEvents())];
  }
  function getSources() {
    const sources = new Map();
    for (const layer of map.getAllLayers()) {
      const source = layer?.getSource?.();
      if (source && typeof source.on === 'function' && !sources.has(source)) {
        sources.set(source, identities.id(layer));
      }
    }
    return sources;
  }
  function synchronizeLayers() {
    const current = new Set(map.getAllLayers());
    for (const [layer, unsubscribe] of layerUnsubscribers) {
      if (!current.has(layer)) { unsubscribe(); layerUnsubscribers.delete(layer); }
    }
    for (const layer of current) {
      if (layerUnsubscribers.has(layer)) continue;
      const stop = ['change:source', 'change:visible', 'change:minZoom', 'change:maxZoom']
        .map(type => listen(layer, type, () => refresh()));
      layerUnsubscribers.set(layer, () => stop.forEach(unsubscribe => unsubscribe()));
    }
  }
  function synchronizeSources() {
    const current = getSources();
    for (const [source, unsubscribe] of sourceUnsubscribers) {
      if (!current.has(source)) { unsubscribe(); sourceUnsubscribers.delete(source); }
    }
    for (const [source, layerId] of current) {
      if (sourceUnsubscribers.has(source)) continue;
      const stop = TILE_EVENTS.map(type => listen(source, type, e => {
        if (disposed) return;
        events.record(type, layerId, e?.tile);
      }));
      sourceUnsubscribers.set(source, () => stop.forEach(unsubscribe => unsubscribe()));
    }
  }
  function refresh() {
    if (disposed) throw new Error('Geo DevTools session has been disposed');
    snapshot = readMapSnapshot(map, identities);
    synchronizeLayers();
    synchronizeSources();
    updateFindings();
    publish();
    return getState();
  }
  function getState() {
    // JSON values only. Avoid callers mutating internal state.
    return structuredClone({snapshot, findings, events: events.getEvents()});
  }
  function exportReport(options = {}) {
    return createReport(snapshot, findings, events.getEvents(), options);
  }
  function subscribe(callback) {
    if (disposed) throw new Error('Geo DevTools session has been disposed');
    observers.add(callback);
    return () => observers.delete(callback);
  }
  function dispose() {
    if (disposed) return;
    disposed = true;
    for (const unsubscribe of externalUnsubscribers) unsubscribe();
    for (const unsubscribe of sourceUnsubscribers.values()) unsubscribe();
    for (const unsubscribe of layerUnsubscribers.values()) unsubscribe();
    externalUnsubscribers = [];
    sourceUnsubscribers.clear();
    layerUnsubscribers.clear();
    observers.clear();
  }
  // Re-snapshot on changes; moveend avoids deep work during each animation frame.
  externalUnsubscribers.push(listen(map, 'moveend', () => refresh()));
  externalUnsubscribers.push(listen(map, 'change:view', () => refresh()));
  externalUnsubscribers.push(listen(map, 'change:layerGroup', () => refresh()));
  const rootLayers = map?.getLayerGroup?.()?.getLayers?.() ?? map?.getLayers?.();
  externalUnsubscribers.push(listen(rootLayers, 'add', () => refresh()));
  externalUnsubscribers.push(listen(rootLayers, 'remove', () => refresh()));
  refresh();
  return {refresh, getState, exportReport, subscribe, dispose};
}

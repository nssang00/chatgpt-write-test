const styling = `
  :host {all:initial; font-family:system-ui,-apple-system,sans-serif; color:#e9eff5;
    position:fixed; right:16px; bottom:16px; z-index:2147483640; font-size:13px;}
  * {box-sizing:border-box;} .panel {width:min(440px,calc(100vw - 32px)); max-height:min(590px,calc(100vh - 32px));
    overflow:hidden; display:flex; flex-direction:column; background:#17222d; border:1px solid #384a5c;
    border-radius:12px; box-shadow:0 16px 40px #0009;} .header{display:flex;justify-content:space-between;
    align-items:center;padding:13px 14px;background:#223141;} .heading{font-weight:700;font-size:14px;}
  .controls {display:flex;gap:5px;} button{cursor:pointer;color:#e9eff5;background:#314456;
    border:1px solid #4b6071;border-radius:6px;padding:6px 9px;font:inherit;}
  button:hover{background:#3b556c;} button:focus-visible{outline:2px solid #76c3fa;}
  .tabs{display:flex;border-bottom:1px solid #384a5c;gap:0;} .tabs button{flex:1;border:0;border-radius:0;background:none;}
  .tabs button[aria-selected="true"]{background:#34495b;color:#fff;border-bottom:2px solid #73b4ef;}
  .body{overflow-y:auto;padding:12px;min-height:135px;} .issue{padding:10px 0;border-bottom:1px solid #364656;}
  .issue:last-child{border:0;} .issue .title{font-weight:650;margin:0 0 4px;} .meta{font-size:11px;color:#abc1cf;margin-top:3px;}
  .label{color:#a6dfc7;} .error{color:#ff8585;} .warning{color:#ffd28a;}.info{color:#9ac7ef;}
  .kv{display:flex;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:1px solid #334658;}
  .kv span:last-child{max-width:65%;text-align:right;overflow-wrap:anywhere;}
  .empty{color:#a9bdca;padding:16px 4px;} .footer{display:flex;justify-content:space-between;align-items:center;
    border-top:1px solid #384a5c;padding:9px 12px;color:#b8c9d6;font-size:11px;}
  .hide{display:none;}
`;
function el(tag, className, text) {
  const n = document.createElement(tag);
  if (className) n.className = className;
  if (text != null) n.textContent = String(text);
  return n;
}
function row(name, value) {
  const r = el('div','kv');r.append(el('span','',name),el('span','',value == null ? 'unknown' : String(value)));
  return r;
}
/** Attaches an optional Shadow-DOM diagnostic panel. Never reads network response bodies. */
export function createGeoDevToolsPanel(session, {mount = document.body} = {}) {
  if (!mount) throw new TypeError('Missing mount element');
  const host = el('div');host.setAttribute('data-geo-devtools','');mount.append(host);
  const shadow = host.attachShadow({mode:'open'});
  const style = el('style');style.textContent = styling;shadow.append(style);
  const panel = el('section','panel');shadow.append(panel);
  const header = el('div','header');
  header.append(el('span','heading','Geo DevTools · v0.2'));
  const actions = el('div','controls');
  const refreshButton=el('button','', 'Refresh');
  refreshButton.onclick = () => session.refresh();
  const exportButton=el('button','','Export JSON');
  exportButton.title='Default export excludes map center, layer labels, coordinates, and tile IDs';
  exportButton.onclick=()=>{
    const payload=JSON.stringify(session.exportReport(),null,2);
    const url=URL.createObjectURL(new Blob([payload],{type:'application/json'}));
    const anchor=document.createElement('a');anchor.href=url;anchor.download='geo-devtools-report.json';
    anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
  const closeButton=el('button','','×');closeButton.setAttribute('aria-label','Close Geo DevTools panel');
  actions.append(refreshButton,exportButton,closeButton);header.append(actions);panel.append(header);
  const tabbar=el('div','tabs');tabbar.setAttribute('role','tablist');panel.append(tabbar);
  const body=el('div','body');panel.append(body);
  const footer=el('div','footer');panel.append(footer);
  const tabs=['Issues','Layers','Tiles'];let selected='Issues';
  function show() {
    const state=session.getState();body.replaceChildren();tabbar.replaceChildren();
    for(const tab of tabs){
      const b=el('button','',tab);b.setAttribute('role','tab');b.setAttribute('aria-selected',String(selected===tab));
      b.onclick=()=>{selected=tab;show();};tabbar.append(b);
    }
    if(selected==='Issues'){
      if(!state.findings.length) body.append(el('div','empty','No findings in the current snapshot. This does not guarantee the map is correct.'));
      for(const item of state.findings){
        const issue=el('div','issue');issue.append(el('div',`title ${item.severity}`,`${item.severity.toUpperCase()} · ${item.title}`));
        issue.append(el('div','meta',`Rule: ${item.rule} · Layer: ${item.layerId??'map'} · ${item.confidence} confidence`));
        issue.append(el('div','',item.suggestion));body.append(issue);
      }
    } else if(selected==='Layers'){
      body.append(row('View projection',state.snapshot.view.projection));
      body.append(row('View zoom',state.snapshot.view.zoom));
      for(const layer of state.snapshot.layers){
        const section=el('div','issue');section.append(el('div','title',`${layer.id}${layer.label ? ` — ${layer.label}` : ''}`));
        section.append(row('Visible',layer.visible));section.append(row('Source projection',layer.source?.projection));
        section.append(row('Source state',layer.source?.state));
        section.append(row('Grid resolutions',layer.source?.tileGrid?.resolutions?.length));body.append(section);
      }
    } else {
      if(!state.events.length) body.append(el('div','empty','No tile events yet. Move or zoom the map to load more tiles.'));
      for(const e of [...state.events].reverse().slice(0,75)) {
        body.append(row(`${e.layerId} · ${e.phase}`,`${e.tileCoord?.join('/')??'unknown tile'} · ${e.durationMs??'-'} ms`));
      }
    }
    footer.replaceChildren(el('span','',`${state.snapshot.layers.length} layers · ${state.findings.length} findings · ${state.events.length} tile events`),
      el('span','', 'Local only · read-only'));
  }
  const unsubscribe=session.subscribe(show);
  let disposed=false;
  function dispose() {if(disposed)return;disposed=true;unsubscribe();host.remove();}
  closeButton.onclick=dispose;
  show();
  return {dispose, element:host};
}

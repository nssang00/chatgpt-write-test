/** Geo Doctor basic, zero-source-modification diagnostics.
 * Public data collection contract: request host/status/classification only.
 * No URL query/credentials/bodies/console messages; runtime inspection is opt-in separately.
 */
const tilePath = /\/\d{1,2}\/\d+\/\d+(?:\.[^/?#]+)?(?:$|[?#])/i;
const tileWords = /\/(?:tiles?|wmts|wms|mvt|vector-tiles?)(?:\/|$)/i;
const fileSuffix = /\.(?:png|jpe?g|webp|gif)$/i;
export const MAP_SELECTORS = '.ol-viewport,.maplibregl-canvas-container,.mapboxgl-canvas-container,.cesium-widget';

export function safeHost(url) {
  try { return new URL(url).hostname || 'unknown'; } catch { return 'unknown'; }
}
export function category(url, resourceType='', contentType='') {
  let path='';
  try { path = new URL(url).pathname; } catch { return 'other'; }
  const content = contentType.toLowerCase();
  if (content.includes('application/vnd.mapbox-vector-tile') ||
      content.includes('application/x-protobuf') || /\.(?:mvt|pbf)$/i.test(path)) return 'vector-tile';
  if (tilePath.test(path) || tileWords.test(path)) return 'tile';
  if (resourceType === 'image' && fileSuffix.test(path)) return 'image-possibly-tile';
  return 'other';
}
function finding(rule, severity, confidence, count, evidence, explanation) {
  return {rule, severity, confidence, count, evidence, explanation};
}
export function diagnose(events, signals, jsErrors=0, consoleErrors=0) {
  const failures=new Map(), others=new Map(), transport=new Map();
  const add=(group, key, data)=> {const prev=group.get(key); group.set(key,prev?{...prev,count:prev.count+1}:{...data,count:1});};
  for (const event of events) {
    if (event.kind==='response' && event.status>=400) {
      const isTile=['tile','vector-tile','image-possibly-tile'].includes(event.category);
      const group=isTile?failures:others;
      add(group,`${event.status}|${event.category}|${event.host}`,{status:event.status,category:event.category,host:event.host});
    } else if (event.kind==='requestfailed') {
      add(transport,`${event.category}|${event.host}`,{category:event.category,host:event.host});
    }
  }
  const sorted=group=>[...group.values()].sort((a,b)=>a.status-b.status||a.category.localeCompare(b.category)||a.host.localeCompare(b.host));
  const out=[];
  for (const x of sorted(failures)) {
    const confident=x.category==='tile'||x.category==='vector-tile';
    out.push(finding('tile-http-error',confident?'error':'warning',confident?'high':'medium',x.count,
      {http_status:x.status,category:x.category,host:x.host},'A map-like resource returned HTTP failure. Verify URL, authorization and tile coverage.'));
  }
  for (const x of sorted(transport)) out.push(finding('resource-transport-failed','warning','high',x.count,
    {category:x.category,host:x.host},'A request failed before an HTTP response (network, CORS, abort or browser error).'));
  for (const x of sorted(others)) out.push(finding('non-tile-http-error','info','high',x.count,
    {http_status:x.status,category:x.category,host:x.host},'An HTTP request failed, but there is insufficient evidence that it is a map tile.'));
  if (jsErrors) out.push(finding('page-js-error','warning','high',jsErrors,{},'The page raised uncaught JavaScript errors. Message bodies are not collected by default.'));
  if (consoleErrors) out.push(finding('console-error','info','high',consoleErrors,{},'The browser console contains errors; content is withheld by default.'));
  if (!signals.map_elements) out.push(finding('map-not-confirmed','info','low',1,
    {canvas_count:signals.canvas_count||0},'No recognized map container observed. This is not proof that a map is absent.'));
  return out;
}
export async function scan(url, {observeMs=1500,screenshot=null,navigationTimeoutMs=20000}={}) {
  if(!Number.isInteger(observeMs)||observeMs<0||observeMs>30000) throw new Error('observeMs must be between 0 and 30000');
  // Lazy import: pure diagnostics and HTML rendering require no Playwright install.
  const {chromium}=await import('playwright');
  const {mkdir}=await import('node:fs/promises');
  const {dirname}=await import('node:path');
  const browser=await chromium.launch({headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  const events=[],counts={js_errors:0,console_errors:0};
  try {
    const context=await browser.newContext({viewport:{width:1280,height:800}});
    const page=await context.newPage();
    page.on('response', r=>events.push({kind:'response',category:category(r.url(),r.request().resourceType(),r.headers()['content-type']||''),status:r.status(),host:safeHost(r.url())}));
    page.on('requestfailed',r=>events.push({kind:'requestfailed',category:category(r.url(),r.resourceType()),host:safeHost(r.url())}));
    page.on('pageerror',()=>counts.js_errors++);
    page.on('console',msg=>{if(msg.type()==='error')counts.console_errors++;});
    let navigationError=null;
    try {
      await page.goto(url,{waitUntil:'domcontentloaded',timeout:navigationTimeoutMs});
      await page.waitForTimeout(observeMs);
    } catch (err) { navigationError=err.constructor?.name||'NavigationError'; }
    let signals={map_elements:0,canvas_count:0};
    if(!page.isClosed()) {
      try {signals=await page.evaluate(selectors=>({map_elements:document.querySelectorAll(selectors).length,canvas_count:document.querySelectorAll('canvas').length}),MAP_SELECTORS);} catch { /* page navigation may have failed */ }
    }
    if(screenshot) {await mkdir(dirname(screenshot),{recursive:true});await page.screenshot({path:screenshot,fullPage:true});}
    const breakdown={};
    for(const e of events)if(e.kind==='response')breakdown[e.category]=(breakdown[e.category]||0)+1;
    const findings=diagnose(events,signals,counts.js_errors,counts.console_errors);
    if(navigationError) findings.push(finding('page-navigation-failed','error','high',1,
      {exception_type:navigationError},'Browser navigation did not complete.'));
    return {
      schema:'geo-doctor-zero-touch-v0',mode:'basic',source_modified:false,
      checked_at:new Date().toISOString(),target_host:safeHost(url),
      coverage:{network_status:'inspected',page_console_counts:'inspected',map_dom_signals:'heuristic',
        runtime_map_objects:'not_inspected',crs_tilegrid:'not_inspected',mvt_bodies:'not_inspected',style_filters:'not_inspected'},
      observed:{responses:Object.values(breakdown).reduce((a,b)=>a+b,0),response_categories:breakdown,
        page_js_errors:counts.js_errors,console_errors:counts.console_errors,...signals},findings,
      privacy:{request_urls:'not_collected',query_parameters:'not_collected',response_bodies:'not_collected',
        console_messages:'not_collected',screenshot:screenshot?'opt-in':'not_collected'}
    };
  } finally {await browser.close();}
}

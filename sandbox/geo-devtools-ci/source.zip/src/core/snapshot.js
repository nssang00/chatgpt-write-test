/** Safe, public-API-only snapshot helpers. No external dependencies. */
const num = (x) => typeof x === 'number' && Number.isFinite(x) ? x : null;
const numbers = (value, expected) => Array.isArray(value) && value.length === expected
  ? value.map(num) : null;
const attempt = (fn, fallback = null) => {
  try { const result = fn(); return result == null ? fallback : result; }
  catch { return fallback; }
};
const call = (object, method, ...args) => attempt(() => typeof object?.[method] === 'function' ? object[method](...args) : null);

const projectionCode = (projection) => typeof projection === 'string' ? projection
  : call(projection, 'getCode');

/** Only safe IDs generated locally; never exports source URL or arbitrary labels. */
export class IdentityRegistry {
  #ids = new WeakMap();
  #next = 0;
  id(object) {
    if (!object || (typeof object !== 'object' && typeof object !== 'function')) return null;
    if (!this.#ids.has(object)) this.#ids.set(object, `layer-${++this.#next}`);
    return this.#ids.get(object);
  }
}

function captureGrid(grid) {
  if (!grid) return null;
  const resolutionsRaw = call(grid, 'getResolutions');
  const resolutions = Array.isArray(resolutionsRaw) ? resolutionsRaw.slice(0, 64).map(num) : null;
  const minZoom = num(call(grid, 'getMinZoom')) ?? 0;
  const maxZoom = num(call(grid, 'getMaxZoom'));
  const origin = numbers(call(grid, 'getOrigin', minZoom), 2);
  return {
    minZoom, maxZoom, origin,
    extent: numbers(call(grid, 'getExtent'), 4),
    resolutions,
    truncatedResolutions: Array.isArray(resolutionsRaw) && resolutionsRaw.length > 64
  };
}

function captureLayer(layer, registry) {
  const source = call(layer, 'getSource');
  const label = call(layer, 'get', 'title') ?? call(layer, 'get', 'name') ?? null;
  const grid = source && call(source, 'getTileGrid');
  const sourceProjection = source && call(source, 'getProjection');
  return {
    id: registry.id(layer),
    label: typeof label === 'string' ? label.slice(0, 120) : null,
    visible: call(layer, 'getVisible'),
    minZoom: num(call(layer, 'getMinZoom')),
    maxZoom: num(call(layer, 'getMaxZoom')),
    source: source ? {
      state: call(source, 'getState'),
      projection: projectionCode(sourceProjection),
      tileGrid: captureGrid(grid),
      hasTileEvents: typeof source.on === 'function'
    } : null
  };
}

/**
 * Read the current configuration. An absent property is unknown rather than incorrect.
 * No URLs, headers, raw features, authentication or network response bodies are read.
 */
export function readMapSnapshot(map, registry = new IdentityRegistry()) {
  const view = call(map, 'getView');
  const layers = call(map, 'getAllLayers');
  if (!map || !view || !Array.isArray(layers)) {
    throw new TypeError('OpenLayers-compatible map must provide getView() and getAllLayers()');
  }
  return {
    schemaVersion: 1,
    engine: 'openlayers',
    capturedAt: new Date().toISOString(),
    view: {
      projection: projectionCode(call(view, 'getProjection')),
      center: numbers(call(view, 'getCenter'), 2),
      zoom: num(call(view, 'getZoom')),
      resolution: num(call(view, 'getResolution'))
    },
    layers: layers.map((layer) => captureLayer(layer, registry))
  };
}

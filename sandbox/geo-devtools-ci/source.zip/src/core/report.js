const keepKeys = (value, keys) => Object.fromEntries(keys.filter(k => value[k] !== undefined).map(k => [k, value[k]]));

/**
 * Share-safe by default: no layer labels, center, origins, grid extents, tile coords,
 * request URLs or raw feature data. Caller must explicitly opt into detailed data.
 */
export function createReport(snapshot, findings, events, options = {}) {
  const includeSensitive = options.includeSensitive === true;
  const view = includeSensitive ? {...snapshot.view} : keepKeys(snapshot.view, ['projection', 'zoom', 'resolution']);
  const layers = (snapshot.layers ?? []).map(layer => ({
    id: layer.id,
    ...(includeSensitive && layer.label ? {label: layer.label} : {}),
    visible: layer.visible,
    minZoom: layer.minZoom,
    maxZoom: layer.maxZoom,
    source: layer.source ? {
      state: layer.source.state,
      projection: layer.source.projection,
      tileGrid: layer.source.tileGrid ? {
        minZoom: layer.source.tileGrid.minZoom,
        maxZoom: layer.source.tileGrid.maxZoom,
        resolutionCount: layer.source.tileGrid.resolutions?.length ?? null,
        ...(includeSensitive ? {
          origin: layer.source.tileGrid.origin,
          extent: layer.source.tileGrid.extent,
          resolutions: layer.source.tileGrid.resolutions
        } : {})
      } : null
    } : null
  }));
  const safeFindings = findings.map(f => {
    if (includeSensitive) return f;
    // Drop potentially identifiable numeric positions from evidence.
    const evidence = Object.fromEntries(Object.entries(f.evidence ?? {})
      .filter(([k]) => !['origin', 'extent', 'center', 'url', 'coordinates'].includes(k)));
    return {...f, evidence};
  });
  return {
    schemaVersion: 1,
    product: 'geo-devtools-mvp',
    capturedAt: snapshot.capturedAt,
    engine: snapshot.engine,
    privacy: includeSensitive ? 'sensitive-values-opted-in' : 'redacted-default',
    view, layers,
    findings: safeFindings,
    events: events.map(e => includeSensitive ? {...e} : keepKeys(e,
      ['phase', 'layerId', 'durationMs', 'tileState', 'at']))
  };
}

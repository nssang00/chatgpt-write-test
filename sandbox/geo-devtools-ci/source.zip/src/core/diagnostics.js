/** Pure rule engine: findings explain observation, confidence and limitations. */
const finding = (id, layerId, severity, confidence, title, evidence, suggestion, limitations = []) => ({
  id: `${layerId ?? 'map'}:${id}`,
  rule: id,
  layerId,
  severity,
  confidence,
  title,
  evidence,
  suggestion,
  limitations
});
const validPair = (items) => Array.isArray(items) && items.length === 2 && items.every(Number.isFinite);
const validBox = (items) => Array.isArray(items) && items.length === 4 && items.every(Number.isFinite) &&
  items[0] < items[2] && items[1] < items[3];

/** @returns {Array<object>} evidence-based findings. No automatically inferred 'correct CRS'. */
export function analyzeSnapshot(snapshot) {
  const results = [];
  const zoom = snapshot.view?.zoom;
  const viewProjection = snapshot.view?.projection;
  if (!viewProjection) results.push(finding('view-projection-unknown', null, 'info', 'high',
    '지도 View 좌표계를 확인하지 못했습니다.', {}, '엔진의 View 설정을 확인하세요.'));
  for (const layer of snapshot.layers ?? []) {
    const lid = layer.id;
    if (!layer.source) {
      results.push(finding('source-missing', lid, 'warning', 'high',
        '레이어에 Source가 연결되어 있지 않습니다.', {}, '레이어의 getSource() 결과와 초기화 순서를 확인하세요.'));
      continue;
    }
    const source = layer.source;
    if (source.state === 'error') results.push(finding('source-error', lid, 'error', 'high',
      'Source 상태가 error입니다.', {state: 'error'}, '데이터 로더/원격 요청 및 콘솔 메시지를 확인하세요.'));
    if (layer.visible === false) results.push(finding('layer-hidden', lid, 'info', 'high',
      '레이어가 숨김 상태입니다.', {visible: false}, '의도하지 않은 경우 setVisible(true) 설정을 확인하세요.'));
    if (Number.isFinite(zoom)) {
      if (Number.isFinite(layer.minZoom) && zoom < layer.minZoom) {
        results.push(finding('below-min-zoom', lid, 'info', 'high',
          '현재 확대 수준에서 레이어가 표시되지 않을 수 있습니다.',
          {viewZoom: zoom, minZoomInclusive: layer.minZoom}, 'OpenLayers Layer의 minZoom 조건(하한 포함)을 확인하세요.'));
      }
      if (Number.isFinite(layer.maxZoom) && zoom >= layer.maxZoom) {
        results.push(finding('above-max-zoom', lid, 'info', 'high',
          '현재 확대 수준에서 레이어가 표시되지 않을 수 있습니다.',
          {viewZoom: zoom, maxZoomExclusive: layer.maxZoom}, 'OpenLayers Layer의 maxZoom 조건(상한 제외)을 확인하세요.'));
      }
    }
    // Projection mismatch alone is normal in a reprojection-capable GIS engine.
    if (source.projection && viewProjection && source.projection !== viewProjection) {
      results.push(finding('projection-difference', lid, 'info', 'low',
        'View와 Source의 좌표계가 서로 다릅니다(정상일 수 있음).',
        {viewProjection, sourceProjection: source.projection},
        'OpenLayers가 지원하는 재투영인지, 사용자 정의 transform 또는 타일 그리드가 필요한지 확인하세요.',
        ['CRS 문자열 차이만으로는 오류를 판정할 수 없습니다.']));
    }
    const grid = source.tileGrid;
    if (!grid) continue;
    if (grid.origin && !validPair(grid.origin)) {
      results.push(finding('invalid-grid-origin', lid, 'warning', 'high',
        'TileGrid 원점에 유효하지 않은 좌표가 포함됩니다.', {origin: grid.origin},
        '유한한 수치의 [x, y] 원점을 지정하세요.'));
    }
    if (grid.extent && !validBox(grid.extent)) {
      results.push(finding('invalid-grid-extent', lid, 'warning', 'high',
        'TileGrid extent의 수치 또는 축 범위가 유효하지 않습니다.', {extent: grid.extent},
        '[minX, minY, maxX, maxY] 순서를 확인하세요.'));
    }
    if (grid.resolutions) {
      const badIndices = [];
      for (let i = 0; i < grid.resolutions.length; i++) {
        const v = grid.resolutions[i];
        if (!Number.isFinite(v) || v <= 0 || (i > 0 && v >= grid.resolutions[i - 1])) badIndices.push(i);
      }
      if (badIndices.length) results.push(finding('invalid-grid-resolutions', lid, 'warning', 'high',
        'TileGrid 해상도 배열에 잘못되거나 증가하는 값이 있습니다.',
        {badIndices, resolutionCount: grid.resolutions.length},
        '해상도는 유한한 양수여야 하며 상위 zoom으로 갈수록 감소해야 합니다.'));
    }
  }
  return results;
}

/** Event-derived errors are separate from metadata findings. */
export function analyzeTileEvents(events = []) {
  const errors = events.filter(e => e.phase === 'error');
  if (!errors.length) return [];
  const perLayer = new Map();
  for (const e of errors) perLayer.set(e.layerId, (perLayer.get(e.layerId) ?? 0) + 1);
  return [...perLayer].map(([layerId, count]) => finding('tile-load-errors', layerId, 'warning', 'high',
    '일부 타일에서 명시적인 로딩 오류가 발생했습니다.',
    {errorEvents: count}, '오류 타일의 z/x/y 및 원본 로더 로그를 확인하세요.',
    ['공개 타일 이벤트만으로 HTTP 상태 코드는 알 수 없습니다.']));
}

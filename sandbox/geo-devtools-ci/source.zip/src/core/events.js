/** OpenLayers TileState: 0 IDLE, 1 LOADING, 2 LOADED, 3 ERROR, 4 EMPTY. */
function getState(tile) {
  try { return typeof tile?.getState === 'function' ? tile.getState() : null; }
  catch { return null; }
}
function getTileCoord(tile) {
  try {
    const coord = typeof tile?.getTileCoord === 'function' ? tile.getTileCoord() : tile?.tileCoord;
    return Array.isArray(coord) && coord.length === 3 && coord.every(Number.isFinite) ? [...coord] : null;
  } catch { return null; }
}
export class TileEventRecorder {
  #starts = new WeakMap();
  #events = [];
  #max;
  #notify;
  constructor({maxEvents = 300, notify = () => {}} = {}) {
    this.#max = Math.max(1, Math.floor(maxEvents));
    this.#notify = notify;
  }
  record(kind, layerId, tile, time = performance.now()) {
    if (!tile || (typeof tile !== 'object' && typeof tile !== 'function')) return;
    if (kind === 'tileloadstart') this.#starts.set(tile, time);
    const start = this.#starts.get(tile);
    const state = getState(tile);
    const phase = kind === 'tileloadstart' ? 'start' :
      kind === 'tileloaderror' ? 'error' : state === 2 ? 'loaded' :
      state === 0 ? 'aborted-or-idle' : state === 4 ? 'empty' : 'ended-unknown';
    if (kind !== 'tileloadstart') this.#starts.delete(tile);
    const event = {
      phase, layerId,
      at: Math.round(time),
      durationMs: start === undefined || kind === 'tileloadstart' ? null : Math.max(0, Math.round(time - start)),
      tileState: state,
      tileCoord: getTileCoord(tile)
    };
    this.#events.push(event);
    if (this.#events.length > this.#max) this.#events.shift();
    this.#notify();
    return event;
  }
  getEvents() { return this.#events.map(e => ({...e, tileCoord: e.tileCoord?.slice() ?? null})); }
  clear() { this.#events = []; this.#starts = new WeakMap(); this.#notify(); }
}

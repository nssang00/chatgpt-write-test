// Example for an existing app with `ol` installed separately.
// This file is a usage reference, not run by the dependency-free test suite.
import Map from 'ol/Map.js';
import View from 'ol/View.js';
import TileLayer from 'ol/layer/Tile.js';
import XYZ from 'ol/source/XYZ.js';
import {attachGeoDevTools, createGeoDevToolsPanel} from '../src/index.js';

const map = new Map({
  target: 'map',
  layers: [new TileLayer({source: new XYZ({url: '/tiles/{z}/{x}/{y}.png'})})],
  view: new View({center: [0, 0], zoom: 2})
});

if (import.meta.env?.DEV ?? true) {
  const session = attachGeoDevTools(map);
  const panel = createGeoDevToolsPanel(session);
  // Example cleanup when hot reloading, routing, or unmounting:
  window.addEventListener('beforeunload', () => {panel.dispose(); session.dispose();},{once:true});
}

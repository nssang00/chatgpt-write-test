import {createServer} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
const root=resolve(import.meta.dirname,'../..');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};
const port=Number(process.env.PORT ?? 4173);
createServer(async(req,res)=>{
  try {
    const url=new URL(req.url,'http://localhost');
    let requested=url.pathname==='/' ? '/examples/demo/index.html' : url.pathname;
    const full=resolve(root,`.${requested}`);
    if(full!==root && !full.startsWith(root+sep)){res.writeHead(403);res.end('Forbidden');return;}
    if(!(await stat(full)).isFile())throw Error('Not a file');
    const data=await readFile(full);
    res.writeHead(200,{'Content-Type':mime[extname(full)]??'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    res.end(data);
  }catch {res.writeHead(404);res.end('Not found');}
}).listen(port,()=>process.stdout.write(`Geo DevTools demo: http://localhost:${port}\n`));

import {attachGeoDevTools,createGeoDevToolsPanel} from '../../src/index.js';
class Emitter {
  listeners=new Map();
  on(type,fn){if(!this.listeners.has(type))this.listeners.set(type,new Set());this.listeners.get(type).add(fn);}
  un(type,fn){this.listeners.get(type)?.delete(fn);}
  emit(type,event={}){for(const fn of this.listeners.get(type)??[])fn(event);}
}
class Source extends Emitter {
  state='ready';projection='EPSG:3857';
  grid={getOrigin:()=>[0,100],getExtent:()=>[0,0,100,100],getMinZoom:()=>0,getMaxZoom:()=>3,getResolutions:()=>[8,4,2,1]};
  getState(){return this.state;}
  getProjection(){return {getCode:()=>this.projection};}
  getTileGrid(){return this.grid;}
}
const source=new Source();
const layer={visible:true,getSource:()=>source,getVisible(){return this.visible;},getMinZoom:()=>-Infinity,getMaxZoom:()=>Infinity,get:(key)=>key==='title'?'Demo buildings':null};
const view={getProjection:()=>({getCode:()=> 'EPSG:3857'}),getCenter:()=>[127.0,37.5],getZoom:()=>2,getResolution:()=>2};
const mapEvents=new Emitter(),collection=new Emitter();
const map={on:mapEvents.on.bind(mapEvents),un:mapEvents.un.bind(mapEvents),getAllLayers:()=>[layer],
  getView:()=>view,getLayerGroup:()=>({getLayers:()=>collection})};
const session=attachGeoDevTools(map);
createGeoDevToolsPanel(session);
const status=document.getElementById('status');
function reset(){source.projection='EPSG:3857';source.grid.getResolutions=()=>[8,4,2,1];layer.visible=true;session.refresh();}
function setStatus(text){status.textContent=text;}
document.getElementById('healthy').onclick=()=>{reset();setStatus('정상 설정. 과거 타일 오류 기록은 계속 남아 있습니다.');};
document.getElementById('broken-grid').onclick=()=>{reset();source.grid.getResolutions=()=>[8,8,-1,1];session.refresh();setStatus('TileGrid 해상도 배열을 고의로 잘못 설정했습니다.');};
document.getElementById('different-crs').onclick=()=>{reset();source.projection='EPSG:4326';session.refresh();setStatus('서로 다른 CRS는 자동 오류로 처리하지 않습니다.');};
document.getElementById('tile-failure').onclick=()=>{
  source.emit('tileloadstart',{tile:{getState:()=>1,getTileCoord:()=>[7,101,48]}});
  source.emit('tileloaderror',{tile:{getState:()=>3,getTileCoord:()=>[7,101,48]}});
  setStatus('고의적인 타일 로딩 오류를 발생시켰습니다.');
};
document.getElementById('hide-layer').onclick=()=>{reset();layer.visible=false;session.refresh();setStatus('레이어를 숨김 상태로 변경했습니다.');};
setStatus('데모 준비 완료. 오른쪽 아래 진단 패널을 사용하세요.');
window.__geoDevtoolsSmoke={ready:true,session};

# Geo DevTools MVP v0.2

> **Product direction (2026-10-12): Zero-change default / optional deep diagnostics.**
> Run a basic browser/network diagnosis without modifying the target OpenLayers project.
> See [Zero-touch strategy](docs/ZERO_TOUCH_STRATEGY.md).
> The runtime adapter remains an *optional* precision mode, not the entry requirement.

### Zero-change basic scanner (experimental)

```bash
python -m pip install playwright==1.57.0
python -m playwright install chromium
python scripts/geo_doctor_scan.py http://localhost:5173 --output geo-doctor.json
```

This creates a sanitized JSON report and companion HTML report without injecting code into the application.
Browser screenshots are **opt-in** via `--screenshot file.png`.
Basic mode cannot inspect hidden JS map objects or prove CRS/TileGrid correctness; the report explicitly marks these as `not_inspected`.

> **Experimental open-source prototype, not a production-ready GIS diagnostic platform.**
> 2026-10-12: 49 tests passed, 1 optional OpenLayers integration test skipped, 0 failed.
> The core's mock OpenLayers integration passed; real `ol` dependency / real browser integration has **not** been confirmed in this environment.

A local-first, read-only toolkit for OpenLayers-compatible map diagnostics and MVT / MapLibre style sample inspection.

## What works today

### OpenLayers-compatible runtime diagnostics (v0.1 + fixes)

- Read view projection / zoom / resolution, flat layer structure, source state and available TileGrid metadata.
- Inspect source `tileloadstart` / `tileloadend` / `tileloaderror` events without network interception.
- Rule-based findings: missing source, hidden layer, source error, invalid TileGrid metadata, min/max zoom visibility, projection differences treated as *informational* only.
- Correct OpenLayers zoom visibility boundary: **`minZoom` inclusive, `maxZoom` exclusive** (corrected in v0.2).
- Local Shadow DOM panel (Issues, Layers, Tiles), JSON report, listener cleanup.

### New: MVT metadata and MapLibre-style sample inspector

- Read an **uncompressed** Mapbox Vector Tile `.mvt` / `.pbf` file (this is **not** an OpenStreetMap PBF parser).
- Inspect layer names, MVT version and extent, feature counts/types, dictionary keys, actually used keys, malformed tag indices.
- Support packed and unpacked protobuf numeric fields (independently verified with a `google.protobuf` generated fixture).
- Compare one or more MVT tile summaries against **MapLibre / Mapbox GL Style JSON** `source-layer` and `['get',property]` / `['has',property]` references.
- Findings about absence in **one tile sample** are `info` with low confidence, never a dataset-wide error.
- No geometry coordinate extraction or raw feature attribute-value extraction; local CLI does print layer/attribute keys.
- Input byte/feature/layer limits; malformed protobuf rejected.

## Quick start — no installation needed

Requires Node.js >=20.

```bash
npm test                     # 50 tests: 49 pass, 1 optional skip in this environment
npm run demo                 # http://localhost:4173/ (MOCK OpenLayers API)
npm run inspect:fixture      # working sample MVT + MapLibre-style comparison
```

Inspect your **local uncompressed** MVT file:

```bash
node bin/geo-mvt-inspect.js path/to/tile.mvt
node bin/geo-mvt-inspect.js path/to/tile.mvt \
  --style path/to/style.json --source your-source-id
node bin/geo-mvt-inspect.js path/to/tile.mvt --json
```

In code:

```js
import {inspectMvt, compareMvtStyle} from './src/index.js';

const sample = inspectMvt(new Uint8Array(arrayBuffer));
const findings = compareMvtStyle([sample], maplibreStyleObject, {
  sourceId: 'your-vector-source'
});
```

**Important:** current MVT inspection is a separate local file / byte API. It is **not yet** automatically capturing PBF responses from OpenLayers, and MapLibre style JSON is not the same as native OpenLayers style functions.

## Attach to an existing OpenLayers map

```js
import {attachGeoDevTools, createGeoDevToolsPanel} from 'geo-devtools-mvp';

if (import.meta.env.DEV) {
  const session = attachGeoDevTools(map);
  const panel = createGeoDevToolsPanel(session);
  // Component / application teardown:
  // panel.dispose(); session.dispose();
}
```

The import above assumes this local package is installed in your app:

```bash
npm install --save-dev /path/to/geo-devtools-mvp
```

Public APIs only, no automatic page-global map discovery and no mutation of the app's map state. For real OpenLayers, verify API compatibility using the optional integration tests below.

## Tests and validation status

```bash
npm test            # dependency-free Node tests, including optional ol test
npm run test:browser # Chromium DOM smoke on an OL-like fake map (optional)
```

The Chromium smoke **could not be completed in this sandbox**: even Chromium `--dump-dom` against a static data URL timed out. It can be run on a normal local Chromium installation (set `CHROMIUM_BIN` if needed). It is not a real `ol/Map` E2E, even if it passes.

To enable the optional **real OL Source/Layer/View/TileGrid integration tests** in your network-enabled environment:

```bash
npm install --no-save ol
npm test
```

These integration tests use real OpenLayers source, layer, view and tilegrid classes but a thin fake map shell, so the full OpenLayers browser runtime still requires an additional E2E test.

See [test scenarios](docs/TEST_CASES.md), [results](docs/TEST_RESULTS.md), and [plan](docs/PLAN.md).

## Privacy / security

- The runtime panel does **not** capture raw HTTP response bodies or auth tokens.
- `session.exportReport()` redacts map center / layer labels / grid origin / raw tile IDs by default; always review an exported report before sharing.
- `inspectMvt()` returns layer and property **names**, but not property values or coordinates. Do not post the result publicly if schema names are private.
- Do not pass multi-gigabyte or decompression bomb-like files; the default raw protobuf limit is 8 MiB. Gzip-compressed bytes must be decompressed separately before calling it.
- Findings on sampled data are *not* proof that the whole tileset is broken.

## Not implemented yet

- Browser URL-only scanner; hidden JS map auto-discovery; HTTP interception.
- Full real-OpenLayers browser E2E; automatic MVT response sampling.
- OpenLayers-native style expression analysis; MapLibre/Cesium runtime adapters.
- Full geometry validation, polygon topology, on-screen feature positions.
- Precision per-layer GPU timings and source code autofix.
- Published npm package or live hosted demo.

## Project contents

```text
src/core/             snapshot, diagnostics, events, report
src/openlayers/       attach/refresh/subscribe/dispose
src/mvt/              protobuf metadata inspector, style sample comparison
src/ui/               Shadow DOM diagnostic panel
bin/                  local MVT inspector CLI
examples/demo/        OL-like mock browser demo + static server
examples/fixtures/    independent protobuf-generated real-format MVT and style JSON
tests/                Node automated tests, optional OL integration, Chromium DOM smoke
scripts/              Chromium smoke runner
docs/                 development plan, scenarios, execution results
```

MIT licensed prototype. Project name, package name, supported engine versions, long-term API compatibility are not finalized.

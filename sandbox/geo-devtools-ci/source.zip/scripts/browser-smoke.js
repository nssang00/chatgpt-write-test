import {spawn,execFileSync} from 'node:child_process';
import {setTimeout as sleep} from 'node:timers/promises';
const port=42593;
const host=`http://127.0.0.1:${port}`;
const server=spawn(process.execPath,['examples/demo/server.js'],{
  cwd:process.cwd(),env:{...process.env,PORT:String(port)},stdio:'ignore'
});
try {
  let ready=false;
  for(let i=0;i<35;i++){
    try{const r=await fetch(`${host}/tests/browser-smoke.html`);if(r.ok){ready=true;break;}}catch{}
    await sleep(100);
  }
  if(!ready)throw new Error('Demo HTTP server did not start');
  const browser=process.env.CHROMIUM_BIN || 'chromium';
  const output=execFileSync(browser,[
    '--headless','--no-sandbox','--disable-dev-shm-usage','--disable-gpu',
    '--disable-background-networking','--no-first-run','--virtual-time-budget=2500',
    '--dump-dom',`${host}/tests/browser-smoke.html`
  ],{encoding:'utf8',timeout:10000,stdio:['ignore','pipe','ignore']});
  if(!output.includes('GEO_BROWSER_SMOKE_PASS')){
    const match=output.match(/GEO_BROWSER_SMOKE_FAIL[^<]*/);
    throw new Error(match?match[0]:'Browser page did not report completion');
  }
  console.log('Chromium DOM smoke: PASS (real browser DOM, OpenLayers-like fake map)');
} finally {
  server.kill('SIGTERM');
}

#!/usr/bin/env python3
"""Zero-touch browser/network health scan. No imports or changes to target map source.

This scanner does not claim access to hidden map instances, CRS or TileGrid settings.
Browser navigation may trigger application-side effects; only scan trusted test pages.
"""
import argparse
import asyncio
import json
import html
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

TILE_EXT = re.compile(r'\.(?:png|jpe?g|webp|gif|pbf|mvt)(?:$|[?#])', re.I)
TILE_PATH = re.compile(r'/\d{1,2}/\d+/\d+(?:\.[^/?#]+)?(?:$|[?#])', re.I)
TILE_WORDS = re.compile(r'/(?:tiles?|wmts|wms|mvt|vector-tiles?)(?:/|$)', re.I)
MAP_SELECTORS = '.ol-viewport,.maplibregl-canvas-container,.mapboxgl-canvas-container,.cesium-widget'


def category(url, resource_type='', content_type=''):
    path = urlsplit(url).path
    ctype = (content_type or '').lower()
    if ('application/vnd.mapbox-vector-tile' in ctype or
            'application/x-protobuf' in ctype or
            re.search(r'\.(?:mvt|pbf)$', path, re.I)):
        return 'vector-tile'
    if TILE_PATH.search(path) or TILE_WORDS.search(path):
        return 'tile'
    # A PNG may be an ordinary UI icon: don't claim it is a map tile without other evidence.
    if resource_type == 'image' and TILE_EXT.search(path):
        return 'image-possibly-tile'
    return 'other'


def safe_host(url):
    try:
        parsed = urlsplit(url)
        return parsed.hostname or 'unknown'
    except (ValueError, TypeError):
        return 'unknown'


def finding(rule, severity, confidence, count, evidence, why):
    return dict(rule=rule, severity=severity, confidence=confidence,
                count=count, evidence=evidence, explanation=why)


def diagnose(events, signals, js_errors=0, console_errors=0):
    findings = []
    failures = Counter()
    others = Counter()
    transport = Counter()
    for e in events:
        if e['kind'] == 'response' and e.get('status', 0) >= 400:
            group = failures if e['category'] in ('tile', 'vector-tile', 'image-possibly-tile') else others
            group[(e['status'], e['category'], e['host'])] += 1
        elif e['kind'] == 'requestfailed':
            transport[(e['category'], e['host'])] += 1
    for (status, typ, host), n in sorted(failures.items()):
        severity = 'error' if typ in ('tile', 'vector-tile') else 'warning'
        confidence = 'high' if typ in ('tile', 'vector-tile') else 'medium'
        findings.append(finding('tile-http-error', severity, confidence, n,
                  {'http_status': status, 'category': typ, 'host': host},
                  'A map-like resource returned HTTP failure. Verify URL, authorization and tile coverage.'))
    for (typ, host), n in sorted(transport.items()):
        findings.append(finding('resource-transport-failed', 'warning', 'high', n,
                  {'category': typ, 'host': host},
                  'A request failed before an HTTP response (network, CORS, abort or browser error).'))
    for (status, typ, host), n in sorted(others.items()):
        findings.append(finding('non-tile-http-error', 'info', 'high', n,
                  {'http_status': status, 'category': typ, 'host': host},
                  'An HTTP request failed, but there is insufficient evidence that it is a map tile.'))
    if js_errors:
        findings.append(finding('page-js-error', 'warning', 'high', js_errors, {},
                  'The page raised uncaught JavaScript errors. Message bodies are not collected by default.'))
    if console_errors:
        findings.append(finding('console-error', 'info', 'high', console_errors, {},
                  'The browser console contains errors; content is withheld by default.'))
    if not signals.get('map_elements'):
        findings.append(finding('map-not-confirmed', 'info', 'low', 1,
                  {'canvas_count': signals.get('canvas_count', 0)},
                  'No recognized map container observed. This is not proof that a map is absent.'))
    return findings


async def scan(url, *, observe_ms=1500, screenshot=None, navigation_timeout_ms=20000):
    from playwright.async_api import async_playwright
    events = []
    counts = dict(js_errors=0, console_errors=0)
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
        try:
            context = await browser.new_context(viewport={'width': 1280, 'height': 800})
            page = await context.new_page()
            page.on('response', lambda r: events.append({
                'kind': 'response', 'category': category(r.url, r.request.resource_type,
                    r.headers.get('content-type','')), 'status': r.status, 'host': safe_host(r.url)}))
            page.on('requestfailed', lambda r: events.append({
                'kind': 'requestfailed', 'category': category(r.url, r.resource_type),
                'host': safe_host(r.url)}))
            page.on('pageerror', lambda _: counts.__setitem__('js_errors', counts['js_errors']+1))
            page.on('console', lambda msg: counts.__setitem__('console_errors', counts['console_errors'] + (msg.type == 'error')))
            nav_error = None
            try:
                await page.goto(url, wait_until='domcontentloaded', timeout=navigation_timeout_ms)
                await page.wait_for_timeout(observe_ms)
            except Exception as exc:
                # Avoid leaking potentially sensitive URLs and query strings from Playwright error messages.
                nav_error = type(exc).__name__
            signals = await page.evaluate('''() => ({
              map_elements: document.querySelectorAll('.ol-viewport,.maplibregl-canvas-container,.mapboxgl-canvas-container,.cesium-widget').length,
              canvas_count: document.querySelectorAll('canvas').length
            })''') if not page.is_closed() else {'map_elements': 0, 'canvas_count': 0}
            if screenshot:
                Path(screenshot).parent.mkdir(parents=True, exist_ok=True)
                await page.screenshot(path=str(screenshot), full_page=True)
            breakdown = Counter(e['category'] for e in events if e['kind']=='response')
            findings = diagnose(events, signals, counts['js_errors'], counts['console_errors'])
            if nav_error:
                findings.append(finding('page-navigation-failed', 'error', 'high', 1,
                                        {'exception_type': nav_error}, 'Browser navigation did not complete.'))
            return {
                'schema': 'geo-doctor-zero-touch-v0',
                'mode': 'basic', 'source_modified': False,
                'checked_at': datetime.now(timezone.utc).isoformat(),
                'target_host': safe_host(url),
                'coverage': {
                    'network_status': 'inspected', 'page_console_counts': 'inspected',
                    'map_dom_signals': 'heuristic', 'runtime_map_objects': 'not_inspected',
                    'crs_tilegrid': 'not_inspected', 'mvt_bodies': 'not_inspected',
                    'style_filters': 'not_inspected'
                },
                'observed': {'responses': sum(breakdown.values()),
                             'response_categories': dict(breakdown),
                             'page_js_errors': counts['js_errors'],
                             'console_errors': counts['console_errors'], **signals},
                'findings': findings,
                'privacy': {'request_urls': 'not_collected', 'query_parameters': 'not_collected',
                            'response_bodies': 'not_collected', 'console_messages': 'not_collected',
                            'screenshot': 'opt-in' if screenshot else 'not_collected'},
            }
        finally:
            await browser.close()



def render_html(report):
    """Offline, read-only HTML report. Report contains only sanitized metadata."""
    h = html.escape
    count = len(report['findings'])
    strong = sum(item['severity'] == 'error' for item in report['findings'])
    items = []
    for item in report['findings']:
        evidence = ', '.join(f'{h(str(k))}: {h(str(v))}' for k, v in item['evidence'].items())
        items.append(f'''<article class="finding {h(item['severity'])}">
          <div class="headline"><strong>{h(item['rule'])}</strong><span>{h(item['severity'])} | {h(item['confidence'])} confidence | {item['count']} occurrence(s)</span></div>
          <p>{h(item['explanation'])}</p><small>{evidence}</small></article>''')
    coverage = ''.join(f'<tr><td>{h(k.replace("_"," "))}</td><td>{h(v)}</td></tr>'
                       for k, v in report['coverage'].items())
    cards = '\n'.join(items) or '<p class="quiet">No issue observed during this scan. Not inspected does not mean healthy.</p>'
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8">
    <title>Geo Doctor | Basic scan</title><meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    *{{box-sizing:border-box}}body{{font-family:system-ui,-apple-system,sans-serif;margin:0;background:#eef4f8;color:#19344e}}
    header{{background:#142e46;color:#fff;padding:28px max(24px,calc((100vw - 1050px)/2))}}h1{{margin:0 0 6px;font-size:27px}}
    header p{{margin:4px 0 0;opacity:.76}}main{{max-width:1050px;margin:0 auto;padding:22px}}
    .summary{{display:flex;gap:15px;flex-wrap:wrap;margin-bottom:22px}}.metric{{background:white;padding:20px 24px;border:1px solid #d5e0ea;border-radius:12px;flex:1;min-width:180px}}
    .metric b{{display:block;font-size:25px}}.metric span{{color:#587085;font-size:13px}}
    section{{background:#fff;border:1px solid #d5e0ea;border-radius:12px;padding:18px 20px;margin:18px 0}}
    h2{{font-size:17px;margin:0 0 12px}}.finding{{border:1px solid #dce6ed;border-left:4px solid #8299ab;padding:13px 16px;margin:12px 0;border-radius:7px}}
    .finding.error{{border-left-color:#ce544f}}.finding.warning{{border-left-color:#c98b31}}.finding.info{{border-left-color:#6887a4}}
    .headline{{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}}.headline span,small,.quiet{{color:#5d758a;font-size:13px}}
    p{{line-height:1.6;margin:9px 0}}table{{border-collapse:collapse;width:100%}}td{{padding:9px;border-bottom:1px solid #e7edf1;font-size:14px}}
    tr td:first-child{{text-transform:capitalize}}footer{{padding:10px 0;color:#587085;font-size:12px}}
    </style></head><body><header><h1>Geo Doctor</h1><p>Basic diagnosis | No changes to map source</p></header>
    <main><div class="summary"><div class="metric"><b>{strong}</b><span>High-confidence error finding(s)</span></div>
    <div class="metric"><b>{count}</b><span>Total findings (including informational)</span></div>
    <div class="metric"><b>{report['observed']['responses']}</b><span>HTTP responses observed</span></div></div>
    <section><h2>Findings</h2>{cards}</section>
    <section><h2>Inspection coverage</h2><p class="quiet">An unchecked area is not a pass. Advanced diagnosis requires explicit permission or runtime connection.</p><table>{coverage}</table></section>
    <footer>Target host: {h(report['target_host'])} | Request URLs, query parameters, response bodies and console messages not recorded.</footer>
    </main></body></html>'''

def main():
    parser = argparse.ArgumentParser(description='Geo Doctor zero-touch browser/network scan; no map code changes')
    parser.add_argument('url', help='A URL you have permission to inspect')
    parser.add_argument('--observe-ms', type=int, default=1500, help='Observation time after DOM load, default 1500 ms')
    parser.add_argument('--output', default='geo-doctor-report.json')
    parser.add_argument('--screenshot', help='Optional screenshot (may contain sensitive page data)')
    parser.add_argument('--html', help='Optional HTML report path (local, sanitized)')
    args = parser.parse_args()
    if args.observe_ms < 0 or args.observe_ms > 30000:
        parser.error('--observe-ms must be between 0 and 30000')
    report = asyncio.run(scan(args.url, observe_ms=args.observe_ms, screenshot=args.screenshot))
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    html_path = args.html or str(Path(args.output).with_suffix('.html'))
    Path(html_path).parent.mkdir(parents=True, exist_ok=True)
    Path(html_path).write_text(render_html(report), encoding='utf-8')
    print(json.dumps({'output': args.output, 'html': html_path, 'findings': len(report['findings']),
                      'coverage': report['coverage']}, ensure_ascii=False))

if __name__ == '__main__':
    main()

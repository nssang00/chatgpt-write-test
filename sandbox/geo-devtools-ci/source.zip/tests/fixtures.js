export class Emitter {
  listeners = new Map();
  on(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type).add(callback);
    return {target:this,type,listener:callback};
  }
  un(type, callback) {this.listeners.get(type)?.delete(callback);}
  emit(type, event={}) {for (const cb of this.listeners.get(type) ?? []) cb({type,...event});}
  listenerCount() {return [...this.listeners.values()].reduce((sum,s) => sum+s.size,0);}
}
export class FakeGrid {
  constructor({origin=[0,100],extent=[0,0,100,100],resolutions=[8,4,2,1],minZoom=0}={}) {
    Object.assign(this,{origin,extent,resolutions,minZoom});
  }
  getMinZoom() {return this.minZoom;}
  getMaxZoom() {return this.resolutions.length-1;}
  getOrigin() {return this.origin;}
  getExtent() {return this.extent;}
  getResolutions() {return this.resolutions;}
}
export class FakeSource extends Emitter {
  constructor({state='ready',projection='EPSG:3857',grid=new FakeGrid()}={}) {super();Object.assign(this,{state,projection,grid});}
  getState() {return this.state;}
  getProjection() {return {getCode:()=>this.projection};}
  getTileGrid() {return this.grid;}
}
export class FakeLayer extends Emitter {
  constructor({title='Example',source=new FakeSource(),visible=true,minZoom=-Infinity,maxZoom=Infinity}={}) {
    super();Object.assign(this,{title,source,visible,minZoom,maxZoom});
  }
  getSource() {return this.source;}
  get(key) {if(key==='title') return this.title; return null;}
  getVisible() {return this.visible;}
  getMinZoom() {return this.minZoom;}
  getMaxZoom() {return this.maxZoom;}
}
export class FakeView {
  constructor({projection='EPSG:3857',center=[10,20],zoom=2,resolution=2}={}) {
    Object.assign(this,{projection,center,zoom,resolution});
  }
  getProjection() {return {getCode:()=>this.projection};}
  getCenter() {return this.center;}
  getZoom() {return this.zoom;}
  getResolution() {return this.resolution;}
}
export class FakeMap extends Emitter {
  constructor({layers=[new FakeLayer()],view=new FakeView()}={}) {
    super();this.layers=layers;this.view=view;this.collection=new Emitter();
  }
  getView() {return this.view;}
  getAllLayers() {return this.layers;}
  getLayers() {return this.collection;}
  getLayerGroup() {return {getLayers:()=>this.collection};}
  addLayer(layer) {this.layers.push(layer);this.collection.emit('add',{element:layer});}
  removeLayer(layer) {this.layers=this.layers.filter(x=>x!==layer);this.collection.emit('remove',{element:layer});}
}
export class FakeTile {
  constructor(state=2,coord=[4,8,9]) {this.state=state;this.coord=coord;}
  getState() {return this.state;}
  getTileCoord() {return this.coord;}
}

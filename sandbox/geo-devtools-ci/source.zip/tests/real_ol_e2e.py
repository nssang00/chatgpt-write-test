"""Full *real* OpenLayers/Map browser integration, runnable after `npm install --no-save ol esbuild`
and `npx esbuild tests/real-ol/entry.js --bundle --format=iife --outfile=artifacts/real-ol-browser.js`.
An actual HTTP navigation requires unblocked localhost; scheduled for isolated GitHub Actions runner.
"""
import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts'/'real-ol'

async def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if not (ROOT/'artifacts/real-ol-browser.js').is_file():
        raise RuntimeError('Bundle missing: build with esbuild before running real OpenLayers E2E')
    port='47681'
    server=subprocess.Popen(['node', 'examples/demo/server.js'],cwd=ROOT,
                           env={**os.environ,'PORT':port}, stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    try:
        async with async_playwright() as p:
            browser=await p.chromium.launch(headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
            ctx=await browser.new_context(viewport={'width':1440,'height':900},device_scale_factor=1)
            await ctx.tracing.start(screenshots=True,snapshots=True)
            page=await ctx.new_page()
            errors=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            try:
                await page.goto(f'http://127.0.0.1:{port}/tests/real-ol/index.html',wait_until='domcontentloaded',timeout=25000)
                await page.wait_for_function("document.querySelector('#status')?.textContent?.startsWith('OL_')",timeout=15000)
                stat=await page.locator('#status').inner_text()
                assert stat=='OL_READY',stat
                checks=await page.evaluate('''() => {
                  const v=window.__geoReal;
                  const s=v.session.getState();
                  return {realMap: v.map instanceof v.Map,realSource: v.rasterSource instanceof v.XYZ,
                          projection:s.snapshot.view.projection, layers:s.snapshot.layers.length,
                          panel:!!document.querySelector('[data-geo-devtools]')};
                }''')
                assert checks['realMap'] and checks['realSource'] and checks['panel'],checks
                assert checks['projection']=='EPSG:3857' and checks['layers']==2,checks
                await page.screenshot(path=str(OUT/'01-real-openlayers.png'),full_page=True)
                await page.evaluate('window.__geoReal.raster.setVisible(false)')
                await page.wait_for_function("window.__geoReal.session.getState().findings.some(x=>x.rule==='layer-hidden')")
                assert '숨김 상태' in await page.locator('[data-geo-devtools] .body').inner_text()
                await page.screenshot(path=str(OUT/'02-real-ol-hidden-layer.png'),full_page=True)
                assert not errors,errors
                (OUT/'results.json').write_text(json.dumps({'passed':True,'checks':checks,'errors':errors},indent=2),encoding='utf8')
                print('REAL OL BROWSER E2E: PASS',checks)
            except Exception as e:
                await page.screenshot(path=str(OUT/'failure.png'),full_page=True)
                (OUT/'results.json').write_text(json.dumps({'passed':False,'error':str(e),'page_errors':errors},indent=2),encoding='utf8')
                raise
            finally:
                await ctx.tracing.stop(path=str(OUT/'trace.zip'))
                await browser.close()
    finally:
        server.terminate()
        try: server.wait(timeout=5)
        except subprocess.TimeoutExpired: server.kill()

if __name__=='__main__':
    asyncio.run(main())

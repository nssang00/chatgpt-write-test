/** Real OpenLayers, no attachGeoDevTools import, no application instrumentation. */
import Map from 'ol/Map.js';
import View from 'ol/View.js';
import XYZ from 'ol/source/XYZ.js';
import TileLayer from 'ol/layer/Tile.js';
const args=new URLSearchParams(location.search);
const broken=args.get('mode')==='broken';
const normal='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4//8/AwAI/AL+6X9nAAAAAElFTkSuQmCC';
const url=broken?'/tests/zero-touch/tiles/{z}/{x}/{y}.png?apiKey=DO_NOT_LEAK':normal;
const source=new XYZ({url,crossOrigin:'anonymous'});
const map=new Map({target:'map',layers:[new TileLayer({source})],view:new View({center:[0,0],zoom:4})});
map.renderSync();
document.getElementById('status').textContent='REAL_OL_READY';
window.__realNoAdapter = {map};

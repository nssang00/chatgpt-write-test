/** Optional real OpenLayers integration. `npm install --no-save ol` to enable.
 * Unlike fake API unit tests this imports real ol Source/Layer/View/TileGrid classes.
 * No DOM or browser required because a small map shell supplies getAllLayers/getView.
 * This is still NOT full real ol/Map browser E2E.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {attachGeoDevTools} from '../src/index.js';
import {FakeMap} from './fixtures.js';
let ol;
try {
  const [View, TileLayer, XYZ, TileGrid] = await Promise.all([
    import('ol/View.js'),import('ol/layer/Tile.js'),import('ol/source/XYZ.js'),import('ol/tilegrid/TileGrid.js')
  ]);
  ol={View:View.default,TileLayer:TileLayer.default,XYZ:XYZ.default,TileGrid:TileGrid.default};
} catch(error) {
  if(error.code!=='ERR_MODULE_NOT_FOUND') throw error;
}
if(!ol){
  test('OL-INTEGRATION: skipped: install ol to validate real API', {skip:'ol package not available locally'},()=>{});
} else {
  test('OL-INTEGRATION-01: real OpenLayers Source/Layer/View/TileGrid are snapshot-compatible',()=>{
    const grid=new ol.TileGrid({origin:[-20037508.342789244,20037508.342789244],
      resolutions:[156543.03392804097,78271.51696402048,39135.75848201024],tileSize:256});
    const source=new ol.XYZ({tileGrid:grid,projection:'EPSG:3857',url:'https://invalid.example/{z}/{x}/{y}.png'});
    const layer=new ol.TileLayer({source,minZoom:2,maxZoom:5,properties:{title:'Test'}});
    const view=new ol.View({center:[0,0],projection:'EPSG:3857',zoom:2});
    const shell=new FakeMap({layers:[layer],view});
    const session=attachGeoDevTools(shell);
    assert.equal(session.getState().snapshot.layers[0].source.projection,'EPSG:3857');
    assert.equal(session.getState().snapshot.layers[0].source.tileGrid.resolutions.length,3);
    assert.ok(!session.getState().findings.some(x=>x.rule==='below-min-zoom'));
    view.setZoom(5);
    session.refresh();
    assert.ok(session.getState().findings.some(x=>x.rule==='above-max-zoom'));
    session.dispose();
  });
  test('OL-INTEGRATION-02: real OpenLayers source event subscription is cleaned up',()=>{
    const source=new ol.XYZ({url:'https://invalid.example/{z}/{x}/{y}.png'});
    const layer=new ol.TileLayer({source});
    const view=new ol.View({center:[0,0],zoom:1});
    const session=attachGeoDevTools(new FakeMap({layers:[layer],view}));
    assert.equal(source.hasListener('tileloaderror'),true);
    session.dispose();
    assert.equal(source.hasListener('tileloaderror'),false);
  });
}

import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {chromium} from 'playwright';
import {ROOT,OUTPUT,ensureDir,startServer,stopServer,writeJson} from './util.js';
const OUT=join(OUTPUT,'real-ol');let server,browser,ctx;
try{
  await ensureDir(OUT);await readFile(join(OUTPUT,'real-ol-browser.js'));
  server=await startServer(47681);
  browser=await chromium.launch({headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  ctx=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1});
  await ctx.tracing.start({screenshots:true,snapshots:true});
  const page=await ctx.newPage();const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:47681/tests/real-ol/index.html',{waitUntil:'domcontentloaded',timeout:25000});
  await page.waitForFunction("document.querySelector('#status')?.textContent?.startsWith('OL_')",{timeout:15000});
  assert.equal(await page.locator('#status').innerText(),'OL_READY');
  const checks=await page.evaluate(()=>{
    const v=window.__geoReal;const s=v.session.getState();
    return {realMap:v.map instanceof v.Map,realSource:v.rasterSource instanceof v.XYZ,projection:s.snapshot.view.projection,layers:s.snapshot.layers.length,panel:!!document.querySelector('[data-geo-devtools]')};
  });
  assert.ok(checks.realMap&&checks.realSource&&checks.panel);assert.equal(checks.projection,'EPSG:3857');assert.equal(checks.layers,2);
  await page.screenshot({path:join(OUT,'01-real-openlayers.png'),fullPage:true});
  await page.evaluate(()=>window.__geoReal.raster.setVisible(false));
  await page.waitForFunction("window.__geoReal.session.getState().findings.some(x=>x.rule==='layer-hidden')");
  assert.match(await page.locator('[data-geo-devtools] .body').innerText(),/숨김 상태/);
  await page.screenshot({path:join(OUT,'02-real-ol-hidden-layer.png'),fullPage:true});
  assert.deepEqual(errors,[]);
  await writeJson(join(OUT,'results.json'),{passed:true,runner:'node-playwright',checks,errors});
  console.log('NODE REAL OL BROWSER E2E: PASS',JSON.stringify(checks));
}catch(e){await writeJson(join(OUT,'results.json'),{passed:false,runner:'node-playwright',error:e.message});console.error(e);process.exitCode=1;}
finally{if(ctx){try{await ctx.tracing.stop({path:join(OUT,'trace.zip')});}catch{}}await browser?.close();await stopServer(server);}

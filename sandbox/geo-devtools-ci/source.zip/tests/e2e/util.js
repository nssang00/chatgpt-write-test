import {spawn} from 'node:child_process';
import {setTimeout as sleep} from 'node:timers/promises';
import {mkdir,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
export const ROOT=resolve(fileURLToPath(new URL('../../',import.meta.url)));
export const OUTPUT=join(ROOT,'artifacts');
export async function ensureDir(dir){await mkdir(dir,{recursive:true});}
export async function writeJson(path,obj){await ensureDir(resolve(path,'..'));await writeFile(path,JSON.stringify(obj,null,2),'utf8');}
export async function startServer(port){
  const proc=spawn(process.execPath,['examples/demo/server.js'],{cwd:ROOT,env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
  let output='';proc.stdout.on('data',x=>output+=String(x));proc.stderr.on('data',x=>output+=String(x));
  for(let i=0;i<100;i++){
    if(proc.exitCode!==null)throw Error('demo server exited: '+output.slice(0,800));
    try{const r=await fetch(`http://127.0.0.1:${port}/examples/demo/index.html`);if(r.ok)return proc;}catch{}
    await sleep(100);
  }
  proc.kill();throw Error('demo server did not start: '+output.slice(0,800));
}
export async function stopServer(proc){if(proc && proc.exitCode===null){proc.kill('SIGTERM');await Promise.race([new Promise(r=>proc.once('exit',r)),sleep(2000)]);if(proc.exitCode===null)proc.kill('SIGKILL');}}

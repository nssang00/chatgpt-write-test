/** Browser panel interaction checks; explicit synthetic OL-compatible fixture, not real OL. */
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {chromium} from 'playwright';
import {ROOT,OUTPUT,ensureDir,writeJson} from './util.js';
const OUT=join(OUTPUT,'browser');
const SRC=['src/core/events.js','src/core/snapshot.js','src/core/diagnostics.js','src/core/report.js','src/openlayers/controller.js','src/ui/panel.js','examples/demo/main.js'];
const results=[],pngs=[],errors=[];
let browser,ctx;
async function verify(name, condition,detail=''){results.push({case:name,pass:Boolean(condition),detail});if(!condition)errors.push(`${name}: ${detail}`);}
try{
  await ensureDir(OUT);
  const sources=[];
  for(const path of SRC){
    let src=await readFile(join(ROOT,path),'utf8');
    src=src.replace(/^import .*?;\s*$/gm,'').replace(/^export (?=(?:class|function|const|let)\b)/gm,'');
    if(/^(?:import|export)\b/m.test(src))throw Error(`unexpected module syntax in ${path}`);
    sources.push(`// === ${path} ===\n${src}`);
  }
  const html=(await readFile(join(ROOT,'examples/demo/index.html'),'utf8')).replace(/<script\s+type="module"\s+src="\.\/main\.js"><\/script>/,'');
  browser=await chromium.launch({headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-first-run']});
  ctx=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1});
  await ctx.tracing.start({screenshots:true,snapshots:true});
  const page=await ctx.newPage();
  page.on('pageerror',e=>errors.push('uncaught JS: '+e.message));
  const png=async name=>{await page.screenshot({path:join(OUT,name+'.png'),fullPage:true,animations:'disabled'});pngs.push(name+'.png');};
  await page.setContent(html,{waitUntil:'domcontentloaded'});
  await page.addScriptTag({content:sources.join('\n')});
  await page.waitForFunction('window.__geoDevtoolsSmoke?.ready === true');
  const panel=page.locator('[data-geo-devtools]');const body=panel.locator('.body');
  await verify('BROWSER-01: panel attached',await panel.count()===1);
  await verify('BROWSER-02: healthy has no findings',(await body.innerText()).includes('No findings'));await png('01-healthy');
  await page.locator('#broken-grid').click();
  await verify('BROWSER-03: invalid resolutions',(await body.innerText()).includes('TileGrid 해상도 배열'));await png('02-invalid-grid');
  await page.locator('#different-crs').click();const crs=await body.innerText();
  await verify('BROWSER-04: CRS difference informational',crs.includes('서로 다릅니다')&&!crs.includes('ERROR ·'));await png('03-crs-information');
  await page.locator('#healthy').click();await page.locator('#tile-failure').click();
  const tile=await body.innerText();await verify('BROWSER-05: tile error finding',tile.includes('타일')&&tile.includes('오류'));await png('04-tile-error');
  await panel.getByRole('tab',{name:'Tiles'}).click();const tileList=await body.innerText();
  await verify('BROWSER-06: events contain start and error',tileList.includes('error')&&tileList.includes('start'));await png('05-tile-events');
  await panel.getByRole('tab',{name:'Layers'}).click();
  await verify('BROWSER-07: layer CRS shown',(await body.innerText()).includes('EPSG:3857'));await png('06-layers');
  const privacy=await page.evaluate(()=>{const s=window.__geoDevtoolsSmoke.session,r=s.exportReport();return {privacy:r.privacy,center:r.view.center,anyTileCoords:r.events.some(e=>e.tileCoord),anyLayerLabel:r.layers.some(l=>l.label)};});
  await verify('BROWSER-08: privacy default',privacy.privacy==='redacted-default'&&privacy.center===null&&!privacy.anyTileCoords&&!privacy.anyLayerLabel);
  await page.locator('#hide-layer').click();await panel.getByRole('tab',{name:'Issues'}).click();
  await verify('BROWSER-09: hidden layer',(await body.innerText()).includes('숨김 상태'));await png('07-hidden-layer');
  await panel.getByRole('button',{name:'Close Geo DevTools panel'}).click();
  await verify('BROWSER-10: close removes panel',await panel.count()===0);
  await verify('BROWSER-11: no uncaught JS errors',errors.length===0,errors.join('; '));
}catch(e){errors.push('runner exception: '+e.stack);results.push({case:'runner exception',pass:false,detail:e.message});}
finally{if(ctx)try{await ctx.tracing.stop({path:join(OUT,'trace.zip')});}catch{}await browser?.close();}
const sum={type:'Chromium DOM, synthetic OL-compatible map; Node Playwright',runner:'node-playwright',passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length,total:results.length,results,screenshots:pngs,errors};
await writeJson(join(OUT,'results.json'),sum);
console.log('NODE VISUAL E2E',JSON.stringify({passed:sum.passed,failed:sum.failed,screenshots:pngs,errors}));
if(errors.length)process.exitCode=1;

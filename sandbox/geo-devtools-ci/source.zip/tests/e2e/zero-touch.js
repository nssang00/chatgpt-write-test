import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {chromium} from 'playwright';
import {scan} from '../../src/zero-touch/scanner.js';
import {renderHtml} from '../../src/zero-touch/report.js';
import {ROOT,OUTPUT,ensureDir,startServer,stopServer,writeJson} from './util.js';
const OUT=join(OUTPUT,'zero-touch');
let server;
try{
  await ensureDir(OUT);
  await readFile(join(OUTPUT,'zero-touch-browser.js'));
  server=await startServer(47682);
  const basic='http://127.0.0.1:47682/tests/zero-touch/index.html';
  const healthy=await scan(basic+'?mode=healthy&token=SENSITIVE',{observeMs:900,screenshot:join(OUT,'01-basic-healthy.png')});
  const broken=await scan(basic+'?mode=broken&token=SENSITIVE',{observeMs:1000,screenshot:join(OUT,'02-basic-tile-404.png')});
  assert.ok(healthy.observed.map_elements>=1,JSON.stringify(healthy));
  assert.ok(!healthy.findings.some(f=>f.rule==='tile-http-error'),JSON.stringify(healthy));
  const hit=broken.findings.find(f=>f.rule==='tile-http-error'&&f.evidence.http_status===404);
  assert.ok(hit&&hit.count>0,JSON.stringify(broken));
  assert.equal(broken.coverage.crs_tilegrid,'not_inspected');
  assert.equal(broken.privacy.query_parameters,'not_collected');
  const serial=JSON.stringify({healthy,broken});
  assert.ok(!serial.includes('SENSITIVE')&&!serial.includes('DO_NOT_LEAK'),'secret in report');
  await writeFile(join(OUT,'healthy-report.html'),renderHtml(healthy),'utf8');
  await writeFile(join(OUT,'broken-report.html'),renderHtml(broken),'utf8');
  const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
  try{
    const page=await browser.newPage({viewport:{width:1280,height:900}});
    await page.goto(pathToFileURL(join(OUT,'broken-report.html')).href);
    await page.screenshot({path:join(OUT,'03-basic-diagnosis-report.png'),fullPage:true});
  }finally{await browser.close();}
  await writeJson(join(OUT,'results.json'),{passed:true,runner:'node-playwright',healthy,broken});
  console.log('NODE ZERO-TOUCH REAL OPENLAYERS E2E: PASS',JSON.stringify({http_404_tiles:hit.count,healthy_tile_errors:0,query_redacted:true}));
}catch(e){await writeJson(join(OUT,'results.json'),{passed:false,error:e.message,runner:'node-playwright'});console.error(e);process.exitCode=1;}
finally{await stopServer(server);}

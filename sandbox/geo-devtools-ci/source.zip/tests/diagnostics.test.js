import test from 'node:test';
import assert from 'node:assert/strict';
import {readMapSnapshot} from '../src/core/snapshot.js';
import {analyzeSnapshot,analyzeTileEvents} from '../src/core/diagnostics.js';
import {FakeMap,FakeLayer,FakeSource,FakeGrid,FakeView} from './fixtures.js';
const diagnose=(map)=>analyzeSnapshot(readMapSnapshot(map));

test('TC-07: healthy map has no findings',()=>{
  assert.deepEqual(diagnose(new FakeMap()),[]);
});
test('TC-08: differing source CRS is information, never automatically an error',()=>{
  const source=new FakeSource({projection:'EPSG:4326'});
  const findings=diagnose(new FakeMap({layers:[new FakeLayer({source})]}));
  assert.equal(findings.length,1);
  assert.equal(findings[0].rule,'projection-difference');
  assert.equal(findings[0].severity,'info');
  assert.equal(findings[0].confidence,'low');
});
test('TC-09: source error state is a high-confidence error',()=>{
  const findings=diagnose(new FakeMap({layers:[new FakeLayer({source:new FakeSource({state:'error'})})]}));
  assert.equal(findings.find(x=>x.rule==='source-error')?.severity,'error');
});
test('TC-10: hidden layer yields informational finding',()=>{
  const findings=diagnose(new FakeMap({layers:[new FakeLayer({visible:false})]}));
  assert.equal(findings.find(x=>x.rule==='layer-hidden')?.severity,'info');
});
test('TC-11: detects invalid resolution sequence and grid origin',()=>{
  const source=new FakeSource({grid:new FakeGrid({resolutions:[8,8,-1],origin:[Infinity,5]})});
  const findings=diagnose(new FakeMap({layers:[new FakeLayer({source})]}));
  assert.ok(findings.some(x=>x.rule==='invalid-grid-resolutions'));
  assert.ok(findings.some(x=>x.rule==='invalid-grid-origin'));
});
test('TC-12: nonmonotonic or invalid extent is caught',()=>{
  const source=new FakeSource({grid:new FakeGrid({extent:[100,0,0,100]})});
  assert.ok(diagnose(new FakeMap({layers:[new FakeLayer({source})]})).some(x=>x.rule==='invalid-grid-extent'));
});
test('TC-13: OpenLayers minZoom inclusive / maxZoom exclusive boundaries',()=>{
  const layer=new FakeLayer({minZoom:3,maxZoom:5});
  const map=new FakeMap({view:new FakeView({zoom:3}),layers:[layer]});
  assert.ok(!diagnose(map).some(x=>x.rule==='below-min-zoom')); // inclusive
  map.view.zoom=2.999;
  assert.ok(diagnose(map).some(x=>x.rule==='below-min-zoom'));
  map.view.zoom=4.999;
  assert.ok(!diagnose(map).some(x=>x.rule==='above-max-zoom'));
  map.view.zoom=5;
  assert.ok(diagnose(map).some(x=>x.rule==='above-max-zoom')); // exclusive
});
test('TC-14: multiple tile errors are grouped by layer',()=>{
  const errors=analyzeTileEvents([
    {phase:'error',layerId:'layer-1'},{phase:'error',layerId:'layer-1'},
    {phase:'loaded',layerId:'layer-1'},{phase:'error',layerId:'layer-2'}]);
  assert.equal(errors.length,2);
  assert.equal(errors.find(x=>x.layerId==='layer-1').evidence.errorEvents,2);
});
test('TC-15: source absence is explicitly shown',()=>{
  assert.equal(diagnose(new FakeMap({layers:[new FakeLayer({source:null})]}))[0].rule,'source-missing');
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {readMapSnapshot, IdentityRegistry} from '../src/core/snapshot.js';
import {FakeMap, FakeLayer, FakeSource, FakeGrid, FakeView} from './fixtures.js';

test('TC-01: normal OpenLayers-like map snapshot extracts public configuration',()=>{
  const snap=readMapSnapshot(new FakeMap());
  assert.equal(snap.engine,'openlayers');
  assert.equal(snap.view.projection,'EPSG:3857');
  assert.deepEqual(snap.view.center,[10,20]);
  assert.equal(snap.layers[0].source.tileGrid.resolutions.length,4);
  assert.equal(snap.layers[0].id,'layer-1');
});
test('TC-02: stable layer identifiers across snapshots',()=>{
  const map=new FakeMap();const registry=new IdentityRegistry();
  assert.equal(readMapSnapshot(map,registry).layers[0].id,readMapSnapshot(map,registry).layers[0].id);
});
test('TC-03: snapshot avoids querying source URLs and raw features',()=>{
  const source=new FakeSource();
  source.getUrls=()=>{throw new Error('MUST NOT READ');};
  source.getFeatures=()=>{throw new Error('MUST NOT READ');};
  const result=readMapSnapshot(new FakeMap({layers:[new FakeLayer({source})]}));
  assert.equal(result.layers.length,1);
});
test('TC-04: absent source does not crash snapshot',()=>{
  const snap=readMapSnapshot(new FakeMap({layers:[new FakeLayer({source:null})]}));
  assert.equal(snap.layers[0].source,null);
});
test('TC-05: invalid map produces explicit error',()=>{
  assert.throws(()=>readMapSnapshot({getView:()=>null,getAllLayers:()=>[]}),/getView/);
});
test('TC-06: captures unusual grid values for diagnostics',()=>{
  const grid=new FakeGrid({resolutions:[8,8,2],origin:[Infinity,10]});
  const snap=readMapSnapshot(new FakeMap({view:new FakeView(),layers:[new FakeLayer({source:new FakeSource({grid})})]}));
  assert.deepEqual(snap.layers[0].source.tileGrid.origin,[null,10]);
  assert.deepEqual(snap.layers[0].source.tileGrid.resolutions,[8,8,2]);
});

import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from geo_doctor_scan import category,safe_host,diagnose,render_html
class BasicRules(unittest.TestCase):
 def test_tile_http_404(self):
  f=diagnose([dict(kind='response',category='tile',status=404,host='example.org')],{'map_elements':1})
  self.assertEqual(f[0]['rule'],'tile-http-error')
  self.assertEqual(f[0]['severity'],'error')
 def test_ordinary_svg_404_not_tile(self):
  f=diagnose([dict(kind='response',category='other',status=404,host='example.org')],{'map_elements':1})
  self.assertEqual(f[0]['rule'],'non-tile-http-error')
  self.assertEqual(f[0]['severity'],'info')
 def test_no_map_not_fatal(self):
  f=diagnose([],{'map_elements':0,'canvas_count':0})
  self.assertEqual(f[0]['severity'],'info')
 def test_no_false_positive(self):
  self.assertFalse(diagnose([dict(kind='response',category='tile',status=200,host='example.org')],{'map_elements':1}))
 def test_tile_detection(self):
  self.assertEqual(category('https://geo.example.org/api/tiles/4/8/7.png?key=secret'),'tile')
  self.assertEqual(category('https://geo.example.org/a/4/8/7.pbf'),'vector-tile')
 def test_image_not_assumed_tile(self):
  self.assertEqual(category('https://example.org/logo.png',resource_type='image'),'image-possibly-tile')
 def test_safe_host_only(self):
  self.assertEqual(safe_host('https://u:pwd@example.org/private?api_key=SECRET'),'example.org')
 def test_html_escapes(self):
  report={'findings':[dict(rule='<script>',severity='info',confidence='low',count=1,explanation='safe',evidence={'key':'<b>unsafe</b>'})], 'coverage':{'crs_tilegrid':'not_inspected'},'observed':{'responses':0},'target_host':'localhost'}
  output=render_html(report)
  self.assertNotIn('<script>',output)
  self.assertIn('&lt;script&gt;',output)
if __name__=='__main__':unittest.main()

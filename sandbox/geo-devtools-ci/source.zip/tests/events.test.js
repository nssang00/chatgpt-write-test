import test from 'node:test';
import assert from 'node:assert/strict';
import {TileEventRecorder} from '../src/core/events.js';
import {FakeTile} from './fixtures.js';

test('TC-16: loaded tile records duration and tile coordinate',()=>{
  const recorder=new TileEventRecorder();const tile=new FakeTile(1,[8,121,90]);
  recorder.record('tileloadstart','layer-1',tile,100);
  tile.state=2;
  recorder.record('tileloadend','layer-1',tile,130);
  assert.deepEqual(recorder.getEvents().map(e=>e.phase),['start','loaded']);
  assert.equal(recorder.getEvents()[1].durationMs,30);
  assert.deepEqual(recorder.getEvents()[1].tileCoord,[8,121,90]);
});
test('TC-17: aborted/idle is not falsely treated as successfully loaded',()=>{
  const recorder=new TileEventRecorder();const tile=new FakeTile(0);
  recorder.record('tileloadend','layer-1',tile,160);
  assert.equal(recorder.getEvents()[0].phase,'aborted-or-idle');
});
test('TC-18: unknown completion remains unknown',()=>{
  const recorder=new TileEventRecorder();
  recorder.record('tileloadend','layer-1',new FakeTile(1));
  assert.equal(recorder.getEvents()[0].phase,'ended-unknown');
});
test('TC-19: tile errors are explicit and bounded in memory',()=>{
  const recorder=new TileEventRecorder({maxEvents:2});
  for(let i=0;i<4;i++) recorder.record('tileloaderror','layer-1',new FakeTile(3),i);
  assert.equal(recorder.getEvents().length,2);
  assert.ok(recorder.getEvents().every(e=>e.phase==='error'));
});

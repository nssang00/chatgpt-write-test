import test from 'node:test';
import assert from 'node:assert/strict';
import {inspectMvt,MvtParseError,compareMvtStyle} from '../src/index.js';

const v = value=>{let n=BigInt(value),out=[];do{let x=Number(n&127n);n>>=7n;if(n)x|=128;out.push(x);}while(n);return out;};
const field=(number,wire,content)=>[...v(number*8+wire),...(wire===2?[...v(content.length),...content]:wire===0?v(content):content)];
const string = value=>[...new TextEncoder().encode(value)];
const message=(fields)=>Uint8Array.from(fields.flat());
const key=(value)=>field(3,2,string(value));
const value=(s)=>field(4,2,field(1,2,string(s)));
const feature=(tags=[0,0])=>field(2,2,message([
  field(1,0,1), field(2,2,tags.flatMap(v)),field(3,0,1),field(4,2,[9,0,0])
]));
function tile({name='buildings', keys=['height'], tags=[0,0], extent=4096, version=2, extraLayers=[]}={}){
  const layer=message([field(1,2,string(name)), feature(tags), ...keys.map(key),value('SECRET_ATTRIBUTE_VALUE_NEVER_EXPORT'),field(5,0,extent),field(15,0,version)]);
  return message([field(3,2,layer),...extraLayers.map(m=>field(3,2,m))]);
}
const sample=()=>inspectMvt(tile());

test('MVT-01: valid MVT decodes layer/keys/types, without leaking property values',()=>{
  const result=sample();
  assert.equal(result.format,'mvt');
  assert.equal(result.layers[0].name,'buildings');
  assert.deepEqual(result.layers[0].usedKeys,['height']);
  assert.equal(result.layers[0].featureCount,1);
  assert.equal(result.layers[0].featureTypes.point,1);
  assert.ok(!JSON.stringify(result).includes('SECRET_ATTRIBUTE_VALUE_NEVER_EXPORT'));
});
test('MVT-02: empty tile is permitted without invented errors',()=>{
  assert.deepEqual(inspectMvt(new Uint8Array()).layers,[]);
});
test('MVT-03: invalid protobuf truncation is rejected',()=>{
  assert.throws(()=>inspectMvt(new Uint8Array([0x1a,0x08,0x0a])),MvtParseError);
});
test('MVT-04: gzip input gives actionable failure',()=>{
  assert.throws(()=>inspectMvt(new Uint8Array([0x1f,0x8b,8])),/Gzip-compressed/);
});
test('MVT-05: wire-type and size limits prevent corrupt input abuse',()=>{
  assert.throws(()=>inspectMvt(new Uint8Array([0x0b])),/Unsupported/);
  assert.throws(()=>inspectMvt(tile(),{maxBytes:4}),/byte limit/);
});
test('MVT-06: invalid tag indices and odd tags are diagnosed',()=>{
  const r=inspectMvt(tile({tags:[5,0,0]}));
  assert.ok(r.layers[0].issues.includes('odd-feature-tags'));
  assert.ok(r.layers[0].issues.includes('invalid-attribute-index'));
});
test('MVT-07: unsupported version is a finding, not silently accepted',()=>{
  assert.ok(inspectMvt(tile({version:3})).layers[0].issues.includes('unsupported-layer-version'));
});
test('MVT-08: unknown protobuf fields skipped and DataView accepted',()=>{
  const original=tile(), bytes=message([field(9,0,33),field(3,2,original.slice(2))]);
  const viewed=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  assert.equal(inspectMvt(viewed).layers.length,1);
});
test('MVT-09: style source-layer absent in sample => informational, not error',()=>{
  const result=compareMvtStyle([sample()],{layers:[{id:'a',source:'osm', 'source-layer':'roads'}]},{sourceId:'osm'});
  assert.equal(result[0].rule,'source-layer-not-observed');
  assert.equal(result[0].severity,'info');
});
test('MVT-10: property get found in features => no finding',()=>{
  const style={layers:[{id:'b',source:'osm','source-layer':'buildings',paint:{'fill-opacity':['get','height']}}]};
  assert.deepEqual(compareMvtStyle([sample()],style,{sourceId:'osm'}),[]);
});
test('MVT-11: missing sampled property is info and retains sample caveat',()=>{
  const style={layers:[{id:'b',source:'osm','source-layer':'buildings',paint:{'fill-opacity':['get','floors']}}]};
  const r=compareMvtStyle([sample()],style,{sourceId:'osm'});
  assert.equal(r[0].rule,'style-attributes-not-observed');
  assert.deepEqual(r[0].evidence.unobservedProperties,['floors']);
  assert.ok(r[0].limitations.some(x=>x.includes('검사하지')));
});
test('MVT-12: style from another source never compared',()=>{
  const style={layers:[{id:'b',source:'other','source-layer':'roads'}]};
  assert.deepEqual(compareMvtStyle([sample()],style,{sourceId:'osm'}),[]);
});
test('MVT-13: literal expressions are not falsely counted as get expressions',()=>{
  const style={layers:[{id:'b',source:'osm','source-layer':'buildings',paint:{'fill-color':['literal',['get','missing']]}}]};
  assert.deepEqual(compareMvtStyle([sample()],style,{sourceId:'osm'}),[]);
});
test('MVT-14: invalid input rejected, prevents misleading ' + 'empty analysis',()=>{
  assert.throws(()=>inspectMvt('not a byte array'),TypeError);
  assert.throws(()=>compareMvtStyle([],{}, {sourceId:'x'}),TypeError);
  assert.throws(()=>compareMvtStyle([], {layers:[]},{}),TypeError);
});

test('MVT-15: independent google.protobuf-generated fixture decodes correctly',async()=>{
  const {readFile}=await import('node:fs/promises');
  const {fileURLToPath}=await import('node:url');
  const filepath=fileURLToPath(new URL('../examples/fixtures/buildings.mvt',import.meta.url));
  const result=inspectMvt(await readFile(filepath));
  assert.equal(result.layers[0].name,'buildings');
  assert.equal(result.layers[0].featureCount,1);
  assert.equal(result.layers[0].featureTypes.polygon,1);
  assert.deepEqual(result.layers[0].usedKeys.sort(),['class','height']);
  assert.deepEqual(result.layers[0].issues,[]);
});
test('MVT-16: fixture style identifies missing source layer without rejecting valid attribute',async()=>{
  const {readFile}=await import('node:fs/promises');
  const {fileURLToPath}=await import('node:url');
  const root=new URL('../examples/fixtures/',import.meta.url);
  const mvt=inspectMvt(await readFile(fileURLToPath(new URL('buildings.mvt',root))));
  const style=JSON.parse(await readFile(fileURLToPath(new URL('buildings-style.json',root)),'utf8'));
  const findings=compareMvtStyle([mvt],style,{sourceId:'demo'});
  assert.equal(findings.length,1);
  assert.equal(findings[0].rule,'source-layer-not-observed');
  assert.equal(findings[0].sourceLayer,'roads');
});

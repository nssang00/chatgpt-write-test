/** Real OpenLayers DOM+rendering integration (bundled with esbuild on GitHub Actions). */
import Map from 'ol/Map.js';
import View from 'ol/View.js';
import TileLayer from 'ol/layer/Tile.js';
import XYZ from 'ol/source/XYZ.js';
import VectorLayer from 'ol/layer/Vector.js';
import VectorSource from 'ol/source/Vector.js';
import Feature from 'ol/Feature.js';
import Polygon from 'ol/geom/Polygon.js';
import Style from 'ol/style/Style.js';
import Fill from 'ol/style/Fill.js';
import Stroke from 'ol/style/Stroke.js';
import {attachGeoDevTools, createGeoDevToolsPanel} from '../../src/index.js';

const status = document.querySelector('#status');
try {
  // Local-only data URI; no requests to third-party tile servers.
  const transparentPng = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4//8/AwAI/AL+6X9nAAAAAElFTkSuQmCC';
  const rasterSource = new XYZ({url: transparentPng, crossOrigin: 'anonymous'});
  const raster = new TileLayer({source: rasterSource, properties: {title: 'Raster tiles'}});
  const features = [
    new Feature(new Polygon([[[-630000,-100000],[-180000,-100000],[-180000,350000],[-630000,350000],[-630000,-100000]]])),
    new Feature(new Polygon([[[220000,-410000],[690000,-410000],[690000,100000],[220000,100000],[220000,-410000]]]))
  ];
  const vector = new VectorLayer({
    source: new VectorSource({features}),
    style: new Style({fill: new Fill({color: 'rgba(35,139,121,0.55)'}),stroke:new Stroke({color:'#125e55',width:3})}),
    properties: {title:'Test polygons'},
  });
  const map = new Map({
    target: 'map', layers: [raster, vector],
    view: new View({center:[0,0],zoom:5,projection:'EPSG:3857'}),
  });
  const session = attachGeoDevTools(map);
  const panel = createGeoDevToolsPanel(session);
  window.__geoReal = {Map, XYZ, map, session, panel, raster, rasterSource, vector};
  map.renderSync();
  status.textContent = 'OL_READY';
} catch (err) {
  status.textContent = 'OL_FAILED ' + (err.stack || String(err));
}

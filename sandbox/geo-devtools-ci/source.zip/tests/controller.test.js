import test from 'node:test';
import assert from 'node:assert/strict';
import {attachGeoDevTools} from '../src/openlayers/controller.js';
import {FakeMap,FakeLayer,FakeSource,FakeTile} from './fixtures.js';

test('TC-20: installs tile listeners and refreshes findings',()=>{
  const source=new FakeSource(),map=new FakeMap({layers:[new FakeLayer({source})]});
  const session=attachGeoDevTools(map);let notified=0;
  session.subscribe(()=>notified++);
  source.emit('tileloadstart',{tile:new FakeTile(1)});
  source.emit('tileloaderror',{tile:new FakeTile(3)});
  assert.equal(session.getState().events.length,2);
  assert.equal(session.getState().findings.find(x=>x.rule==='tile-load-errors')?.severity,'warning');
  assert.ok(notified>=2);
  session.dispose();
});
test('TC-21: source listeners are unique when shared by two layers',()=>{
  const source=new FakeSource();
  const session=attachGeoDevTools(new FakeMap({layers:[new FakeLayer({source}),new FakeLayer({source})]}));
  assert.equal(source.listenerCount(),3);
  session.dispose();
  assert.equal(source.listenerCount(),0);
});
test('TC-22: dynamically added and removed layers rewire sources',()=>{
  const map=new FakeMap({layers:[]}),session=attachGeoDevTools(map);
  const source=new FakeSource(),layer=new FakeLayer({source});
  map.addLayer(layer);
  assert.equal(session.getState().snapshot.layers.length,1);
  assert.equal(source.listenerCount(),3);
  map.removeLayer(layer);
  assert.equal(source.listenerCount(),0);
  assert.equal(session.getState().snapshot.layers.length,0);
  session.dispose();
});
test('TC-23: dispose removes listeners and blocks later actions',()=>{
  const map=new FakeMap(),session=attachGeoDevTools(map),source=map.layers[0].source;
  const count=source.listenerCount();assert.ok(count>0);
  session.dispose();session.dispose();
  assert.equal(source.listenerCount(),0);
  assert.equal(map.listenerCount(),0);
  assert.equal(map.collection.listenerCount(),0);
  assert.throws(()=>session.refresh(),/disposed/);
});
test('TC-24: getState is immutable from caller perspective',()=>{
  const session=attachGeoDevTools(new FakeMap());
  const state=session.getState();state.snapshot.layers[0].id='tampered';
  assert.equal(session.getState().snapshot.layers[0].id,'layer-1');
  session.dispose();
});
test('TC-28: source replacement automatically rewires event listeners',()=>{
  const previous=new FakeSource(),layer=new FakeLayer({source:previous});
  const session=attachGeoDevTools(new FakeMap({layers:[layer]}));
  const next=new FakeSource();layer.source=next;layer.emit('change:source');
  assert.equal(previous.listenerCount(),0);
  assert.equal(next.listenerCount(),3);
  session.dispose();
  assert.equal(layer.listenerCount(),0);
});
test('TC-29: a crashing observer cannot affect map event handlers',()=>{
  const map=new FakeMap(),session=attachGeoDevTools(map);
  session.subscribe(()=>{throw new Error('user callback failed');});
  assert.doesNotThrow(()=>map.emit('moveend'));
  session.dispose();
});

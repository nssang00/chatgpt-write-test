import test from 'node:test';
import assert from 'node:assert/strict';
import {attachGeoDevTools} from '../src/openlayers/controller.js';
import {FakeMap,FakeLayer,FakeTile,FakeView} from './fixtures.js';

test('TC-25: safe export excludes labels, map center and tile coordinates',()=>{
  const secret='SECRET_INTERNAL_SITE_X';
  const map=new FakeMap({view:new FakeView({center:[123456.78,87654.32]}),layers:[new FakeLayer({title:secret})]});
  const session=attachGeoDevTools(map);
  map.layers[0].source.emit('tileloaderror',{tile:new FakeTile(3,[20,101010,202020])});
  const report=JSON.stringify(session.exportReport());
  assert.ok(!report.includes(secret));
  assert.ok(!report.includes('123456.78'));
  assert.ok(!report.includes('101010'));
  assert.ok(!report.includes('202020'));
  assert.equal(session.exportReport().privacy,'redacted-default');
  session.dispose();
});
test('TC-26: exporting sensitive data requires explicit opt-in',()=>{
  const map=new FakeMap({layers:[new FakeLayer({title:'PRIVATE_LABEL'})]});
  const session=attachGeoDevTools(map);
  assert.ok(!JSON.stringify(session.exportReport()).includes('PRIVATE_LABEL'));
  assert.ok(JSON.stringify(session.exportReport({includeSensitive:true})).includes('PRIVATE_LABEL'));
  session.dispose();
});
test('TC-27: exports are JSON-serializable',()=>{
  const session=attachGeoDevTools(new FakeMap());
  assert.doesNotThrow(()=>JSON.stringify(session.exportReport()));
  session.dispose();
});

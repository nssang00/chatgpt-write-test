"""Checks zero source modifications with a real OpenLayers map and a local 404 tile fixture."""
import asyncio
import json
import os
import subprocess
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from geo_doctor_scan import scan, render_html
OUT=ROOT/'artifacts'/'zero-touch'

async def main():
    OUT.mkdir(parents=True,exist_ok=True)
    assert (ROOT/'artifacts'/'zero-touch-browser.js').exists(), 'Bundle with esbuild first'
    port='47682'
    server=subprocess.Popen(['node','examples/demo/server.js'],cwd=ROOT,
                            env={**os.environ,'PORT':port},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        # The scanner does not load/attach any Geo DevTools adapter in the target application.
        # No query parameters from the target URL or tile URLs may leak into the JSON report.
        basic=f'http://127.0.0.1:{port}/tests/zero-touch/index.html'
        healthy=await scan(basic+'?mode=healthy&token=SENSITIVE',observe_ms=1000,
                           screenshot=OUT/'01-basic-healthy.png')
        broken=await scan(basic+'?mode=broken&token=SENSITIVE',observe_ms=1200,
                          screenshot=OUT/'02-basic-tile-404.png')
        assert healthy['observed']['map_elements'] >= 1, healthy
        assert not any(x['rule']=='tile-http-error' for x in healthy['findings']),healthy
        hits=[x for x in broken['findings'] if x['rule']=='tile-http-error' and x['evidence']['http_status']==404]
        assert hits and hits[0]['count'] >= 1,broken
        assert broken['coverage']['crs_tilegrid']=='not_inspected'
        assert broken['privacy']['query_parameters']=='not_collected'
        serial=json.dumps({'healthy':healthy,'broken':broken})
        assert 'SENSITIVE' not in serial and 'DO_NOT_LEAK' not in serial, 'Query parameter leaked'
        assert all(x['rule'] != 'tile-http-error' for x in healthy['findings'])
        (OUT/'healthy-report.html').write_text(render_html(healthy),encoding='utf-8')
        (OUT/'broken-report.html').write_text(render_html(broken),encoding='utf-8')
        from playwright.async_api import async_playwright
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=True,args=['--no-sandbox'])
            page = await browser.new_page(viewport={'width':1280,'height':900})
            await page.goto((OUT/'broken-report.html').as_uri())
            await page.screenshot(path=str(OUT/'03-basic-diagnosis-report.png'),full_page=True)
            await browser.close()
        (OUT/'results.json').write_text(json.dumps({'passed':True,'healthy':healthy,'broken':broken},indent=2),encoding='utf-8')
        print('ZERO-TOUCH REAL OPENLAYERS E2E: PASS',{'http_404_tiles':hits[0]['count'],'healthy_tile_errors':0,'query_redacted':True})
    finally:
        server.terminate()
        try:server.wait(timeout=5)
        except subprocess.TimeoutExpired:server.kill()

if __name__=='__main__':asyncio.run(main())

import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync,spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const cli=fileURLToPath(new URL('../bin/geo-mvt-inspect.js',import.meta.url));
const mvt=fileURLToPath(new URL('../examples/fixtures/buildings.mvt',import.meta.url));
const style=fileURLToPath(new URL('../examples/fixtures/buildings-style.json',import.meta.url));
test('CLI-01: inspect fixture with one command',()=>{
  const out=execFileSync(process.execPath,[cli,mvt],{encoding:'utf8'});
  assert.match(out,/buildings: 1 features/);
});
test('CLI-02: compare MapLibre style, structured output without raw feature values',()=>{
  const out=execFileSync(process.execPath,[cli,mvt,'--style',style,'--source','demo','--json'],{encoding:'utf8'});
  const report=JSON.parse(out);
  assert.equal(report.findings[0].rule,'source-layer-not-observed');
  assert.ok(!out.includes('residential'));
});
test('CLI-03: malformed args exit nonzero with diagnostic',()=>{
  const r=spawnSync(process.execPath,[cli,mvt,'--style',style],{encoding:'utf8'});
  assert.equal(r.status,1);
  assert.match(r.stderr,/must be provided together/);
});

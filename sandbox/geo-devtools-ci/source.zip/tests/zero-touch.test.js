import {test} from 'node:test';
import assert from 'node:assert/strict';
import {category,safeHost,diagnose} from '../src/zero-touch/scanner.js';
import {renderHtml} from '../src/zero-touch/report.js';
const signals={map_elements:1,canvas_count:1};
test('BASIC-01: HTTP 404 tile is diagnosed as high-confidence error',()=>{
 const x=diagnose([{kind:'response',category:'tile',status:404,host:'example.org'}],signals);
 assert.equal(x[0].rule,'tile-http-error');assert.equal(x[0].severity,'error');assert.equal(x[0].confidence,'high');
});
test('BASIC-02: UI SVG 404 must not be labeled a tile failure',()=>{
 const x=diagnose([{kind:'response',category:'other',status:404,host:'example.org'}],signals);
 assert.equal(x[0].rule,'non-tile-http-error');assert.equal(x[0].severity,'info');
});
test('BASIC-03: map-not-confirmed is not a fatal diagnosis',()=>{
 const x=diagnose([],{map_elements:0,canvas_count:0});assert.equal(x[0].severity,'info');
});
test('BASIC-04: healthy tile request is not an error',()=>{
 assert.deepEqual(diagnose([{kind:'response',category:'tile',status:200,host:'example.org'}],signals),[]);
});
test('BASIC-05: XYZ and vector tile paths classified correctly',()=>{
 assert.equal(category('https://example.org/api/tiles/4/8/7.png?key=SECRET'),'tile');
 assert.equal(category('https://example.org/a/4/8/7.pbf'),'vector-tile');
});
test('BASIC-06: generic image has weak evidence',()=>{
 assert.equal(category('https://example.org/logo.png','image'),'image-possibly-tile');
});
test('BASIC-07: safeHost excludes credentials, path and query',()=>{
 assert.equal(safeHost('https://u:pwd@example.org/private?api_key=SECRET'),'example.org');
});
test('BASIC-08: reports escape untrusted content',()=>{
 const report={findings:[{rule:'<script>',severity:'info',confidence:'low',count:1,explanation:'safe',evidence:{key:'<b>unsafe</b>'}}],coverage:{crs_tilegrid:'not_inspected'},observed:{responses:0},target_host:'localhost'};
 const html=renderHtml(report);assert.doesNotMatch(html,/<script>/);assert.match(html,/&lt;script&gt;/);
});
test('BASIC-09: multiple identical failures aggregate, statuses stay distinct',()=>{
 const f=diagnose([{kind:'response',status:404,category:'tile',host:'a.test'},{kind:'response',status:404,category:'tile',host:'a.test'},{kind:'response',status:403,category:'tile',host:'a.test'}],signals);
 assert.equal(f.length,2);assert.deepEqual(f.map(x=>x.count).sort(),[1,2]);
});
test('BASIC-10: failure before HTTP response is not confused with HTTP status',()=>{
 const f=diagnose([{kind:'requestfailed',category:'tile',host:'a.test'}],signals);
 assert.equal(f[0].rule,'resource-transport-failed');assert.equal(f[0].evidence.http_status,undefined);
});

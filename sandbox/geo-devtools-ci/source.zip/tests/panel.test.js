import test from 'node:test';
import assert from 'node:assert/strict';
import {attachGeoDevTools} from '../src/openlayers/controller.js';
import {createGeoDevToolsPanel} from '../src/ui/panel.js';
import {FakeMap,FakeLayer,FakeSource} from './fixtures.js';
class FakeNode {
  constructor(tag){this.tag=tag;this.children=[];this.attrs={};this._text='';this.className='';this.onclick=null;}
  set textContent(value){this._text=String(value);this.children=[];}
  get textContent(){return this._text + this.children.map(c=>c.textContent).join('');}
  append(...nodes){this.children.push(...nodes);}
  replaceChildren(...nodes){this.children=[...nodes];this._text='';}
  remove(){this.removed=true;}
  setAttribute(k,v){this.attrs[k]=v;}
  attachShadow(){this.shadowRoot=new FakeNode('shadow');return this.shadowRoot;}
}
function find(node,predicate){if(predicate(node))return node;for(const child of node.children){const matched=find(child,predicate);if(matched)return matched;}return null;}
test('TC-30: panel renders diagnostic issue, switches tabs and cleans up',()=>{
  const original=globalThis.document;
  globalThis.document={body:new FakeNode('body'),createElement:tag=>new FakeNode(tag)};
  try {
    const map=new FakeMap({layers:[new FakeLayer({source:new FakeSource({state:'error'})})]});
    const session=attachGeoDevTools(map);
    const panel=createGeoDevToolsPanel(session);
    assert.ok(panel.element.shadowRoot.textContent.includes('Source 상태가 error'));
    const tiles=find(panel.element.shadowRoot,n=>n.tag==='button'&&n.textContent==='Tiles');
    assert.ok(tiles);
    tiles.onclick();
    assert.ok(panel.element.shadowRoot.textContent.includes('No tile events yet'));
    panel.dispose();
    assert.equal(panel.element.removed,true);
    session.dispose();
  } finally {globalThis.document=original;}
});

import {attachGeoDevTools,createGeoDevToolsPanel} from '/src/index.js';
import {FakeMap,FakeLayer,FakeSource,FakeTile} from '/tests/fixtures.js';
const target=document.querySelector('#result');
try {
  const source=new FakeSource({state:'error'});
  const map=new FakeMap({layers:[new FakeLayer({source})]});
  const session=attachGeoDevTools(map);
  const panel=createGeoDevToolsPanel(session);
  const root=panel.element.shadowRoot;
  const assert=(condition,message)=>{if(!condition)throw new Error(message);};
  assert(root.querySelector('.panel'),'panel must attach in Shadow DOM');
  assert(root.querySelector('.body').textContent.includes('Source 상태가 error'),'issue text visible');
  const tilesTab=[...root.querySelectorAll('[role=tab]')].find(x=>x.textContent==='Tiles');
  assert(tilesTab,'tile tab exists');
  tilesTab.click();
  assert(root.querySelector('.body').textContent.includes('No tile events'),'tile tab empty message');
  const tile=new FakeTile(1,[7,43,52]);
  source.emit('tileloadstart',{tile});
  tile.state=2;
  source.emit('tileloadend',{tile});
  assert(root.querySelector('.body').textContent.includes('loaded'),'tile state updates on DOM');
  assert(root.querySelector('.footer').textContent.includes('2 tile events'),'footer updates');
  assert(session.getState().events.length===2,'events captured');
  const layerTab=[...root.querySelectorAll('[role=tab]')].find(x=>x.textContent==='Layers');
  layerTab.click();
  assert(root.querySelector('.body').textContent.includes('EPSG:3857'),'projection shown');
  const close=[...root.querySelectorAll('button')].find(x=>x.getAttribute('aria-label')==='Close Geo DevTools panel');
  close.click();
  assert(!panel.element.isConnected,'close removes panel');
  session.dispose();
  assert(source.listenerCount()===0,'dispose frees event listeners');
  target.textContent='GEO_BROWSER_SMOKE_PASS';
} catch(error) {
  target.textContent='GEO_BROWSER_SMOKE_FAIL: '+(error?.stack??error);
}

"""Chromium DOM functional/visual tests for Geo DevTools, with no navigation required.

This sandbox test uses the *actual* Geo DevTools runtime + panel, a synthetic
OpenLayers-compatible map, and does NOT claim a real ol/Map browser test.
The in-memory local bundling is intentionally narrow and offline-only.
"""
from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import re
import traceback

from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'artifacts' / 'browser'
SRC_FILES = [
    'src/core/events.js',
    'src/core/snapshot.js',
    'src/core/diagnostics.js',
    'src/core/report.js',
    'src/openlayers/controller.js',
    'src/ui/panel.js',
    'examples/demo/main.js',
]


def bundle_demo():
    snippets = []
    for name in SRC_FILES:
        data = (ROOT / name).read_text(encoding='utf-8')
        data = re.sub(r'^import .*?;\s*$', '', data, flags=re.MULTILINE)
        data = re.sub(r'^export (?=(?:class|function|const|let)\b)', '', data, flags=re.MULTILINE)
        if re.search(r'^(?:import|export)\b', data, flags=re.MULTILINE):
            raise ValueError(f'unhandled module syntax in {name}')
        snippets.append(f'\n// === {name} ===\n{data}')
    return '\n'.join(snippets)


def demo_html():
    html = (ROOT / 'examples/demo/index.html').read_text(encoding='utf-8')
    html = re.sub(r'<script\s+type="module"\s+src="\./main\.js"></script>', '', html)
    return html


async def run():
    OUT.mkdir(parents=True, exist_ok=True)
    args = ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--no-first-run']
    browser_path = os.environ.get('CHROMIUM_BIN')
    results = []
    failures = []
    pngs = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, executable_path=browser_path, args=args)
        context = await browser.new_context(viewport={'width': 1440, 'height': 900}, device_scale_factor=1)
        await context.tracing.start(screenshots=True, snapshots=True, sources=False)
        page = await context.new_page()
        page_errors = []
        page.on('pageerror', lambda err: page_errors.append(str(err)))

        async def verify(label, condition, details=''):
            if not condition:
                failures.append(label + (': ' + details if details else ''))
            results.append({'case': label, 'pass': bool(condition), 'detail': details})

        async def screenshot(name):
            path = OUT / f'{name}.png'
            await page.screenshot(path=str(path), full_page=True, animations='disabled')
            pngs.append(path.name)

        try:
            await page.set_content(demo_html(), wait_until='domcontentloaded', timeout=15000)
            await page.add_script_tag(content=bundle_demo())
            await page.wait_for_function('window.__geoDevtoolsSmoke?.ready === true', timeout=10000)
            panel = page.locator('[data-geo-devtools]')
            body = panel.locator('.body')
            # Playwright selectors pierce open Shadow DOM.
            await verify('BROWSER-01: panel attached', await panel.count() == 1)
            await verify('BROWSER-02: healthy has no findings', 'No findings' in await body.inner_text())
            await screenshot('01-healthy')

            await page.locator('#broken-grid').click()
            invalid_text = await body.inner_text()
            await verify('BROWSER-03: invalid resolutions', 'TileGrid 해상도 배열' in invalid_text)
            await screenshot('02-invalid-grid')

            await page.locator('#different-crs').click()
            crs_text = await body.inner_text()
            await verify('BROWSER-04: CRS difference is not an error',
                         '서로 다릅니다' in crs_text and 'ERROR ·' not in crs_text)
            await screenshot('03-crs-information')

            await page.locator('#healthy').click()
            await page.locator('#tile-failure').click()
            tile_issue = await body.inner_text()
            await verify('BROWSER-05: tile load error finding', '타일' in tile_issue and '오류' in tile_issue)
            await screenshot('04-tile-error')
            await panel.get_by_role('tab', name='Tiles').click()
            tiles_text = await body.inner_text()
            await verify('BROWSER-06: tile event list includes error', 'error' in tiles_text and 'start' in tiles_text)
            await screenshot('05-tile-events')
            await panel.get_by_role('tab', name='Layers').click()
            await verify('BROWSER-07: layers contain EPSG code', 'EPSG:3857' in await body.inner_text())
            await screenshot('06-layers')

            # Verify JSON export protection directly from runtime without downloading.
            privacy = await page.evaluate('''() => {
              const s=window.__geoDevtoolsSmoke.session;
              const r=s.exportReport();
              return {privacy:r.privacy,center:r.view.center,
                anyTileCoords:r.events.some(e=>e.tileCoord),
                anyLayerLabel:r.layers.some(l=>l.label)};
            }''')
            await verify('BROWSER-08: redacted report default',
                         privacy['privacy']=='redacted-default' and privacy['center'] is None
                         and not privacy['anyTileCoords'] and not privacy['anyLayerLabel'])

            await page.locator('#hide-layer').click()
            await panel.get_by_role('tab', name='Issues').click()
            await verify('BROWSER-09: hidden layer issue', '숨김 상태' in await body.inner_text())
            await screenshot('07-hidden-layer')

            await panel.get_by_role('button', name='Close Geo DevTools panel').click()
            await verify('BROWSER-10: close removes panel', await panel.count() == 0)
            await verify('BROWSER-11: no uncaught JS errors', not page_errors, '; '.join(page_errors))
        except Exception as e:
            failures.append('Uncaught E2E exception: ' + str(e))
            results.append({'case': 'browser runner', 'pass': False, 'detail': traceback.format_exc()})
            try:
                await screenshot('failure')
            except Exception:
                pass
        finally:
            await context.tracing.stop(path=str(OUT / 'trace.zip'))
            await browser.close()

    summary = {
        'timestamp': datetime.now(timezone.utc).isoformat(),
        'type': 'real Chromium DOM; synthetic OpenLayers-compatible map; injected source bundle',
        'passed': sum(bool(r['pass']) for r in results),
        'failed': sum(not r['pass'] for r in results),
        'total': len(results),
        'results': results,
        'screenshots': pngs,
        'errors': failures,
        'restrictions': 'NOT real OpenLayers Map E2E; local sandbox blocks browser navigations',
    }
    (OUT / 'results.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    html = ['<!doctype html><html lang="ko"><meta charset="utf-8">',
            '<title>Geo DevTools Browser Test Report</title>',
            '<style>body{font:15px system-ui;margin:35px auto;max-width:1000px;background:#f6f8fb;color:#142638}img{width:100%;border:1px solid #cbd5e1;border-radius:8px}section{padding:15px;margin:12px 0 24px;background:white;border-radius:12px;box-shadow:0 2px 9px #0001}h1{font-size:26px}.good{color:#137349}.bad{color:#b12c25}</style>',
            f'<h1>Geo DevTools visual E2E — {summary["passed"]}/{summary["total"]} passed</h1>',
            '<p>Real Chromium DOM with a synthetic OpenLayers-style map. Not a real OpenLayers browser integration.</p>']
    for r in results:
        safe_case = r['case'].replace('&','&amp;').replace('<','&lt;')
        html.append(f'<div class={"good" if r["pass"] else "bad"}>{"PASS" if r["pass"] else "FAIL"} · {safe_case}</div>')
    for img in pngs:
        html.append(f'<section><h2>{img}</h2><img src="{img}" alt="{img}"></section>')
    html.append('</html>')
    (OUT / 'report.html').write_text('\n'.join(html), encoding='utf-8')
    print(json.dumps({'passed': summary['passed'], 'failed': summary['failed'], 'screenshots': pngs,
                      'errors':failures}, ensure_ascii=False, indent=2), flush=True)
    if failures:
        raise SystemExit(1)

if __name__ == '__main__':
    asyncio.run(run())

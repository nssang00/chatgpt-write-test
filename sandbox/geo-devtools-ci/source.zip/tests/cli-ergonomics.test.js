import {test} from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {parseCliArgs,HELP} from '../bin/geo-doctor.js';

test('CLI-01: URL only triggers basic scan with default report outputs',()=>{
  const p=parseCliArgs(['http://localhost:5173']);
  assert.equal(p.url,'http://localhost:5173/');
  assert.deepEqual(p.opts,{output:'geo-doctor-report.json',html:null,screenshot:null,observeMs:1500});
});
test('CLI-02: old explicit scan argument remains compatible',()=>{
  assert.deepEqual(parseCliArgs(['scan','http://localhost:5173']),parseCliArgs(['http://localhost:5173']));
});
test('CLI-03: explicit screenshot is opt-in',()=>{
  assert.equal(parseCliArgs(['http://localhost:5173','--screenshot','map.png']).opts.screenshot,'map.png');
  assert.equal(parseCliArgs(['http://localhost:5173']).opts.screenshot,null);
});
test('CLI-04: human-oriented help works without starting browser',()=>{
  assert.equal(parseCliArgs(['--help']).help,true);
  const out=execFileSync(process.execPath,['bin/geo-doctor.js','--help'],{encoding:'utf8'});
  assert.ok(out.includes('geo-doctor <URL>'));
  assert.ok(HELP.includes('No changes to the target app'));
});
test('CLI-05: invalid input rejected before browsing',()=>{
  for(const args of [['invalid'],['file:///etc/passwd'],['http://localhost','--output'],['http://localhost','--observe-ms','NaN']]){
    assert.throws(()=>parseCliArgs(args));
  }
});

"""Start an isolated loopback web app and launch a browser via a one-time secret."""
import argparse
import os
import secrets
import socket
import threading
import time
import webbrowser

import uvicorn
from backend.app.main import create_app
from backend.app.auth.rso import RSOConfig


def available_port(preferred: int = 8765) -> int:
    for port in (preferred, 0):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return sock.getsockname()[1]
            except OSError:
                continue
    raise RuntimeError("로컬 포트를 확보할 수 없습니다.")


def open_browser_when_ready(port: int, token: str, browser_port: int) -> None:
    for _ in range(80):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.15):
                webbrowser.open(f"http://127.0.0.1:{browser_port}/#launch={token}")
                return
        except OSError:
            time.sleep(0.1)
    print("웹서버가 시작되지 않았습니다. 방화벽과 포트를 확인하세요.")


def main() -> None:
    parser = argparse.ArgumentParser(description="VAL DASH local demo server")
    parser.add_argument("--dev", action="store_true", help="Open Vite development frontend at port 5173")
    args = parser.parse_args()
    port = available_port()
    config = RSOConfig.from_env()
    if config.approved and config.client_id and config.redirect_uri and not config.is_ready(port):
        parser.error("Configured RSO callback must exactly match http://127.0.0.1:<active-port>/api/auth/riot/callback. Check port and Riot developer registration.")
    if args.dev and port != 8765:
        parser.error("React Vite proxy requires backend port 8765. Stop the other process.")
    if args.dev:
        os.environ["VALDASH_DEV_ORIGIN"] = "http://127.0.0.1:5173"
    token = secrets.token_urlsafe(48)
    app = create_app(launch_token=token, port=port, rso_config=config)
    browser_port = 5173 if args.dev else port
    threading.Thread(target=open_browser_when_ready, args=(port, token, browser_port), daemon=True).start()
    print(f"VAL DASH 로컬 서버: http://127.0.0.1:{port}")
    print("Riot RSO login configured:", "yes" if config.is_ready(port) else "no (demo mode only)")
    print("브라우저를 자동으로 열고 있습니다. 종료: Ctrl+C")
    print("주의: 주소만 직접 입력하면 실행 인증이 되지 않습니다. 자동으로 열린 탭을 사용하세요.")
    uvicorn.run(app, host="127.0.0.1", port=port, access_log=False, log_level="warning")


if __name__ == "__main__":
    main()

"""VAL DASH executable scripts."""

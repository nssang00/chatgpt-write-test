"""Opt-in manual live smoke test for an interactive, trusted Windows machine.

No username, password, MFA code, CAPTCHA data, tokens or account identifiers
are accepted as command-line inputs or printed. The account owner enters
credentials into Riot's own login page and completes any challenges manually.

This is an experimental third-party integration, NOT an approved Riot RSO app.
Use only for an account you own and understand the Riot policy risks.
"""
from __future__ import annotations

import os
import sys

from backend.app.auth.riot_web import InteractiveLoginError, interactive_riot_login
from backend.app.providers.riot_internal import (
    UpstreamUnavailable, read_live_penalties, read_live_store,
    riot_account, riot_entitlement, validated_shard,
)


def live_smoke(*, login=interactive_riot_login, get_account=riot_account,
               get_entitlement=riot_entitlement, get_store=read_live_store,
               get_penalties=read_live_penalties, output=print) -> int:
    """Only report boolean milestones/counts. Do not dump upstream responses."""
    if os.getenv("VALDASH_ALLOW_INTERACTIVE_LIVE_TEST") != "yes":
        output("LIVE_TEST_DISABLED: set VALDASH_ALLOW_INTERACTIVE_LIVE_TEST=yes")
        return 2
    shard = os.getenv("VALDASH_SHARD", "kr")
    try:
        validated_shard(shard)
    except UpstreamUnavailable:
        output("LIVE_TEST_ERROR: INVALID_REGION")
        return 2

    try:
        output("LIVE_LOGIN_PENDING: complete Riot login, CAPTCHA and MFA in the local browser window")
        token, _ = login()
        account = get_account(token)
        entitlements = get_entitlement(token)
        output("LIVE_LOGIN_OK")
        store = get_store(token, entitlements, account["puuid"], shard)
        if not isinstance(store.get("offers"), list):
            output("LIVE_STORE_INVALID_RESPONSE")
            return 1
        output("LIVE_STORE_OK: count=" + str(len(store["offers"])))
        penalties = get_penalties(token, entitlements, shard)
        if not isinstance(penalties.get("records"), list):
            output("LIVE_PENALTIES_INVALID_RESPONSE")
            return 1
        output("LIVE_PENALTIES_OK: count=" + str(penalties["returned_count"]))
        output("LIVE_TEST_PASS")
        return 0
    except InteractiveLoginError as exc:
        # Exception codes are controlled by our module; never include Riot data.
        output("LIVE_LOGIN_FAILED: " + str(exc))
        return 1
    except UpstreamUnavailable as exc:
        output("LIVE_API_FAILED: " + exc.code)
        return 1
    except Exception:
        # Even a traceback can expose headers, URLs, PUUID, browser state etc.
        output("LIVE_TEST_FAILED: UNEXPECTED_ERROR")
        return 1


if __name__ == "__main__":
    sys.exit(live_smoke())

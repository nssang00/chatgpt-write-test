# VAL DASH v0.2 — 보안 및 OAuth 설계

## 신뢰 경계

```text
Browser (standalone/React) ── local cookie + CSRF ──> FastAPI on 127.0.0.1
                                                          |-- MockProvider (game data)
                                                          |-- SQLite (demo only)
                                                          `-- Approved RSO OAuth (optional)
                                                               |-- auth.riotgames.com/authorize
                                                               |-- auth.riotgames.com/token
                                                               `-- asia.api.riotgames.com/riot/account/v1/accounts/me
```

- 웹 앱은 라이엇 비밀번호를 묻지 않습니다. 공식 Riot 인증 화면에서만 인증합니다.
- 본인 계정의 Riot ID(PUUID, 게임 이름, 태그) 외 데이터는 계속 데모로 표시됩니다.
- 승인된 RSO Client ID/Secret/리디렉션 URL이 설정되어야 로그인 버튼이 활성화됩니다.
- OAuth 일회용 `state`는 서버 메모리에 로컬 세션 ID와 함께 저장되며 5분만 유효합니다.
- 승인된 경우 코드 교환은 서버에서 Client Secret Basic으로 수행합니다.
- RSO가 PKCE를 지원하도록 승인된 경우에만 PKCE 선택 옵션을 사용합니다.
- 콜백은 별도 Origin에서 넘어오므로 `SameSite=Strict` 로컬 세션 쿠키가 없더라도 서버 측 `state` 연결로 처리합니다.
- 토큰은 서버 프로세스 메모리 외 저장되지 않습니다. Refresh Token을 폐기하고 Access Token만 단기로 유지합니다.
- 비공식 게임 클라이언트 API, 비밀번호 추출, 쿠키 복사, 캡차 우회, 2FA 자동 입력은 포함되지 않습니다.

## 주요 API

| Method | Path | 용도 |
| --- | --- | --- |
| POST | `/api/session/bootstrap` | 로컬 실행 세션 시작 (일회용 토큰) |
| GET | `/api/session` | CSRF 및 연결 계정의 공개 식별자 |
| POST | `/api/auth/riot/start` | 승인 환경에서 OAuth state 발급 및 로그인 URL 반환 |
| GET | `/api/auth/riot/callback` | Riot이 넘긴 code/state 검증 후 계정 조회 |
| GET | `/api/auth/riot/status` | 로그인 가능/연결 상태 (토큰 반환하지 않음) |
| POST | `/api/auth/riot/disconnect` | 서버 메모리의 토큰·계정 연결 해제 |
| GET | `/api/overview`, `/api/store`, `/api/penalties`, `/api/rank`, `/api/inventory` | 가상 게임 데이터 |
| POST | `/api/session/logout` | 로컬 세션 종료 |

## CI 한계

테스트는 `httpx.MockTransport`로 OAuth 요청을 모의하며 GitHub Actions Secrets에 개인 Riot 비밀번호를 넣지 않습니다. Windows `.bat` 실행과 가상 인증 성공은 검증할 수 있지만, 라이엇 RSO 승인/콜백 등록과 대화형 2차 인증, 개인 상점/제재 조회는 검증하지 못합니다.

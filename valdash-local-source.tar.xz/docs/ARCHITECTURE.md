# VAL DASH v0.1 보안·아키텍처 설계

## 신뢰 경계

```text
브라우저 (standalone JS / 선택적 React)
  | HTTP, 127.0.0.1 only
  | HttpOnly/SameSite=Strict 앱 세션 쿠키
  | POST 시 X-CSRF-Token
  v
FastAPI (로컬 프로세스)
  |-- 자체 세션 검증 (메모리, 2시간)
  |-- Origin/Host/Fetch Metadata 검증
  |-- Pydantic 입력 검증
  |-- Provider interface
  |     |-- mock.py         [활성]
  |     |-- official.py     [비활성 / RSO 승인 필요]
  |     `-- experimental.py [비활성 / 검증 전]
  `-- SQLite (~/.valdash-local/valdash.sqlite3): 데모 설정/기록만
```

## 로컬 세션 부트스트랩

1. 실행기가 CSPRNG로 `launch_token`을 만듭니다.
2. 실행기는 브라우저에서 `http://127.0.0.1:<port>/#launch=<token>`을 엽니다.
3. Fragment는 HTTP 요청에 포함되지 않습니다. 프런트는 해당 fragment를 읽자마자 URL에서 제거합니다.
4. `POST /api/session/bootstrap`에서 일회성 토큰을 확인하여 로컬 세션 쿠키 및 CSRF 토큰을 발급합니다.
5. 브라우저 JS에서는 HttpOnly 쿠키 값을 읽을 수 없습니다. 이후 API 요청 시 쿠키는 자동으로 전송됩니다.
6. `POST` 요청에서는 `X-CSRF-Token` 및 허용 Origin을 확인합니다. 앱 종료 시 세션은 메모리에서 사라집니다.

**예외·한계:** 동일 사용자 계정으로 실행 중인 악성 로컬 프로세스, 디버거, 브라우저 악성 확장에 대해서는 완전한 방어를 제공하지 않습니다. 로컬 HTTP에서 `Secure` 쿠키를 강제하면 브라우저에 따라 동작이 달라질 수 있으므로 이 데모는 `Secure=False`로 사용합니다. 실제 토큰을 다루는 단계에서는 localhost HTTPS 및 OS 보안 저장소 적용을 재검토해야 합니다.

## 프런트 API (모든 실제 계정 정보는 현재 가상)

| Method | Path | Result | Auth |
| --- | --- | --- | --- |
| GET | `/api/health` | 서버 상태 | 불필요 |
| POST | `/api/session/bootstrap` | 로컬 쿠키/CSRF 발급 | 1회용 launch token |
| GET | `/api/session` | 로컬 세션 상태 | 쿠키 |
| POST | `/api/session/logout` | 로컬 세션 파기 | 쿠키 + CSRF |
| GET | `/api/accounts` | 데모 계정 | 쿠키 |
| GET | `/api/providers` | 연동 상태 | 쿠키 |
| GET | `/api/overview` | 전체 데모 대시보드 | 쿠키 |
| GET | `/api/store` | 4개 가상 상품 | 쿠키 |
| GET | `/api/penalties` | 데모 제재 상태 | 쿠키 |
| GET | `/api/rank` | 데모 랭크/전적 | 쿠키 |
| GET | `/api/inventory` | 데모 스킨/재화 | 쿠키 |
| GET | `/api/history` | 로컬 조회 로그 | 쿠키 |
| POST | `/api/demo/scenario` | `clear/active/unknown` | 쿠키 + CSRF |
| POST | `/api/data/refresh` | 데모 갱신 기록 | 쿠키 + CSRF |
| POST | `/api/auth/riot/start` | 501 미지원 | 쿠키 + CSRF |

`GET /api/penalties`의 `status`는 다음처럼 구분합니다.

- `clear`: 제공자가 확인하는 범위에 활성 제재 없음 (현재 데모)
- `active`: 제재 정보가 반환됨 (현재 데모)
- `unavailable`: 조회에 실패해 상태를 알 수 없음 (현재 데모)

모든 주요 데이터 응답은 `mode: "demo"`, `live: false`를 포함하므로 실제 조회 결과로 오해할 가능성을 줄입니다.

## 구현되지 않은 부분

- Riot 실제 계정 로그인 (공식 RSO 미승인)
- 비공식 계정 인증 및 내부 API
- 개인 상점 및 제재 실데이터 조회
- 브라우저에서 Riot 토큰 저장/갱신
- 정식 배포 및 패키징 자동화
- React 의존성 실제 설치/빌드 확인 (현재 실행 환경에 npm 인터넷 없음)

## 향후 권장 개발 순서

1. 로컬 인증/조회/표시/데이터 캐시 요구사항을 확정하고 테스트 강화.
2. 공식 API 지원 범위 및 RSO 승인 가능성 확인.
3. 실제 제공자를 테스트 격리 후 연결하며 `NOT_SUPPORTED`, `AUTH_REQUIRED`, `PROVIDER_FAILURE`와 `NO_ACTIVE_PENALTY`를 별도 상태로 유지.
4. 토큰 갱신과 보안 저장소(OS keyring)를 별도 모듈로 검증. 비밀번호는 받지 않음.
5. 릴리즈 전 Chromium/Edge 자동화, 악성 Origin, DNS 리바인딩, CSRF, 쿠키 속성 등을 보안 점검.

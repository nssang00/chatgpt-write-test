@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON_CMD=py -3"
) else (
    set "PYTHON_CMD=python"
)

%PYTHON_CMD% -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python 3.11 or newer is required.
    echo Install Python from https://www.python.org/downloads/ and retry.
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [INFO] Creating local virtual environment...
    %PYTHON_CMD% -m venv ".venv"
    if errorlevel 1 (
        echo [ERROR] Could not create .venv.
        exit /b 1
    )
)

echo [INFO] Installing dependencies...
".venv\Scripts\python.exe" -m pip install -r "requirements.txt"
if errorlevel 1 (
    echo [ERROR] Dependency installation failed.
    exit /b 1
)

echo [OK] Installation completed. Double-click run.bat.
exit /b 0

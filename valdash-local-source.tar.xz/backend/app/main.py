"""FastAPI backend for VAL DASH, an offline-first DEMO local web application.

The application does not make any Riot network requests or ask for Riot passwords.
It binds to loopback; its local session is separate from Riot authentication.
"""
from __future__ import annotations

import hmac
import os
import secrets
import time
from pathlib import Path
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .db import init_db, scenario_get, scenario_set, refresh_add, refresh_recent
from .providers.mock import MockProvider

ROOT = Path(__file__).resolve().parents[2]
SESSION_COOKIE = "valdash_local_session"
SESSION_TTL_SECONDS = 2 * 60 * 60


class BootstrapBody(BaseModel):
    launch_token: str = Field(min_length=32, max_length=256)


class ScenarioBody(BaseModel):
    scenario: Literal["clear", "active", "unknown"]


def create_app(
    *,
    launch_token: str | None = None,
    db_path: Path | None = None,
    port: int = 8765,
    test_mode: bool = False,
) -> FastAPI:
    app = FastAPI(
        title="VAL DASH Local", version="0.1.0", docs_url=None, redoc_url=None,
        openapi_url=None,
    )
    app.state.launch_token = launch_token or secrets.token_urlsafe(40)
    app.state.launch_token_used = False
    app.state.sessions: dict[str, dict] = {}
    app.state.port = port
    app.state.test_mode = test_mode
    app.state.db_path = db_path or (Path.home() / ".valdash-local" / "valdash.sqlite3")
    app.state.provider = MockProvider()
    init_db(app.state.db_path)

    allowed_hosts = ["127.0.0.1"]
    if test_mode:
        allowed_hosts.append("testserver")
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=allowed_hosts)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        if request.method == "POST" and request.url.path.startswith("/api/"):
            if not request.headers.get("content-type", "").lower().startswith("application/json"):
                return JSONResponse(status_code=415, content={"code": "JSON_REQUIRED", "message": "JSON 요청만 허용합니다."})
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; "
            "form-action 'self'; img-src 'self' data:; script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; connect-src 'self'; font-src 'self'"
        )
        return response

    def validate_origin(request: Request) -> None:
        # Browsers set Origin for fetch POST. A missing Origin is tolerated only
        # because non-browser clients may omit it. The separate launch token and
        # CSRF token still protect the session.
        origin = request.headers.get("origin")
        allowed = {f"http://127.0.0.1:{app.state.port}"}
        if test_mode:
            allowed.add("http://testserver")
        # Explicit local development exception for Vite's port; disabled by default.
        dev_origin = os.getenv("VALDASH_DEV_ORIGIN", "")
        if dev_origin == "http://127.0.0.1:5173":
            allowed.add(dev_origin)
        if origin and origin not in allowed:
            raise HTTPException(status_code=403, detail={"code": "BAD_ORIGIN", "message": "허용되지 않은 요청 출처"})
        if request.headers.get("sec-fetch-site") == "cross-site":
            raise HTTPException(status_code=403, detail={"code": "CROSS_SITE", "message": "외부 사이트의 요청 차단"})

    def get_session(request: Request) -> dict:
        sid = request.cookies.get(SESSION_COOKIE, "")
        session = app.state.sessions.get(sid)
        if not session or session["expires_at"] < time.time():
            if sid:
                app.state.sessions.pop(sid, None)
            raise HTTPException(status_code=401, detail={"code": "LOCAL_SESSION_REQUIRED", "message": "로컬 세션이 필요합니다. 앱을 다시 실행하세요."})
        return session

    def require_csrf(request: Request, session: dict = Depends(get_session)) -> dict:
        validate_origin(request)
        given = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(given, session["csrf"]):
            raise HTTPException(status_code=403, detail={"code": "CSRF_FAILED", "message": "요청 검증에 실패했습니다."})
        content_type = request.headers.get("content-type", "")
        if not content_type.lower().startswith("application/json"):
            raise HTTPException(status_code=415, detail={"code": "JSON_REQUIRED", "message": "JSON 요청만 허용합니다."})
        return session

    @app.get("/api/health")
    def health():
        return {"ok": True, "mode": "demo", "live": False, "version": "0.1.0"}

    @app.post("/api/session/bootstrap")
    def bootstrap(payload: BootstrapBody, request: Request, response: Response):
        validate_origin(request)
        if app.state.launch_token_used or not hmac.compare_digest(payload.launch_token, app.state.launch_token):
            raise HTTPException(status_code=403, detail={"code": "INVALID_LAUNCH_TOKEN", "message": "실행 인증이 만료되었거나 올바르지 않습니다."})
        app.state.launch_token_used = True
        # Remove the launch token from memory once exchanged for a session.
        app.state.launch_token = ""
        sid = secrets.token_urlsafe(40)
        csrf = secrets.token_urlsafe(32)
        app.state.sessions[sid] = {"csrf": csrf, "expires_at": time.time() + SESSION_TTL_SECONDS}
        response.set_cookie(
            SESSION_COOKIE, sid, max_age=SESSION_TTL_SECONDS,
            httponly=True, samesite="strict", secure=False, path="/",
        )
        return {"ok": True, "csrf_token": csrf, "mode": "demo", "expires_in": SESSION_TTL_SECONDS}

    @app.get("/api/session")
    def session_status(session: dict = Depends(get_session)):
        return {"ok": True, "csrf_token": session["csrf"], "mode": "demo", "riot_connected": False}

    @app.post("/api/session/logout")
    def logout(request: Request, response: Response, session: dict = Depends(require_csrf)):
        sid = request.cookies.get(SESSION_COOKIE, "")
        app.state.sessions.pop(sid, None)
        response.delete_cookie(SESSION_COOKIE, path="/", samesite="strict")
        return {"ok": True, "message": "로컬 세션을 종료했습니다. 다시 시작하려면 프로그램을 재실행하세요."}

    @app.get("/api/providers")
    def providers(session: dict = Depends(get_session)):
        return {
            "current": "demo",
            "providers": [
                {"id": "demo", "enabled": True, "label": "가상 데이터"},
                {"id": "official", "enabled": False, "label": "라이엇 승인과 RSO 설정 필요"},
                {"id": "experimental", "enabled": False, "label": "정책·인증·동작 검증 전 비활성화"},
            ],
        }

    @app.get("/api/accounts")
    def accounts(session: dict = Depends(get_session)):
        return {"mode": "demo", "accounts": [{"id": "demo-kr", "riot_id": "DEMO#0001", "region": "KR", "is_demo": True}]}

    def overview_data():
        value = scenario_get(app.state.db_path)
        overview = app.state.provider.overview(value)
        overview["scenario"] = value
        return overview

    @app.get("/api/overview")
    def overview(session: dict = Depends(get_session)):
        return overview_data()

    @app.get("/api/store")
    def store(session: dict = Depends(get_session)):
        result = overview_data()
        return {"mode": "demo", "live": False, "store": result["store"], "updated_at": result["updated_at"]}

    @app.get("/api/penalties")
    def penalties(session: dict = Depends(get_session)):
        result = overview_data()
        return {"mode": "demo", "live": False, "penalty": result["penalty"], "updated_at": result["updated_at"]}

    @app.get("/api/rank")
    def rank(session: dict = Depends(get_session)):
        result = overview_data()
        return {"mode": "demo", "live": False, "rank": result["rank"], "matches": result["matches"]}

    @app.get("/api/inventory")
    def inventory(session: dict = Depends(get_session)):
        result = overview_data()
        return {"mode": "demo", "live": False, "inventory": result["inventory"], "wallet": result["wallet"]}

    @app.get("/api/history")
    def history(session: dict = Depends(get_session)):
        return {"mode": "demo", "items": refresh_recent(app.state.db_path)}

    @app.post("/api/demo/scenario")
    def update_scenario(payload: ScenarioBody, session: dict = Depends(require_csrf)):
        scenario_set(app.state.db_path, payload.scenario)
        return {"mode": "demo", "scenario": payload.scenario}

    @app.post("/api/data/refresh")
    def refresh(session: dict = Depends(require_csrf)):
        at = refresh_add(app.state.db_path)
        return {"mode": "demo", "live": False, "updated_at": at, "message": "가상 데이터만 갱신했습니다."}

    @app.post("/api/auth/riot/start")
    def riot_auth_disabled(session: dict = Depends(require_csrf)):
        return JSONResponse(status_code=501, content={
            "code": "RIOT_AUTH_NOT_CONFIGURED",
            "message": "공식 VALORANT RSO 승인 및 등록된 콜백이 없어 실계정 연결을 제공하지 않습니다.",
            "live": False,
        })

    # This static bundle uses no remote CDN scripts or fonts. If the React app
    # has been compiled with npm run build, serve that instead of the fallback.
    built_dir = ROOT / "frontend" / "dist"
    static_dir = built_dir if (built_dir / "index.html").exists() else ROOT / "standalone"
    app.mount("/", StaticFiles(directory=static_dir, html=True), name="frontend")
    return app


app = create_app()

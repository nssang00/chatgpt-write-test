"""A small SQLite store for DEMO settings and a local refresh history only."""
import sqlite3
from pathlib import Path
from datetime import datetime, timezone


def init_db(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execute("CREATE TABLE IF NOT EXISTS refresh_log (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, source TEXT NOT NULL)")
        db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('scenario', 'clear')")
        db.commit()


def scenario_get(path: Path) -> str:
    with sqlite3.connect(path) as db:
        result = db.execute("SELECT value FROM settings WHERE key='scenario'").fetchone()
    return result[0] if result and result[0] in ("clear", "active", "unknown") else "clear"


def scenario_set(path: Path, value: str) -> None:
    with sqlite3.connect(path) as db:
        db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('scenario', ?)", (value,))
        db.commit()


def refresh_add(path: Path) -> str:
    at = datetime.now(timezone.utc).isoformat()
    with sqlite3.connect(path) as db:
        db.execute("INSERT INTO refresh_log (at, source) VALUES (?, ?)", (at, "demo"))
        db.commit()
    return at


def refresh_recent(path: Path, limit: int = 8) -> list[dict]:
    with sqlite3.connect(path) as db:
        rows = db.execute("SELECT at, source FROM refresh_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [{"at": at, "source": source} for at, source in rows]

"""Approved Riot Sign On helpers (no credential collection)."""

"""Experimental, USER-INTERACTIVE Riot website login.

A real Chromium/Edge window shows auth.riotgames.com. The user types their
credentials exclusively into Riot's page. This process does NOT fill, collect,
log or store passwords, MFA codes, browser cookies or persistent browser state.

The third-party use of Riot's public web client is unofficial and may stop
working or be incompatible with Riot's policies. This is not approved RSO.
"""
from __future__ import annotations

from urllib.parse import urlencode, urlsplit, parse_qs
import secrets
import time

WEB_CLIENT_ID = "play-valorant-web-prod"
REDIRECT_URL = "https://playvalorant.com/opt_in"
AUTH_URL = "https://auth.riotgames.com/authorize"
MAX_LOGIN_SECONDS = 300


class InteractiveLoginError(Exception):
    """No secret details are allowed in this error's string."""


def login_url(nonce: str) -> str:
    return AUTH_URL + "?" + urlencode({
        "client_id": WEB_CLIENT_ID,
        "redirect_uri": REDIRECT_URL,
        "response_type": "token id_token",
        "scope": "openid account",
        "nonce": nonce,
    })


def parse_riot_redirect(url: str) -> tuple[str, int] | None:
    """Only accept a Riot-issued redirect to the exact known client URL."""
    parts = urlsplit(url)
    if parts.scheme != "https" or parts.hostname not in ("playvalorant.com", "www.playvalorant.com"):
        return None
    if parts.path.rstrip("/") != "/opt_in" or parts.port not in (None, 443):
        return None
    if parts.username or parts.password:
        return None
    fragment = parse_qs(parts.fragment, keep_blank_values=True)
    token = fragment.get("access_token", [""])[0]
    if not token or len(token) > 8192:
        return None
    try:
        ttl = int(fragment.get("expires_in", ["3600"])[0])
    except (TypeError, ValueError):
        return None
    if ttl <= 0 or ttl > 86400:
        return None
    return token, ttl


def interactive_riot_login(timeout: int = MAX_LOGIN_SECONDS) -> tuple[str, int]:
    """Open a fresh nonpersistent browser for user input (never headless)."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise InteractiveLoginError("PLAYWRIGHT_NOT_INSTALLED") from exc
    found: list[tuple[str, int]] = []
    try:
        with sync_playwright() as playwright:
            browser = None
            # Microsoft Edge is installed on most Windows 10/11 machines.
            # Do not silently install a browser or bypass anti-bot mechanisms.
            for channel in ("msedge", "chrome", None):
                try:
                    if channel is None:
                        browser = playwright.chromium.launch(headless=False)
                    else:
                        browser = playwright.chromium.launch(channel=channel, headless=False)
                    break
                except Exception:
                    continue
            if browser is None:
                raise InteractiveLoginError("BROWSER_NOT_AVAILABLE")
            try:
                ctx = browser.new_context(accept_downloads=False)
                page = ctx.new_page()

                def on_navigate(frame):
                    if frame == page.main_frame:
                        result = parse_riot_redirect(frame.url)
                        if result:
                            found.append(result)

                page.on("framenavigated", on_navigate)
                page.goto(login_url(secrets.token_urlsafe(24)), wait_until="domcontentloaded", timeout=25000)
                deadline = time.monotonic() + timeout
                while time.monotonic() < deadline:
                    if found:
                        return found[0]
                    if page.is_closed():
                        raise InteractiveLoginError("LOGIN_WINDOW_CLOSED")
                    # Riot can require a CAPTCHA or a second factor. The user
                    # must complete both directly in the official browser UI.
                    page.wait_for_timeout(400)
                raise InteractiveLoginError("LOGIN_TIMEOUT")
            finally:
                browser.close()
    except InteractiveLoginError:
        raise
    except Exception as exc:
        # Never include browser URLs/HTTP payloads/tracebacks in responses.
        raise InteractiveLoginError("BROWSER_AUTH_FAILED") from exc

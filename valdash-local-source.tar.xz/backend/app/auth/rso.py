"""Riot's approved OAuth authorization-code flow (Client Secret Basic).

No Riot passwords or browser cookies are accepted. Access tokens are returned to
our backend only; the UI receives just the verified Riot ID. This module does
not use client-internal VALORANT endpoints.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from urllib.parse import urlencode, urlsplit

import httpx

AUTHORIZE_URL = "https://auth.riotgames.com/authorize"
TOKEN_URL = "https://auth.riotgames.com/token"
ACCOUNT_ME = "https://asia.api.riotgames.com/riot/account/v1/accounts/me"
CALLBACK_PATH = "/api/auth/riot/callback"


@dataclass(frozen=True)
class RSOConfig:
    client_id: str = ""
    client_secret: str = ""
    redirect_uri: str = ""
    approved: bool = False
    use_pkce: bool = False  # Enable only if specifically supported by the approved client.

    @classmethod
    def from_env(cls) -> "RSOConfig":
        return cls(
            client_id=os.getenv("RIOT_RSO_CLIENT_ID", "").strip(),
            client_secret=os.getenv("RIOT_RSO_CLIENT_SECRET", ""),
            redirect_uri=os.getenv("RIOT_RSO_REDIRECT_URI", "").strip(),
            approved=os.getenv("RIOT_RSO_APPROVED", "").lower() == "true",
            use_pkce=os.getenv("RIOT_RSO_USE_PKCE", "").lower() == "true",
        )

    def is_ready(self, port: int) -> bool:
        # Never permit arbitrary server/redirect settings from user input.
        # Riot must have explicitly registered this *exact* localhost callback.
        expected = f"http://127.0.0.1:{port}{CALLBACK_PATH}"
        return bool(
            self.approved and self.client_id and self.client_secret
            and self.redirect_uri == expected
        )

    def authorization_url(self, state: str, challenge: str | None = None) -> str:
        values = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": "openid offline_access",
            "state": state,
        }
        if challenge:
            values.update({"code_challenge": challenge, "code_challenge_method": "S256"})
        return f"{AUTHORIZE_URL}?{urlencode(values)}"


def validate_authorization_url(url: str) -> bool:
    parsed = urlsplit(url)
    return parsed.scheme == "https" and parsed.netloc == "auth.riotgames.com" and parsed.path == "/authorize"


def exchange_code(config: RSOConfig, code: str, *, verifier: str | None = None,
                  transport: httpx.BaseTransport | None = None) -> tuple[str, int]:
    form = {"grant_type": "authorization_code", "code": code, "redirect_uri": config.redirect_uri}
    if verifier:
        form["code_verifier"] = verifier
    with httpx.Client(timeout=10, follow_redirects=False, transport=transport) as client:
        response = client.post(TOKEN_URL, data=form, auth=httpx.BasicAuth(config.client_id, config.client_secret))
        response.raise_for_status()
        payload = response.json()
    if not isinstance(payload, dict):
        raise ValueError("unexpected token response")
    access_token = payload.get("access_token")
    if not isinstance(access_token, str) or not access_token or payload.get("token_type", "Bearer").lower() != "bearer":
        raise ValueError("invalid OAuth access token")
    try:
        expires = int(payload.get("expires_in", 300))
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid OAuth expiry") from exc
    if expires < 1 or expires > 86400:
        raise ValueError("invalid OAuth expiry")
    # Deliberately ignore refresh_token; never write any token to SQLite or logs.
    return access_token, expires


def account_me(access_token: str, *, transport: httpx.BaseTransport | None = None) -> dict[str, str]:
    with httpx.Client(timeout=10, follow_redirects=False, transport=transport) as client:
        response = client.get(ACCOUNT_ME, headers={"Authorization": f"Bearer {access_token}"})
        response.raise_for_status()
        body = response.json()
    if not isinstance(body, dict):
        raise ValueError("unexpected account response")
    puuid, game_name, tag_line = (body.get(k) for k in ("puuid", "gameName", "tagLine"))
    if not all(isinstance(x, str) and x and len(x) <= 128 for x in (puuid, game_name, tag_line)):
        raise ValueError("invalid account response")
    return {"puuid": puuid, "riot_id": f"{game_name}#{tag_line}"}

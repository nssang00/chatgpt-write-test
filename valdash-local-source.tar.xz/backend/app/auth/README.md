# 공식 Riot RSO 인증 모듈

`rso.py`는 **라이엇이 승인한 RSO 클라이언트에 한해** Authorization Code + Client Secret Basic 기반 계정 연결을 지원합니다.

- 비밀번호 입력·저장 및 2FA 대행을 하지 않습니다.
- `/authorize`로 이동하는 주소는 `auth.riotgames.com`으로 고정됩니다.
- 토큰 교환은 `/token`, 사용자 식별은 공식 Account API `/riot/account/v1/accounts/me`를 사용합니다.
- OAuth `state`는 서버 세션에 묶이고 5분 유효하며 한 번만 사용할 수 있습니다.
- Access Token은 앱 메모리에만 저장하고, Refresh Token은 보관하지 않습니다.
- PKCE는 승인된 클라이언트에 지원된 경우에만 선택적으로 사용합니다.
- 가상 게임 데이터와 Riot 로그인 식별은 절대 합치지 않습니다.

실제 사용에 필요한 승인 요건과 환경변수는 루트 `README.md`를 참고하세요.

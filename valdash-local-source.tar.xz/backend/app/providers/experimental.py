"""An explicit non-operational boundary for undocumented Riot endpoints.

Never scrape credentials, intercept browser cookies, or silently request tokens.
"""
from .base import Provider


class ExperimentalProvider(Provider):
    name = "disabled"

    def overview(self, scenario: str) -> dict:
        raise NotImplementedError("Unofficial provider has not been audited or enabled")

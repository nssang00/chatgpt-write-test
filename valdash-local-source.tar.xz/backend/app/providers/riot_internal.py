"""Read-only unofficial VALORANT client API adapter (experimental).

All requests are outbound to fixed Riot endpoints or public metadata; never
accept caller-provided URLs or relay tokens to the browser. Fail closed on
unknown responses; an upstream error is not evidence of no restriction.
"""
from __future__ import annotations

import base64
import json
import re
from typing import Any

import httpx

RIOT_USERINFO = "https://auth.riotgames.com/userinfo"
ENTITLEMENTS_URL = "https://entitlements.auth.riotgames.com/api/token/v1"
VERSION_URL = "https://valorant-api.com/v1/version"
VALID_SHARDS = {"kr", "ap", "na", "eu"}
PLAYER_ID_PATTERN = re.compile(r"^[0-9a-fA-F-]{36}$")
VP_ID = "85ad13f7-3d1b-5128-9eb2-7cd8ee0b5741"


class UpstreamUnavailable(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def riot_account(access_token: str, *, transport: httpx.BaseTransport | None = None) -> dict:
    try:
        with httpx.Client(timeout=10, transport=transport, follow_redirects=False) as client:
            response = client.get(RIOT_USERINFO, headers={"Authorization": "Bearer " + access_token})
            response.raise_for_status()
            payload = response.json()
        if not isinstance(payload, dict) or not isinstance(payload.get("sub"), str):
            raise ValueError("invalid profile")
        acct = payload.get("acct") or {}
        name = acct.get("game_name") or "Riot Account"
        tag = acct.get("tag_line") or ""
        if not isinstance(name, str) or not isinstance(tag, str):
            raise ValueError("invalid profile fields")
        return {"puuid": payload["sub"], "riot_id": name + ("#" + tag if tag else "")}
    except (httpx.HTTPError, ValueError, TypeError) as exc:
        raise UpstreamUnavailable("RIOT_ACCOUNT_LOOKUP_FAILED") from exc


def riot_entitlement(access_token: str, *, transport: httpx.BaseTransport | None = None) -> str:
    try:
        with httpx.Client(timeout=10, transport=transport, follow_redirects=False) as client:
            response = client.post(ENTITLEMENTS_URL, headers={"Authorization": "Bearer " + access_token}, json={})
            response.raise_for_status()
            payload = response.json()
        token = payload.get("entitlements_token")
        if not isinstance(token, str) or not token:
            raise ValueError("missing entitlement")
        return token
    except (httpx.HTTPError, ValueError, TypeError, AttributeError) as exc:
        raise UpstreamUnavailable("RIOT_ENTITLEMENT_FAILED") from exc


def client_headers(access_token: str, entitlement: str, *, transport: httpx.BaseTransport | None = None) -> dict:
    try:
        with httpx.Client(timeout=10, transport=transport, follow_redirects=False) as client:
            response = client.get(VERSION_URL)
            response.raise_for_status()
            version_data = response.json().get("data")
        version = version_data.get("riotClientVersion") if isinstance(version_data, dict) else None
        if not isinstance(version, str) or not version or len(version) > 200:
            raise ValueError("version unavailable")
    except (httpx.HTTPError, ValueError, TypeError, AttributeError) as exc:
        raise UpstreamUnavailable("CLIENT_VERSION_UNAVAILABLE") from exc
    platform = base64.b64encode(json.dumps({
        "platformType": "PC", "platformOS": "Windows",
        "platformOSVersion": "10.0.19045.1.256.64bit", "platformChipset": "Unknown",
    }, separators=(",", ":")).encode()).decode()
    return {
        "Authorization": "Bearer " + access_token,
        "X-Riot-Entitlements-JWT": entitlement,
        "X-Riot-ClientPlatform": platform,
        "X-Riot-ClientVersion": version,
    }


def validated_shard(shard: str) -> str:
    if shard not in VALID_SHARDS:
        raise UpstreamUnavailable("UNSUPPORTED_REGION")
    return shard


def store_response(payload: Any) -> dict:
    if not isinstance(payload, dict):
        raise UpstreamUnavailable("STORE_SCHEMA_UNSUPPORTED")
    layout = payload.get("SkinsPanelLayout")
    if not isinstance(layout, dict):
        raise UpstreamUnavailable("STORE_SCHEMA_UNSUPPORTED")
    item_ids = layout.get("SingleItemOffers")
    offers = layout.get("SingleItemStoreOffers")
    if not isinstance(item_ids, list) and not isinstance(offers, list):
        raise UpstreamUnavailable("STORE_SCHEMA_UNSUPPORTED")
    safe_offers = []
    for value in (offers or []):
        if not isinstance(value, dict):
            continue
        offer_id = value.get("OfferID")
        cost = value.get("Cost", {})
        if isinstance(offer_id, str) and isinstance(cost, dict):
            price = cost.get(VP_ID)
            if isinstance(price, int) and not isinstance(price, bool):
                safe_offers.append({"id": offer_id, "price_vp": price})
    if not safe_offers:
        safe_offers = [{"id": i, "price_vp": None} for i in (item_ids or []) if isinstance(i, str)]
    return {"offers": safe_offers[:20], "seconds_remaining": layout.get("SingleItemOffersRemainingDurationInSeconds")}


def penalties_response(payload: Any) -> dict:
    if not isinstance(payload, dict) or not isinstance(payload.get("Penalties"), list):
        raise UpstreamUnavailable("PENALTY_SCHEMA_UNSUPPORTED")
    parsed = []
    effects = (
        "GameBanEffect", "QueueRestrictionEffect", "QueueDelayEffect", "RankedRatingPenaltyEffect",
        "RiotRestrictionEffect", "WarningEffect", "PremierRestrictionEffect",
    )
    for item in payload["Penalties"]:
        if not isinstance(item, dict):
            continue
        parsed.append({
            "effects": [key for key in effects if item.get(key) is not None],
            "expiry": item.get("Expiry") if isinstance(item.get("Expiry"), str) else None,
            "games_remaining": item.get("GamesRemaining") if isinstance(item.get("GamesRemaining"), int) else None,
        })
    return {"returned_count": len(parsed), "records": parsed[:50],
            "disclaimer": "이 응답만으로 모든 차단 유형이 없다고 확정할 수 없습니다."}


def enrich_skin_names(offers: list[dict], *, transport: httpx.BaseTransport | None = None) -> list[dict]:
    """Best-effort public metadata lookup; no Riot credentials sent here."""
    output = []
    with httpx.Client(timeout=5, transport=transport, follow_redirects=False) as client:
        for original in offers:
            item = dict(original)
            item["name"] = None
            item_id = item.get("id", "")
            if isinstance(item_id, str) and PLAYER_ID_PATTERN.fullmatch(item_id):
                try:
                    response = client.get(f"https://valorant-api.com/v1/weapons/skinlevels/{item_id}",
                                          params={"language": "ko-KR"})
                    response.raise_for_status()
                    data = response.json().get("data")
                    name = data.get("displayName") if isinstance(data, dict) else None
                    if isinstance(name, str) and 0 < len(name) <= 200:
                        item["name"] = name
                except (httpx.HTTPError, ValueError, TypeError, AttributeError):
                    pass
            output.append(item)
    return output


def read_live_store(access_token: str, entitlement: str, puuid: str, shard: str, *,
                    transport: httpx.BaseTransport | None = None) -> dict:
    validated_shard(shard)
    if not PLAYER_ID_PATTERN.fullmatch(puuid):
        raise UpstreamUnavailable("INVALID_ACCOUNT_ID")
    headers = client_headers(access_token, entitlement, transport=transport)
    url = f"https://pd.{shard}.a.pvp.net/store/v3/storefront/{puuid}"
    try:
        with httpx.Client(timeout=15, transport=transport, follow_redirects=False) as client:
            response = client.post(url, headers=headers, json={})
            response.raise_for_status()
            result = store_response(response.json())
        result["offers"] = enrich_skin_names(result["offers"], transport=transport)
        return result
    except (httpx.HTTPError, ValueError, TypeError) as exc:
        raise UpstreamUnavailable("STORE_FETCH_FAILED") from exc


def read_live_penalties(access_token: str, entitlement: str, shard: str, *,
                        transport: httpx.BaseTransport | None = None) -> dict:
    validated_shard(shard)
    headers = client_headers(access_token, entitlement, transport=transport)
    url = f"https://pd.{shard}.a.pvp.net/restrictions/v3/penalties"
    try:
        with httpx.Client(timeout=15, transport=transport, follow_redirects=False) as client:
            response = client.get(url, headers=headers)
            response.raise_for_status()
            return penalties_response(response.json())
    except (httpx.HTTPError, ValueError, TypeError) as exc:
        raise UpstreamUnavailable("PENALTY_FETCH_FAILED") from exc

"""Clearly-labelled fake data, for building and testing the local UI."""
from datetime import datetime, timezone, timedelta
from .base import Provider


class MockProvider(Provider):
    name = "demo"

    def overview(self, scenario: str) -> dict:
        now = datetime.now(timezone.utc).isoformat()
        if scenario == "active":
            penalty = {
                "status": "active", "label": "매칭 참가 제한",
                "reason": "예시: 자리 비움 관련 제재", "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=45)).isoformat(),
                "type": "queue_restriction",
            }
        elif scenario == "unknown":
            penalty = {
                "status": "unavailable", "label": "조회 불가",
                "reason": "제공자 오류를 가정한 데모 시나리오", "expires_at": None,
                "type": None,
            }
        else:
            penalty = {
                "status": "clear", "label": "조회된 활성 제재 없음 (데모)",
                "reason": None, "expires_at": None, "type": None,
            }
        return {
            "mode": "demo", "live": False, "updated_at": now,
            "account": {"id": "demo-kr", "riot_id": "DEMO#0001", "region": "KR", "level": 184},
            "wallet": {"vp": 2475, "radianite": 45, "kingdom_credits": 8200},
            "rank": {"tier": "다이아몬드 2", "rr": 67, "season_wins": 34,
                     "recent_rr": [52, 63, 43, 56, 67], "recent_wins": [True, True, False, True, True]},
            "store": {
                "remaining_label": "실제 초기화 시간은 미조회", "daily_offers": [
                    {"id": "item-1", "name": "프라임 밴달", "weapon": "밴달", "price_vp": 1775, "rarity": "프리미엄", "palette": "gold"},
                    {"id": "item-2", "name": "리버 오퍼레이터", "weapon": "오퍼레이터", "price_vp": 1775, "rarity": "프리미엄", "palette": "violet"},
                    {"id": "item-3", "name": "가이아의 복수 고스트", "weapon": "고스트", "price_vp": 1775, "rarity": "프리미엄", "palette": "green"},
                    {"id": "item-4", "name": "아라크시스 쇼티", "weapon": "쇼티", "price_vp": 2175, "rarity": "익스클루시브", "palette": "rose"},
                ], "night_market": {"available": False, "label": "기간 정보 없음 (데모)"},
            },
            "penalty": penalty,
            "matches": [
                {"id": "m1", "map": "어센트", "agent": "제트", "result": "승리", "score": "13 : 9", "kda": "22 / 14 / 5", "rr_change": 11},
                {"id": "m2", "map": "헤이븐", "agent": "레이즈", "result": "승리", "score": "13 : 11", "kda": "19 / 17 / 8", "rr_change": 13},
                {"id": "m3", "map": "바인드", "agent": "제트", "result": "패배", "score": "10 : 13", "kda": "14 / 19 / 3", "rr_change": -20},
                {"id": "m4", "map": "로터스", "agent": "오멘", "result": "승리", "score": "13 : 7", "kda": "16 / 11 / 9", "rr_change": 13},
                {"id": "m5", "map": "선셋", "agent": "제트", "result": "승리", "score": "13 : 8", "kda": "24 / 13 / 4", "rr_change": 11},
            ],
            "inventory": {
                "total_skins": 28,
                "skins": [
                    {"name": "프라임 밴달", "weapon": "밴달", "equipped": True, "palette": "gold"},
                    {"name": "리버 팬텀", "weapon": "팬텀", "equipped": True, "palette": "violet"},
                    {"name": "가이아의 복수 고스트", "weapon": "고스트", "equipped": False, "palette": "green"},
                    {"name": "아이온 오퍼레이터", "weapon": "오퍼레이터", "equipped": False, "palette": "blue"},
                ],
            },
            "missions": [
                {"title": "데모 미션 · 스파이크 설치", "progress": 6, "goal": 10, "reward": "10,000 XP"},
                {"title": "데모 미션 · 라운드 플레이", "progress": 22, "goal": 30, "reward": "8,000 XP"},
            ],
        }

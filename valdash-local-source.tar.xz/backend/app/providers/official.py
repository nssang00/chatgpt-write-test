"""Future official RSO-backed provider. Requires Riot approval/credentials."""
from .base import Provider


class OfficialProvider(Provider):
    name = "official-unconfigured"

    def overview(self, scenario: str) -> dict:
        raise NotImplementedError("Riot Production/RSO approval required; no credentials are configured")

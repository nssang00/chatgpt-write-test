"""Data provider contract. No Riot client credentials are handled here."""
from abc import ABC, abstractmethod
from typing import Any


class Provider(ABC):
    name: str

    @abstractmethod
    def overview(self, scenario: str) -> dict[str, Any]:
        raise NotImplementedError

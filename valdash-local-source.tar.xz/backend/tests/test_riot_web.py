"""Mocked experimental Riot browser login tests. Never use real passwords."""
import time
from urllib.parse import urlsplit, parse_qs

import httpx
from fastapi.testclient import TestClient
import pytest

from backend.app.main import create_app
from backend.app.auth.riot_web import login_url, parse_riot_redirect, InteractiveLoginError
from backend.app.providers.riot_internal import store_response, penalties_response, UpstreamUnavailable

PUUID = "00000000-1111-2222-3333-444444444444"


def test_login_redirect_parser_rejects_token_theft_urls():
    params = parse_qs(urlsplit(login_url('very-random')).query)
    assert params['client_id'] == ['play-valorant-web-prod']
    assert params['nonce'] == ['very-random']
    assert parse_riot_redirect('https://playvalorant.com/opt_in#access_token=abc&expires_in=900') == ('abc',900)
    for url in (
        'https://evil.example/opt_in#access_token=leaked',
        'https://playvalorant.com.evil.example/opt_in#access_token=leaked',
        'http://playvalorant.com/opt_in#access_token=leaked',
        'https://playvalorant.com/admin#access_token=leaked',
        'https://playvalorant.com/opt_in#access_token=leaked&expires_in=-1',
        'https://playvalorant.com/opt_in#access_token=leaked&expires_in=no',
    ):
        assert parse_riot_redirect(url) is None


def test_store_parser_and_penalty_parser_fail_closed():
    parsed = store_response({'SkinsPanelLayout': {'SingleItemOffers':['offer-one'], 'SingleItemStoreOffers':[
        {'OfferID':'offer-one','Cost':{'85ad13f7-3d1b-5128-9eb2-7cd8ee0b5741':1775}}
    ]}})
    assert parsed['offers'] == [{'id':'offer-one','price_vp':1775}]
    assert penalties_response({'Penalties': []})['returned_count'] == 0
    with pytest.raises(UpstreamUnavailable):
        store_response({'error':'upstream format changed'})
    with pytest.raises(UpstreamUnavailable):
        penalties_response({})


def mock_riot_api(request: httpx.Request):
    assert 'secret-password' not in str(request.url)
    if request.url.path == '/userinfo':
        assert request.headers.get('authorization') == 'Bearer opaque-token'
        return httpx.Response(200, json={'sub':PUUID,'acct':{'game_name':'TestUser','tag_line':'KR1'}})
    if request.url.path == '/api/token/v1':
        return httpx.Response(200,json={'entitlements_token':'local-entitlement'})
    if request.url.path == '/v1/version':
        return httpx.Response(200,json={'data':{'riotClientVersion':'release-99.99-test'}})
    if '/store/v3/storefront/' in request.url.path:
        assert request.headers.get('x-riot-entitlements-jwt') == 'local-entitlement'
        return httpx.Response(200,json={'SkinsPanelLayout': {'SingleItemOffers':['offer-a','offer-b'],
            'SingleItemStoreOffers': [{'OfferID':'offer-a','Cost':{'85ad13f7-3d1b-5128-9eb2-7cd8ee0b5741':2175}}]}})
    if request.url.path == '/restrictions/v3/penalties':
        return httpx.Response(200,json={'Subject':PUUID,'Penalties':[{'Expiry':'2027-01-01T00:00:00Z','QueueRestrictionEffect':{'Duration':60}, 'GamesRemaining':0}]})
    raise AssertionError(f'unexpected upstream path: {request.url.path}')


def boot(app):
    client = TestClient(app)
    client.__enter__()
    csrf = client.post('/api/session/bootstrap',json={'launch_token':'x'*60}).json()['csrf_token']
    return client, {'X-CSRF-Token':csrf,'Origin':'http://testserver'}


def wait_status(client,expected='authenticated'):
    for _ in range(100):
        r=client.get('/api/auth/riot-web/status').json()
        if r['status'] != 'pending':
            break
        time.sleep(.01)
    assert r['status'] == expected, r
    return r


def test_user_web_login_fetches_real_like_data_without_exposing_tokens(tmp_path):
    app=create_app(test_mode=True,db_path=tmp_path/'data.db',launch_token='x'*60,
                   web_login=lambda:('opaque-token',900),
                   web_transport=httpx.MockTransport(mock_riot_api))
    client,csrf=boot(app)
    try:
        assert client.get('/api/live/store').status_code == 401
        assert client.post('/api/auth/riot-web/start',json={}).status_code == 403
        assert client.post('/api/auth/riot-web/start',json={},headers={**csrf,'Origin':'https://evil.example'}).status_code == 403
        r=client.post('/api/auth/riot-web/start',json={},headers=csrf)
        assert r.status_code == 200
        status=wait_status(client)
        assert status['account']['riot_id']=='TestUser#KR1'
        result=client.get('/api/live/store').json()
        assert result['live'] is True and result['store']['offers'][0]['price_vp']==2175
        penalty=client.get('/api/live/penalties').json()
        assert penalty['penalties']['returned_count']==1
        assert penalty['penalties']['records'][0]['effects']==['QueueRestrictionEffect']
        for payload in (r.json(), status, result, penalty, client.get('/api/session').json()):
            assert 'opaque-token' not in str(payload)
            assert 'local-entitlement' not in str(payload)
        assert client.post('/api/auth/riot-web/disconnect',json={},headers=csrf).status_code == 200
        assert client.get('/api/live/store').status_code == 401
    finally:
        client.__exit__(None,None,None)


def test_login_failure_is_not_mislabeled_as_no_ban(tmp_path):
    def failure():
        raise InteractiveLoginError('LOGIN_WINDOW_CLOSED')
    app=create_app(test_mode=True,db_path=tmp_path/'data.db',launch_token='x'*60, web_login=failure)
    client,csrf=boot(app)
    try:
        assert client.post('/api/auth/riot-web/start',json={},headers=csrf).status_code == 200
        assert wait_status(client,'error')['error']=='LOGIN_WINDOW_CLOSED'
        assert client.get('/api/live/penalties').status_code == 401
    finally:
        client.__exit__(None,None,None)


def test_expired_session_tokens_not_used(tmp_path):
    app=create_app(test_mode=True,db_path=tmp_path/'data.db',launch_token='x'*60,
                   web_login=lambda:('opaque-token',1),web_transport=httpx.MockTransport(mock_riot_api))
    client,csrf=boot(app)
    try:
        client.post('/api/auth/riot-web/start',json={},headers=csrf)
        wait_status(client)
        for session in app.state.sessions.values():
            session['web_credentials']['expires_at']=time.time()-1
        assert client.get('/api/live/penalties').status_code == 401
        assert client.get('/api/session').json()['web_connected'] is False
    finally:
        client.__exit__(None,None,None)

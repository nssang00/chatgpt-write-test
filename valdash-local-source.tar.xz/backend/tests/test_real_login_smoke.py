"""Smoke-test orchestrator tests: no third-party network or secrets used."""
import os

from scripts.real_login_smoke import live_smoke
from backend.app.auth.riot_web import InteractiveLoginError
from backend.app.providers.riot_internal import UpstreamUnavailable


def test_not_enabled_by_default(monkeypatch):
    monkeypatch.delenv('VALDASH_ALLOW_INTERACTIVE_LIVE_TEST', raising=False)
    log = []
    assert live_smoke(login=lambda: (_ for _ in ()).throw(AssertionError('must not login')),
                      output=log.append) == 2
    assert log == ['LIVE_TEST_DISABLED: set VALDASH_ALLOW_INTERACTIVE_LIVE_TEST=yes']


def test_only_counts_and_status_are_logged(monkeypatch):
    monkeypatch.setenv('VALDASH_ALLOW_INTERACTIVE_LIVE_TEST', 'yes')
    monkeypatch.setenv('VALDASH_SHARD', 'kr')
    log = []
    secret='secret-tkn-DO_NOT_PRINT'
    result=live_smoke(login=lambda:(secret,60),
                      get_account=lambda token:{'puuid':'test-private-puuid','riot_id':'PRIVATE#1234'},
                      get_entitlement=lambda token:'sensitive-jwt',
                      get_store=lambda token,ent,uid,shard:{'offers':[{'id':'skin-a'}]},
                      get_penalties=lambda token,ent,shard:{'returned_count':0,'records':[]},
                      output=log.append)
    assert result == 0
    assert log[-1] == 'LIVE_TEST_PASS'
    assert 'PRIVATE#1234' not in repr(log)
    assert 'test-private-puuid' not in repr(log)
    assert secret not in repr(log)
    assert 'sensitive-jwt' not in repr(log)


def test_captcha_wait_failure_is_handled(monkeypatch):
    monkeypatch.setenv('VALDASH_ALLOW_INTERACTIVE_LIVE_TEST', 'yes')
    log=[]
    def no_login():
        raise InteractiveLoginError('LOGIN_TIMEOUT')
    assert live_smoke(login=no_login, output=log.append)==1
    assert log[-1]=='LIVE_LOGIN_FAILED: LOGIN_TIMEOUT'


def test_store_error_does_not_report_no_penalty(monkeypatch):
    monkeypatch.setenv('VALDASH_ALLOW_INTERACTIVE_LIVE_TEST', 'yes')
    log=[]
    def error(*args):
        raise UpstreamUnavailable('STORE_FETCH_FAILED')
    assert live_smoke(login=lambda:('tkn',60), get_account=lambda token:{'puuid':'id'},
                      get_entitlement=lambda token:'ent', get_store=error,
                      output=log.append)==1
    assert 'LIVE_API_FAILED: STORE_FETCH_FAILED' in log
    assert not any('PENALTIES_OK' in line for line in log)

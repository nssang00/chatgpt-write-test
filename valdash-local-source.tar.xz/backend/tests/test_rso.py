"""Offline OAuth integration tests; NEVER contact Riot or store real credentials."""
from __future__ import annotations

import base64
import time
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

import httpx
import pytest
from fastapi.testclient import TestClient

from backend.app.auth.rso import RSOConfig
from backend.app.main import create_app


@pytest.fixture
def oauth_client(tmp_path: Path):
    requests = []

    def handle(req: httpx.Request) -> httpx.Response:
        requests.append(req)
        if req.url.path == "/token":
            assert req.url.host == "auth.riotgames.com"
            assert req.headers["authorization"] == "Basic " + base64.b64encode(b"test-client:test-secret").decode()
            data = parse_qs(req.content.decode())
            assert data["grant_type"] == ["authorization_code"]
            assert data["redirect_uri"] == ["http://127.0.0.1:8765/api/auth/riot/callback"]
            if data["code"] == ["rejected-code"]:
                return httpx.Response(400, json={"error": "invalid_grant", "debug": "do-not-expose"})
            return httpx.Response(200, json={"access_token": "very-private-access-token", "token_type": "Bearer",
                                              "expires_in": 240, "refresh_token": "very-private-refresh-token"})
        if req.url.path == "/riot/account/v1/accounts/me":
            assert req.url.host == "asia.api.riotgames.com"
            assert req.headers["authorization"] == "Bearer very-private-access-token"
            return httpx.Response(200, json={"puuid": "test-puuid", "gameName": "Verified", "tagLine": "KR1"})
        raise AssertionError(f"unexpected call: {req.url}")

    config = RSOConfig(client_id="test-client", client_secret="test-secret", approved=True,
                       redirect_uri="http://127.0.0.1:8765/api/auth/riot/callback")
    app = create_app(launch_token="z" * 60, db_path=tmp_path / "rso.sqlite3", port=8765,
                     test_mode=True, rso_config=config, rso_transport=httpx.MockTransport(handle))
    with TestClient(app) as client:
        result = client.post("/api/session/bootstrap", json={"launch_token": "z" * 60},
                             headers={"origin": "http://testserver"})
        assert result.status_code == 200
        yield client, app, result.json()["csrf_token"], requests


def begin(client, csrf):
    r = client.post("/api/auth/riot/start", json={}, headers={"X-CSRF-Token": csrf, "Origin": "http://testserver"})
    assert r.status_code == 200, r.text
    authorize_url = r.json()["authorize_url"]
    assert authorize_url.startswith("https://auth.riotgames.com/authorize?")
    params = parse_qs(urlsplit(authorize_url).query)
    assert params["client_id"] == ["test-client"]
    assert params["response_type"] == ["code"]
    assert params["scope"] == ["openid offline_access"]
    assert "test-secret" not in authorize_url
    return params["state"][0]


def test_oauth_login_returns_identity_only_and_retains_demo_mode(oauth_client):
    client, app, csrf, requests = oauth_client
    state = begin(client, csrf)
    response = client.get("/api/auth/riot/callback", params={"state": state, "code": "one-time-code"}, follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/?auth=connected"
    status = client.get("/api/session").json()
    assert status["riot_connected"] is True
    assert status["riot_account"] == {"puuid": "test-puuid", "riot_id": "Verified#KR1"}
    assert status["mode"] == "demo"
    for secret in ("test-secret", "very-private-access-token", "very-private-refresh-token"):
        assert secret not in str(status)
        assert secret not in str(client.get("/api/accounts").json())
        assert secret not in str(client.get("/api/providers").json())
    overview = client.get("/api/overview").json()
    assert overview["mode"] == "demo" and overview["live"] is False
    assert overview["account"]["riot_id"].startswith("DEMO")
    assert len(requests) == 2
    # Only the access token is stored in memory, refresh is not persisted.
    assert "very-private-refresh-token" not in str(app.state.sessions)
    assert client.get("/api/auth/riot/callback", params={"state": state, "code": "one-time-code"}).status_code == 403


def test_oauth_state_and_csrf_validation(oauth_client):
    client, app, csrf, requests = oauth_client
    assert client.post("/api/auth/riot/start", json={}).status_code == 403
    assert client.post("/api/auth/riot/start", json={}, headers={"X-CSRF-Token": csrf, "Origin": "https://bad.example"}).status_code == 403
    assert client.get("/api/auth/riot/callback", params={"code": "one-time-code", "state": "forged"}).status_code == 403
    state = begin(client, csrf)
    app.state.oauth_pending[state]["expires_at"] = time.time() - 2
    assert client.get("/api/auth/riot/callback", params={"code": "one-time-code", "state": state}).status_code == 403
    assert len(requests) == 0


def test_auth_denial_and_failed_exchange_never_mark_connected(oauth_client):
    client, app, csrf, requests = oauth_client
    state = begin(client, csrf)
    response = client.get("/api/auth/riot/callback", params={"state": state, "error": "access_denied"}, follow_redirects=False)
    assert response.status_code == 303
    assert client.get("/api/session").json()["riot_connected"] is False
    state = begin(client, csrf)
    response = client.get("/api/auth/riot/callback", params={"state": state, "code": "rejected-code"}, follow_redirects=False)
    assert response.status_code == 303 and response.headers["location"] == "/?auth=error"
    status = client.get("/api/session").json()
    assert status["riot_connected"] is False
    assert "do-not-expose" not in str(status)


def test_disconnect_and_expiry(oauth_client):
    client, app, csrf, requests = oauth_client
    state = begin(client, csrf)
    client.get("/api/auth/riot/callback", params={"state": state, "code": "one-time-code"}, follow_redirects=False)
    assert client.post("/api/auth/riot/disconnect", json={}).status_code == 403
    r = client.post("/api/auth/riot/disconnect", json={}, headers={"X-CSRF-Token":csrf})
    assert r.status_code == 200
    assert not client.get("/api/session").json()["riot_connected"]
    state = begin(client, csrf)
    client.get("/api/auth/riot/callback", params={"state": state, "code": "one-time-code"}, follow_redirects=False)
    for ses in app.state.sessions.values():
        ses["riot_token_expires_at"] = time.time() - 1
    assert client.get("/api/session").json()["riot_connected"] is False
    assert all("riot_token" not in ses for ses in app.state.sessions.values())


def test_config_gate_rejects_unapproved_and_wrong_callback(tmp_path):
    for config in (
        RSOConfig(client_id="a", client_secret="b", redirect_uri="http://127.0.0.1:8765/api/auth/riot/callback"),
        RSOConfig(client_id="a", client_secret="b", redirect_uri="http://bad.example/callback", approved=True),
        RSOConfig(client_id="a", client_secret="", redirect_uri="http://127.0.0.1:8765/api/auth/riot/callback", approved=True),
    ):
        app = create_app(test_mode=True, db_path=tmp_path / f"{len(str(config))}.db",
                         launch_token="a" * 60, rso_config=config)
        with TestClient(app) as c:
            r = c.post("/api/session/bootstrap", json={"launch_token":"a"*60})
            assert r.status_code == 200
            status = c.get("/api/session").json()
            assert status["riot_login_available"] is False
            response = c.post("/api/auth/riot/start", json={}, headers={"X-CSRF-Token":status["csrf_token"]})
            assert response.status_code == 501
            assert c.get("/api/auth/riot/status").json()["enabled"] is False


def test_pkce_optional_and_verifier_passed(tmp_path):
    def mocked(req: httpx.Request):
        if req.url.path == "/token":
            form = parse_qs(req.content.decode())
            assert len(form["code_verifier"][0]) >= 43
            return httpx.Response(200, json={"access_token":"x","token_type":"Bearer","expires_in":10})
        return httpx.Response(200,json={"puuid":"p","gameName":"A","tagLine":"B"})
    config=RSOConfig(client_id="a",client_secret="b",redirect_uri="http://127.0.0.1:8765/api/auth/riot/callback", approved=True,use_pkce=True)
    app=create_app(test_mode=True,db_path=tmp_path/"pkce.db",launch_token="t"*50,rso_config=config,rso_transport=httpx.MockTransport(mocked))
    with TestClient(app) as c:
        csrf=c.post("/api/session/bootstrap",json={"launch_token":"t"*50}).json()["csrf_token"]
        r=c.post("/api/auth/riot/start",json={},headers={"X-CSRF-Token":csrf})
        qs=parse_qs(urlsplit(r.json()["authorize_url"]).query)
        assert qs["code_challenge_method"] == ["S256"]
        res=c.get("/api/auth/riot/callback",params={"state":qs["state"][0],"code":"hello"},follow_redirects=False)
        assert res.status_code==303

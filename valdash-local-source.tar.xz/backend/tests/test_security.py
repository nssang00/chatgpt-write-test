from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from backend.app.main import create_app, SESSION_COOKIE


@pytest.fixture
def client(tmp_path: Path):
    app = create_app(launch_token="test-" + "x" * 65, db_path=tmp_path / "demo.db", test_mode=True)
    with TestClient(app) as client:
        yield client, app


def boot(client: TestClient, app):
    result = client.post("/api/session/bootstrap", json={"launch_token": app.state.launch_token}, headers={"Origin": "http://testserver"})
    assert result.status_code == 200, result.text
    return result.json()["csrf_token"]


def test_unauthenticated_access_is_denied(client):
    c, _ = client
    assert c.get("/api/overview").status_code == 401
    assert c.get("/api/accounts").status_code == 401
    assert c.get("/api/history").status_code == 401


def test_bad_launch_token_rejected(client):
    c, app = client
    r = c.post("/api/session/bootstrap", json={"launch_token": "bad-" + "x"*60})
    assert r.status_code == 403
    assert app.state.launch_token_used is False


def test_bootstrap_one_time_and_session_cookie(client):
    c, app = client
    token = app.state.launch_token
    csrf = boot(c, app)
    assert csrf
    assert c.cookies.get(SESSION_COOKIE)
    assert app.state.launch_token == ""
    assert app.state.launch_token_used is True
    assert c.get("/api/session").json()["riot_connected"] is False
    assert c.post("/api/session/bootstrap", json={"launch_token": token}).status_code == 403


def test_readonly_demo_data(client):
    c, app = client
    boot(c, app)
    data = c.get("/api/overview").json()
    assert data["mode"] == "demo" and data["live"] is False
    assert len(data["store"]["daily_offers"]) == 4
    assert data["account"]["riot_id"].startswith("DEMO")
    assert "csrf_token" not in data
    assert c.get("/api/penalties").json()["live"] is False
    assert c.get("/api/providers").json()["current"] == "demo"


def test_csrf_and_origin_protection(client):
    c, app = client
    csrf = boot(c, app)
    assert c.post("/api/demo/scenario", json={"scenario": "active"}).status_code == 403
    assert c.post("/api/demo/scenario", json={"scenario": "active"}, headers={"X-CSRF-Token":csrf, "Origin": "https://evil.example"}).status_code == 403
    assert c.post("/api/demo/scenario", json={"scenario": "active"}, headers={"X-CSRF-Token":csrf, "Sec-Fetch-Site": "cross-site"}).status_code == 403
    assert c.post("/api/demo/scenario", content="scenario=active", headers={"X-CSRF-Token":csrf}).status_code == 415


def test_scenarios_and_error_handling(client):
    c, app = client
    csrf = boot(c, app)
    headers={"X-CSRF-Token":csrf,"Origin":"http://testserver"}
    assert c.post("/api/demo/scenario", json={"scenario": "active"}, headers=headers).status_code == 200
    assert c.get("/api/penalties").json()["penalty"]["status"] == "active"
    assert c.post("/api/demo/scenario", json={"scenario": "unknown"}, headers=headers).status_code == 200
    assert c.get("/api/penalties").json()["penalty"]["status"] == "unavailable"
    assert c.post("/api/demo/scenario", json={"scenario": "undefined"}, headers=headers).status_code == 422


def test_refresh_history_and_logout(client):
    c, app = client
    csrf = boot(c, app)
    h={"X-CSRF-Token":csrf,"Origin":"http://testserver"}
    assert c.post("/api/data/refresh", json={}, headers=h).status_code == 200
    assert len(c.get("/api/history").json()["items"]) == 1
    assert c.post("/api/session/logout", json={}, headers=h).status_code == 200
    assert c.get("/api/overview").status_code == 401


def test_riot_auth_is_explicitly_disabled(client):
    c, app = client
    csrf = boot(c, app)
    r=c.post("/api/auth/riot/start", json={}, headers={"X-CSRF-Token":csrf})
    assert r.status_code == 501
    assert r.json()["live"] is False


def test_dns_rebinding_host_header_denied(client):
    c, app = client
    r = c.get("/api/health", headers={"Host":"attacker.example"})
    assert r.status_code == 400


def test_csp_and_no_store(client):
    c, app = client
    r=c.get("/")
    assert r.status_code == 200
    assert "script-src 'self'" in r.headers["content-security-policy"]
    assert r.headers["cache-control"] == "no-store"
    assert r.headers["referrer-policy"] == "no-referrer"

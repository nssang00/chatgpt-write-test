/* VAL DASH standalone frontend. Fully offline, no external scripts or styles. */
(() => {
  'use strict';
  const root = document.getElementById('root');
  const PAGES = [
    ['overview', '◫', '대시보드'], ['store', '▣', '오늘의 상점'],
    ['penalties', '◇', '계정 제재'], ['rank', '▥', '랭크 · 전적'],
    ['inventory', '▤', '보유 아이템'], ['settings', '⚙', '설정'],
  ];
  const state = { page: 'overview', csrf: '', data: null, providers: null, history: [], modal: false, toast: '', riot: null, web: null, storeLive: null, penaltiesLive: null, liveError: '' };
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const num = v => Number(v || 0).toLocaleString('ko-KR');
  const date = v => v ? new Date(v).toLocaleString('ko-KR', { hour12: false }) : '없음';
  const pct = (n, max) => Math.max(0, Math.min(100, max ? Math.round(n / max * 100) : 0));

  async function api(path, options = {}) {
    const hasBody = options.body !== undefined;
    const headers = { ...(hasBody ? { 'Content-Type': 'application/json' } : {}), ...(options.method === 'POST' && state.csrf ? {'X-CSRF-Token':state.csrf} : {}) };
    const response = await fetch(path, { credentials: 'same-origin', ...options, headers: {...headers, ...(options.headers || {})} });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const details = typeof data.detail === 'object' ? data.detail : data;
      throw new Error(details.message || details.code || `HTTP ${response.status}`);
    }
    return data;
  }

  function msg(text) {
    state.toast = text;
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();
    const div = document.createElement('div');
    div.className = 'toast';
    div.textContent = text;
    document.body.appendChild(div);
    window.setTimeout(() => div.remove(), 3800);
  }

  function navButton(page, icon, label) {
    return `<button type="button" data-page="${page}" class="nav-item ${state.page === page ? 'active' : ''}" aria-current="${state.page === page ? 'page' : 'false'}"><span class="nav-icon" aria-hidden="true">${icon}</span><span>${label}</span></button>`;
  }
  function section(title, subtitle = '') {
    return `<div class="heading-row"><div><h2 class="section-title">${title}</h2>${subtitle ? `<div class="section-desc">${subtitle}</div>` : ''}</div></div>`;
  }
  function metric(title, value, foot, icon, cls = '') {
    return `<div class="panel metric"><div class="metric-kicker"><span>${title}</span><span class="metric-icon" aria-hidden="true">${icon}</span></div><div class="metric-value ${cls}">${value}</div><div class="metric-foot">${foot}</div></div>`;
  }
  function storeCards(offers) {
    return `<div class="grid store-grid">${offers.map(x => `<article class="panel store-card"><div class="store-art ${esc(x.palette)}"><div class="weapon-art" aria-hidden="true"></div></div><div class="store-copy"><div class="item-type">${esc(x.rarity)} · ${esc(x.weapon)}</div><div class="item-name">${esc(x.name)}</div><div class="item-price">${num(x.price_vp)} <span>VP</span></div></div></article>`).join('')}</div>`;
  }
  function penaltiesCard(penalty) {
    const active = penalty.status === 'active';
    const unknown = penalty.status === 'unavailable';
    const tone = active ? 'accent-text' : unknown ? 'warn' : 'good';
    return `<div class="panel"><div class="panel-heading"><div class="panel-title">계정 제재 상태</div><span class="pill ${unknown ? 'warning' : ''}">가상 시나리오</span></div><div class="small">현재 API 응답 상태를 가정한 예시</div><div class="large-status ${tone}">${esc(penalty.label)}</div><div class="data-rows" style="margin-top:17px"><div class="data-row"><span class="key">제재 유형</span><span class="val">${esc(penalty.type || '없음 / 알 수 없음')}</span></div><div class="data-row"><span class="key">해제 시각</span><span class="val">${esc(penalty.expires_at ? date(penalty.expires_at) : '미제공')}</span></div><div class="data-row"><span class="key">설명</span><span class="val">${esc(penalty.reason || '활성 제재 없음 시나리오')}</span></div></div></div>`;
  }
  function matchItems(matches) {
    return `<div class="matches">${matches.map(m => `<div class="match"><div class="match-result ${m.result === '승리' ? 'win' : 'loss'}">${m.result === '승리' ? 'WIN' : 'LOSE'}</div><div style="flex:1"><div class="map">${esc(m.map)} <span class="small">${esc(m.score)}</span></div><div class="agent">${esc(m.agent)}</div></div><div class="kda">${esc(m.kda)}</div><div class="rr ${m.rr_change > 0 ? 'good' : 'accent-text'}">${m.rr_change > 0 ? '+' : ''}${m.rr_change} RR</div></div>`).join('')}</div>`;
  }
  function rrChart(rr) {
    const vals = rr.map(Number);
    const step = 100 / Math.max(1, vals.length - 1);
    const pts = vals.map((v, i) => `${(i * step).toFixed(2)},${(100 - Math.max(0, Math.min(100, v))).toFixed(2)}`).join(' ');
    return `<div class="chart-box"><svg viewBox="-4 -10 108 124" role="img" aria-label="데모 최근 5경기 RR 변화"><line x1="0" y1="100" x2="100" y2="100" stroke="#394858" stroke-width=".7"/><line x1="0" y1="50" x2="100" y2="50" stroke="#2b3948" stroke-width=".7" stroke-dasharray="2 3"/><polyline points="${pts}" fill="none" stroke="#ff6171" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>${vals.map((v, i) => `<circle cx="${(i*step).toFixed(2)}" cy="${100 - v}" r="2.8" fill="#ff7480" stroke="#0d1520" stroke-width="1.5"/>`).join('')}</svg></div><div class="chart-labels"><span>이전 경기</span><span>최근 경기</span></div>`;
  }
  function missions(items) {
    return items.map(x => `<div style="margin-bottom:18px"><div class="data-row"><strong>${esc(x.title)}</strong><span class="small">${num(x.progress)} / ${num(x.goal)}</span></div><div class="bar-track"><div class="bar-fill" style="width:${pct(x.progress,x.goal)}%"></div></div><div class="small">보상: ${esc(x.reward)}</div></div>`).join('');
  }

  function home(d) {
    return `<div class="grid metrics">
      ${metric('현재 랭크', esc(d.rank.tier), `${d.rank.rr} RR · 데모`, '♛')}
      ${metric('오늘의 상점', `${d.store.daily_offers.length}개`, '가상 스킨 목록', '▣', 'accent')}
      ${metric('VP 잔액', `${num(d.wallet.vp)} VP`, '실제 잔액과 무관', '◈', 'blue')}
      ${metric('제재 상태', d.penalty.status === 'active' ? '제한 중' : d.penalty.status === 'unavailable' ? '조회 불가' : '제재 없음', '가상 상태', '◇', d.penalty.status === 'active' ? 'accent' : '')}
    </div>
    ${section('오늘의 상점 미리보기','4개 상품 모두 가상 데이터')}
    ${storeCards(d.store.daily_offers)}
    ${section('계정 현황','랭크 및 제재 예시')}
    <div class="grid two-col">
      <div class="panel"><div class="panel-heading"><span class="panel-title">최근 RR 변동</span><span class="tag">${esc(d.rank.tier)}</span></div>${rrChart(d.rank.recent_rr)}<div class="data-row" style="margin-top:12px"><span class="key">현재 RR</span><span class="val">${d.rank.rr} / 100</span></div></div>
      ${penaltiesCard(d.penalty)}
    </div>
    ${section('최근 경기','실제 경기 전적이 아님')}
    <div class="panel">${matchItems(d.matches.slice(0,3))}</div>`;
  }
  function storePage(d) {
    return `<div class="info-box"><span>▣</span><div><b>오늘의 개인 상점 · DEMO</b><div>상점 구성과 가격은 개발 테스트용 예시입니다. 실제 계정 상점과 무관합니다.</div></div></div>
    ${section('일일 상점',esc(d.store.remaining_label))}${storeCards(d.store.daily_offers)}
    ${section('야시장')}<div class="panel"><div class="panel-title">${esc(d.store.night_market.label)}</div><p class="small">실제 야시장 기간과 할인 가격을 조회하지 않습니다.</p></div>`;
  }
  function penaltyPage(d) {
    return `<div class="grid two-col">${penaltiesCard(d.penalty)}<div class="panel"><div class="panel-title">상태 테스트</div><p class="small">실제 계정 제재 조회가 아닙니다. 다음 시나리오를 전환해 화면 동작을 확인할 수 있습니다.</p><div class="choice-row" style="margin-top:17px">${scenarioChoices(d.scenario)}</div></div></div>
    ${section('제재 조회 해석 기준')}<div class="panel"><div class="data-rows"><div class="data-row"><span class="key">활성 제재 확인</span><span class="val">제재 유형·만료 정보 표시</span></div><div class="data-row"><span class="key">제재 응답 없음</span><span class="val">해당 조회 범위에서만 없음</span></div><div class="data-row"><span class="key">요청 실패</span><span class="val warn">제재 없음으로 처리하지 않음</span></div><div class="data-row"><span class="key">HWID 제한 등</span><span class="val">포괄적 조회 여부 검증되지 않음</span></div></div></div>`;
  }
  function rankPage(d) {
    const wins = d.matches.filter(x => x.result === '승리').length;
    return `<div class="grid metrics">${metric('현재 티어',esc(d.rank.tier),'가상 티어','♛')}${metric('RR',`${d.rank.rr} / 100`,'가상 랭크 포인트','↗','blue')}${metric('최근 5경기',`${wins}승 ${d.matches.length-wins}패`,'테스트 기록','◫')}${metric('최근 승률',`${pct(wins,d.matches.length)}%`,'데모 경기 기준','◉')}</div>${section('RR 추이')}<div class="panel">${rrChart(d.rank.recent_rr)}</div>${section('최근 경기 기록')}<div class="panel">${matchItems(d.matches)}</div>`;
  }
  function inventoryPage(d) {
    return `<div class="grid metrics">${metric('보유 스킨',`${num(d.inventory.total_skins)}개`,'가상 컬렉션','▤')}${metric('VP',`${num(d.wallet.vp)}`,'가상 재화','◈')}${metric('레디어나이트',`${num(d.wallet.radianite)}`,'가상 재화','✧')}${metric('킹덤 크레딧',`${num(d.wallet.kingdom_credits)}`,'가상 재화','◇')}</div>${section('보유 스킨 미리보기')}<div class="grid store-grid">${d.inventory.skins.map(x=>`<div class="panel store-card"><div class="store-art ${esc(x.palette)}"><div class="weapon-art" aria-hidden="true"></div></div><div class="store-copy"><div class="item-type">${esc(x.weapon)}</div><div class="item-name">${esc(x.name)}</div><span class="tag ${x.equipped ? 'green' : ''}">${x.equipped?'장착 예시':'보유 예시'}</span></div></div>`).join('')}</div>${section('데모 미션')}<div class="panel">${missions(d.missions)}</div>`;
  }
  function scenarioChoices(scenario) {
    return [['clear','활성 제재 없음'],['active','제재 중'],['unknown','조회 오류']].map(x => `<button type="button" class="choice-btn ${scenario === x[0] ? 'active' : ''}" data-scenario="${x[0]}">${x[1]}</button>`).join('');
  }
  function settingsPage(d) {
    return `<div class="grid two-col">
      <div class="panel"><div class="panel-heading"><span class="panel-title">데이터 연결 상태</span><span class="pill warning">${state.riot?.riot_connected ? "계정 연결됨 · DEMO" : "실계정 미연동"}</span></div><div class="data-rows"><div class="data-row"><span class="key">데이터 공급자</span><span class="val">MockProvider</span></div><div class="data-row"><span class="key">공식 RSO</span><span class="val">${state.riot?.riot_login_available ? '사용 가능' : '승인·설정 필요'}</span></div><div class="data-row"><span class="key">비공식 API</span><span class="val">실험적 연동</span></div><div class="data-row"><span class="key">저장되는 데이터</span><span class="val">데모 설정 · 조회 기록</span></div><div class="data-row"><span class="key">실계정 비밀번호</span><span class="val good">수집하지 않음</span></div></div><button type="button" class="btn muted" data-action="connect" style="margin-top:18px">라이엇 계정 연결 정보</button></div>
      <div class="panel"><div class="panel-title">제재 상태 시나리오</div><p class="small">제재 없음 / 제재 중 / API 조회 실패의 UI를 테스트합니다.</p><div class="choice-row">${scenarioChoices(d.scenario)}</div><p class="small" style="margin-top:21px">변경한 설정은 로컬 SQLite에만 저장됩니다.</p></div>
    </div>${section('데모 조회 기록')}<div class="panel">${state.history.length ? `<table class="table-like"><thead><tr><th>조회 시각 (로컬 시간)</th><th>데이터 원본</th></tr></thead><tbody>${state.history.map(x=>`<tr><td>${esc(date(x.at))}</td><td><span class="tag">${esc(x.source)}</span></td></tr>`).join('')}</tbody></table>` : '<div class="empty">조회 기록이 없습니다. 상단의 새로고침을 눌러보세요.</div>'}</div>
    ${section('참고 자료')}<div class="panel"><p class="small">라이엇 공식 개발자 정책과 이 프로그램의 계정 연결 제약을 확인할 수 있습니다.</p><a href="https://developer.riotgames.com/docs/valorant" target="_blank" rel="noopener noreferrer">Riot Developer Portal — VALORANT 정책</a><p class="small" style="margin-top:15px">이 앱은 Riot Games와 관련이 없으며 승인 또는 후원받지 않았습니다.</p></div>`;
  }

  function modal() {
    const connected = state.riot?.riot_connected;
    const available = state.riot?.riot_login_available;
    const label = connected ? `인증 계정: ${esc(state.riot.riot_account.riot_id)}` : (available ? '공식 라이엇 페이지에서 로그인할 수 있습니다.' : '승인된 Riot RSO 클라이언트와 등록된 콜백이 필요합니다.');
    return `<div class="modal-backdrop" role="presentation"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-heading"><h2 id="modal-heading">라이엇 계정 연결</h2><p>${label}</p><p>계정을 연결하더라도 상점·제재·랭크·재화는 모두 가상 데이터입니다. 라이엇 비밀번호는 VAL DASH에 입력하지 마세요.</p><div class="choice-row">${connected ? '<button type="button" class="btn primary" data-action="riot-disconnect">연결 해제</button>' : `<button type="button" class="btn primary" data-action="riot-login" ${available ? '' : 'disabled'}>라이엇 공식 로그인</button>`}<button type="button" class="btn muted" data-action="close-modal">닫기</button></div></div></div>`;
  }
  function livePanel() {
    const connected = state.web?.account;
    const stat = state.web?.status || 'idle';
    const pending = stat === 'pending';
    let offers = state.storeLive?.store?.offers || [];
    let records = state.penaltiesLive?.penalties?.records || [];
    return `<div class="panel" style="margin-bottom:22px"><div class="panel-heading"><strong class="panel-title">실제 계정 조회 · 실험적</strong><span class="pill warning">UNOFFICIAL</span></div>
      <p class="small">별도의 라이엇 공식 로그인 창에서 아이디·비밀번호·2차 인증을 직접 입력합니다. VAL DASH는 비밀번호를 받거나 저장하지 않습니다. 라이엇 정책과 인증 변경으로 동작이 중단될 수 있습니다.</p>
      <div class="choice-row" style="margin-top:14px">
      ${connected ? `<button type="button" class="btn primary" data-action="web-store">실제 상점 조회</button><button type="button" class="btn primary" data-action="web-penalties">실제 제재 조회</button><button type="button" class="btn muted" data-action="web-disconnect">연결 해제</button>` : `<button type="button" class="btn primary" data-action="web-login" ${pending?'disabled':''}>${pending?'로그인 진행 중…':'라이엇 계정으로 로그인'}</button>`}
      <button type="button" class="btn muted" data-action="web-status">상태 갱신</button></div>
      <p class="small">${connected ? `연결된 계정: ${esc(connected.riot_id)}` : pending ? '새 로그인 창에서 인증을 진행하세요.' : stat==='error'?'인증 실패: '+esc(state.web.error||'UNKNOWN') : '실계정 미연동'}</p>
      ${state.liveError?`<p class="warn">${esc(state.liveError)}</p>`:''}
      ${state.storeLive?.live?`<h3 class="small-title">실제 상점 응답</h3>${offers.map(o=>`<div class="data-row"><span class="key">${esc(o.name||o.id)}</span><strong>${o.price_vp===null?'가격 미확인':num(o.price_vp)+' VP'}</strong></div>`).join('')}<p class="small">스킨 이름 매핑은 미구현입니다.</p>`:''}
      ${state.penaltiesLive?.live?`<h3 class="small-title">실제 제재 API 응답 ${state.penaltiesLive.penalties.returned_count}건</h3><p class="small">${esc(state.penaltiesLive.penalties.disclaimer)}</p>${records.map(o=>`<p class="small">${esc(o.effects.join(', ')||'미상')} · ${esc(o.expiry||'만료 미제공')}</p>`).join('')}`:''}
    </div>`;
  }

  async function updateWebStatus() {
    try { state.web = await api('/api/auth/riot-web/status'); render(); } catch (error) {state.liveError = String(error.message);render();}
  }
  function render() {
    const d = state.data;
    if (!d) return;
    const pageName = PAGES.find(x => x[0] === state.page)?.[2] || '대시보드';
    const page = ({ overview:home, store:storePage, penalties:penaltyPage, rank:rankPage, inventory:inventoryPage, settings:settingsPage }[state.page] || home)(d);
    root.innerHTML = `<div class="app">
      <aside class="sidebar" aria-label="메인 메뉴"><div class="brand"><span class="brand-icon">V</span><div>VAL DASH<small>LOCAL COMPANION</small></div></div><div class="side-label">WORKSPACE</div><nav class="nav">${PAGES.map(x=>navButton(...x)).join('')}</nav><div class="side-bottom"><div class="small-title"><span class="dot"></span> DEMO MODE</div><p>${state.riot?.riot_connected ? 'Riot 계정 인증됨 (게임 데이터 DEMO)' : 'Riot RSO · 승인 시 로그인'}<br>로컬 서버 · 개인 PC</p><button type="button" data-action="logout" class="btn muted">로컬 세션 종료</button></div></aside>
      <main class="content"><header class="topbar"><div><div class="breadcrumb">VAL DASH / ${esc(pageName)}</div><h1 class="top-title">${esc(pageName)}</h1></div><div class="account-actions"><span class="pill">● DEMO DATA</span><button type="button" class="btn muted" data-action="connect">${state.riot?.riot_connected ? esc(state.riot.riot_account.riot_id) : '계정 연결'}</button><button type="button" class="btn primary" data-action="refresh">↻ 새로고침</button></div></header>
      <div class="notice"><div><strong>이 화면의 모든 계정 데이터는 가상입니다</strong><p>발로란트 설치 없이 실행할 수 있는 로컬 웹앱 프로토타입. 실제 상점·제재·랭크를 조회하지 않습니다.</p></div><span class="notice-icon" aria-hidden="true">⚠</span></div>
      ${livePanel()}
      ${page}
      <div class="footer">VAL DASH v0.3.0 · Demo below / experimental live above · Updated: ${esc(date(d.updated_at))}</div>
      </main><nav class="mobile-nav" aria-label="모바일 메뉴">${PAGES.slice(0,5).map(x=>navButton(...x)).join('')}</nav>
    </div>${state.modal ? modal() : ''}`;
  }
  function renderLocked(error) {
    root.innerHTML = `<div class="locked"><div class="brand-icon">V</div><h1>로컬 세션이 없습니다</h1><p>안전한 접근을 위해 프로그램이 열어준 브라우저 탭에서만 세션을 시작할 수 있습니다. 터미널에서 프로그램을 종료한 후 <code>python run_local.py</code>로 다시 실행하세요.</p><p class="error-text">${esc(error || '실행 인증이 필요합니다.')}</p><p class="small">라이엇 계정 ID, 비밀번호를 입력하지 마세요. 이 앱은 실계정 로그인을 제공하지 않습니다.</p></div>`;
  }
  async function reload() {
    const [d, h] = await Promise.all([api('/api/overview'), api('/api/history')]);
    state.data = d;
    state.history = h.items;
    render();
  }
  async function init() {
    // The fragment is never sent to the HTTP server. Clear it immediately.
    const fragment = window.location.hash;
    const token = fragment.startsWith('#launch=') ? decodeURIComponent(fragment.slice(8)) : null;
    if (fragment) history.replaceState(null, '', window.location.pathname + window.location.search);
    try {
      if (token) {
        const boot = await api('/api/session/bootstrap', {method:'POST',body:JSON.stringify({ launch_token: token })});
        state.csrf = boot.csrf_token;
      }
      const status = await api('/api/session');
      state.csrf = status.csrf_token;
      state.riot = status;
      await reload();
      const authResult = new URLSearchParams(window.location.search).get('auth');
      state.web = await api('/api/auth/riot-web/status');
      render();
      if (authResult) {
        history.replaceState(null, '', window.location.pathname);
        msg(status.riot_auth_error || (status.riot_connected ? '라이엇 계정 인증 완료. 게임 정보는 계속 가상 데이터입니다.' : '로그인 취소 또는 실패'));
      }
    } catch (error) {
      renderLocked(error.message);
    }
  }
  root.addEventListener('click', async (event) => {
    const el = event.target.closest('button');
    if (!el || !root.contains(el)) return;
    if (el.dataset.page) {
      state.page = el.dataset.page;
      render();
      return;
    }
    if (el.dataset.action === 'connect') { state.modal = true; render(); return; }
    if (el.dataset.action === 'close-modal') { state.modal = false; render(); return; }
    if (el.dataset.action === 'web-login') {
      try {
        await api('/api/auth/riot-web/start', {method:'POST',body:'{}'});
        state.liveError = '';state.web = {status:'pending',account:null,error:null};render();
        const poll = setInterval(async () => {
          try {const result = await api('/api/auth/riot-web/status');state.web = result;render();if(result.status!=='pending')clearInterval(poll);}
          catch {clearInterval(poll);}
        }, 1600);
      } catch (error) {msg('로그인 시작 실패: '+error.message);}
      return;
    }
    if (el.dataset.action === 'web-status') {await updateWebStatus();return;}
    if (el.dataset.action === 'web-store') {
      try {state.liveError='';state.storeLive=await api('/api/live/store');} catch(e){state.storeLive=null;state.liveError='상점 조회 실패: '+e.message;}render();return;
    }
    if (el.dataset.action === 'web-penalties') {
      try {state.liveError='';state.penaltiesLive=await api('/api/live/penalties');} catch(e){state.penaltiesLive=null;state.liveError='제재 조회 실패: '+e.message;}render();return;
    }
    if (el.dataset.action === 'web-disconnect') {
      try {await api('/api/auth/riot-web/disconnect',{method:'POST',body:'{}'});state.storeLive=null;state.penaltiesLive=null;state.liveError='';await updateWebStatus();}catch(e){msg('연결 해제 실패: '+e.message);}return;
    }
    if (el.dataset.action === 'riot-login') {
      try {
        const r = await api('/api/auth/riot/start', {method:'POST', body:'{}'});
        const u = new URL(r.authorize_url);
        if (u.origin !== 'https://auth.riotgames.com' || u.pathname !== '/authorize') throw new Error('허용되지 않은 인증 URL');
        window.location.assign(r.authorize_url);
      } catch (error) {msg(`인증 시작 실패: ${error.message}`);} return;
    }
    if (el.dataset.action === 'riot-disconnect') {
      try {await api('/api/auth/riot/disconnect', {method:'POST',body:'{}'});
        state.riot = await api('/api/session'); state.modal = false; render(); msg('계정 연결 해제 완료');
      } catch (error) {msg(`연결 해제 실패: ${error.message}`);} return;
    }
    try {
      if (el.dataset.scenario) {
        await api('/api/demo/scenario', {method:'POST',body:JSON.stringify({scenario:el.dataset.scenario})});
        await reload();
        msg('데모 시나리오를 변경했습니다.');
      } else if (el.dataset.action === 'refresh') {
        el.disabled = true;
        await api('/api/data/refresh', {method:'POST',body:'{}'});
        await reload();
        msg('가상 데이터가 새로고침되었습니다.');
      } else if (el.dataset.action === 'logout') {
        await api('/api/session/logout', {method:'POST',body:'{}'});
        state.csrf = '';
        renderLocked('로컬 세션을 종료했습니다. 다시 실행해야 합니다.');
      }
    } catch (error) { msg(`요청 실패: ${error.message}`); }
  });
  init();
})();

# VAL DASH — 발로란트 계정 조회 로컬 웹앱 (v0.2)

> **실제 라이엇 계정 로그인 코드 추가 (승인된 RSO 클라이언트가 있을 때만 활성화)**
>
> 오늘의 상점, 제재, 랭크, 전적, VP, 스킨 등은 **계정 연결 여부와 관계없이 모두 데모 데이터**입니다. 이 프로젝트는 Riot Games의 승인 또는 후원을 받은 제품이 아닙니다.

## Windows 실행

1. Python 3.11 이상을 설치합니다.
2. `install.bat` 실행: 가상환경 생성, 필수 라이브러리 설치.
3. `run.bat` 실행: `127.0.0.1:8765`에서 로컬 웹앱 시작 후 브라우저 열기.
4. 브라우저에서 데모 대시보드 사용. 종료할 때는 터미널 `Ctrl+C`.

macOS/Linux: `python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt && python run_local.py`

## 실제 사용자 Riot 로그인: 필요한 사전 조건

**라이엇이 승인한 Production 개발자 앱 + RSO Client ID/Secret + Riot에 등록된 정확한 Redirect URI가 있어야 합니다.** 개인 전용 앱이나 온라인 상점 추적은 Riot의 VALORANT 승인 대상에서 제외된다고 명시되어 있습니다. 승인 없이는 실제 로그인하지 않습니다.

승인되었다면 Windows `cmd.exe`에서 실행 세션에 아래 환경변수를 설정할 수 있습니다. `RIOT_RSO_CLIENT_SECRET`은 **공개 저장소, 코드, GitHub Variables에 입력하지 마세요.** 아래 `YOUR_...`는 예시일 뿐입니다.

```bat
set "RIOT_RSO_APPROVED=true"
set "RIOT_RSO_CLIENT_ID=YOUR_APPROVED_CLIENT_ID"
set "RIOT_RSO_CLIENT_SECRET=YOUR_APPROVED_CLIENT_SECRET"
set "RIOT_RSO_REDIRECT_URI=http://127.0.0.1:8765/api/auth/riot/callback"
run.bat
```

**중요:** `http://127.0.0.1:8765/api/auth/riot/callback` 주소를 *라이엇 측에 실제로 등록하고 허용받은 경우에만* 동작합니다. 임의로 이 주소를 등록할 수 있다고 가정하지 마세요. 이미 다른 프로세스가 포트를 점유하면 승인된 RSO 모드에서 실행을 중단합니다.

계정 연결 버튼을 누르면 브라우저가 Riot 공식 `auth.riotgames.com/authorize`로 이동합니다. 로그인과 2차 인증은 라이엇에서 수행되고, 앱의 콜백은 승인된 Client Secret Basic 방식으로 인증 코드를 토큰으로 교환한 다음 공식 Riot Account API (`/riot/account/v1/accounts/me`)로 본인의 Riot ID를 확인합니다. 인증코드·토큰·비밀번호를 프론트에 반환하지 않습니다.

- OAuth `state`는 세션에 바인딩되어 5분 후 만료되고 단 한 번만 사용됩니다.
- 로컬 세션에 실시간 Access Token을 **메모리 내에서만** 보관하며 만료 또는 연결 해제 시 제거합니다.
- Refresh Token은 저장하지 않습니다. 토큰을 갱신하려면 다시 로그인합니다.
- OAuth PKCE는 승인된 RSO 클라이언트에서 지원 여부를 확인한 후에만 `RIOT_RSO_USE_PKCE=true`로 활성화합니다.
- 실계정 Riot ID가 연결되더라도 **상점·제재 등 데이터 카드에는 가상 정보만 표시**합니다.
- 로그인 실패나 취소 시 민감한 공급자 응답을 표시하지 않습니다.

### 미승인 환경에서의 동작

실제 사용자 인증 기능은 회색 비활성화 상태로 표시됩니다. `POST /api/auth/riot/start`는 `501 RIOT_RSO_NOT_APPROVED_OR_CONFIGURED`를 반환합니다. 일반 데모 기능은 정상적으로 이용할 수 있습니다.

## GitHub Actions Secrets 및 Variables

**권장 방식: Actions는 가짜 OAuth 공급자(MockTransport)로 로그인 테스트를 자동화합니다.** 실제 계정의 Riot ID·비밀번호·2FA 코드·인증 쿠키·세션 토큰은 **Actions Secrets에도 저장하지 않습니다.** CI에서는 실제 대화형 로그인과 2FA를 재현할 수 없고, 로그인 성공만으로 개인 상점·제재 API 사용 권한이 생기지도 않습니다.

나중에 Riot이 RSO 클라이언트를 승인하고 CI에 승인 설정 자체가 필요한 특수한 경우에만:

| GitHub 설정 | 권장 키 | 보관 값 |
|---|---|---|
| Actions Secrets | `RIOT_RSO_CLIENT_SECRET` | 라이엇이 발급한 **앱** 비밀키 (선택) |
| Actions Variables | `RIOT_RSO_CLIENT_ID` | 승인된 클라이언트 식별자 (선택) |
| Actions Variables | `RIOT_RSO_REDIRECT_URI` | 라이엇이 승인한 콜백 URL (선택) |
| Actions Variables | `RIOT_RSO_APPROVED` | 승인되었다면 `true` (선택) |

**현재 프로젝트의 워크플로는 이 값들을 요구하거나 주입하지 않습니다.** 앱 비밀키를 CI에 넣어도 라이엇 사용자의 비밀번호 로그인이나 2차 인증을 대체할 수 없습니다. 실제 RSO 연결의 최종 검증은 승인된 리디렉션 URI를 가진 사용자의 브라우저에서 직접 해야 합니다.

확인: `https://github.com/nssang00/chatgpt-write-test/actions` → `VAL DASH Local (Windows + OAuth Mock + Frontend)`.

## 자동 검증

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q backend/tests
node --check standalone/app.js
```

테스트는 진짜 Riot API를 호출하지 않고 승인 설정/미설정, OAuth URL, state/CSRF, 코드 교환, 계정 식별, 콜백 오류, 재사용 거부, 연결 해제, 토큰 만료를 검사합니다. GitHub Actions는 `windows-latest`에서 `install.bat`과 `run.bat`을 직접 실행하고 서버 헬스체크 및 미인증 요청 차단을 확인하며 Ubuntu에서 React 빌드도 확인합니다.

## 보안 및 범위

- Loopback `127.0.0.1`만 바인딩; 외부 웹 서버 없음
- 일회용 launch token → HttpOnly/SameSite Strict 로컬 세션 쿠키
- CSRF/Origin/Host 보호; `no-store`, CSP 등 보안 헤더
- OAuth `state` 검증; 등록한 정확한 callback만 허용; 토큰/비밀번호 로그 금지
- SQLite에는 데모 설정과 조회 기록만 저장
- 현재 게임 데이터 공급자는 `MockProvider`; `mode: demo` 및 `live: false` 유지
- 동일 PC에서 실행되는 악성 프로세스/확장 프로그램까지 완벽하게 막을 수는 없음

참고 문서: [Riot VALORANT API 정책](https://developer.riotgames.com/docs/valorant), [Riot OAuth 문서](https://support-developer.riotgames.com/hc/en-us/articles/22897607341075-OAuth-Client-Documentation), `docs/ARCHITECTURE.md`.

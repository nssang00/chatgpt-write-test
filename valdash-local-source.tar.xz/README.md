# VAL DASH — 발로란트 계정 조회 로컬 웹앱 (v0.3 · 실험적 웹 로그인)

> **새 기능 (v0.3): 사용자 ID/비밀번호 입력을 라이엇 공식 웹 인증 화면에서 진행할 수 있는 별도 브라우저 로그인 모듈**을 추가했습니다. 별도 Edge/Chrome 창에서 Riot 로그인 및 MFA를 완료하면, 인증 토큰을 백엔드 메모리에만 두고 상점/제재 비공식 API를 호출할 수 있습니다. 단 **실제 라이엇 서버에 대한 성공 테스트는 수행하지 않았습니다.** 인증/게임 API는 라이엇 측에서 언제든 바뀔 수 있고, 비공식 이용에 정책상의 위험이 있습니다. 모든 계정 정보는 본인 계정이어야 합니다.

> 대시보드의 기존 가상 랭크/전적/컬렉션은 계속 데모입니다. 새 **실제 계정 조회 · 실험적 기능** 패널에서만 실제 상점/제재 응답이 보이고, 불가능한 경우 오류가 표시됩니다. Riot Games의 승인 또는 후원을 받은 제품이 아닙니다.

## Windows 실행

1. Python 3.11 이상을 설치합니다.
2. `install.bat` 실행: 가상환경 생성, 필수 라이브러리 설치.
3. `run.bat` 실행: `127.0.0.1:8765`에서 로컬 웹앱 시작 후 브라우저 열기.
4. 브라우저에서 데모 대시보드 사용. 종료할 때는 터미널 `Ctrl+C`.

macOS/Linux: `python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt && python run_local.py`

## GO VAL 방식의 실험적 사용자 로그인 (RSO 승인 없이 시도)

1. `install.bat`을 실행합니다. Python 의존성 `playwright`가 함께 설치됩니다.
2. Edge 또는 Chrome이 설치되어 있어야 합니다. Edge/Chrome이 없는 PC에서는 `.venv\Scripts\python.exe -m playwright install chromium`으로 Playwright 브라우저를 설치할 수 있습니다.
3. `run.bat` 실행 후 VAL DASH의 **실제 계정 조회 · 실험적 기능 → 라이엇 계정으로 로그인**을 누릅니다.
4. **별도로 열린 `auth.riotgames.com` 라이엇 로그인 페이지**에서 사용자 ID, 비밀번호, 2차 인증을 직접 입력합니다. VAL DASH 입력창이나 GitHub Secrets에는 계정 비밀번호를 넣지 마세요.
5. 로그인과 토큰 교환이 성공하면 계정 Riot ID가 표시됩니다. `실제 상점 조회` 또는 `실제 제재 조회`를 눌러 응답을 확인할 수 있습니다.
6. 모든 브라우저 인증 쿠키는 일회용 비영구 브라우저 컨텍스트에만 보관되고, 창을 닫으면 삭제됩니다. Access Token/Entitlements JWT는 Python 백엔드 메모리에만 보관되며 디스크/SQLite/프론트엔드로 전달하지 않습니다.

**중요한 제한**

- Riot 웹사이트의 기존 웹 클라이언트 인증 흐름을 사용하는 **비공식 실험 기능**입니다. API 사용 권한을 공식적으로 부여받은 것은 아닙니다.
- 로그인 중 CAPTCHA, MFA, 봇 방어는 사용자가 라이엇 웹페이지에서 직접 처리합니다. 우회 또는 자동입력 코드는 없습니다. Riot 쪽 차단/변경으로 실패할 수 있습니다.
- 자동 shard 검출은 아직 구현되지 않았으며, 현재 `kr` 서버 계정을 대상으로 합니다. 다른 서버 계정을 사용하면 조회 오류가 날 수 있습니다.
- 상점은 현재 우선 **상품 ID·확인 가능한 VP 가격**을 우선 표시하고, 공개 카탈로그에서 매칭되는 경우 스킨 이름도 보여줍니다. 보유 스킨/랭크/전적은 별도 미구현이므로 기존 카드에는 데모 데이터가 유지됩니다.
- 제재 `Penalties: []` 결과는 해당 API에서 기록을 반환하지 않았다는 의미일 뿐, 모든 이용 제한이 없다는 뜻은 아닙니다.
- 새 로그인 구현의 브라우저 리디렉션 파싱·토큰 처리·샘플 API는 모의 서버로 검증했으며, 실계정 인증·API는 검증하지 못했습니다.

## 공식 RSO 로그인 (기존 옵션, 별도 인증 방식)



**이 공식 모드에는 라이엇이 승인한 Production 개발자 앱 + RSO Client ID/Secret + Riot에 등록된 정확한 Redirect URI가 있어야 합니다.** 개인 전용 앱이나 온라인 상점 추적은 Riot의 VALORANT 승인 대상에서 제외된다고 명시되어 있습니다. 승인 없이는 실제 로그인하지 않습니다.

승인되었다면 Windows `cmd.exe`에서 실행 세션에 아래 환경변수를 설정할 수 있습니다. `RIOT_RSO_CLIENT_SECRET`은 **공개 저장소, 코드, GitHub Variables에 입력하지 마세요.** 아래 `YOUR_...`는 예시일 뿐입니다.

```bat
set "RIOT_RSO_APPROVED=true"
set "RIOT_RSO_CLIENT_ID=YOUR_APPROVED_CLIENT_ID"
set "RIOT_RSO_CLIENT_SECRET=YOUR_APPROVED_CLIENT_SECRET"
set "RIOT_RSO_REDIRECT_URI=http://127.0.0.1:8765/api/auth/riot/callback"
run.bat
```

**중요:** `http://127.0.0.1:8765/api/auth/riot/callback` 주소를 *라이엇 측에 실제로 등록하고 허용받은 경우에만* 동작합니다. 임의로 이 주소를 등록할 수 있다고 가정하지 마세요. 이미 다른 프로세스가 포트를 점유하면 승인된 RSO 모드에서 실행을 중단합니다.

계정 연결 버튼을 누르면 브라우저가 Riot 공식 `auth.riotgames.com/authorize`로 이동합니다. 로그인과 2차 인증은 라이엇에서 수행되고, 앱의 콜백은 승인된 Client Secret Basic 방식으로 인증 코드를 토큰으로 교환한 다음 공식 Riot Account API (`/riot/account/v1/accounts/me`)로 본인의 Riot ID를 확인합니다. 인증코드·토큰·비밀번호를 프론트에 반환하지 않습니다.

- OAuth `state`는 세션에 바인딩되어 5분 후 만료되고 단 한 번만 사용됩니다.
- 로컬 세션에 실시간 Access Token을 **메모리 내에서만** 보관하며 만료 또는 연결 해제 시 제거합니다.
- Refresh Token은 저장하지 않습니다. 토큰을 갱신하려면 다시 로그인합니다.
- OAuth PKCE는 승인된 RSO 클라이언트에서 지원 여부를 확인한 후에만 `RIOT_RSO_USE_PKCE=true`로 활성화합니다.
- 공식 RSO로 연결해도 기존 데모 카드는 가상 정보입니다. 비공식 실험 패널을 통해 연결한 경우에만 실제 서버 조회를 별도로 시도합니다.
- 로그인 실패나 취소 시 민감한 공급자 응답을 표시하지 않습니다.

### 미승인 환경에서의 동작

공식 RSO 로그인만 회색 비활성화 상태로 표시됩니다. 실험적 웹 로그인은 별도 패널에서 실행할 수 있습니다. `POST /api/auth/riot/start`는 `501 RIOT_RSO_NOT_APPROVED_OR_CONFIGURED`를 반환합니다. 일반 데모 기능은 정상적으로 이용할 수 있습니다.

## GitHub Actions Secrets 및 Variables

**권장 방식: Actions는 가짜 OAuth 공급자(MockTransport)로 로그인 테스트를 자동화합니다.** 실제 계정의 Riot ID·비밀번호·2FA 코드·인증 쿠키·세션 토큰은 **Actions Secrets에도 저장하지 않습니다.** CI에서는 실제 대화형 로그인과 2FA를 재현할 수 없고, 로그인 성공만으로 개인 상점·제재 API 사용 권한이 생기지도 않습니다.

나중에 Riot이 RSO 클라이언트를 승인하고 CI에 승인 설정 자체가 필요한 특수한 경우에만:

| GitHub 설정 | 권장 키 | 보관 값 |
|---|---|---|
| Actions Secrets | `RIOT_RSO_CLIENT_SECRET` | 라이엇이 발급한 **앱** 비밀키 (선택) |
| Actions Variables | `RIOT_RSO_CLIENT_ID` | 승인된 클라이언트 식별자 (선택) |
| Actions Variables | `RIOT_RSO_REDIRECT_URI` | 라이엇이 승인한 콜백 URL (선택) |
| Actions Variables | `RIOT_RSO_APPROVED` | 승인되었다면 `true` (선택) |

**GitHub Actions에 일반 사용자 ID/비밀번호를 저장하지 마세요. 현재 프로젝트의 CI는 모의 API와 모의 로그인으로만 검증합니다.** 앱 비밀키를 CI에 넣어도 라이엇 사용자의 비밀번호 로그인이나 2차 인증을 대체할 수 없습니다. 실제 RSO 연결의 최종 검증은 승인된 리디렉션 URI를 가진 사용자의 브라우저에서 직접 해야 합니다.

확인: `https://github.com/nssang00/chatgpt-write-test/actions` → `VAL DASH Local (Windows + OAuth Mock + Frontend)`.

## 자동 검증

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q backend/tests
node --check standalone/app.js
```

테스트는 진짜 Riot API를 호출하지 않고 승인 설정/미설정, OAuth URL, state/CSRF, 코드 교환, 계정 식별, 콜백 오류, 재사용 거부, 연결 해제, 토큰 만료를 검사합니다. GitHub Actions는 `windows-latest`에서 `install.bat`과 `run.bat`을 직접 실행하고 서버 헬스체크 및 미인증 요청 차단을 확인하며 Ubuntu에서 React 빌드도 확인합니다.

## 보안 및 범위

- Loopback `127.0.0.1`만 바인딩; 외부 웹 서버 없음
- 일회용 launch token → HttpOnly/SameSite Strict 로컬 세션 쿠키
- CSRF/Origin/Host 보호; `no-store`, CSP 등 보안 헤더
- OAuth `state` 검증; 등록한 정확한 callback만 허용; 토큰/비밀번호 로그 금지
- SQLite에는 데모 설정과 조회 기록만 저장
- 기존 데모 데이터 공급자는 `MockProvider`; 새 `api/live/*` 경로에서만 비공식 실제 조회를 시도
- 동일 PC에서 실행되는 악성 프로세스/확장 프로그램까지 완벽하게 막을 수는 없음

참고 문서: [Riot VALORANT API 정책](https://developer.riotgames.com/docs/valorant), [Riot OAuth 문서](https://support-developer.riotgames.com/hc/en-us/articles/22897607341075-OAuth-Client-Documentation), `docs/ARCHITECTURE.md`.

## 최신 테스트 결과

- 모의 인증 및 API 응답 기반 Python 테스트: `21 passed` (실제 Riot 서버 요청 없음).
- `node --check standalone/app.js`: 통과.
- React/TypeScript는 이 실행 환경에서 `npm install`이 시간 초과되어 최신 수정본 빌드를 검증하지 못함.
- GitHub Actions의 기존 PR #45는 **이 v0.3 아카이브를 포함하지 않음**. CI 통과 내역을 새 기능의 검증으로 오해하지 마세요.

## 실제 계정 로그인 스모크 테스트 (v0.4, 선택)

`GitHub Actions` 일반 호스팅 러너에서는 사람의 CAPTCHA/MFA 조작을 할 수 없습니다. **CAPTCHA 우회나 자동 해결은 제공하지 않습니다.** 사용자가 자신의 Windows 데스크톱에서 Riot 웹 로그인 창을 열어 직접 완료해야 합니다.

로컬에서 직접 실행하려면 `install.bat` 이후 PowerShell에서:

```powershell
$env:VALDASH_ALLOW_INTERACTIVE_LIVE_TEST='yes'
$env:VALDASH_SHARD='kr'
.venv\Scripts\python.exe -m scripts.real_login_smoke
```

GitHub Actions로 기록하고 싶다면 본인이 관리하는 **전용 self-hosted Windows runner**에 `valdash-interactive` 라벨을 부여하고, runner를 **Windows 서비스가 아닌 로그인한 사용자의 대화형 세션**에서 실행하세요. Actions → `VAL DASH - Opt-in interactive live login` → Run workflow → `YES`로 확인한 뒤 데스크톱에 나타나는 Riot 로그인 창에서 비밀번호, CAPTCHA 및 MFA를 직접 입력해야 합니다. **GitHub Actions Secrets에 라이엇 계정 비밀번호를 넣지 않습니다.**

이 옵션은 `workflow_dispatch`에서만 실행되므로 PR이나 push로 계정 조회를 실행하지 않습니다. 공개 저장소에서 self-hosted runner를 사용하는 것 자체가 위험하므로, **전용 비관리자 Windows 계정과 제한된 컴퓨터**를 사용하고 신뢰할 수 없는 PR 코드를 runner에서 실행하지 마세요. 가능하다면 별도 비공개 저장소에서 운영하는 것이 더 안전합니다.

실행 로그는 계정명·토큰·PUUID·개별 상품 ID 대신 로그인 성공, 상점 제안 수, 제재 레코드 수 또는 오류 코드만 출력합니다. 실패는 제재 없음으로 취급하지 않습니다. 실제 Riot 계정 로그인의 성공 여부는 아직 실계정에서 확인되지 않았고, 비공식 API 사용 정책상의 위험이 있습니다.

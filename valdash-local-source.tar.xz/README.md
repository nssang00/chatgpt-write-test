# VAL DASH — 발로란트 로컬 웹 대시보드 (v0.1.0)

> **데모 전용 / 실제 라이엇 계정 조회 미지원**
>
> 이 앱의 상점, 제재, 랭크, 전적, VP, 스킨, 미션은 모두 가상 데이터입니다. 이 앱은 Riot Games의 공식 제품이 아니며 승인 또는 후원받지 않았습니다.

Chrome/Edge 등 웹브라우저에서 확인하는 **로컬 웹앱 MVP**입니다. 게임 설치·Riot Client·외부 웹서버가 필요하지 않습니다. 별도 서버/클라우드에 계정 정보를 보내지 않습니다.

## 가장 빠른 실행 (Windows)

1. [Python 3.11 이상](https://www.python.org/downloads/) 설치 (설치할 때 Windows라면 `Add Python to PATH` 선택).
2. **`install.bat`를 더블클릭**하여 가상환경과 필요한 라이브러리를 설치.
3. **`run.bat`를 더블클릭**하여 로컬 서버를 실행.
4. 프로그램이 자동으로 여는 브라우저 탭에서 사용.
5. 종료하려면 열린 터미널 창에서 `Ctrl+C`.

CMD 또는 PowerShell을 선호한다면 `py -3 -m venv .venv` → `.venv\Scripts\python -m pip install -r requirements.txt` → `.venv\Scripts\python run_local.py`를 순서대로 실행해도 됩니다.

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_local.py
```

**자동으로 브라우저가 열리지 않으면** 프로그램을 종료한 뒤 기본 브라우저 설정을 확인하고 재시작하세요. **콘솔에 나온 주소만 직접 입력하는 것은 로그인으로 인정되지 않습니다.** 실행할 때마다 비밀값이 브라우저 URL의 fragment(`#...`)로 전달되고 즉시 삭제되며, 로컬 세션 쿠키로 교환됩니다.

## 포함된 화면

- 대시보드: 랭크 / VP / 상점 / 제재 상태와 미리보기
- 오늘의 상점: 가상의 스킨 4개와 가격, 야시장 예시
- 계정 제재: `활성 제재 없음`, `제재 중`, `조회 불가` 시나리오 전환
- 랭크 · 전적: RR 추이, 최근 5경기 KDA / RR
- 보유 아이템: 스킨, VP, 레디어나이트, 킹덤 크레딧, 미션
- 설정: 데이터 공급자 상태, 시나리오 설정, 데모 조회 기록

데모 모드임을 **모든 화면 상단과 API 응답에서 표시**합니다. 특히 `조회 불가`를 `제재 없음`과 구분합니다.

## 저장되는 데이터

- `~/.valdash-local/valdash.sqlite3`: 가상 제재 시나리오와 데모 새로고침 기록
- 프로그램 실행 중 메모리: 로컬 세션 ID, CSRF 토큰
- 브라우저: `HttpOnly; SameSite=Strict` 로컬 세션 쿠키만 저장
- **저장하지 않는 것**: Riot ID/비밀번호, Riot Access Token, Refresh Token, Entitlement Token

이 프로그램은 `127.0.0.1`에만 연결되며 외부 호스팅을 하지 않습니다. 같은 PC의 **악성 프로그램까지 방어하는 것은 불가능**합니다. Riot 계정 비밀번호를 앱에서 입력하지 마세요.

## React + Vite 소스

패키지에는 즉시 실행 가능한 **외부 의존성 없는 `standalone/` UI**와 확장 개발용 **React + TypeScript + Vite `frontend/`** 소스가 모두 포함되어 있습니다.

React 빌드 방식으로 전환할 때 (인터넷 접근 및 Node.js 20.19+/22.12+ 권장):

```bash
cd frontend
npm install
npm run build
cd ..
python run_local.py
```

`frontend/dist/index.html`이 생성되면 FastAPI가 자동으로 React 빌드를 서빙합니다. 미생성 상태에서는 `standalone/` UI를 서빙하므로 `npm` 없이도 기본 기능이 실행됩니다.

Hot reload로 개발하려면 **두 개의 터미널**을 이용합니다.

첫 번째:

```bash
cd frontend
npm install
npm run dev
```

두 번째 (프로젝트 루트):

```bash
python run_local.py --dev
```

개발 모드에서는 Vite가 `127.0.0.1:5173`, API 서버가 `127.0.0.1:8765`를 사용합니다. `run_local.py --dev`가 실행된 경우에만 백엔드가 Vite의 정확한 Origin을 허용합니다. Vite를 먼저 실행하세요.

**검증**: React 프론트엔드 빌드 결과는 GitHub Actions의 검증 기록을 확인하세요. 기본 `standalone/` UI는 Node.js 없이 실행됩니다.

## 테스트

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q backend/tests
```

브라우저 JavaScript 구문만 점검하려면 `node --check standalone/app.js`를 실행합니다.

## 기술 구성

| 구성 | 구현 |
| --- | --- |
| 기본 UI | HTML / CSS / JavaScript 무빌드 버전 |
| 확장 UI | React + TypeScript + Vite |
| 백엔드 | Python FastAPI / Uvicorn |
| DB | SQLite (데모 기록 / 설정) |
| 계정 인증 | 미구현 — 공식 RSO 승인 전 비활성화 |
| 로컬 인증 | 실행 시 1회용 시작 토큰 + HttpOnly 세션 쿠키 |
| 보안 | loopback 바인딩, TrustedHost, CSRF, Origin, CSP, no-store |
| 외부 데이터 | 없음 — 모든 개인 데이터는 가상 |

## 라이엇 정책 및 향후 기능

공식 정책: https://developer.riotgames.com/docs/valorant

Riot 공식 문서상 VALORANT 개인용 비공개 애플리케이션은 승인 대상이 아니며, 온라인 개인 상점 추적은 공식 API에서 지원되지 않습니다. RSO 사용은 승인된 Production 애플리케이션에 제한됩니다. 따라서 **현재 프로젝트는 비공식 인증·스토어·제재 API에 접속하는 코드를 포함하지 않습니다**.

향후 승인 가능한 범위에서 실데이터 기능을 구축할 경우 `backend/app/providers/official.py`와 `backend/app/auth/`를 확장하세요. 비공식 제공자는 기본 비활성화 상태로 유지하세요. 공식 정책·인증·현재 API를 재검증하지 않은 채 활성화하지 마세요.

API 계약과 보안 설계는 `docs/ARCHITECTURE.md`에 설명되어 있습니다.

import {useEffect, useRef, useState} from 'react';
import {request, type Overview, type Scenario, type Penalty, type Offer, type Match, type Session} from './api';

type Page = 'overview'|'store'|'penalties'|'rank'|'inventory'|'settings';
const menu: {id:Page;icon:string;label:string}[] = [
  {id:'overview',icon:'◫',label:'대시보드'}, {id:'store',icon:'▣',label:'오늘의 상점'},
  {id:'penalties',icon:'◇',label:'계정 제재'}, {id:'rank',icon:'▥',label:'랭크 · 전적'},
  {id:'inventory',icon:'▤',label:'보유 아이템'}, {id:'settings',icon:'⚙',label:'설정'},
];
const fmt = (n:number) => n.toLocaleString('ko-KR');
const fmtTime = (s:string|null) => s ? new Date(s).toLocaleString('ko-KR', {hour12:false}) : '미제공';
const percent = (value:number,total:number) => total ? Math.min(100,Math.max(0,Math.round(value/total*100))) : 0;

function Metric({title,value,foot,icon,accent=false}: {title:string;value:string;foot:string;icon:string;accent?:boolean}) {
  return <div className="panel metric"><div className="metric-kicker"><span>{title}</span><span className="metric-icon">{icon}</span></div><div className={'metric-value '+(accent?'accent':'')}>{value}</div><div className="metric-foot">{foot}</div></div>;
}
function Section({title,desc}:{title:string;desc?:string}) {
  return <div className="heading-row"><div><h2 className="section-title">{title}</h2>{desc && <div className="section-desc">{desc}</div>}</div></div>;
}
function StoreCards({offers}:{offers:Offer[]}) {
  return <div className="grid store-grid">{offers.map(x=><article className="panel store-card" key={x.id}><div className={'store-art '+x.palette}><div className="weapon-art" aria-hidden="true" /></div><div className="store-copy"><div className="item-type">{x.rarity} · {x.weapon}</div><div className="item-name">{x.name}</div><div className="item-price">{fmt(x.price_vp)} <span>VP</span></div></div></article>)}</div>;
}
function PenaltyCard({penalty}:{penalty:Penalty}) {
  const tone = penalty.status === 'active'?'accent-text':penalty.status === 'unavailable'?'warn':'good';
  return <div className="panel"><div className="panel-heading"><div className="panel-title">계정 제재 상태</div><span className="pill">가상 시나리오</span></div><div className="small">서버 상태를 가정한 테스트 데이터</div><div className={'large-status '+tone}>{penalty.label}</div><div className="data-rows" style={{marginTop:17}}><div className="data-row"><span className="key">제재 유형</span><span className="val">{penalty.type??'없음 / 알 수 없음'}</span></div><div className="data-row"><span className="key">해제 시각</span><span className="val">{fmtTime(penalty.expires_at)}</span></div><div className="data-row"><span className="key">설명</span><span className="val">{penalty.reason??'활성 제재 없음 시나리오'}</span></div></div></div>;
}
function Matches({matches}:{matches:Match[]}) {
  return <div className="matches">{matches.map(m=><div className="match" key={m.id}><div className={'match-result '+(m.result === '승리'?'win':'loss')}>{m.result === '승리'?'WIN':'LOSE'}</div><div style={{flex:1}}><div className="map">{m.map} <span className="small">{m.score}</span></div><div className="agent">{m.agent}</div></div><div className="kda">{m.kda}</div><div className={'rr '+(m.rr_change>0?'good':'accent-text')}>{m.rr_change>0?'+':''}{m.rr_change} RR</div></div>)}</div>;
}
function RRChart({values}:{values:number[]}) {
  const step = 100/Math.max(1,values.length-1);
  const pts = values.map((v,i)=>`${i*step},${100-v}`).join(' ');
  return <><div className="chart-box"><svg viewBox="-4 -10 108 124" role="img" aria-label="데모 RR 변화"><line x1="0" x2="100" y1="100" y2="100" stroke="#394858"/><line x1="0" x2="100" y1="50" y2="50" stroke="#2b3948" strokeDasharray="2 3"/><polyline points={pts} fill="none" stroke="#ff6171" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>{values.map((v,i)=><circle key={i} cx={i*step} cy={100-v} r="2.8" fill="#ff7480" stroke="#0d1520" strokeWidth="1.5"/>)}</svg></div><div className="chart-labels"><span>이전 경기</span><span>최근 경기</span></div></>;
}
function ScenarioControls({value,onSelect}:{value:Scenario;onSelect:(s:Scenario)=>void}) {
  const options: {id:Scenario;label:string}[] = [{id:'clear',label:'활성 제재 없음'},{id:'active',label:'제재 중'},{id:'unknown',label:'조회 오류'}];
  return <div className="choice-row">{options.map(x=><button key={x.id} type="button" className={'choice-btn '+(value===x.id?'active':'')} onClick={()=>onSelect(x.id)}>{x.label}</button>)}</div>;
}
function Dashboard({d}:{d:Overview}) {
  return <><div className="grid metrics"><Metric title="현재 랭크" value={d.rank.tier} foot={`${d.rank.rr} RR · 데모`} icon="♛"/><Metric title="오늘의 상점" value={`${d.store.daily_offers.length}개`} foot="가상 스킨 목록" icon="▣" accent/><Metric title="VP 잔액" value={`${fmt(d.wallet.vp)} VP`} foot="실제 잔액 아님" icon="◈"/><Metric title="제재 상태" value={d.penalty.status==='active'?'제한 중':d.penalty.status==='unavailable'?'조회 불가':'제재 없음'} foot="가상 상태" icon="◇"/></div><Section title="오늘의 상점 미리보기" desc="4개 상품 모두 가상 데이터"/><StoreCards offers={d.store.daily_offers}/><Section title="계정 현황" desc="랭크 및 제재 예시"/><div className="grid two-col"><div className="panel"><div className="panel-heading"><div className="panel-title">최근 RR 변동</div><span className="tag">{d.rank.tier}</span></div><RRChart values={d.rank.recent_rr}/></div><PenaltyCard penalty={d.penalty}/></div><Section title="최근 경기" desc="실제 경기 기록이 아님"/><div className="panel"><Matches matches={d.matches.slice(0,3)}/></div></>;
}

type LiveLoginStatus = {status:string;error:string|null;account:{riot_id:string;puuid:string}|null};
type LiveStore = {live:boolean;store:{offers:{id:string;name:string|null;price_vp:number|null}[];seconds_remaining:number|null}};
type LivePenalties = {live:boolean;penalties:{returned_count:number;records:{effects:string[];expiry:string|null;games_remaining:number|null}[];disclaimer:string}};
function LiveAccountPanel({csrfToken}:{csrfToken:string}) {
  const [status,setStatus] = useState<LiveLoginStatus>({status:'idle',error:null,account:null});
  const [store,setStore] = useState<LiveStore|null>(null);
  const [penalties,setPenalties] = useState<LivePenalties|null>(null);
  const [error,setError] = useState('');
  async function updateStatus() {
    try {
      const next = await request<LiveLoginStatus>('/api/auth/riot-web/status');
      setStatus(next);
    } catch (e) {setError(e instanceof Error?e.message:'조회 오류');}
  }
  useEffect(()=>{void updateStatus();},[]);
  useEffect(()=>{
    if (status.status !== 'pending') return;
    const interval = window.setInterval(()=>{void updateStatus();},1400);
    return ()=>window.clearInterval(interval);
  },[status.status]);
  async function start() {
    setError('');setStore(null);setPenalties(null);
    try {await request('/api/auth/riot-web/start','POST',{},csrfToken);setStatus({status:'pending',error:null,account:null});}
    catch(e) {setError(e instanceof Error?e.message:'인증 시작 실패');}
  }
  async function disconnect() {
    try {await request('/api/auth/riot-web/disconnect','POST',{},csrfToken);setStatus({status:'idle',error:null,account:null});setStore(null);setPenalties(null);}
    catch(e) {setError(e instanceof Error?e.message:'연결 해제 실패');}
  }
  async function loadStore() {
    try {setError('');setStore(await request<LiveStore>('/api/live/store'));}
    catch(e) {setStore(null);setError('상점 조회 실패: '+(e instanceof Error?e.message:'알 수 없음'));}
  }
  async function loadPenalties() {
    try {setError('');setPenalties(await request<LivePenalties>('/api/live/penalties'));}
    catch(e) {setPenalties(null);setError('제재 조회 실패: '+(e instanceof Error?e.message:'알 수 없음'));}
  }
  return <section className="panel" style={{marginBottom:24}}><div className="panel-heading"><b className="panel-title">실제 계정 조회 · 실험적 기능</b><span className="pill warning">UNOFFICIAL</span></div>
    <p className="small">별도로 열리는 라이엇 공식 웹 로그인 창에서 아이디·비밀번호 및 2차 인증을 입력합니다. VAL DASH에는 비밀번호를 입력하지 않습니다. 로그인 방식과 내부 API는 라이엇 정책·업데이트에 따라 중단될 수 있습니다.</p>
    <div className="choice-row" style={{marginTop:16}}>
      {!status.account && <button type="button" className="btn primary" onClick={start} disabled={status.status==='pending'}>{status.status==='pending'?'라이엇 로그인 창에서 인증 중…':'라이엇 계정으로 로그인'}</button>}
      {status.account && <><button type="button" className="btn primary" onClick={loadStore}>실제 상점 조회</button><button type="button" className="btn primary" onClick={loadPenalties}>실제 제재 조회</button><button type="button" className="btn muted" onClick={disconnect}>계정 연결 해제</button></>}
      <button type="button" className="btn muted" onClick={()=>void updateStatus()}>상태 새로고침</button>
    </div>
    <p className="small" style={{marginTop:12}}>상태: {status.account?`연결됨 (${status.account.riot_id})`:status.status==='pending'?'별도 로그인 창에서 입력 대기':status.status==='error'?`인증 실패 (${status.error||'UNKNOWN'})`:'연결 안 됨'}</p>
    {error && <p className="warn" role="alert">{error}</p>}
    {store?.live && <div style={{marginTop:16}}><b>서버에서 조회된 상점 상품</b><p className="small">스킨 이름은 아직 매핑하지 않았으며 ID와 VP 가격만 표시합니다.</p><div className="data-rows">{store.store.offers.map((offer,i)=><div className="data-row" key={i}><span className="key" style={{overflowWrap:'anywhere'}}>{offer.name||offer.id}</span><b>{offer.price_vp===null?'가격 미확인':`${fmt(offer.price_vp)} VP`}</b></div>)}</div></div>}
    {penalties?.live && <div style={{marginTop:16}}><b>서버에서 반환된 제재 기록 {penalties.penalties.returned_count}건</b><p className="small">{penalties.penalties.disclaimer}</p>{penalties.penalties.records.map((record,i)=><p className="small" key={i}>{record.effects.join(', ')||'알 수 없는 제재 유형'} · 만료: {record.expiry||'미제공'} · 남은 경기: {record.games_remaining??'미제공'}</p>)}</div>}
  </section>;
}

export default function App() {
  const [page,setPage] = useState<Page>('overview');
  const [data,setData] = useState<Overview|null>(null);
  const [history,setHistory] = useState<{at:string;source:string}[]>([]);
  const [error,setError] = useState<string|null>(null);
  const [modal,setModal] = useState(false);
  const [riot,setRiot] = useState<Session|null>(null);
  const [toast,setToast] = useState('');
  const csrf = useRef('');
  const initialized = useRef(false);

  async function reload() {
    const [overview,logs] = await Promise.all([
      request<Overview>('/api/overview'),request<{items:{at:string;source:string}[]}>('/api/history'),
    ]);
    setData(overview);setHistory(logs.items);
  }
  useEffect(()=>{
    // React StrictMode can call effects twice in development; bootstrap once.
    if (initialized.current) return;
    initialized.current = true;
    const raw = window.location.hash;
    const token = raw.startsWith('#launch=')?decodeURIComponent(raw.slice(8)):null;
    if (raw) window.history.replaceState(null,'',window.location.pathname+window.location.search);
    (async()=>{
      try {
        if (token) {
          const result = await request<{csrf_token:string}>('/api/session/bootstrap','POST',{launch_token:token});
          csrf.current = result.csrf_token;
        }
        const session = await request<Session>('/api/session');
        csrf.current = session.csrf_token;
        setRiot(session);
        await reload();
        const authOutcome = new URLSearchParams(window.location.search).get('auth');
        if (authOutcome) {
          window.history.replaceState(null,'',window.location.pathname);
          setToast(session.riot_auth_error || (session.riot_connected ? '라이엇 계정 인증이 완료됐습니다. 개인 상점·제재 데이터는 여전히 데모입니다.' : '라이엇 로그인 결과를 확인하세요.'));
        }
      } catch(e) {setError(e instanceof Error?e.message:'로컬 세션이 없습니다.');}
    })();
  },[]);
  async function act(path:string,body:unknown) {
    try {await request(path,'POST',body,csrf.current);await reload();setToast('데모 데이터를 갱신했습니다.');window.setTimeout(()=>setToast(''),3000);} catch(e) {setToast(e instanceof Error?e.message:'오류');}
  }
  async function connectRiot() {
    try {
      const {authorize_url} = await request<{authorize_url:string}>('/api/auth/riot/start','POST',{},csrf.current);
      const u = new URL(authorize_url);
      if (u.origin !== 'https://auth.riotgames.com' || u.pathname !== '/authorize') throw new Error('허용되지 않은 인증 URL');
      window.location.assign(authorize_url);
    } catch (e) {setToast(e instanceof Error?e.message:'인증 시작 실패');setModal(false);}
  }
  async function disconnectRiot() {
    try {await request('/api/auth/riot/disconnect','POST',{},csrf.current);
      const session = await request<Session>('/api/session');setRiot(session);setModal(false);setToast('라이엇 계정 연결을 해제했습니다.');
    } catch(e){setToast(e instanceof Error?e.message:'연결 해제 실패');}
  }
  async function logout() {
    try {await request('/api/session/logout','POST',{},csrf.current);} catch {/* local exit regardless */}
    csrf.current='';setError('로컬 세션을 종료했습니다. 프로그램을 다시 실행하세요.');setData(null);
  }
  if (error) return <div className="locked"><div className="brand-icon">V</div><h1>로컬 세션이 없습니다</h1><p>프로그램이 자동으로 연 탭에서 접속해야 합니다. 터미널에서 종료 후 <code>python run_local.py</code>로 다시 실행하세요.</p><p className="error-text">{error}</p><p className="small">이 프로그램에서는 라이엇 계정 비밀번호를 입력하지 마세요.</p></div>;
  if (!data) return <div className="loading-screen"><span className="brand-icon">V</span><p>로컬 대시보드를 준비하고 있습니다…</p></div>;
  const d = data;
  const title = menu.find(x=>x.id===page)?.label||'대시보드';
  const nav = (items:typeof menu) => items.map(x=><button type="button" key={x.id} className={'nav-item '+(page===x.id?'active':'')} onClick={()=>setPage(x.id)} aria-current={page===x.id?'page':undefined}><span className="nav-icon" aria-hidden="true">{x.icon}</span><span>{x.label}</span></button>);
  return <><div className="app"><aside className="sidebar" aria-label="메인 메뉴"><div className="brand"><span className="brand-icon">V</span><div>VAL DASH<small>LOCAL COMPANION</small></div></div><div className="side-label">WORKSPACE</div><nav className="nav">{nav(menu)}</nav><div className="side-bottom"><div className="small-title"><span className="dot"/> DEMO MODE</div><p>{riot?.riot_connected?'계정 연결됨 · 게임 데이터는 DEMO':'라이엇 웹 로그인 · 실험적'}<br/>로컬 서버 · 개인 PC</p><button className="btn muted" onClick={logout}>로컬 세션 종료</button></div></aside>
  <main className="content"><header className="topbar"><div><div className="breadcrumb">VAL DASH / {title}</div><h1 className="top-title">{title}</h1></div><div className="account-actions"><span className="pill">● DEMO DATA</span><button className="btn muted" onClick={()=>setModal(true)}>{riot?.riot_connected?riot.riot_account?.riot_id:'계정 연결'}</button><button className="btn primary" onClick={()=>act('/api/data/refresh',{})}>↻ 새로고침</button></div></header><div className="notice"><div><strong>이 화면의 모든 계정 데이터는 가상입니다</strong><p>게임 설치 없이 실행하는 로컬 웹앱 프로토타입. 실제 상점·제재·랭크를 조회하지 않습니다.</p></div><span className="notice-icon">⚠</span></div>
  <LiveAccountPanel csrfToken={csrf.current}/>
  {page==='overview' && <Dashboard d={d}/>}
  {page==='store' && <><div className="info-box"><span>▣</span><div><b>오늘의 상점 · DEMO</b><div>개인 상점의 실제 데이터를 조회하지 않습니다.</div></div></div><Section title="일일 상점" desc={d.store.remaining_label}/><StoreCards offers={d.store.daily_offers}/><Section title="야시장"/><div className="panel"><div className="panel-title">{d.store.night_market.label}</div></div></>}
  {page==='penalties' && <><div className="grid two-col"><PenaltyCard penalty={d.penalty}/><div className="panel"><div className="panel-title">제재 상태 테스트</div><p className="small">가상 데이터를 전환해 오류 상황을 확인합니다.</p><ScenarioControls value={d.scenario} onSelect={v=>act('/api/demo/scenario',{scenario:v})}/></div></div><Section title="상태 해석"/><div className="panel"><div className="data-row"><span className="key">제재 응답 없음</span><b>조회 가능한 범위에서만 없음</b></div><div className="data-row" style={{marginTop:14}}><span className="key">서버 요청 실패</span><b className="warn">조회 불가로 표시</b></div></div></>}
  {page==='rank' && <><div className="grid metrics"><Metric title="티어" value={d.rank.tier} foot="가상" icon="♛"/><Metric title="RR" value={`${d.rank.rr}/100`} foot="가상" icon="↗"/><Metric title="최근 승리" value={`${d.matches.filter(m=>m.result==='승리').length}승`} foot="5경기" icon="◫"/><Metric title="계정 레벨" value={`${d.account.level}`} foot="가상" icon="◈"/></div><Section title="RR 추이"/><div className="panel"><RRChart values={d.rank.recent_rr}/></div><Section title="전적"/><div className="panel"><Matches matches={d.matches}/></div></>}
  {page==='inventory' && <><div className="grid metrics"><Metric title="보유 스킨" value={`${d.inventory.total_skins}개`} foot="가상" icon="▤"/><Metric title="VP" value={fmt(d.wallet.vp)} foot="가상" icon="◈"/><Metric title="레디어나이트" value={fmt(d.wallet.radianite)} foot="가상" icon="✧"/><Metric title="킹덤 크레딧" value={fmt(d.wallet.kingdom_credits)} foot="가상" icon="◇"/></div><Section title="스킨 미리보기"/><div className="grid store-grid">{d.inventory.skins.map(s=><div className="panel store-card" key={s.name}><div className={'store-art '+s.palette}><div className="weapon-art"/></div><div className="store-copy"><div className="item-type">{s.weapon}</div><div className="item-name">{s.name}</div><span className={'tag '+(s.equipped?'green':'')}>{s.equipped?'장착 예시':'보유 예시'}</span></div></div>)}</div><Section title="데모 미션"/><div className="panel">{d.missions.map(m=><div key={m.title} style={{marginBottom:20}}><div className="data-row"><b>{m.title}</b><span className="small">{m.progress}/{m.goal}</span></div><div className="bar-track"><div className="bar-fill" style={{width:percent(m.progress,m.goal)+'%'}}/></div><div className="small">{m.reward}</div></div>)}</div></>}
  {page==='settings' && <><div className="grid two-col"><div className="panel"><div className="panel-title">데이터 공급자</div><p className="small">MockProvider 사용 · 계정 연결 여부와 관계없이 게임 데이터는 가상입니다.</p><div className="data-rows"><div className="data-row"><span className="key">공식 RSO</span><b>{riot?.riot_login_available?'사용 가능':'승인·설정 필요'}</b></div><div className="data-row"><span className="key">비공식 API</span><b>비활성화</b></div><div className="data-row"><span className="key">비밀번호 보관</span><b className="good">하지 않음</b></div></div></div><div className="panel"><div className="panel-title">데모 제재 시나리오</div><p className="small">결과 표기를 직접 검증할 수 있습니다.</p><ScenarioControls value={d.scenario} onSelect={v=>act('/api/demo/scenario',{scenario:v})}/></div></div><Section title="조회 기록"/><div className="panel">{history.length===0?<div className="empty">기록 없음</div>:history.map((h,i)=><div key={i} className="data-row" style={{marginBottom:9}}><span>{fmtTime(h.at)}</span><span className="tag">{h.source}</span></div>)}</div><Section title="정책 참고"/><div className="panel"><a href="https://developer.riotgames.com/docs/valorant" target="_blank" rel="noopener noreferrer">Riot Developer Portal — VALORANT</a><p className="small">Riot Games의 후원 또는 승인을 받은 제품이 아닙니다.</p></div></>}
  <div className="footer">VAL DASH v0.3.0 · Experimental account login · demo below · Updated: {fmtTime(d.updated_at)}</div></main><nav className="mobile-nav" aria-label="모바일 메뉴">{nav(menu.slice(0,5))}</nav></div>
  {modal && <div className="modal-backdrop"><div className="modal" role="dialog" aria-modal="true" aria-labelledby="connect-title"><h2 id="connect-title">라이엇 계정 연결</h2><p>{riot?.riot_connected?`인증된 계정: ${riot.riot_account?.riot_id}`:riot?.riot_login_available?'라이엇 공식 인증 페이지에서 로그인합니다. VAL DASH는 비밀번호를 받지 않습니다.':'라이엇이 승인한 RSO 클라이언트와 등록된 로컬 콜백이 필요합니다. 현재는 계정 연결을 사용할 수 없습니다.'}</p><p>계정을 연결해도 상점·제재·랭크·재화는 계속 가상 데이터입니다.</p><div className="choice-row">{riot?.riot_connected?<button className="btn primary" onClick={disconnectRiot}>연결 해제</button>:<button className="btn primary" onClick={connectRiot} disabled={!riot?.riot_login_available}>라이엇 공식 로그인</button>}<button className="btn muted" onClick={()=>setModal(false)}>닫기</button></div></div></div>}
  {toast && <div role="status" className="toast">{toast}</div>}
  </>;
}

import {useEffect, useRef, useState} from 'react';
import {request, type Overview, type Scenario, type Penalty, type Offer, type Match} from './api';

type Page = 'overview'|'store'|'penalties'|'rank'|'inventory'|'settings';
const menu: {id:Page;icon:string;label:string}[] = [
  {id:'overview',icon:'◫',label:'대시보드'}, {id:'store',icon:'▣',label:'오늘의 상점'},
  {id:'penalties',icon:'◇',label:'계정 제재'}, {id:'rank',icon:'▥',label:'랭크 · 전적'},
  {id:'inventory',icon:'▤',label:'보유 아이템'}, {id:'settings',icon:'⚙',label:'설정'},
];
const fmt = (n:number) => n.toLocaleString('ko-KR');
const fmtTime = (s:string|null) => s ? new Date(s).toLocaleString('ko-KR', {hour12:false}) : '미제공';
const percent = (value:number,total:number) => total ? Math.min(100,Math.max(0,Math.round(value/total*100))) : 0;

function Metric({title,value,foot,icon,accent=false}: {title:string;value:string;foot:string;icon:string;accent?:boolean}) {
  return <div className="panel metric"><div className="metric-kicker"><span>{title}</span><span className="metric-icon">{icon}</span></div><div className={'metric-value '+(accent?'accent':'')}>{value}</div><div className="metric-foot">{foot}</div></div>;
}
function Section({title,desc}:{title:string;desc?:string}) {
  return <div className="heading-row"><div><h2 className="section-title">{title}</h2>{desc && <div className="section-desc">{desc}</div>}</div></div>;
}
function StoreCards({offers}:{offers:Offer[]}) {
  return <div className="grid store-grid">{offers.map(x=><article className="panel store-card" key={x.id}><div className={'store-art '+x.palette}><div className="weapon-art" aria-hidden="true" /></div><div className="store-copy"><div className="item-type">{x.rarity} · {x.weapon}</div><div className="item-name">{x.name}</div><div className="item-price">{fmt(x.price_vp)} <span>VP</span></div></div></article>)}</div>;
}
function PenaltyCard({penalty}:{penalty:Penalty}) {
  const tone = penalty.status === 'active'?'accent-text':penalty.status === 'unavailable'?'warn':'good';
  return <div className="panel"><div className="panel-heading"><div className="panel-title">계정 제재 상태</div><span className="pill">가상 시나리오</span></div><div className="small">서버 상태를 가정한 테스트 데이터</div><div className={'large-status '+tone}>{penalty.label}</div><div className="data-rows" style={{marginTop:17}}><div className="data-row"><span className="key">제재 유형</span><span className="val">{penalty.type??'없음 / 알 수 없음'}</span></div><div className="data-row"><span className="key">해제 시각</span><span className="val">{fmtTime(penalty.expires_at)}</span></div><div className="data-row"><span className="key">설명</span><span className="val">{penalty.reason??'활성 제재 없음 시나리오'}</span></div></div></div>;
}
function Matches({matches}:{matches:Match[]}) {
  return <div className="matches">{matches.map(m=><div className="match" key={m.id}><div className={'match-result '+(m.result === '승리'?'win':'loss')}>{m.result === '승리'?'WIN':'LOSE'}</div><div style={{flex:1}}><div className="map">{m.map} <span className="small">{m.score}</span></div><div className="agent">{m.agent}</div></div><div className="kda">{m.kda}</div><div className={'rr '+(m.rr_change>0?'good':'accent-text')}>{m.rr_change>0?'+':''}{m.rr_change} RR</div></div>)}</div>;
}
function RRChart({values}:{values:number[]}) {
  const step = 100/Math.max(1,values.length-1);
  const pts = values.map((v,i)=>`${i*step},${100-v}`).join(' ');
  return <><div className="chart-box"><svg viewBox="-4 -10 108 124" role="img" aria-label="데모 RR 변화"><line x1="0" x2="100" y1="100" y2="100" stroke="#394858"/><line x1="0" x2="100" y1="50" y2="50" stroke="#2b3948" strokeDasharray="2 3"/><polyline points={pts} fill="none" stroke="#ff6171" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>{values.map((v,i)=><circle key={i} cx={i*step} cy={100-v} r="2.8" fill="#ff7480" stroke="#0d1520" strokeWidth="1.5"/>)}</svg></div><div className="chart-labels"><span>이전 경기</span><span>최근 경기</span></div></>;
}
function ScenarioControls({value,onSelect}:{value:Scenario;onSelect:(s:Scenario)=>void}) {
  const options: {id:Scenario;label:string}[] = [{id:'clear',label:'활성 제재 없음'},{id:'active',label:'제재 중'},{id:'unknown',label:'조회 오류'}];
  return <div className="choice-row">{options.map(x=><button key={x.id} type="button" className={'choice-btn '+(value===x.id?'active':'')} onClick={()=>onSelect(x.id)}>{x.label}</button>)}</div>;
}
function Dashboard({d}:{d:Overview}) {
  return <><div className="grid metrics"><Metric title="현재 랭크" value={d.rank.tier} foot={`${d.rank.rr} RR · 데모`} icon="♛"/><Metric title="오늘의 상점" value={`${d.store.daily_offers.length}개`} foot="가상 스킨 목록" icon="▣" accent/><Metric title="VP 잔액" value={`${fmt(d.wallet.vp)} VP`} foot="실제 잔액 아님" icon="◈"/><Metric title="제재 상태" value={d.penalty.status==='active'?'제한 중':d.penalty.status==='unavailable'?'조회 불가':'제재 없음'} foot="가상 상태" icon="◇"/></div><Section title="오늘의 상점 미리보기" desc="4개 상품 모두 가상 데이터"/><StoreCards offers={d.store.daily_offers}/><Section title="계정 현황" desc="랭크 및 제재 예시"/><div className="grid two-col"><div className="panel"><div className="panel-heading"><div className="panel-title">최근 RR 변동</div><span className="tag">{d.rank.tier}</span></div><RRChart values={d.rank.recent_rr}/></div><PenaltyCard penalty={d.penalty}/></div><Section title="최근 경기" desc="실제 경기 기록이 아님"/><div className="panel"><Matches matches={d.matches.slice(0,3)}/></div></>;
}

export default function App() {
  const [page,setPage] = useState<Page>('overview');
  const [data,setData] = useState<Overview|null>(null);
  const [history,setHistory] = useState<{at:string;source:string}[]>([]);
  const [error,setError] = useState<string|null>(null);
  const [modal,setModal] = useState(false);
  const [toast,setToast] = useState('');
  const csrf = useRef('');
  const initialized = useRef(false);

  async function reload() {
    const [overview,logs] = await Promise.all([
      request<Overview>('/api/overview'),request<{items:{at:string;source:string}[]}>('/api/history'),
    ]);
    setData(overview);setHistory(logs.items);
  }
  useEffect(()=>{
    // React StrictMode can call effects twice in development; bootstrap once.
    if (initialized.current) return;
    initialized.current = true;
    const raw = window.location.hash;
    const token = raw.startsWith('#launch=')?decodeURIComponent(raw.slice(8)):null;
    if (raw) window.history.replaceState(null,'',window.location.pathname+window.location.search);
    (async()=>{
      try {
        if (token) {
          const result = await request<{csrf_token:string}>('/api/session/bootstrap','POST',{launch_token:token});
          csrf.current = result.csrf_token;
        }
        const session = await request<{csrf_token:string}>('/api/session');
        csrf.current = session.csrf_token;
        await reload();
      } catch(e) {setError(e instanceof Error?e.message:'로컬 세션이 없습니다.');}
    })();
  },[]);
  async function act(path:string,body:unknown) {
    try {await request(path,'POST',body,csrf.current);await reload();setToast('데모 데이터를 갱신했습니다.');window.setTimeout(()=>setToast(''),3000);} catch(e) {setToast(e instanceof Error?e.message:'오류');}
  }
  async function logout() {
    try {await request('/api/session/logout','POST',{},csrf.current);} catch {/* local exit regardless */}
    csrf.current='';setError('로컬 세션을 종료했습니다. 프로그램을 다시 실행하세요.');setData(null);
  }
  if (error) return <div className="locked"><div className="brand-icon">V</div><h1>로컬 세션이 없습니다</h1><p>프로그램이 자동으로 연 탭에서 접속해야 합니다. 터미널에서 종료 후 <code>python run_local.py</code>로 다시 실행하세요.</p><p className="error-text">{error}</p><p className="small">이 프로그램에서는 라이엇 계정 비밀번호를 입력하지 마세요.</p></div>;
  if (!data) return <div className="loading-screen"><span className="brand-icon">V</span><p>로컬 대시보드를 준비하고 있습니다…</p></div>;
  const d = data;
  const title = menu.find(x=>x.id===page)?.label||'대시보드';
  const nav = (items:typeof menu) => items.map(x=><button type="button" key={x.id} className={'nav-item '+(page===x.id?'active':'')} onClick={()=>setPage(x.id)} aria-current={page===x.id?'page':undefined}><span className="nav-icon" aria-hidden="true">{x.icon}</span><span>{x.label}</span></button>);
  return <><div className="app"><aside className="sidebar" aria-label="메인 메뉴"><div className="brand"><span className="brand-icon">V</span><div>VAL DASH<small>LOCAL COMPANION</small></div></div><div className="side-label">WORKSPACE</div><nav className="nav">{nav(menu)}</nav><div className="side-bottom"><div className="small-title"><span className="dot"/> DEMO MODE</div><p>라이엇 로그인 없음<br/>로컬 서버 · 개인 PC</p><button className="btn muted" onClick={logout}>로컬 세션 종료</button></div></aside>
  <main className="content"><header className="topbar"><div><div className="breadcrumb">VAL DASH / {title}</div><h1 className="top-title">{title}</h1></div><div className="account-actions"><span className="pill">● DEMO DATA</span><button className="btn muted" onClick={()=>setModal(true)}>계정 연결</button><button className="btn primary" onClick={()=>act('/api/data/refresh',{})}>↻ 새로고침</button></div></header><div className="notice"><div><strong>이 화면의 모든 계정 데이터는 가상입니다</strong><p>게임 설치 없이 실행하는 로컬 웹앱 프로토타입. 실제 상점·제재·랭크를 조회하지 않습니다.</p></div><span className="notice-icon">⚠</span></div>
  {page==='overview' && <Dashboard d={d}/>}
  {page==='store' && <><div className="info-box"><span>▣</span><div><b>오늘의 상점 · DEMO</b><div>개인 상점의 실제 데이터를 조회하지 않습니다.</div></div></div><Section title="일일 상점" desc={d.store.remaining_label}/><StoreCards offers={d.store.daily_offers}/><Section title="야시장"/><div className="panel"><div className="panel-title">{d.store.night_market.label}</div></div></>}
  {page==='penalties' && <><div className="grid two-col"><PenaltyCard penalty={d.penalty}/><div className="panel"><div className="panel-title">제재 상태 테스트</div><p className="small">가상 데이터를 전환해 오류 상황을 확인합니다.</p><ScenarioControls value={d.scenario} onSelect={v=>act('/api/demo/scenario',{scenario:v})}/></div></div><Section title="상태 해석"/><div className="panel"><div className="data-row"><span className="key">제재 응답 없음</span><b>조회 가능한 범위에서만 없음</b></div><div className="data-row" style={{marginTop:14}}><span className="key">서버 요청 실패</span><b className="warn">조회 불가로 표시</b></div></div></>}
  {page==='rank' && <><div className="grid metrics"><Metric title="티어" value={d.rank.tier} foot="가상" icon="♛"/><Metric title="RR" value={`${d.rank.rr}/100`} foot="가상" icon="↗"/><Metric title="최근 승리" value={`${d.matches.filter(m=>m.result==='승리').length}승`} foot="5경기" icon="◫"/><Metric title="계정 레벨" value={`${d.account.level}`} foot="가상" icon="◈"/></div><Section title="RR 추이"/><div className="panel"><RRChart values={d.rank.recent_rr}/></div><Section title="전적"/><div className="panel"><Matches matches={d.matches}/></div></>}
  {page==='inventory' && <><div className="grid metrics"><Metric title="보유 스킨" value={`${d.inventory.total_skins}개`} foot="가상" icon="▤"/><Metric title="VP" value={fmt(d.wallet.vp)} foot="가상" icon="◈"/><Metric title="레디어나이트" value={fmt(d.wallet.radianite)} foot="가상" icon="✧"/><Metric title="킹덤 크레딧" value={fmt(d.wallet.kingdom_credits)} foot="가상" icon="◇"/></div><Section title="스킨 미리보기"/><div className="grid store-grid">{d.inventory.skins.map(s=><div className="panel store-card" key={s.name}><div className={'store-art '+s.palette}><div className="weapon-art"/></div><div className="store-copy"><div className="item-type">{s.weapon}</div><div className="item-name">{s.name}</div><span className={'tag '+(s.equipped?'green':'')}>{s.equipped?'장착 예시':'보유 예시'}</span></div></div>)}</div><Section title="데모 미션"/><div className="panel">{d.missions.map(m=><div key={m.title} style={{marginBottom:20}}><div className="data-row"><b>{m.title}</b><span className="small">{m.progress}/{m.goal}</span></div><div className="bar-track"><div className="bar-fill" style={{width:percent(m.progress,m.goal)+'%'}}/></div><div className="small">{m.reward}</div></div>)}</div></>}
  {page==='settings' && <><div className="grid two-col"><div className="panel"><div className="panel-title">데이터 공급자</div><p className="small">MockProvider 사용 · 라이엇 계정 연결 없음</p><div className="data-rows"><div className="data-row"><span className="key">공식 RSO</span><b>승인·설정 필요</b></div><div className="data-row"><span className="key">비공식 API</span><b>비활성화</b></div><div className="data-row"><span className="key">비밀번호 보관</span><b className="good">하지 않음</b></div></div></div><div className="panel"><div className="panel-title">데모 제재 시나리오</div><p className="small">결과 표기를 직접 검증할 수 있습니다.</p><ScenarioControls value={d.scenario} onSelect={v=>act('/api/demo/scenario',{scenario:v})}/></div></div><Section title="조회 기록"/><div className="panel">{history.length===0?<div className="empty">기록 없음</div>:history.map((h,i)=><div key={i} className="data-row" style={{marginBottom:9}}><span>{fmtTime(h.at)}</span><span className="tag">{h.source}</span></div>)}</div><Section title="정책 참고"/><div className="panel"><a href="https://developer.riotgames.com/docs/valorant" target="_blank" rel="noopener noreferrer">Riot Developer Portal — VALORANT</a><p className="small">Riot Games의 후원 또는 승인을 받은 제품이 아닙니다.</p></div></>}
  <div className="footer">VAL DASH v0.1.0 · Mock data only · Updated: {fmtTime(d.updated_at)}</div></main><nav className="mobile-nav" aria-label="모바일 메뉴">{nav(menu.slice(0,5))}</nav></div>
  {modal && <div className="modal-backdrop"><div className="modal" role="dialog" aria-modal="true" aria-labelledby="connect-title"><h2 id="connect-title">실계정 연동은 비활성화되어 있습니다</h2><p>VALORANT 공식 RSO 연동은 라이엇 승인이 필요합니다. 개인 상점과 계정 제재는 공식 API에서 제공하지 않으므로 현재 버전에서는 라이엇 계정 정보를 수집하지 않습니다.</p><button className="btn primary" onClick={()=>setModal(false)}>확인</button></div></div>}
  {toast && <div role="status" className="toast">{toast}</div>}
  </>;
}

export type Scenario = 'clear' | 'active' | 'unknown';
export type Offer = {id: string; name: string; weapon: string; price_vp: number; rarity: string; palette: string};
export type OwnedSkin = {name: string; weapon: string; equipped: boolean; palette: string};
export type Penalty = {status: 'clear'|'active'|'unavailable';label:string;reason:string|null;expires_at:string|null;type:string|null};
export type Match = {id:string;map:string;agent:string;result:string;score:string;kda:string;rr_change:number};
export type Overview = {
  mode:'demo';live:false;updated_at:string;scenario:Scenario;
  account:{id:string;riot_id:string;region:string;level:number};
  wallet:{vp:number;radianite:number;kingdom_credits:number};
  rank:{tier:string;rr:number;season_wins:number;recent_rr:number[];recent_wins:boolean[]};
  store:{remaining_label:string;daily_offers:Offer[];night_market:{available:boolean;label:string}};
  penalty:Penalty;matches:Match[];
  inventory:{total_skins:number;skins:OwnedSkin[]};
  missions:{title:string;progress:number;goal:number;reward:string}[];
};
export type Session = {ok:boolean;csrf_token:string;mode:'demo';riot_connected:boolean};

export class ApiError extends Error {}
export async function request<T>(path: string, method = 'GET', body?: unknown, csrfToken?: string): Promise<T> {
  const headers: Record<string, string> = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (method !== 'GET' && csrfToken) headers['X-CSRF-Token'] = csrfToken;
  const response = await fetch(path, {
    method, credentials: 'same-origin', headers,
    ...(body === undefined ? {} : {body: JSON.stringify(body)}),
  });
  const payload = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    const detail = (payload.detail && typeof payload.detail === 'object' ? payload.detail : payload) as Record<string,unknown>;
    throw new ApiError(String(detail.message || detail.code || `HTTP ${response.status}`));
  }
  return payload as T;
}

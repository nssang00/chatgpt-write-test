@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Dependencies are not installed. Run install.bat first.
    exit /b 1
)

".venv\Scripts\python.exe" "run_local.py" %*
set "APP_EXIT_CODE=%errorlevel%"
if not "%APP_EXIT_CODE%"=="0" (
    echo [ERROR] VAL DASH stopped with exit code %APP_EXIT_CODE%.
)
exit /b %APP_EXIT_CODE%

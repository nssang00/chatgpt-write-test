@echo off
if not exist "%~dp0UMAA.Standalone\bin\Release\net48\UMAA.Standalone.exe" (echo Run Build-Standalone.bat first.& exit /b 1)
start "" /D "%~dp0UMAA.Standalone\bin\Release\net48" "%~dp0UMAA.Standalone\bin\Release\net48\UMAA.Standalone.exe"

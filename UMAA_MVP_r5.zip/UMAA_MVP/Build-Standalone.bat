@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" || exit /b 1
set "RC=1"
set "OUT=%CD%\UMAA.Standalone\bin\Release\net48"
where dotnet.exe >nul 2>&1 || (echo ERROR: dotnet SDK not found.& goto :finish)
dotnet build ".\UMAA.Standalone\UMAA.Standalone.csproj" -c Release
if errorlevel 1 goto :finish
for %%F in (UMAA.Standalone.exe UMAA.UI.dll UMAA.Core.dll UMAA.Repository.SQLite.dll System.Data.SQLite.dll Microsoft.Web.WebView2.Core.dll Microsoft.Web.WebView2.Wpf.dll Newtonsoft.Json.dll) do if not exist "%OUT%\%%F" (
 echo ERROR: Missing "%OUT%\%%F"
 goto :finish
)
call "%~dp0Check-RuntimeFiles.bat" "%OUT%"
if errorlevel 1 goto :finish
echo SUCCESS: "%OUT%\UMAA.Standalone.exe"
set "RC=0"
:finish
if not "%RC%"=="0" echo FAILED: Review the error above.
popd
endlocal & exit /b %RC%

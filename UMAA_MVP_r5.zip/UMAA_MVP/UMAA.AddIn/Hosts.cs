using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using UMAA.UI;
namespace UMAA.AddIn {
 [ComVisible(true), Guid("FFB67B65-01B9-4FE1-AC57-1218671D27F2"), ProgId("UMAA.MVP.WorkspaceHost"), ClassInterface(ClassInterfaceType.AutoDispatch)]
 public class WorkspaceHost:UserControl {
  readonly WorkspaceView view;
  public WorkspaceHost(){view=new WorkspaceView();Controls.Add(new ElementHost{Dock=DockStyle.Fill,Child=view});}
  internal void Attach(WorkspaceSession session){view.DataContext=session;}
  protected override void Dispose(bool disposing){if(disposing)view?.Dispose();base.Dispose(disposing);}
 }
 [ComVisible(true), Guid("56810D3C-31BA-4ED8-B92D-C75AEE162785"), ProgId("UMAA.MVP.InspectorHost"), ClassInterface(ClassInterfaceType.AutoDispatch)]
 public class InspectorHost:UserControl {
  readonly InspectorView view;
  public InspectorHost(){view=new InspectorView();Controls.Add(new ElementHost{Dock=DockStyle.Fill,Child=view});}
  internal void Attach(WorkspaceSession session){view.DataContext=session;}
 }
}

using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Forms.Integration;
using UMAA.UI;
using UMAA.Repository.EA;
using UMAA.Repository.SQLite;
namespace UMAA.AddIn
{
 [ComVisible(true), Guid("7301F8BA-E7B0-4674-89CA-38DE74859031"), ProgId("UMAA.MVP.AddIn"), ClassInterface(ClassInterfaceType.AutoDispatch)]
 public class AddInEntry
 {
  const string Menu="-UMAA MVP", Tab="UMAA MVP Workspace", Dock="UMAA MVP Inspector";
  const string OpenTab="Open Workspace", OpenDock="Show Inspector", OpenPopup="Open Separate Window", LoadCurrent="Load Current QEA";
  WorkspaceSession session; InspectorHost inspector; Window popup;
  public string EA_Connect(global::EA.Repository repository){session=new WorkspaceSession(path=>new QeaModelReader(path));session.Navigator=new EaModelNavigator(repository);return "";}
  public object EA_GetMenuItems(global::EA.Repository repository,string location,string menuName){if(string.IsNullOrEmpty(menuName))return Menu;if(menuName==Menu)return new[]{OpenTab,OpenDock,OpenPopup,LoadCurrent};return null;}
  public void EA_GetMenuState(global::EA.Repository repository,string location,string menuName,string itemName,ref bool isEnabled,ref bool isChecked){isEnabled=true;isChecked=false;}
  public void EA_MenuClick(global::EA.Repository repository,string location,string menuName,string itemName){
   try{
    if(session==null)EA_Connect(repository);
    session.Navigator=new EaModelNavigator(repository);
    if(itemName==OpenTab){
     if(Convert.ToString(repository.IsTabOpen(Tab))=="0"){
      var host=(WorkspaceHost)repository.AddTab(Tab,"UMAA.MVP.WorkspaceHost");if(host==null)throw new InvalidOperationException("AddTab returned null");host.Attach(session);
     }
     repository.ActivateTab(Tab);
    }else if(itemName==OpenDock){
     if(inspector==null){inspector=(InspectorHost)repository.AddWindow(Dock,"UMAA.MVP.InspectorHost");if(inspector==null)throw new InvalidOperationException("AddWindow returned null");inspector.Attach(session);}
     repository.ShowAddinWindow(Dock);
    }else if(itemName==OpenPopup){
     if(popup!=null){if(popup.WindowState==WindowState.Minimized)popup.WindowState=WindowState.Normal;popup.Activate();return;}
     var view=new WorkspaceView{DataContext=session};popup=new Window{Title="UMAA MVP - separate window",Width=1080,Height=740,MinWidth=600,MinHeight=460,Content=view,WindowStartupLocation=WindowStartupLocation.CenterScreen};
     popup.Closed+=(s,e)=>{view.Dispose();popup=null;};ElementHost.EnableModelessKeyboardInterop(popup);popup.Show();
    }else if(itemName==LoadCurrent){
     var path=repository.ConnectionString;
     if(string.IsNullOrWhiteSpace(path)||!File.Exists(path)||(!path.EndsWith(".qea",StringComparison.OrdinalIgnoreCase)&&!path.EndsWith(".qeax",StringComparison.OrdinalIgnoreCase)))throw new InvalidOperationException("Current EA connection is not a local QEA/QEAX file. Open it manually in Workspace.");
     // EA callbacks can lack a WPF synchronization context; dispatch using the UI thread.
     var dispatcher=System.Windows.Threading.Dispatcher.CurrentDispatcher;
     var current=session;
     dispatcher.BeginInvoke(new Action(async ()=>{try{await current.OpenAsync(path);}catch(Exception ex){current.Write(ex.Message);}}));
    }
   }catch(Exception ex){MessageBox.Show(ex.Message,"UMAA MVP error");}
  }
  public void EA_OnContextItemChanged(global::EA.Repository repository,string guid,global::EA.ObjectType objectType){if(session==null)return;try{session.Context=new EaModelNavigator(repository).Describe(guid,objectType);}catch{session.Context=objectType+"\n"+guid;}}
  public void EA_FileClose(global::EA.Repository repository){if(session!=null){session.Context="EA model closed";session.Navigator=null;session.ResetSource();}if(popup!=null)popup.Close();}
  public void EA_Disconnect(){if(popup!=null)popup.Close();if(session!=null){session.Navigator=null;session.ResetSource();}inspector=null;session=null;}
 }
}

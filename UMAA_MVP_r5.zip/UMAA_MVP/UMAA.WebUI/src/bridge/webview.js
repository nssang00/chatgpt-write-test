// Only the WebView2 host exposes this transport. Ordinary browsers stay disconnected.
export const bridge = window.chrome?.webview;

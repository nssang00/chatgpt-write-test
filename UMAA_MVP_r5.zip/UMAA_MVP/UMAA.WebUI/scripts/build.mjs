// Static IIFE + CSS, following umaa_dev_studio's build layout.
import { build, context, version } from 'esbuild';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { readFileSync } from 'node:fs';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
if (version !== pkg.devDependencies.esbuild) throw new Error('esbuild version mismatch. Run npm ci.');
const watch = process.argv.includes('--watch');
const options = {
  absWorkingDir: root, entryPoints: ['src/main.js'], outdir: 'dist',
  entryNames: '[name]', bundle: true, format: 'iife', platform: 'browser',
  target: ['es2020'], jsx: 'automatic', minify: !watch,
  sourcemap: watch, legalComments: 'inline', logLevel: 'info',
};
try {
  if (watch) {
    const ctx = await context(options); await ctx.watch();
    console.log('Watching source files (no HTTP server). Rebuild/reopen desktop host to see changes.');
    const stop = async () => { await ctx.dispose(); process.exit(0); };
    process.on('SIGINT', stop); process.on('SIGTERM', stop);
  } else { await build(options); }
} catch (error) { console.error(error); process.exitCode = 1; }

import { readFileSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = p => readFileSync(resolve(root,p),'utf8');
const html = read('index.html'), build = read('scripts/build.mjs');
const checks = [
  ['relative JS', html.includes('src="./dist/main.js"')],
  ['relative CSS', html.includes('href="./dist/main.css"')],
  ['no inline script/style', !/<script(?![^>]*src=)|<style[ >]/i.test(html)],
  ['IIFE static bundle', build.includes("format: 'iife'") && build.includes('bundle: true')],
  ['no server', !/\bserve\s*\(/.test(build)],
  ['JS output', existsSync(resolve(root,'dist/main.js'))],
  ['CSS output', existsSync(resolve(root,'dist/main.css'))],
];
for (const [label, ok] of checks) console.log(`${ok?'PASS':'FAIL'} ${label}`);
if (checks.some(([,ok])=>!ok)) process.exitCode=1;

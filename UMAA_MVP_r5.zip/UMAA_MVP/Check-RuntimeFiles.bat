@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "OUT=%~1"
rem PackageReference normally deploys native assets automatically.
rem Normalize x64 copies for the .NET Framework / EA load-from context.
if not exist "%OUT%\x64\SQLite.Interop.dll" (
 if exist "%OUT%\runtimes\win-x64\native\SQLite.Interop.dll" (
  if not exist "%OUT%\x64" mkdir "%OUT%\x64"
  copy /y "%OUT%\runtimes\win-x64\native\SQLite.Interop.dll" "%OUT%\x64\SQLite.Interop.dll" >nul
 )
)
if not exist "%OUT%\x64\SQLite.Interop.dll" (
 echo ERROR: x64 SQLite.Interop.dll missing. Run Build-AddIn.bat or Build-Standalone.bat with the r3 project files.
 exit /b 1
)
if not exist "%OUT%\WebView2Loader.dll" if exist "%OUT%\runtimes\win-x64\native\WebView2Loader.dll" copy /y "%OUT%\runtimes\win-x64\native\WebView2Loader.dll" "%OUT%\WebView2Loader.dll" >nul
if not exist "%OUT%\WebView2Loader.dll" if exist "%OUT%\x64\WebView2Loader.dll" copy /y "%OUT%\x64\WebView2Loader.dll" "%OUT%\WebView2Loader.dll" >nul
if not exist "%OUT%\WebView2Loader.dll" (
 echo ERROR: WebView2Loader.dll missing. Check NuGet restore.
 exit /b 1
)
exit /b 0

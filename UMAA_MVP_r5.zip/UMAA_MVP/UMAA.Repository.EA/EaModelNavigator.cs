using System;
using UMAA.Core;
namespace UMAA.Repository.EA
{
    // Call on the EA UI/STA thread. Never hold an element RCW in the shared model.
    public sealed class EaModelNavigator : IModelNavigator
    {
        readonly global::EA.Repository repository;
        public EaModelNavigator(global::EA.Repository repository){this.repository=repository??throw new ArgumentNullException(nameof(repository));}
        public void Navigate(string source,string guid){if(!System.IO.File.Exists(source)||!System.IO.File.Exists(repository.ConnectionString)||!string.Equals(System.IO.Path.GetFullPath(source),System.IO.Path.GetFullPath(repository.ConnectionString),StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Open the current EA QEA before navigating.");var element=repository.GetElementByGuid(guid);if(element==null)throw new InvalidOperationException("Element not found in the current EA model.");repository.ShowInProjectView(element);}
        public string Describe(string guid,global::EA.ObjectType kind){if(kind==global::EA.ObjectType.otElement){var e=repository.GetElementByGuid(guid);return e.Name+"\n"+guid;}return kind+"\n"+guid;}
        public string ConnectionString=>repository.ConnectionString;
    }
}

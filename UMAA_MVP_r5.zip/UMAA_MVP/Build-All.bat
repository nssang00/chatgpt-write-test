@echo off
call "%~dp0Build-AddIn.bat" %*
if errorlevel 1 exit /b 1
call "%~dp0Build-Standalone.bat"
exit /b %ERRORLEVEL%

@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "INTEROP_ARG=%~1"
if defined INTEROP_ARG set "INTEROP_ARG=%~f1"
pushd "%~dp0" || exit /b 1
set "RC=1"
set "PROJECT=%CD%\UMAA.AddIn\UMAA.AddIn.csproj"
set "INTEROP=%CD%\Interop.EA.dll"
if defined INTEROP_ARG set "INTEROP=%INTEROP_ARG%"
set "OUT=%CD%\UMAA.AddIn\bin\Release\net48"
echo === UMAA MVP - Build Release x64 ===
where dotnet.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: dotnet SDK not found in PATH.
    goto :finish
)
if not exist "%PROJECT%" (
    echo ERROR: Project not found: "%PROJECT%"
    goto :finish
)
if not exist "%INTEROP%" (
    echo ERROR: Interop.EA.dll not found: "%INTEROP%"
    echo Place it next to this BAT or pass its path as argument 1.
    goto :finish
)
rem A previously installed Add-In may have its build output locked by EA.
tasklist /FI "IMAGENAME eq EA.exe" /NH | findstr /I /B /C:"EA.exe " >nul
if not errorlevel 1 (
    echo ERROR: Save your work and close EA before building.
    goto :finish
)
dotnet build "%PROJECT%" -c Release "/p:EaInteropPath=%INTEROP%"
if errorlevel 1 goto :finish
for %%F in (UMAA.AddIn.dll UMAA.UI.dll UMAA.Core.dll UMAA.Repository.EA.dll UMAA.Repository.SQLite.dll Interop.EA.dll System.Data.SQLite.dll Microsoft.Web.WebView2.Core.dll Microsoft.Web.WebView2.Wpf.dll Newtonsoft.Json.dll) do if not exist "%OUT%\%%F" (
    echo ERROR: Build output missing: "%OUT%\%%F"
    goto :finish
)
call "%~dp0Check-RuntimeFiles.bat" "%OUT%"
if errorlevel 1 goto :finish
echo.
echo SUCCESS: Build completed. No COM or registry changes were made.
echo Output: "%OUT%"
echo Next: Run Install-AddIn.bat as administrator under your EA user account.
set "RC=0"
:finish
if not "%RC%"=="0" echo FAILED: Review the error above.
popd
endlocal & exit /b %RC%

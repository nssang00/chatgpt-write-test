@echo off
setlocal
pushd "%~dp0" || exit /b 1
dotnet build ".\UMAA.Tests\UMAA.Tests.csproj" -c Release
if errorlevel 1 (popd & exit /b 1)
".\UMAA.Tests\bin\Release\net48\UMAA.Tests.exe" "%CD%\Sample\SampleModel.db"
set "RC=%ERRORLEVEL%"
popd
endlocal & exit /b %RC%

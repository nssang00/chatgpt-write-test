using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using UMAA.Core;

namespace UMAA.UI
{
    public sealed class MappingRow : INotifyPropertyChanged
    {
        public ModelField Field {get;}
        public string Source=>Field.Name;
        public string Type=>Field.Type;
        string target;
        public string Target {get=>target;set{if(target==value)return;target=value;PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(nameof(Target)));}}
        public MappingRow(ModelField f){Field=f;target=f.Name;}
        public FieldMapping Snapshot()=>new FieldMapping{Source=Source,Type=Type,Target=Target,Lower=Field.Lower,Upper=Field.Upper,Classifier=Field.Classifier};
        public event PropertyChangedEventHandler PropertyChanged;
    }
    public sealed class WorkspaceSession : INotifyPropertyChanged
    {
        IModelReader reader;
        readonly Func<string,IModelReader> openReader;
        IModelNavigator navigator;
        public IModelNavigator Navigator {get=>navigator;set{navigator=value;Notify();}}
        public ObservableCollection<ModelElement> Elements {get;}=new ObservableCollection<ModelElement>();
        public ObservableCollection<MappingRow> Mapping {get;}=new ObservableCollection<MappingRow>();
        public ObservableCollection<string> Log {get;}=new ObservableCollection<string>();
        public ObservableCollection<string> Issues {get;}=new ObservableCollection<string>();
        string context="EA not connected",source="Demo",status="Ready",preview="",search="",result="Not validated",savedPath="",artifactCheck="Not checked";
        ModelElement selected,loaded;
        bool busy; int epoch; long revision;
        public WorkspaceSession(Func<string,IModelReader> factory){openReader=factory??throw new ArgumentNullException(nameof(factory));UseDemo();}
        public string Context {get=>context;set{context=value;Notify();}}
        public string Source {get=>source;private set{source=value;Notify();}}
        public string Search {get=>search;set{search=value;Notify();}}
        public string Status {get=>status;private set{status=value;Notify();}}
        public string Preview {get=>preview;private set{preview=value;Notify();Notify(nameof(CanSave));}}
        public string Result {get=>result;private set{result=value;Notify();}}
        public string SavedPath {get=>savedPath;private set{savedPath=value;Notify();}}
        public string ArtifactCheck {get=>artifactCheck;private set{artifactCheck=value;Notify();}}
        public string LoadedGuid=>loaded?.Guid??"";
        public string LoadedName=>loaded?.Name??"No loaded element";
        public long Revision=>revision;
        public bool Busy {get=>busy;private set{busy=value;Notify();Notify(nameof(Ready));Notify(nameof(CanSave));}}
        public bool Ready=>!Busy;
        public bool CanSave=>!Busy&&!string.IsNullOrEmpty(Preview);
        public ModelElement Selected {get=>selected;set{if(ReferenceEquals(selected,value))return;selected=value;Notify();}}
        public event PropertyChangedEventHandler PropertyChanged;
        public event EventHandler MappingChanged;
        void Notify([CallerMemberName]string n=null)=>PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(n));
        public void Write(string s){Status=s;Log.Add(DateTime.Now.ToString("HH:mm:ss")+"  "+s);while(Log.Count>300)Log.RemoveAt(0);}
        void ClearMapping(){foreach(var row in Mapping)row.PropertyChanged-=RowChanged;Mapping.Clear();loaded=null;Notify(nameof(LoadedName));Invalidate();}
        void Invalidate(){Preview="";SavedPath="";ArtifactCheck="Not checked";Issues.Clear();Result="Not validated";revision++;MappingChanged?.Invoke(this,EventArgs.Empty);}
        void RowChanged(object s,PropertyChangedEventArgs e)=>Invalidate();
        void ReplaceElements(IEnumerable<ModelElement> values){Selected=null;Elements.Clear();foreach(var v in values)Elements.Add(v);Selected=Elements.FirstOrDefault();}
        void ReplaceFields(ModelElement element,IEnumerable<ModelField> fields){ClearMapping();loaded=element;foreach(var f in fields){var row=new MappingRow(f);row.PropertyChanged+=RowChanged;Mapping.Add(row);}Notify(nameof(LoadedName));Invalidate();}
        public void UseDemo(){if(Busy)return;epoch++;reader=new DemoModelReader();Source="Demo (not official UMAA)";Search="";ClearMapping();ReplaceElements(reader.GetElements("",2000));if(Selected!=null)ReplaceFields(Selected,reader.GetFields(Selected.Guid));Write("Demo model loaded.");}
        public void ResetSource(){epoch++;reader=null;Source="No file";ClearMapping();ReplaceElements(new ModelElement[0]);Write("Model closed.");}
        public async Task<bool> OpenAsync(string path){if(Busy)return false;Busy=true;int token=++epoch;try{
            var newReader=openReader(path);var list=await Task.Run(()=>newReader.GetElements("",2000));if(token!=epoch)return false;
            reader=newReader;Source=path;Search="";ClearMapping();ReplaceElements(list);Write("SQLite read-only: "+list.Count+" elements (max 2000). Select and load fields.");return true;
        }catch(Exception ex){if(token==epoch)Write("Open failed: "+ex.Message);return false;}finally{Busy=false;}}
        public async Task<bool> SearchAsync(){if(Busy||reader==null)return false;Busy=true;int token=epoch;var r=reader;var query=Search;try{var list=await Task.Run(()=>r.GetElements(query,2000));if(token!=epoch)return false;ReplaceElements(list);Write("Search: "+list.Count+" elements (max 2000).");return true;}catch(Exception ex){if(token==epoch)Write("Search failed: "+ex.Message);return false;}finally{Busy=false;}}
        public async Task<bool> LoadFieldsAsync(){if(Busy||reader==null||Selected==null)return false;Busy=true;int token=epoch;var r=reader;var el=Selected;try{var fields=await Task.Run(()=>r.GetFields(el.Guid));if(token!=epoch)return false;ReplaceFields(el,fields);Write("Loaded "+el.Name+": "+fields.Count+" fields.");return true;}catch(Exception ex){if(token==epoch)Write("Load fields failed: "+ex.Message);return false;}finally{Busy=false;}}
        public bool Navigate(){if(Busy||Navigator==null||Selected==null){Write("EA navigation unavailable.");return false;}try{Navigator.Navigate(Source,Selected.Guid);Write("EA navigation: "+Selected.Name);return true;}catch(Exception ex){Write("EA navigation failed: "+ex.Message);return false;}}
        public void AutoMap(){if(Busy)return;foreach(var row in Mapping.Where(x=>string.IsNullOrWhiteSpace(x.Target)))row.Target=row.Source;Write("Empty targets filled.");}
        public bool ApplyWebMapping(long expected,string[] values){if(Busy||expected!=Revision||values==null||values.Length!=Mapping.Count||values.Any(x=>x==null||x.Length>256))return false;for(int i=0;i<values.Length;i++)Mapping[i].Target=values[i];Write("Web mapping applied.");return true;}
        List<FieldMapping> Snapshot()=>Mapping.Select(x=>x.Snapshot()).ToList();
        public bool Validate(){if(Busy)return false;Issues.Clear();foreach(var error in IdlGenerator.Validate(loaded?.Name,Snapshot()))Issues.Add(error);Result=Issues.Count==0?"MVP checks passed":"Review required: "+Issues.Count;Write(Result);return Issues.Count==0;}
        public bool Generate(){if(Busy)return false;Preview="";SavedPath="";ArtifactCheck="Not checked";if(!Validate())return false;Preview=IdlGenerator.Generate(loaded.Name,Snapshot());Write("IDL preview generated.");return true;}
        public bool SaveIdl(string path){if(!CanSave)return false;try{
            System.IO.File.WriteAllText(path,Preview,new System.Text.UTF8Encoding(false));SavedPath=path;ArtifactCheck="Not checked";Write("Saved: "+path);return true;
        }catch(Exception ex){Write("Save failed: "+ex.Message);return false;}}
        public bool VerifySavedIdl(){if(Busy||!CanSave||string.IsNullOrEmpty(SavedPath))return false;try{
            var expected=new System.Text.UTF8Encoding(false).GetBytes(Preview);
            using(var file=new System.IO.FileStream(SavedPath,System.IO.FileMode.Open,System.IO.FileAccess.Read,System.IO.FileShare.Read)){
                bool match=file.Length==expected.Length;
                for(int i=0;match&&i<expected.Length;i++)match=file.ReadByte()==expected[i];
                ArtifactCheck=match?"File matches current IDL preview":"File differs from current IDL preview";Write(ArtifactCheck);return match;
            }
        }catch(Exception ex){ArtifactCheck="File check failed: "+ex.Message;Write(ArtifactCheck);return false;}}
    }
}

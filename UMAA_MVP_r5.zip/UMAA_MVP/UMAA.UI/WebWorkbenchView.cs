using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Microsoft.Win32;
using Newtonsoft.Json;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;

namespace UMAA.UI
{
    // UI-thread bridge. Core and repositories are not exposed as JavaScript host objects.
    internal sealed class WebWorkbenchView : Grid, IDisposable
    {
        readonly WorkspaceSession session;
        readonly JsonSerializerSettings jsonSettings=new JsonSerializerSettings{TypeNameHandling=TypeNameHandling.None,MetadataPropertyHandling=MetadataPropertyHandling.Ignore,DateParseHandling=DateParseHandling.None,MaxDepth=32};
        readonly TextBlock hint=new TextBlock{Margin=new Thickness(16),TextWrapping=TextWrapping.Wrap,Text="Initializing UMAA Web Workbench…"};
        WebView2 web;
        bool started,disposed,pageReady,handling,queued;
        const string Page="https://umaa-mvp.local/index.html";
        const string Script="https://umaa-mvp.local/dist/main.js";
        const string Style="https://umaa-mvp.local/dist/main.css";
        static bool AllowedResource(string uri)=>string.Equals(uri,Page,StringComparison.Ordinal)||string.Equals(uri,Script,StringComparison.Ordinal)||string.Equals(uri,Style,StringComparison.Ordinal);
        static void ExtractAsset(string folder,string relative,string resource){
            var path=Path.Combine(folder,relative);
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            using(var input=typeof(WebWorkbenchView).Assembly.GetManifestResourceStream(resource)){
                if(input==null)throw new InvalidOperationException("Embedded WebUI asset not found: "+resource);
                using(var output=File.Create(path))input.CopyTo(output);
            }
        }
        public WebWorkbenchView(WorkspaceSession session){this.session=session;Children.Add(hint);Loaded+=OnLoaded;session.PropertyChanged+=Changed;session.MappingChanged+=MappingChanged;}
        async void OnLoaded(object sender,RoutedEventArgs e){
            if(started||disposed)return;started=true;
            try{
                var baseDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"UMAA.MVP");
                var process=System.Diagnostics.Process.GetCurrentProcess();
                var folder=Path.Combine(baseDir,"WebAssets",process.Id+"-"+process.StartTime.ToUniversalTime().Ticks,Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(folder);
                ExtractAsset(folder,"index.html","UMAA.WebUI.index.html");
                ExtractAsset(folder,Path.Combine("dist","main.js"),"UMAA.WebUI.dist.main.js");
                ExtractAsset(folder,Path.Combine("dist","main.css"),"UMAA.WebUI.dist.main.css");
                var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(baseDir,"WebRuntime",process.ProcessName));
                if(disposed)return;
                web=new WebView2();Children.Add(web);await web.EnsureCoreWebView2Async(env);if(disposed)return;
                var core=web.CoreWebView2;
                core.Settings.AreHostObjectsAllowed=false;core.Settings.AreDevToolsEnabled=false;core.Settings.AreDefaultContextMenusEnabled=false;
                core.Settings.IsWebMessageEnabled=true;core.Settings.IsStatusBarEnabled=false;
                core.SetVirtualHostNameToFolderMapping("umaa-mvp.local",folder,CoreWebView2HostResourceAccessKind.Deny);
                core.NavigationStarting+=(s,a)=>{if(!string.Equals(a.Uri,Page,StringComparison.Ordinal))a.Cancel=true;else pageReady=false;};
                core.NewWindowRequested+=(s,a)=>a.Handled=true;
                core.PermissionRequested+=(s,a)=>a.State=CoreWebView2PermissionState.Deny;
                core.AddWebResourceRequestedFilter("*",CoreWebView2WebResourceContext.All);
                core.WebResourceRequested+=(s,a)=>{if(!AllowedResource(a.Request.Uri))a.Response=env.CreateWebResourceResponse(null,403,"Forbidden","Content-Type: text/plain");};
                core.WebMessageReceived+=Receive;
                core.NavigationCompleted+=(s,a)=>{if(!a.IsSuccess&&!disposed)session.Write("Web navigation failed: "+a.WebErrorStatus);};
                core.Navigate(Page);
            }catch(Exception ex){if(!disposed){if(web!=null){Children.Remove(web);web.Dispose();web=null;}hint.Text="WebView2 initialization failed. Install/update Microsoft Edge WebView2 Runtime (x64), then reopen the workspace.\n"+ex.Message;session.Write(hint.Text);}}
        }
        void Changed(object sender,PropertyChangedEventArgs e)=>Schedule();
        void MappingChanged(object sender,EventArgs e)=>Schedule();
        void Schedule(){if(disposed||handling||queued||!pageReady)return;queued=true;Dispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>{queued=false;if(!handling)SendState();}));}
        void Post(object value){if(disposed||!pageReady||web?.CoreWebView2==null)return;var json=JsonConvert.SerializeObject(value,Formatting.None,jsonSettings);if(json.Length>16*1024*1024)throw new InvalidOperationException("Web payload exceeds 16 Mi characters.");web.CoreWebView2.PostWebMessageAsJson(json);}
        void SendState(){try{Post(new{kind="state",revision=session.Revision,source=session.Source,context=session.Context,status=session.Status,busy=session.Busy,canNavigate=session.Navigator!=null,selected=session.Selected?.Guid??"",loaded=session.LoadedGuid,name=session.LoadedName,search=session.Search,result=session.Result,preview=session.Preview,savedPath=session.SavedPath,artifactCheck=session.ArtifactCheck,elements=session.Elements.Select(x=>new{guid=x.Guid,name=x.Name,package=x.Package,type=x.Type,stereotype=x.Stereotype}).ToArray(),rows=session.Mapping.Select(r=>new{source=r.Source,type=r.Type,target=r.Target}).ToArray(),issues=session.Issues.ToArray(),logs=session.Log.ToArray()});}catch(Exception ex){System.Diagnostics.Debug.WriteLine(ex);try{Post(new{kind="error",message="State delivery failed: "+ex.Message});}catch{}}}
        public sealed class Request {public string action{get;set;}public long revision{get;set;}public string[] targets{get;set;}public string guid{get;set;}public string query{get;set;}public int id{get;set;}}
        // Dispatch after the WebView callback returns; native modal dialogs must not run inside the callback.
        void Receive(object s,CoreWebView2WebMessageReceivedEventArgs e){
            if(disposed||!string.Equals(e.Source,Page,StringComparison.Ordinal))return;
            Request req;
            try{if(e.WebMessageAsJson.Length>2*1024*1024)throw new InvalidOperationException("Request too large.");req=JsonConvert.DeserializeObject<Request>(e.WebMessageAsJson,jsonSettings);if(req==null)return;}
            catch(Exception ex){try{Post(new{kind="error",message="Invalid request: "+ex.Message});}catch{}return;}
            if(req.action=="ready"){pageReady=true;SendState();return;}
            Dispatcher.BeginInvoke(DispatcherPriority.Normal,new Action(async ()=>await Execute(req)));
        }
        async Task Execute(Request req){
            if(disposed||!pageReady)return;
            if(handling||session.Busy){try{Post(new{kind="done",id=req.id,ok=false,message="Another operation is running."});}catch(Exception ex){System.Diagnostics.Debug.WriteLine(ex);}return;}
            handling=true;bool ok=true;string message="";
            try{
                switch(req.action){
                    case "refresh":break;
                    case "demo":session.UseDemo();break;
                    case "open":var open=new OpenFileDialog{Filter="QEA / SQLite (*.qea;*.qeax;*.db)|*.qea;*.qeax;*.db",CheckFileExists=true};if(open.ShowDialog()==true)ok=await session.OpenAsync(open.FileName);else message="File selection cancelled.";break;
                    case "search":if(req.query==null||req.query.Length>256)throw new InvalidOperationException("Invalid query.");session.Search=req.query;ok=await session.SearchAsync();break;
                    case "select":case "load":case "navigate":
                        var el=session.Elements.FirstOrDefault(x=>x.Guid==req.guid);if(el==null)throw new InvalidOperationException("Element not found in current results.");session.Selected=el;
                        if(req.action=="load")ok=await session.LoadFieldsAsync();else if(req.action=="navigate")ok=session.Navigate();break;
                    case "apply":ok=session.ApplyWebMapping(req.revision,req.targets);if(!ok)message="Mapping changed or request invalid. Reload the current mapping before retrying.";break;
                    case "validate":case "generate":case "save":case "verify":
                        if(req.revision!=session.Revision)throw new InvalidOperationException("Model/mapping changed; refresh and retry.");
                        if(req.action=="validate")ok=session.Validate();else if(req.action=="generate")ok=session.Generate();else if(req.action=="verify")ok=session.VerifySavedIdl();else{
                            if(!session.CanSave)throw new InvalidOperationException("Generate IDL first.");
                            var save=new SaveFileDialog{Filter="IDL (*.idl)|*.idl",FileName="UmaaDemo.idl",OverwritePrompt=true};
                            if(save.ShowDialog()==true){if(req.revision!=session.Revision)throw new InvalidOperationException("Mapping changed while dialog was open.");ok=session.SaveIdl(save.FileName);}
                        }break;
                    default:throw new InvalidOperationException("Unsupported command.");
                }
            }catch(Exception ex){ok=false;message=ex.Message;session.Write("Command failed: "+message);}
            finally{handling=false;if(!disposed){SendState();try{Post(new{kind="done",id=req.id,ok,message=string.IsNullOrEmpty(message)?session.Status:message});}catch(Exception ex){System.Diagnostics.Debug.WriteLine(ex);}}}
        }
        public void Dispose(){if(disposed)return;disposed=true;session.PropertyChanged-=Changed;session.MappingChanged-=MappingChanged;Loaded-=OnLoaded;if(web!=null){if(web.CoreWebView2!=null)web.CoreWebView2.WebMessageReceived-=Receive;web.Dispose();web=null;}}
    }
}

namespace UMAA.UI { public partial class InspectorView : System.Windows.Controls.UserControl { public InspectorView(){InitializeComponent();} } }

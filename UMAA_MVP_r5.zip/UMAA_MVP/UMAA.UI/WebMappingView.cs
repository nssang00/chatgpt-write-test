// r4: superseded by WebWorkbenchView.cs; retained for overwrite-only patches.

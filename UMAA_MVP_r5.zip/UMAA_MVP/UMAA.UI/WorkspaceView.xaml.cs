using System;
using System.Windows.Controls;
namespace UMAA.UI
{
    public partial class WorkspaceView : UserControl, IDisposable
    {
        WebWorkbenchView web;
        bool disposed;
        public WorkspaceView(){InitializeComponent();Loaded+=(s,e)=>EnsureWeb();DataContextChanged+=(s,e)=>{ReleaseWeb();EnsureWeb();};}
        // Keep one WebView per workspace while EA switches its document tabs.
        void EnsureWeb(){if(disposed||!IsLoaded||web!=null||!(DataContext is WorkspaceSession session))return;web=new WebWorkbenchView(session);WebContainer.Children.Clear();WebContainer.Children.Add(web);}
        void ReleaseWeb(){if(web==null)return;var old=web;web=null;WebContainer.Children.Remove(old);old.Dispose();}
        public void Dispose(){if(disposed)return;disposed=true;ReleaseWeb();}
    }
}

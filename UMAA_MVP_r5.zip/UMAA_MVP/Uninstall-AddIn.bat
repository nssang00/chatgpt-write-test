@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "REGASM=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
set "DLL=%~dp0UMAA.AddIn\bin\Release\net48\UMAA.AddIn.dll"
set "EAKEY=HKCU\Software\Sparx Systems\EAAddins64\UMAA.MVP"
fltmc >nul 2>&1 || (echo ERROR: Use administrator CMD under the EA user account.& exit /b 1)
tasklist /FI "IMAGENAME eq EA.exe" /NH | findstr /I /B /C:"EA.exe " >nul
if not errorlevel 1 (echo ERROR: Close EA first.& exit /b 1)
if not exist "%DLL%" (echo ERROR: Original DLL missing. Restore the build output before unregistering.& exit /b 1)
"%REGASM%" "%DLL%" /unregister
if errorlevel 1 exit /b 1
reg query "%EAKEY%" /reg:64 >nul 2>&1
if not errorlevel 1 (
 reg delete "%EAKEY%" /f /reg:64
 if errorlevel 1 exit /b 1
)
echo SUCCESS: UMAA.MVP unregistered. Original UMAA.Sample is unchanged.
exit /b 0

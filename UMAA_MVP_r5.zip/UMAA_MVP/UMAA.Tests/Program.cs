using System;
using System.Linq;
using UMAA.Core;
using UMAA.Repository.SQLite;
namespace UMAA.Tests
{
    static class Program
    {
        static void Check(bool ok,string label){if(!ok)throw new Exception(label);Console.WriteLine("PASS: "+label);}
        static int Main(string[] args){try{
            var d=new DemoModelReader();var fields=d.GetFields("demo-position");var map=fields.Select(f=>new FieldMapping{Source=f.Name,Target=f.Name,Type=f.Type,Lower=f.Lower,Upper=f.Upper,Classifier=f.Classifier}).ToList();
            Check(IdlGenerator.Validate("PositionData",map).Count==0,"valid scalar model");Check(IdlGenerator.Generate("PositionData",map).Contains("double latitude;"),"IDL output");
            map[0].Target="";Check(IdlGenerator.Validate("PositionData",map).Count>0,"missing name rejected");map[0].Target=map[1].Target;Check(IdlGenerator.Validate("PositionData",map).Any(x=>x.StartsWith("Duplicate")),"duplicate rejected");map[0].Target="module";Check(IdlGenerator.Validate("PositionData",map).Count>0,"reserved name rejected");
            map[0].Target="lat";map[0].Upper="*";Check(IdlGenerator.Validate("PositionData",map).Any(x=>x.StartsWith("Multiplicity")),"multiplicity rejected");
            var q=new QeaModelReader(args[0]);var elements=q.GetElements("Position",2000);Check(elements.Count==1,"SQLite search");Check(q.GetFields(elements[0].Guid).Count==4,"SQLite field read");Check(q.GetElements("' OR 1=1 --",2000).Count==0,"parameterized query");Console.WriteLine("All tests passed.");return 0;
        }catch(Exception ex){Console.Error.WriteLine(ex);return 1;}}
    }
}

@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" || exit /b 1
set "RC=1"
set "OUT=%CD%\UMAA.AddIn\bin\Release\net48"
set "DLL=%OUT%\UMAA.AddIn.dll"
set "REGASM=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\RegAsm.exe"
set "EAKEY=HKCU\Software\Sparx Systems\EAAddins64\UMAA.MVP"
set "PROGID=UMAA.MVP.AddIn"
echo === UMAA MVP - Install Add-In x64 ===
whoami
fltmc >nul 2>&1
if errorlevel 1 (
    echo ERROR: Run CMD as administrator under the same Windows account as EA.
    goto :finish
)
if not exist "%REGASM%" (
    echo ERROR: 64-bit .NET Framework RegAsm not found.
    goto :finish
)
for %%F in (UMAA.AddIn.dll UMAA.UI.dll UMAA.Core.dll UMAA.Repository.EA.dll UMAA.Repository.SQLite.dll Interop.EA.dll System.Data.SQLite.dll Microsoft.Web.WebView2.Core.dll Microsoft.Web.WebView2.Wpf.dll Newtonsoft.Json.dll) do if not exist "%OUT%\%%F" (
    echo ERROR: Build output missing: "%OUT%\%%F"
    echo Run Build-AddIn.bat first.
    goto :finish
)
tasklist /FI "IMAGENAME eq EA.exe" /NH | findstr /I /B /C:"EA.exe " >nul
if not errorlevel 1 (
    echo ERROR: Save your work and close EA before installing.
    goto :finish
)
call "%~dp0Check-RuntimeFiles.bat" "%OUT%"
if errorlevel 1 goto :finish
reg query "HKCU\Software\Sparx Systems\EAAddins64\UMAA.Sample" /reg:64 >nul 2>&1
if not errorlevel 1 echo NOTE: Disable the old UMAA.Sample in EA before loading UMAA.MVP.
echo [1/3] Register 64-bit COM classes...
"%REGASM%" "%DLL%" /codebase
if errorlevel 1 goto :finish
echo [2/3] Register EA Add-In for current user...
reg add "%EAKEY%" /ve /t REG_SZ /d "%PROGID%" /f /reg:64
if errorlevel 1 goto :finish
echo [3/3] Verify registry entries...
reg query "%EAKEY%" /ve /reg:64
if errorlevel 1 goto :finish
for %%P in (UMAA.MVP.AddIn UMAA.MVP.WorkspaceHost UMAA.MVP.InspectorHost) do (
    reg query "HKCR\%%P\CLSID" /ve /reg:64
    if errorlevel 1 goto :finish
)
echo.
echo SUCCESS: Registration completed. No build was performed.
echo Start 64-bit EA under the same Windows user account.
echo Check Specialize - Manage Add-Ins - UMAA.MVP.
echo Keep the output directory in place. EA loading has not been verified.
set "RC=0"
:finish
if not "%RC%"=="0" echo FAILED: Review the error above. Partial registry changes may remain.
popd
endlocal & exit /b %RC%

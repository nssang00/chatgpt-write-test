# UMAA Interface Generator — MVP r5 (esbuild)

EA Add-In + Standalone, shared WebView2 Workbench (WPF host), C# Core, EA Automation API and SQLite repositories.

## 1. 요구 환경
- Windows x64, .NET Framework 4.8 런타임, .NET SDK (기존 사용 환경의 9.0.102 등), 선택적으로 Visual Studio 2022.
- EA 모드: Enterprise Architect 16/17 **64비트** 및 해당 설치본의 `Interop.EA.dll` (별도 제공하지 않음). EA 라이선스는 사용자 보유 필요.
- 독립 모드: EA/Interop.EA.dll 불필요. WebView2 기능에는 Microsoft Edge WebView2 Runtime (x64)이 필요. WebView2는 중앙 업무 UI에 필수이며, 초기화 실패 시 WPF 진단 메시지를 표시한다.
- 처음 빌드는 NuGet 패키지 복원에 인터넷 또는 사내 NuGet 캐시/피드 필요: Microsoft.Web.WebView2 1.0.3537.50, System.Data.SQLite.Core 1.0.119, Newtonsoft.Json 13.0.4, Microsoft.NETFramework.ReferenceAssemblies 1.0.3 (버전 고정 MVP; 정식 배포 전 보안/호환성 검토).
- .NET Framework 참조 어셈블리는 Directory.Build.props의 NuGet 참조를 통해 복원한다. Developer Pack 설치 없이 빌드할 수 있는 구성을 목표로 하며, Windows/WPF 빌드 도구 및 .NET Framework 런타임은 여전히 필요하다.
- r5 웹 UI는 esbuild 0.27.7 (참고 저장소의 lock 버전)로 정적 IIFE/ CSS 번들을 생성한다. Node.js 18 이상(지원 중인 LTS 권장) 및 npm은 빌드 시에만 필요하다. 최초 npm 복원에는 인터넷 또는 사내 캐시/레지스트리가 필요하다. 실행 시 Node.js, 서버, CDN은 필요 없다. React 전환은 이번 변경 범위에서 제외했다.

## 1-1. JSON 의존성 변경 (r2)
- `System.Web.Extensions` 및 `JavaScriptSerializer`를 제거하고 `Newtonsoft.Json` 13.0.4로 변경했다. `dotnet build`의 기본 NuGet restore로 패키지를 복원한다.
- r4에서 전체 업무 명령용 JSON Bridge로 확장했다. 입력 길이 제한, JSON 깊이 제한 및 TypeNameHandling.None을 적용한다.
- Build-Standalone / Build-AddIn / Install-AddIn BAT에서 Newtonsoft.Json.dll의 출력 여부를 확인한다. EA 내 다른 Add-In의 Newtonsoft.Json 버전 충돌은 실제 호스트에서 검증 필요하다.
- 기존 폴더에 변경 파일을 덮어쓴 경우 EA와 Standalone을 종료한 후 다시 빌드한다. 기존 등록 DLL 경로가 동일하면 대개 재등록은 필요하지 않다. 새 폴더에서 빌드한 경우 Install-AddIn.bat로 재등록한다.

## 2. 독립 실행 (EA 없이 먼저 확인)
일반 CMD에서 압축을 푼 프로젝트 폴더로 이동한다.

```cmd
Build-Standalone.bat
Run-Standalone.bat
```

출력: `UMAA.Standalone\bin\Release\net48\UMAA.Standalone.exe`. DLL과 네이티브 라이브러리를 포함한 **출력 폴더 전체**를 유지한다. 기존 Preview 프로젝트를 대체하는 실제 독립 호스트이다.

## 3. EA Add-In 빌드와 설치 (분리)
EA를 종료한다. 기존 `UMAA.Sample`이 이미 설치되어 있다면 Manage Add-Ins에서 비활성화 후 EA를 종료한다. 이전 샘플과 같은 이름의 어셈블리가 한 프로세스에 로드될 수 있으므로 동시에 활성화하지 않는다. 기존 등록은 자동 삭제하지 않는다.

`Interop.EA.dll`을 이 README와 같은 최상위 폴더에 복사한다. 일반 CMD:

```cmd
Build-AddIn.bat
```

또는 DLL의 실제 위치를 전달한다.

```cmd
Build-AddIn.bat "C:\Program Files\Sparx Systems\EA\Interop.EA.dll"
```

빌드 성공 후 **EA 실행에 사용할 동일한 Windows 계정**의 관리자 CMD에서:

```cmd
Install-AddIn.bat
```

이 BAT는 빌드하지 않고 Framework64 RegAsm 및 HKCU EAAddins64 레지스트리만 등록한다. 관리자 계정이 다르면 HKCU가 달라진다. unsigned /codebase RA0000 경고는 MVP에서 예상되며, 실제 실패와 구분한다. 등록 폴더를 이동하지 않는다.

EA 실행 → Specialize / Add-Ins / Manage Add-Ins → `UMAA.MVP` 활성화, 필요시 재시작. 실제 메뉴명 `UMAA MVP`:
- Open Workspace: EA 중앙 탭 (AddTab)
- Show Inspector: 도킹 패널 (AddWindow)
- Open Separate Window: WPF 비모달 독립 창
- Load Current QEA: EA의 ConnectionString이 로컬 QEA/QEAX 경로일 때 읽기 전용으로 조회. 다른 연결 문자열이면 Workspace에서 직접 파일 선택.

EA Add-In이 안 보일 경우 관리자 CMD와 EA가 동일 사용자 및 EA 64비트인지 확인하고 다음 명령을 실행한다.

```cmd
reg query "HKCU\Software\Sparx Systems\EAAddins64\UMAA.MVP" /ve /reg:64
reg query "HKCR\UMAA.MVP.AddIn\CLSID" /ve /reg:64
```

제거: EA 종료 후 관리자 CMD에서 `Uninstall-AddIn.bat`. 이전 UMAA.Sample 등록은 그대로 유지된다. DLL을 삭제하기 전에 제거한다. `Build-All.bat`는 두 호스트를 빌드하지만 설치는 하지 않는다.

## 4. 화면 사용법 (r4)
1. Workbench 전체를 단일 WebView2로 표시한다. `QEA 열기` 또는 `샘플 모델`을 선택한다. `Sample\SampleModel.db`는 EA에서 직접 열 수 없는 합성 SQLite 시험 데이터다.
2. 모델 분석에서 검색 (최대 2,000개) 및 요소 선택, 필드 불러오기. 인터페이스 구성 탭에서도 선택 요소를 편집 대상으로 불러올 수 있다. EA에서 보기 기능은 현재 EA와 동일한 QEA일 때만 사용한다.
3. 메시지 매핑에서 대상 필드 이름을 수정하고 **매핑 적용**을 누른다. 미적용 초안이 있으면 모델을 바꾸거나 생성/검증할 수 없다. 다른 창의 변경으로 충돌하면 최신값을 다시 불러온다.
4. 모델 검사에서 현재 단일 요소의 기본 IDL 제한을 검사한다. 자동생성에서 IDL 생성 및 파일 저장. 산출물 검증에서 저장 파일이 현재 미리보기와 바이트 단위로 일치하는지 검사한다. 컴파일러 검증은 아니다.
5. 규칙과 환경 메뉴는 현재 구현 범위를 읽기 전용으로 표시한다. 작업 상태/로그는 공통 C# 세션에서 관리한다. EA Browser/Properties/Output을 HTML에서 복제하지 않으며, Standalone은 WPF Inspector를 기존처럼 함께 제공한다.

## 5. 프로젝트 관계
```
UMAA.AddIn       UMAA.Standalone
   |                   |
   +------ UMAA.UI ----+
              |
          UMAA.Core      (도메인 + IModelReader + IModelNavigator)
           ^      ^
           |      |
 Repository.EA   Repository.SQLite
 (EA API)         (read-only QEA)
```
- 각 실행 호스트가 구체적인 Repository를 생성하고 WorkspaceSession에 주입한다. Core/UI는 Interop.EA.dll과 SQLite를 직접 참조하지 않는다.
- Repository.EA: EA API로 요소 선택·컨텍스트 조회. Repository.SQLite: DB 읽기 및 속성 추출. 현재 MVP는 두 모드 모두 QEA를 수정하지 않는다.
- UMAA.WebUI: 독립적인 로컬 HTML 리소스. 별도 C# 프로젝트가 아니므로 .sln에서 DLL로 빌드되지 않는다.
- UMAA.Tests: Core/SQLite 콘솔 테스트. `Test.bat` 실행 (EA 불필요).

## 6. 한계 및 검증 상태
- 구현 범위: 기본 탐색·검색·필드 로드·WebView2 매핑·스칼라 IDL 생성 및 파일 저장·기본 검사. 실제 UMAA ICD PDF/IDL 파서, 공식 UMAA 규칙, 상속/관계/복합 타입, 코드/문서 생성, IDL 컴파일 검증, 작업 DB 영속화, 다중 인터페이스 구성, 변환 규칙 편집은 미구현.
- QEA 직접 쓰기, EA 모델 생성/삭제/수정 기능을 의도적으로 제외. SQLite는 read-only 및 PRAGMA query_only=ON. EA와 동시 읽기는 잠금/스냅샷 제약이 있으며 EA의 저장 완료 후 새로 조회해야 한다. 보호된 모델은 권한을 확인한 파일만 사용하고 EA 접근 제어를 우회하는 용도로 사용하지 않는다. QEA 스키마/라이선스 조건은 실운용 전 검토 필요.
- 실제 EA AddTab/AddWindow/WPF/WebView2 중첩 호스팅, COM 등록 및 Windows 빌드는 제작 환경(Linux)에서 실행 검증하지 못했다. 실제 QEA 스키마 테스트도 필요하다. WPF 포커스, DPI, 런타임 경로 및 라이브러리 충돌을 우선 확인한다.
- WebView2 런타임/패키지의 라이선스, 배포 보안 정책 및 버전 유지관리는 별도 검토한다. 외부 탐색/호스트 객체는 차단하고 지정 로컬 페이지의 JSON 메시지만 처리한다. 로컬 자산 추출 폴더 및 WebView2 사용자 데이터는 `%LOCALAPPDATA%\UMAA.MVP`에 남을 수 있다.

## 7. 참고 문서
- https://sparxsystems.com/enterprise_architect_user_guide/17.2/add-ins___scripting/deployingaddins.html
- https://sparxsystems.com/enterprise_architect_user_guide/17.2/add-ins___scripting/repository3.html
- https://learn.microsoft.com/microsoft-edge/webview2/get-started/wpf
- https://developer.microsoft.com/microsoft-edge/webview2/
- https://www.nuget.org/packages/System.Data.SQLite.Core/1.0.119
- https://www.nuget.org/packages/Microsoft.Web.WebView2/1.0.3537.50

- https://www.nuget.org/packages/Newtonsoft.Json/13.0.4
- https://learn.microsoft.com/dotnet/framework/migration-guide/reference-assemblies


## r3: SQLite 네이티브 DLL 자동 배포

- r2에 덮어쓴 후 EA와 Standalone을 종료하고 `Build-Standalone.bat` 또는 `Build-AddIn.bat`를 다시 실행합니다.
- AddIn, Standalone, Tests에서 `Stub.System.Data.SQLite.Core.NetFramework` 1.0.119의 NuGet 패키지 경로를 생성하고 `Directory.Build.targets`에서 `build/net46/x64/SQLite.Interop.dll`을 각 빌드 출력의 `x64/`로 복사합니다. 별도 DLL 다운로드나 수동 복사가 필요하지 않도록 구성했습니다.
- `Test.bat`으로 샘플 DB 조회를 확인할 수 있습니다. `System.Data.SQLite.dll`과 `x64/SQLite.Interop.dll`을 함께 배포합니다.
- 패키지 경로를 못 찾으면 NuGet 복원 로그와 `dotnet nuget locals global-packages --list`를 확인합니다.
- 실제 Windows 빌드 및 EA 호스팅은 미검증입니다. 파일이 존재하는데도 런타임 DllNotFoundException이 발생하면 x64 네이티브 종속성 및 EA 내부 로딩 경로도 확인해야 합니다.

## r4: WebView2 중심 Workbench (이전 버전 기록)
- 첨부 UI 프로토타입의 색상, 중앙 탭, 작업 로그, 매핑 편집기 구성을 반영. EA 외부 틀은 제외했다. WPF는 컨테이너, 네이티브 파일 대화상자, Inspector로 유지한다.
- WebWorkbenchView는 로컬 HTML을 로드하고 허용된 명령을 C# WorkspaceSession에 전달한다. 파일 경로는 웹 메시지가 아니라 Windows 대화상자에서 선택한다. Core / Repository / NuGet / SQLite x64 복사 / BAT / COM 등록 방식은 r3 유지.
- 기존 r3에 패치를 덮어쓸 경우 WebMappingView.cs는 호환용 빈 파일로 교체된다. 전체 ZIP으로 새 폴더에서 시작할 경우 EA 재등록이 필요하다.
- r4에서는 화면을 순수 HTML/CSS/JS로 유지했고 React/Vite/Node.js 의존성을 추가하지 않았다. r5부터 빌드 시 Node.js를 사용한다. 웹 UI 단독 브라우저 실행은 안내 화면만 표시하며 실제 기능은 C# 호스트가 필요하다.
- 실제 Windows 빌드 및 EA/WebView2 연동 시험은 별도 필요하다.

### 제작 환경 검증
- XML/XAML 파싱, JavaScript 문법, 샘플 DB의 실제 SQL 실행, Chromium 모의 Bridge에서 초안 편집·적용·생성·저장·검증 화면 및 변경 무효화·충돌·좁은 화면을 시험했다. 모의 Bridge는 Windows 파일 저장이나 COM 시험이 아니다.
- Windows에서 `Build-Standalone.bat`, `Run-Standalone.bat`, `Test.bat` 실행 후 EA 빌드 및 등록을 확인할 것.

## r5 — esbuild 정적 번들

참고: https://github.com/nssang00/umaa_dev_studio 의 `scripts/build.mjs`, `index.html`, `package-lock.json`. 기존 r4 화면 및 C# 명령/응답 계약은 유지하고 JS/CSS만 분리한다.

- `Build-WebUI.bat`: esbuild 복원(미설치/버전 불일치/바이너리 문제 시), 빌드, 정적 산출물 확인. `UMAA.UI.csproj`의 MSBuild target에서 자동 실행하므로 Build-AddIn / Build-Standalone BAT 및 Windows dotnet build에서도 적용된다.
- `UMAA.WebUI/src/main.js`, `src/styles.css`, `src/bridge/webview.js` → `dist/main.js`, `dist/main.css`.
- index.html과 두 번들은 UI DLL에 임베드한다. 기존 r4와 같은 가상 HTTPS 호스트에 추출하고 3개 리소스만 허용한다. C# 메시지 송신 출처 검증 및 외부 탐색 차단은 유지한다.
- 직접 브라우저에서 index.html을 열면 호스트 미연결 안내가 표시되며 실제 QEA 기능은 실행되지 않는다. watch는 정적 파일만 다시 생성하며 데스크톱 반영에는 C# 재빌드 및 재실행이 필요하다.
- 기존 r4 패치 적용 시 프로젝트 루트에 덮어쓴 뒤 EA/Standalone을 종료하고 기존 빌드 BAT를 실행한다. COM 등록과 SQLite 네이티브 DLL 복사 설정은 그대로 유지한다.
- 검증 한계: 작업 환경의 npm registry 접근 실패로 실제 esbuild 설치/번들 및 Windows 빌드, EA 실행은 미검증이다. Node 구문, XML 및 구조 정적 검증만 수행했다.

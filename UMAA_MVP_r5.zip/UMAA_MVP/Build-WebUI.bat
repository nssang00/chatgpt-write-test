@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0UMAA.WebUI" || exit /b 1
set "RC=1"
where node.exe >nul 2>&1 || (echo ERROR: Node.js LTS not found. Install Node.js 18 or newer.& goto :finish)
where npm.cmd >nul 2>&1 || (echo ERROR: npm.cmd not found.& goto :finish)
node -e "if (+process.versions.node.split('.')[0] < 18) process.exit(1)"
if errorlevel 1 (echo ERROR: Node.js 18 or newer required.& goto :finish)
node -e "try{if(require('esbuild').version!==require('./package.json').devDependencies.esbuild)process.exit(1);require('esbuild').transformSync('let x=1')}catch(e){process.exit(1)}" >nul 2>&1
if errorlevel 1 (
  echo Restoring esbuild from package-lock.json...
  call npm ci --include=dev --prefer-offline --no-audit --no-fund
  if errorlevel 1 goto :finish
)
call npm run build
if errorlevel 1 goto :finish
call npm run check:static
if errorlevel 1 goto :finish
set "RC=0"
:finish
if not "%RC%"=="0" echo ERROR: WebUI build failed. Check Node.js, npm registry/cache and the error above.
popd
endlocal & exit /b %RC%

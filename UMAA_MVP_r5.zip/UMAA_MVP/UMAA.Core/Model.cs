using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace UMAA.Core
{
    public sealed class ModelElement
    {
        public string Guid { get; set; }
        public string Name { get; set; }
        public string Package { get; set; }
        public string Type { get; set; }
        public string Stereotype { get; set; }
        public override string ToString() => Name;
    }
    public sealed class ModelField
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Lower { get; set; }
        public string Upper { get; set; }
        public string Classifier { get; set; }
    }
    public sealed class FieldMapping
    {
        public string Source { get; set; }
        public string Type { get; set; }
        public string Target { get; set; }
        public string Lower { get; set; }
        public string Upper { get; set; }
        public string Classifier { get; set; }
    }
    public interface IModelReader
    {
        IReadOnlyList<ModelElement> GetElements(string search, int limit);
        IReadOnlyList<ModelField> GetFields(string guid);
    }
    // Host capability; no EA dependency here.
    public interface IModelNavigator { void Navigate(string source, string guid); }
    public sealed class DemoModelReader : IModelReader
    {
        public IReadOnlyList<ModelElement> GetElements(string search, int limit) => new[] {
            new ModelElement{ Guid="demo-position", Name="PositionData", Package="Navigation", Type="Class", Stereotype="Message" },
            new ModelElement{ Guid="demo-velocity", Name="VelocityData", Package="Navigation", Type="Class", Stereotype="Message" }
        }.Where(x=>x.Name.IndexOf(search ?? "",StringComparison.OrdinalIgnoreCase)>=0).Take(limit).ToList();
        public IReadOnlyList<ModelField> GetFields(string guid) => guid=="demo-position" ? new[] {
            F("latitude","double"),F("longitude","double"),F("heading","float"),F("quality","short")
        } : guid=="demo-velocity" ? new[] {F("speed","double")} : new ModelField[0];
        static ModelField F(string n,string t)=>new ModelField{Name=n,Type=t,Lower="1",Upper="1"};
    }
    public static class IdlGenerator
    {
        // Intentionally narrow: scalar primitive fields only. Not an official UMAA compiler.
        static readonly HashSet<string> Types = new HashSet<string>(StringComparer.Ordinal) {
            "short","unsigned short","long","unsigned long","long long","unsigned long long","float","double","boolean","char","wchar","octet","string","wstring","int8","uint8","int16","uint16","int32","uint32","int64","uint64"
        };
        static readonly HashSet<string> Reserved = new HashSet<string>( ("module struct interface union enum sequence typedef const long short float double string boolean octet char wchar void unsigned int8 uint8 int16 uint16 int32 uint32 int64 uint64 true false switch case default any fixed exception attribute readonly in out inout oneway raises context object valuebase valuetype public private factory native abstract local import typeid typeprefix wstring map bitset bitmask annotation int longdouble supports truncatable component home provides uses multiple emits publishes consumes primarykey set get port porttype connector mirrorport eventtype").Split(' '),StringComparer.OrdinalIgnoreCase);
        public static bool IsIdentifier(string s)=>!string.IsNullOrWhiteSpace(s)&&Regex.IsMatch(s,@"^[A-Za-z][A-Za-z0-9_]*\z")&&!Reserved.Contains(s);
        public static IReadOnlyList<string> Validate(string name,IReadOnlyList<FieldMapping> rows)
        {
            var errors=new List<string>();
            if(!IsIdentifier(name))errors.Add("Invalid structure name: "+name);
            if(rows==null||rows.Count==0){errors.Add("No fields selected.");return errors;}
            foreach(var r in rows){
                if(!IsIdentifier(r.Target))errors.Add("Invalid or missing mapping: "+r.Source);
                if(!Types.Contains(r.Type??""))errors.Add("Unsupported scalar IDL type: "+r.Source+" / "+r.Type);
                if(!string.IsNullOrWhiteSpace(r.Classifier)&&r.Classifier!="0")errors.Add("Referenced type not supported: "+r.Source);
                if((!string.IsNullOrWhiteSpace(r.Lower)&&r.Lower!="1")||(!string.IsNullOrWhiteSpace(r.Upper)&&r.Upper!="1"))errors.Add("Multiplicity not supported: "+r.Source);
            }
            foreach(var g in rows.Where(r=>!string.IsNullOrWhiteSpace(r.Target)).GroupBy(r=>r.Target,StringComparer.OrdinalIgnoreCase).Where(g=>g.Count()>1))errors.Add("Duplicate target: "+g.Key);
            return errors;
        }
        public static string Generate(string name,IReadOnlyList<FieldMapping> rows){
            var errors=Validate(name,rows);if(errors.Count>0)throw new InvalidOperationException(string.Join("\n",errors));
            var b=new StringBuilder();b.AppendLine("// MVP scalar-only IDL; not certified UMAA output");b.AppendLine("module UmaaDemo {");b.AppendLine("  struct "+name+" {");
            foreach(var r in rows)b.AppendLine("    "+r.Type+" "+r.Target+";");b.AppendLine("  };");b.AppendLine("};");return b.ToString();
        }
    }
}

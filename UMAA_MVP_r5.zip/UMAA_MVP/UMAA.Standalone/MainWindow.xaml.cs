using UMAA.UI;
using UMAA.Repository.SQLite;
namespace UMAA.Standalone {public partial class MainWindow : System.Windows.Window {public MainWindow(){InitializeComponent();DataContext=new WorkspaceSession(path=>new QeaModelReader(path)){Context="Standalone · EA not installed / connected"};Closed+=(s,e)=>Workspace.Dispose();}}}

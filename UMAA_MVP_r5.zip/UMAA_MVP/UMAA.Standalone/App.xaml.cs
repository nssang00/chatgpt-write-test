namespace UMAA.Standalone { public partial class App : System.Windows.Application {} }

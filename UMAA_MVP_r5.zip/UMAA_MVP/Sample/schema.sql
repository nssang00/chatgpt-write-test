-- Synthetic read-only fixture, NOT an EA project and NOT official UMAA.
CREATE TABLE t_package(Package_ID INTEGER PRIMARY KEY, Name TEXT);
CREATE TABLE t_object(Object_ID INTEGER PRIMARY KEY, ea_guid TEXT, Name TEXT, Package_ID INTEGER, Object_Type TEXT, Stereotype TEXT);
CREATE TABLE t_attribute(ID INTEGER PRIMARY KEY, Object_ID INTEGER, Name TEXT, Type TEXT, LowerBound TEXT, UpperBound TEXT, Classifier TEXT, Pos INTEGER);
INSERT INTO t_package VALUES(1,'Navigation'),(2,'Vehicle');
INSERT INTO t_object VALUES(1,'{11111111-1111-1111-1111-111111111111}','PositionData',1,'Class','Message'),(2,'{22222222-2222-2222-2222-222222222222}','VelocityData',1,'Class','Message'),(3,'{33333333-3333-3333-3333-333333333333}','VehicleStatus',2,'DataType','Message');
INSERT INTO t_attribute VALUES(1,1,'latitude','double','1','1','0',0),(2,1,'longitude','double','1','1','0',1),(3,1,'heading','float','1','1','0',2),(4,1,'quality','short','1','1','0',3),(5,2,'speed','double','1','1','0',0),(6,3,'state','short','1','1','0',0),(7,3,'samples','double','0','*','0',1);

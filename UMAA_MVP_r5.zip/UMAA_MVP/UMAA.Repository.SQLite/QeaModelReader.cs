using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using UMAA.Core;

namespace UMAA.Repository.SQLite
{
    public sealed class QeaModelReader : IModelReader
    {
        public string Path { get; }
        public QeaModelReader(string path){Path=System.IO.Path.GetFullPath(path);if(!File.Exists(Path))throw new FileNotFoundException("QEA file not found",Path);}
        SQLiteConnection Open(){
            var c=new SQLiteConnection(new SQLiteConnectionStringBuilder{DataSource=Path,ReadOnly=true,FailIfMissing=true,Pooling=false,DefaultTimeout=3}.ConnectionString);
            try {c.Open();using(var cmd=c.CreateCommand()){cmd.CommandText="PRAGMA query_only=ON;";cmd.ExecuteNonQuery();}return c;}catch{c.Dispose();throw;}
        }
        static string S(SQLiteDataReader r,int i)=>r.IsDBNull(i)?"":Convert.ToString(r.GetValue(i),System.Globalization.CultureInfo.InvariantCulture);
        public IReadOnlyList<ModelElement> GetElements(string search,int limit){
            var list=new List<ModelElement>();using(var c=Open())using(var cmd=c.CreateCommand()){
                cmd.CommandText=@"SELECT o.ea_guid,o.Name,p.Name,o.Object_Type,o.Stereotype FROM t_object o LEFT JOIN t_package p ON p.Package_ID=o.Package_ID WHERE o.Object_Type IN ('Class','DataType','Interface','Signal') AND (instr(lower(coalesce(o.Name,'')),lower(@search))>0 OR @search='') ORDER BY o.Name,o.Object_ID LIMIT @limit";
                cmd.Parameters.AddWithValue("@search",search??"");cmd.Parameters.AddWithValue("@limit",Math.Max(1,Math.Min(limit,5000)));
                using(var r=cmd.ExecuteReader())while(r.Read())list.Add(new ModelElement{Guid=S(r,0),Name=S(r,1),Package=S(r,2),Type=S(r,3),Stereotype=S(r,4)});
            }return list;
        }
        public IReadOnlyList<ModelField> GetFields(string guid){
            var list=new List<ModelField>();using(var c=Open())using(var cmd=c.CreateCommand()){
                cmd.CommandText=@"SELECT a.Name,a.Type,a.LowerBound,a.UpperBound,a.Classifier FROM t_attribute a JOIN t_object o ON o.Object_ID=a.Object_ID WHERE o.ea_guid=@guid COLLATE NOCASE ORDER BY a.Pos,a.ID";
                cmd.Parameters.AddWithValue("@guid",guid??"");using(var r=cmd.ExecuteReader())while(r.Read())list.Add(new ModelField{Name=S(r,0),Type=S(r,1),Lower=S(r,2),Upper=S(r,3),Classifier=S(r,4)});
            }return list;
        }
    }
}

# Fail the Actions job unless on-runner evidence proves the raw Windows NTFS
# delete -> scan -> preview -> extract -> SHA256 and same-volume rejection.
param([string]$Evidence = 'build-logs/windows-live-ntfs-vhd-evidence.json')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (-not (Test-Path -LiteralPath $Evidence -PathType Leaf)) {
    throw "Windows live-volume evidence missing: $Evidence"
}
$e = Get-Content -LiteralPath $Evidence -Encoding utf8 -Raw | ConvertFrom-Json -ErrorAction Stop
foreach ($field in @('raw_windows_volume_tested', 'raw_scan_completed',
                     'deleted_candidate_found', 'nonresident_deleted_candidate_found',
                     'preview_matches_original', 'same_volume_extraction_rejected',
                     'resident_recovered_sha256_matches_original',
                     'disposed_vhd_detached')) {
    if ($null -eq $e.PSObject.Properties[$field] -or $e.$field -ne $true) {
        throw "Windows live-volume evidence incomplete: $field"
    }
}
if ($e.schema -ne 2 -or $e.result -ne 'passed' -or $e.image_file_input -ne $false -or
    $e.windows_gui_executed -ne $false -or $e.real_physical_media_tested -ne $false) {
    throw 'Windows live-volume evidence reports an invalid test outcome/scope'
}
foreach ($field in @('native_exe_sha256', 'original_sha256', 'recovered_sha256')) {
    if ($e.$field -cnotmatch '^[0-9a-f]{64}$') { throw "Missing SHA-256: $field" }
}
if ($e.original_sha256 -cne $e.recovered_sha256 -or $e.recovered_bytes -ne $e.original_bytes) {
    throw 'Recovered resident file differs from original despite success flag'
}
Write-Host '[PASS] Windows mounted NTFS volume, deleted-file scan, actual extraction SHA-256, same-volume protection, VHD cleanup.'

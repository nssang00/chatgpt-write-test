# Real Windows raw-volume integration test. Executes ONLY on a GitHub Actions
# Windows runner and modifies ONLY a newly created disposable VHD.
# The test uses \\.\X: to exercise ReadOnlySource's Win32 live device path,
# not an .img parser. Never select, format, or lock a host physical disk.
param(
    [Parameter(Mandatory = $true)][string]$Engine,
    [string]$EvidenceDirectory = 'build-logs'
)
$ErrorActionPreference = 'Stop'
# Intentional negative native test must return an exit code rather than throw
# before its stderr can be inspected (PowerShell 7.3+ native command policy).
$PSNativeCommandUseErrorActionPreference = $false
Set-StrictMode -Version Latest

if ($env:GITHUB_ACTIONS -ne 'true' -or [string]::IsNullOrWhiteSpace($env:RUNNER_TEMP)) {
    throw 'Refusing to create a VHD outside an explicitly identified GitHub Actions runner.'
}
if (-not $IsWindows) { throw 'Requires a Windows runner and PowerShell 7.' }
$enginePath = (Resolve-Path -LiteralPath $Engine -ErrorAction Stop).Path
if (-not $enginePath.EndsWith('.exe', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'The test requires the native Windows CLI executable.'
}
New-Item -ItemType Directory -Path $EvidenceDirectory -Force | Out-Null
$evidenceDir = (Resolve-Path -LiteralPath $EvidenceDirectory).Path
$report = Join-Path $evidenceDir 'windows-live-ntfs-vhd-evidence.json'
$id = [Guid]::NewGuid().ToString('N').Substring(0, 12)
$testDir = Join-Path $env:RUNNER_TEMP "rw-live-ntfs-$id"
New-Item -ItemType Directory -Path $testDir -Force | Out-Null
$vhd = Join-Path $testDir "rw-live-ntfs-$id.vhd"
$selectedLetter = $null
foreach ($candidate in @('R','S','T','U','V','W','X','Y','Z')) {
    if (-not (Test-Path -LiteralPath "${candidate}:\")) { $selectedLetter = $candidate; break }
}
if ($null -eq $selectedLetter) { throw 'No free disposable drive letter found.' }
$devicePath = "\\.\${selectedLetter}:"
$diskpartCreate = Join-Path $testDir 'create-vhd.txt'
$diskpartDetach = Join-Path $testDir 'detach-vhd.txt'
# Select ONLY the GUID-named VHD created by this test. NEVER "select disk".
@(
    "create vdisk file=`"$vhd`" maximum=256 type=expandable"
    "select vdisk file=`"$vhd`""
    'attach vdisk'
    'convert gpt'
    'create partition primary'
    'format fs=ntfs quick label=RWLIVECI'
    "assign letter=$selectedLetter"
) | Set-Content -LiteralPath $diskpartCreate -Encoding ascii
@("select vdisk file=`"$vhd`"", 'detach vdisk') |
    Set-Content -LiteralPath $diskpartDetach -Encoding ascii

$evidence = [ordered]@{
    schema = 2
    case = 'windows-live-ntfs-deletion-scan-extract-sha256'
    result = 'not-run'
    runner = $env:RUNNER_OS
    source_kind = 'disposable-ntfs-vhd-mounted-as-raw-volume'
    device = $devicePath
    image_file_input = $false
    raw_windows_volume_tested = $false
    raw_scan_completed = $false
    disposed_vhd_detached = $false
    deleted_candidate_found = $false
    preview_matches_original = $false
    resident_recovered_sha256_matches_original = $false
    same_volume_extraction_rejected = $false
    extraction_to_host_volume_attempted = $false
    nonresident_recovery_verified = $false
    nonresident_deleted_candidate_found = $false
    windows_gui_executed = $false
    real_physical_media_tested = $false
    native_exe_sha256 = (Get-FileHash -LiteralPath $enginePath -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Save-Evidence {
    $evidence | ConvertTo-Json -Depth 6 |
        Set-Content -LiteralPath $report -Encoding utf8
}
function Invoke-DiskPartScript([string]$scriptFile, [string]$logFile) {
    & "$env:SystemRoot\System32\diskpart.exe" /s $scriptFile *>&1 |
        Out-File -LiteralPath $logFile -Encoding utf8
    if ($LASTEXITCODE -ne 0) {
        throw "DiskPart failed (exit $LASTEXITCODE). See $logFile"
    }
}
function Invoke-EngineJson([string[]]$CliArgs, [string]$Label) {
    $stdout = Join-Path $evidenceDir "live-$label-stdout.txt"
    $stderr = Join-Path $evidenceDir "live-$label-stderr.txt"
    & $enginePath @CliArgs 1> $stdout 2> $stderr
    $exit = $LASTEXITCODE
    if ($exit -ne 0) {
        $diagnostic = (Get-Content -LiteralPath $stderr -Encoding utf8 -Raw)
        throw "Live $label failed (exit $exit): $diagnostic"
    }
    $lines = @(Get-Content -LiteralPath $stdout -Encoding utf8 | Where-Object { $_.Trim().Length -gt 0 })
    $parsed = @()
    foreach ($line in $lines) {
        try { $parsed += $line | ConvertFrom-Json -ErrorAction Stop }
        catch { throw "Invalid JSON from live ${Label}: $line" }
    }
    return $parsed
}

try {
    Invoke-DiskPartScript $diskpartCreate (Join-Path $evidenceDir 'live-diskpart-create.log')
    # DiskPart may return success for some failed commands; independently
    # confirm that this exact VHD owns the selected mounted drive letter.
    $diskImage = Get-DiskImage -ImagePath $vhd -ErrorAction Stop
    if (-not $diskImage.Attached) { throw 'Disposable VHD was not attached.' }
    $vhdDisk = $diskImage | Get-Disk -ErrorAction Stop
    $partition = $null
    $volume = $null
    # DiskPart may finish before Storage Management publishes the drive.
    for ($attempt = 0; $attempt -lt 15; $attempt++) {
        $partition = Get-Partition -DriveLetter $selectedLetter -ErrorAction SilentlyContinue
        $volume = Get-Volume -DriveLetter $selectedLetter -ErrorAction SilentlyContinue
        if ($partition -and $volume) { break }
        Start-Sleep -Seconds 1
    }
    if (-not $partition -or -not $volume -or
        $partition.DiskNumber -ne $vhdDisk.Number -or $volume.FileSystem -ne 'NTFS' -or
        $volume.FileSystemLabel -ne 'RWLIVECI') {
        throw 'Mounted drive identity mismatch; refusing to use any host volume.'
    }
    $evidence.vhd_disk_number = $vhdDisk.Number
    $evidence.file_system = $volume.FileSystem

    # Two independent deleted records. Resident data is immune to cluster
    # TRIM semantics in the VHD provider; nonresident metadata exercises
    # the ordinary deleted-file MFT/runlist path. Both are created before
    # either is deleted to prevent accidental reuse of the same MFT record.
    $deletedName = "rw_ci_deleted_$id.txt"
    $largeName = "rw_ci_deleted_${id}_large.bin"
    $deletedFile = "${selectedLetter}:\$deletedName"
    $largeFile = "${selectedLetter}:\$largeName"
    $payload = [Text.Encoding]::ASCII.GetBytes(('RW-NATIVE-VOLUME-SCAN-' * 8))
    $largePayload = [Text.Encoding]::ASCII.GetBytes(('RW-NONRESIDENT-MFT-' * 3072))
    [IO.File]::WriteAllBytes($deletedFile, $payload)
    [IO.File]::WriteAllBytes($largeFile, $largePayload)
    $expectedSha = (Get-FileHash -LiteralPath $deletedFile -Algorithm SHA256).Hash.ToLowerInvariant()
    $evidence.original_sha256 = $expectedSha
    $evidence.original_bytes = $payload.Length
    $evidence.large_original_sha256 = (Get-FileHash -LiteralPath $largeFile -Algorithm SHA256).Hash.ToLowerInvariant()
    $evidence.large_original_bytes = $largePayload.Length
    Remove-Item -LiteralPath $deletedFile -Force
    Remove-Item -LiteralPath $largeFile -Force
    if ((Test-Path -LiteralPath $deletedFile) -or (Test-Path -LiteralPath $largeFile)) {
        throw 'Deletion fixture still exists.'
    }

    $rows = @(Invoke-EngineJson -CliArgs @('scan', $devicePath, '--limit', '4096', '--json') -Label 'scan')
    $matches = @($rows | Where-Object { $_.kind -eq 'file' -and
        $_.path.EndsWith($deletedName, [StringComparison]::OrdinalIgnoreCase) })
    $largeMatches = @($rows | Where-Object { $_.kind -eq 'file' -and
        $_.path.EndsWith($largeName, [StringComparison]::OrdinalIgnoreCase) })
    $evidence.raw_windows_volume_tested = $true
    $evidence.raw_scan_completed = $true
    $evidence.scan_result_count = $rows.Count
    if ($matches.Count -ne 1 -or $largeMatches.Count -ne 1) {
        throw "Deleted NTFS fixtures missing from raw scan: resident=$($matches.Count), nonresident=$($largeMatches.Count)."
    }
    $file = $matches[0]
    if ($file.status -ne 'resident' -or $largeMatches[0].status -eq 'resident') {
        throw 'Deleted fixtures did not exercise separate resident and nonresident NTFS paths.'
    }
    if ([int64]$file.size -ne $payload.Length -or
        [int64]$largeMatches[0].size -ne $largePayload.Length) {
        throw 'Deleted-file metadata size mismatch.'
    }
    $evidence.deleted_candidate_found = $true
    $evidence.nonresident_deleted_candidate_found = $true
    $evidence.deleted_mft_id = $file.id
    $evidence.large_deleted_mft_id = $largeMatches[0].id
    $evidence.candidate_status = $file.status
    $evidence.large_candidate_status = $largeMatches[0].status

    $preview = @(Invoke-EngineJson -CliArgs @('preview', 'ntfs', $devicePath, "$($file.id)", '--json') -Label 'preview')
    if ($preview.Count -ne 1 -or $preview[0].kind -ne 'preview') { throw 'Invalid preview JSON.' }
    $expectedHex = [Convert]::ToHexString($payload).ToLowerInvariant()
    if ($preview[0].hex -ne $expectedHex -or [int]$preview[0].bytes -ne $payload.Length) {
        throw 'Actual Windows raw-volume preview did not match deleted fixture bytes.'
    }
    $evidence.preview_matches_original = $true

    # A real raw-device extraction exercises the guarded NTFS extraction path
    # and file publication, unlike a preview-only or image-based smoke test.
    # First prove the source virtual disk cannot be selected as output.
    $blockedStdout = Join-Path $evidenceDir 'live-reject-source-stdout.txt'
    $blockedStderr = Join-Path $evidenceDir 'live-reject-source-stderr.txt'
    & $enginePath 'extract' $devicePath "$($file.id)" "${selectedLetter}:\" '--json' 1> $blockedStdout 2> $blockedStderr
    $blockedCode = $LASTEXITCODE
    $blockedError = Get-Content -LiteralPath $blockedStderr -Encoding utf8 -Raw
    if ($blockedCode -eq 0 -or $blockedError -notmatch 'same physical disk') {
        throw "Recovery to the source disk was not rejected by the disk-separation guard (exit $blockedCode): $blockedError"
    }
    if (Test-Path -LiteralPath $deletedFile) {
        throw 'Source-volume extraction unexpectedly recreated the deleted test file.'
    }
    $evidence.same_volume_extraction_rejected = $true

    $outputFolder = Join-Path $testDir 'recovered'
    New-Item -ItemType Directory -Path $outputFolder -Force | Out-Null
    $outputDrive = [IO.Path]::GetPathRoot($outputFolder).Substring(0, 1)
    $outputPartition = Get-Partition -DriveLetter $outputDrive -ErrorAction Stop
    if ($outputPartition.DiskNumber -eq $vhdDisk.Number) {
        throw 'Test output disk resolves to the source VHD; cannot run extraction.'
    }
    $evidence.output_disk_number = $outputPartition.DiskNumber
    $evidence.extraction_to_host_volume_attempted = $true
    $extracted = @(Invoke-EngineJson -CliArgs @('extract', $devicePath, "$($file.id)", $outputFolder, '--json') -Label 'extract-resident')
    if ($extracted.Count -ne 1 -or $extracted[0].kind -ne 'extract') {
        throw 'Raw-volume extraction did not return exactly one extract JSON record.'
    }
    $recoveredPath = [IO.Path]::GetFullPath([string]$extracted[0].path)
    $outputRoot = [IO.Path]::GetFullPath($outputFolder).TrimEnd('\') + '\'
    if (-not $recoveredPath.StartsWith($outputRoot, [StringComparison]::OrdinalIgnoreCase) -or
        -not (Test-Path -LiteralPath $recoveredPath -PathType Leaf)) {
        throw 'Recovered file is missing or outside the expected output folder.'
    }
    $recoveredSha = (Get-FileHash -LiteralPath $recoveredPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $evidence.recovered_sha256 = $recoveredSha
    $evidence.recovered_bytes = (Get-Item -LiteralPath $recoveredPath).Length
    if ($recoveredSha -ne $expectedSha -or $evidence.recovered_bytes -ne $payload.Length) {
        throw 'Recovered resident file SHA-256 or size differs from pre-deletion original.'
    }
    $evidence.resident_recovered_sha256_matches_original = $true

    # A nonresident deleted file can be discarded by virtual-disk TRIM even
    # with a valid MFT/runlist. Require it to be scanned; record full recovery
    # only when its allocation state makes recovery safe. Never report an
    # unverified large file as successfully recovered.
    if ($largeMatches[0].status -eq 'free-clusters') {
        $largeOutput = @(Invoke-EngineJson -CliArgs @('extract', $devicePath, "$($largeMatches[0].id)", $outputFolder, '--json') -Label 'extract-nonresident')
        if ($largeOutput.Count -ne 1 -or $largeOutput[0].kind -ne 'extract') {
            throw 'Nonresident free-clusters candidate was not extracted.'
        }
        $largeRecoveredPath = [IO.Path]::GetFullPath([string]$largeOutput[0].path)
        if (-not $largeRecoveredPath.StartsWith($outputRoot, [StringComparison]::OrdinalIgnoreCase)) {
            throw 'Recovered nonresident file escaped the expected output folder.'
        }
        $largeRecoveredSha = (Get-FileHash -LiteralPath $largeRecoveredPath -Algorithm SHA256).Hash.ToLowerInvariant()
        $evidence.large_recovered_sha256 = $largeRecoveredSha
        $evidence.nonresident_recovery_verified = ($largeRecoveredSha -eq $evidence.large_original_sha256)
        if (-not $evidence.nonresident_recovery_verified) {
            $evidence.nonresident_recovery_note = 'Bytes differ after deletion (possible discard/TRIM). NOT a full recovery pass.'
        }
    } else {
        $evidence.nonresident_recovery_note = 'Not attempted: allocation status not free-clusters; write blocked.'
    }
    $evidence.result = 'passed'
    Write-Host '[PASS] Windows raw-volume NTFS scan, resident preview/extraction exact SHA-256, and same-volume rejection.'
} catch {
    $evidence.result = 'failed'
    $evidence.error = $_.Exception.Message
    Write-Error -ErrorAction Continue "[FAILED] $($_.Exception.Message)"
    throw
} finally {
    Save-Evidence
    # Detach ONLY our uniquely named VHD. Never detach a pre-existing disk.
    if (Test-Path -LiteralPath $vhd) {
        try {
            Invoke-DiskPartScript $diskpartDetach (Join-Path $evidenceDir 'live-diskpart-detach.log')
            $stillAttached = (Get-DiskImage -ImagePath $vhd -ErrorAction SilentlyContinue).Attached
            if ($stillAttached) { throw 'Disposable VHD is still attached after cleanup.' }
            $evidence.disposed_vhd_detached = $true
            Remove-Item -LiteralPath $testDir -Recurse -Force
            Save-Evidence
        } catch {
            $evidence.cleanup_error = $_.Exception.Message
            $evidence.result = 'failed'
            Save-Evidence
            throw "VHD cleanup failed: $($_.Exception.Message)"
        }
    }
}

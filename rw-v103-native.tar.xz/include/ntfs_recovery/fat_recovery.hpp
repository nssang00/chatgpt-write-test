#pragma once

#include <cstdint>
#include <filesystem>
#include "ntfs_recovery/read_only_source.hpp"
#include <optional>
#include <string>
#include <vector>

namespace ntfs {

// Read-only FAT32/exFAT recovery for regular-file volume/disk images.
// IDs are opaque directory-entry coordinates and are not filesystem inode numbers.
// 'heuristic-contiguous' on FAT32 means allocation was checked, but original
// cluster order is unproven; NEVER describe that as a verified recovery.
struct FatCandidate {
    std::uint64_t id = 0;
    std::uint64_t size = 0;
    std::string path;
    std::string status;
};

class FatRecovery {
public:
    explicit FatRecovery(const std::filesystem::path& image,
                         std::optional<std::uint32_t> partition = std::nullopt);
    std::vector<FatCandidate> scan();
    std::filesystem::path extract(std::uint64_t id, const std::filesystem::path& output_directory);
    std::vector<std::uint8_t> preview(std::uint64_t id);
    std::string filesystem_name() const;

private:
    struct Located {
        FatCandidate info;
        std::uint32_t cluster = 0;
        bool contiguous = false;
        std::uint64_t valid_data_bytes = 0;
        std::vector<std::uint32_t> chain;
    };
    std::vector<std::uint8_t> read(std::uint64_t offset, std::size_t size);
    std::uint32_t fat_entry(std::uint32_t cluster);
    std::vector<std::uint32_t> chain(std::uint32_t cluster, std::uint64_t size_hint, bool contiguous);
    std::vector<std::uint8_t> directory(std::uint32_t cluster, bool contiguous, std::uint64_t size_hint);
    void visit(std::uint32_t cluster, bool contiguous, std::uint64_t size_hint,
               const std::string& path, unsigned depth);
    void find_bitmap(const std::vector<std::uint8_t>& root);
    std::string classify(const std::vector<std::uint32_t>& locations, bool heuristic) const;
    std::vector<std::uint32_t> deleted_clusters(std::uint32_t first, std::uint64_t length,
                                                 bool contiguous, bool fat32);
    std::filesystem::path image_;
    std::optional<std::uint32_t> partition_index_;
    ReadOnlySource input_;
    std::uint64_t volume_offset_ = 0;
    std::uint64_t volume_length_ = 0;
    std::uint64_t volume_size_ = 0;
    std::uint64_t sector_size_ = 0;
    std::uint64_t cluster_size_ = 0;
    std::uint64_t fat_offset_ = 0;
    std::uint64_t fat_bytes_ = 0;
    std::uint64_t data_offset_ = 0;
    std::uint32_t cluster_count_ = 0;
    std::uint32_t root_cluster_ = 0;
    bool exfat_ = false;
    std::uint8_t active_bitmap_id_ = 0;
    bool bitmap_found_ = false;
    std::vector<std::uint8_t> bitmap_;
    std::vector<Located> results_;
    std::vector<std::uint32_t> visited_dirs_;
};

} // namespace ntfs

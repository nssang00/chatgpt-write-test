#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include "ntfs_recovery/read_only_source.hpp"
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace ntfs {

struct Run {
    std::uint64_t first_vcn = 0;
    std::uint64_t count = 0;
    std::optional<std::uint64_t> lcn;
};

struct DataStream {
    std::uint64_t size = 0;
    bool resident = false;
    bool supported = true;
    std::vector<std::uint8_t> value;
    std::vector<Run> runs;
};

enum class Status { Resident, FreeClusters, Reallocated, UnknownBitmap, Unsupported };

const char* status_name(Status status);

struct Candidate {
    std::uint64_t record_id = 0;
    std::uint64_t parent_id = 0;
    std::uint16_t parent_sequence = 0;
    std::uint16_t record_sequence = 0;
    std::string name;
    std::string path;
    DataStream content;
    Status status = Status::Unsupported;
};

class Recovery {
public:
    explicit Recovery(const std::filesystem::path& volume_image,
                      std::optional<std::uint32_t> partition_index = std::nullopt);
    std::vector<Candidate> scan(std::uint64_t max_records = 0);
    std::filesystem::path extract(const Candidate& file, const std::filesystem::path& output_directory);
    // Up to 256 bytes; same allocation and identity checks as extract().
    std::vector<std::uint8_t> preview(const Candidate& file);
    std::uint64_t record_count() const noexcept;

private:
    struct Name {
        std::string text;
        std::uint64_t parent = 0;
        std::uint16_t parent_sequence = 0;
        int priority = -1;
    };
    struct Record {
        std::uint16_t sequence = 0;
        bool in_use = false;
        bool directory = false;
        bool has_attr_list = false;
        std::optional<Name> name;
        std::optional<DataStream> data;
    };
    struct Geometry {
        std::uint64_t sector_bytes = 0;
        std::uint64_t cluster_bytes = 0;
        std::uint64_t record_bytes = 0;
        std::uint64_t volume_bytes = 0;
        std::uint64_t mft_lcn = 0;
    };

    std::vector<std::uint8_t> read_image(std::uint64_t offset, std::size_t size);
    std::vector<std::uint8_t> read_stream(const DataStream& stream, std::uint64_t offset, std::size_t size);
    std::optional<Record> parse_record(std::vector<std::uint8_t> bytes) const;
    std::vector<std::uint8_t> read_mft_record(std::uint64_t record_id);
    Status assess(const DataStream& data);
    void refresh_bitmap();
    DataStream verified_content(const Candidate& file);
    std::string build_path(const Candidate& file, const std::map<std::uint64_t, Record>& records) const;

    std::filesystem::path image_path_;
    ReadOnlySource input_;
    std::uint64_t image_size_ = 0;
    std::uint64_t volume_offset_ = 0;
    std::uint64_t volume_limit_ = 0;
    Geometry geo_;
    DataStream mft_;
    std::optional<DataStream> bitmap_;
};

} // namespace ntfs

#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include "ntfs_recovery/read_only_source.hpp"
#include <optional>
#include <string>
#include <vector>

namespace ntfs {

struct CarvedFile {
    std::uint64_t offset = 0;
    std::uint64_t size = 0;
    std::string extension;
};

class Carver {
public:
    explicit Carver(const std::filesystem::path& image);
    std::vector<CarvedFile> scan(std::uint64_t max_bytes = 0);
    std::optional<CarvedFile> inspect(std::uint64_t offset);
    std::filesystem::path extract(const CarvedFile& file, const std::filesystem::path& destination);
    std::vector<std::uint8_t> preview(std::uint64_t offset);

private:
    std::vector<std::uint8_t> read(std::uint64_t offset, std::size_t size);
    std::uint8_t byte(std::uint64_t offset);
    std::optional<CarvedFile> png(std::uint64_t offset);
    std::optional<CarvedFile> jpeg(std::uint64_t offset);
    std::optional<CarvedFile> pdf(std::uint64_t offset);
    std::optional<CarvedFile> zip(std::uint64_t offset);

    std::filesystem::path image_path_;
    ReadOnlySource input_;
    std::uint64_t image_size_ = 0;
    std::uint64_t cache_offset_ = 0;
    std::vector<std::uint8_t> cache_;
};
} // namespace ntfs

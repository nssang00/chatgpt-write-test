#pragma once
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <vector>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace ntfs {
// Only regular image files and exact Windows \\.\X: volume device names are allowed.
// Live volumes are opened with GENERIC_READ exclusively; no volume locks or writes.
bool is_live_volume_name(const std::filesystem::path& path) noexcept;
void enforce_destination_separation(const std::filesystem::path& source,
                                    const std::filesystem::path& output_directory);

class ReadOnlySource {
public:
    explicit ReadOnlySource(const std::filesystem::path& path);
    ReadOnlySource(const ReadOnlySource&) = delete;
    ReadOnlySource& operator=(const ReadOnlySource&) = delete;
    ~ReadOnlySource();
    [[nodiscard]] std::uint64_t size() const noexcept { return size_; }
    [[nodiscard]] bool live() const noexcept { return live_; }
    void read_at(std::uint64_t offset, std::uint8_t* dest, std::size_t count);
private:
    std::ifstream file_;
    std::uint64_t size_ = 0;
    bool live_ = false;
#ifdef _WIN32
    HANDLE device_ = INVALID_HANDLE_VALUE;
    std::uint32_t sector_bytes_ = 512;
#endif
};
} // namespace ntfs

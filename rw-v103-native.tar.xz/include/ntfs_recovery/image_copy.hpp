#pragma once

#include <cstdint>
#include <filesystem>

namespace ntfs {
// Only regular files: no raw volumes, devices, or live-disk access.
// The destination must be an existing directory. Never overwrites a file.
struct ImageCopyResult {
    std::filesystem::path path;
    std::uint64_t size;
};

// Throws on mismatch or on an I/O error; compares every byte with bounded memory.
std::uint64_t verify_images(const std::filesystem::path& left,
                            const std::filesystem::path& right);
// Writes an unpublished staged file, verifies it against the source, then publishes.
ImageCopyResult copy_image_verified(const std::filesystem::path& source,
                                     const std::filesystem::path& destination_directory);
} // namespace ntfs

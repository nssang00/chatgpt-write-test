#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <functional>

namespace ntfs {

// Writes to an exclusive private staging file in the target directory, then
// publishes a complete result with no-clobber semantics at finish(). Never
// exposes an incomplete file at the requested destination path.
class ExclusiveOutput {
public:
    explicit ExclusiveOutput(const std::filesystem::path& path);
    ~ExclusiveOutput() noexcept;
    ExclusiveOutput(const ExclusiveOutput&) = delete;
    ExclusiveOutput& operator=(const ExclusiveOutput&) = delete;
    void write(const std::uint8_t* data, std::size_t size);
    void finish();
    // Called only after staging flush/close and before publication. A failed
    // validator leaves the destination absent and cleans up staging.
    void finish_verified(const std::function<void(const std::filesystem::path&)>& validator);

private:
    std::filesystem::path path_;
    std::filesystem::path staging_path_;
#ifdef _WIN32
    void* handle_ = nullptr;
#else
    int fd_ = -1;
#endif
    bool finished_ = false;
};

} // namespace ntfs

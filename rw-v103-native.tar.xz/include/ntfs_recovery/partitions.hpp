#pragma once

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace ntfs {

// A partition is an untrusted, bounded byte range inside a regular-file image.
// Partition indexes preserve on-disk slot numbers (starting at 1).
struct Partition {
    std::uint32_t index = 0;
    std::string scheme;
    std::uint64_t offset = 0;
    std::uint64_t length = 0;
};

// Supports MBR primary/extended-logical, and CRC-validated GPT primary or
// backup headers/tables. Never opens a physical device or writes to the image.
std::vector<Partition> list_partitions(const std::filesystem::path& image);

} // namespace ntfs

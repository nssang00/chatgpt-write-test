#include "ntfs_recovery/recovery.hpp"
#include "ntfs_recovery/exclusive_output.hpp"
#include "ntfs_recovery/partitions.hpp"

#include <algorithm>
#include <bit>
#include <array>
#include <iomanip>
#include <limits>
#include <stdexcept>
#include <string_view>

namespace ntfs {
namespace {
using Bytes = std::vector<std::uint8_t>;

std::uint64_t checked_add(std::uint64_t a, std::uint64_t b) {
    if (b > std::numeric_limits<std::uint64_t>::max() - a) throw std::runtime_error("integer overflow");
    return a + b;
}
std::uint64_t checked_mul(std::uint64_t a, std::uint64_t b) {
    if (a && b > std::numeric_limits<std::uint64_t>::max() / a) throw std::runtime_error("integer overflow");
    return a * b;
}
void require_range(const Bytes& data, std::uint64_t offset, std::uint64_t size) {
    if (offset > data.size() || size > data.size() - offset) throw std::runtime_error("truncated NTFS structure");
}
std::uint64_t read_le(const Bytes& data, std::uint64_t pos, unsigned count) {
    if (count < 1 || count > 8) throw std::runtime_error("invalid integer width");
    require_range(data, pos, count);
    std::uint64_t value = 0;
    for (unsigned i = 0; i < count; ++i) value |= static_cast<std::uint64_t>(data[static_cast<size_t>(pos + i)]) << (8 * i);
    return value;
}
std::int64_t read_signed_le(const Bytes& data, std::uint64_t pos, unsigned count) {
    const std::uint64_t unsigned_value = read_le(data, pos, count);
    if (count == 8) return std::bit_cast<std::int64_t>(unsigned_value);
    const unsigned bits = count * 8;
    const std::uint64_t sign = std::uint64_t{1} << (bits - 1);
    if (!(unsigned_value & sign)) return static_cast<std::int64_t>(unsigned_value);
    const auto mask = (std::uint64_t{1} << bits) - 1;
    const auto magnitude = ((~unsigned_value) & mask) + 1;
    return -static_cast<std::int64_t>(magnitude);
}
bool is_power_of_two(std::uint64_t n) { return n != 0 && (n & (n - 1)) == 0; }

std::string decode_utf16(const Bytes& data, std::uint64_t pos, std::uint64_t units) {
    require_range(data, pos, checked_mul(units, 2));
    std::string out;
    for (std::uint64_t i = 0; i < units; ++i) {
        std::uint32_t cp = static_cast<std::uint32_t>(read_le(data, pos + i * 2, 2));
        if (cp >= 0xD800 && cp <= 0xDBFF) {
            if (++i >= units) throw std::runtime_error("invalid UTF-16 surrogate");
            const auto lo = read_le(data, pos + i * 2, 2);
            if (lo < 0xDC00 || lo > 0xDFFF) throw std::runtime_error("invalid UTF-16 surrogate");
            cp = 0x10000 + ((cp - 0xD800) << 10) + static_cast<std::uint32_t>(lo - 0xDC00);
        } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
            throw std::runtime_error("invalid UTF-16 surrogate");
        }
        if (cp < 0x80) out.push_back(static_cast<char>(cp));
        else if (cp < 0x800) {
            out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
            out.push_back(static_cast<char>(0x80 | (cp & 63)));
        } else if (cp < 0x10000) {
            out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 63)));
            out.push_back(static_cast<char>(0x80 | (cp & 63)));
        } else {
            out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 63)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 63)));
            out.push_back(static_cast<char>(0x80 | (cp & 63)));
        }
    }
    return out;
}

std::vector<Run> parse_runs(const Bytes& data, std::uint64_t start, std::uint64_t end,
                            std::uint64_t starting_vcn, std::uint64_t cluster_count) {
    std::vector<Run> runs;
    std::uint64_t vcn = starting_vcn;
    std::int64_t current_lcn = 0;
    bool terminated = false;
    while (start < end) {
        const auto header = data[static_cast<size_t>(start++)];
        if (!header) { terminated = true; break; }
        const unsigned len_bytes = header & 0x0F;
        const unsigned off_bytes = header >> 4;
        if (len_bytes == 0 || len_bytes > 8 || off_bytes > 8 ||
            end - start < len_bytes + off_bytes) throw std::runtime_error("malformed NTFS data runs");
        const auto count = read_le(data, start, len_bytes);
        start += len_bytes;
        if (count == 0 || count > cluster_count || vcn > cluster_count || count > cluster_count - vcn)
            throw std::runtime_error("invalid NTFS run length");
        std::optional<std::uint64_t> lcn;
        if (off_bytes) {
            const auto delta = read_signed_le(data, start, off_bytes);
            if ((delta > 0 && current_lcn > std::numeric_limits<std::int64_t>::max() - delta) ||
                (delta < 0 && current_lcn < std::numeric_limits<std::int64_t>::min() - delta))
                throw std::runtime_error("NTFS run offset overflow");
            current_lcn += delta;
            if (current_lcn < 0 || static_cast<std::uint64_t>(current_lcn) >= cluster_count ||
                count > cluster_count - static_cast<std::uint64_t>(current_lcn))
                throw std::runtime_error("NTFS run exceeds volume");
            lcn = static_cast<std::uint64_t>(current_lcn);
        }
        start += off_bytes;
        runs.push_back({vcn, count, lcn});
        vcn = checked_add(vcn, count);
    }
    if (!terminated || runs.empty()) throw std::runtime_error("unterminated NTFS data runs");
    return runs;
}

std::string safe_filename(std::string_view name) {
    std::string result;
    for (std::size_t i = 0; i < name.size();) {
        const auto c = static_cast<unsigned char>(name[i]);
        const std::size_t width = c >= 0xF0 ? 4 : c >= 0xE0 ? 3 : c >= 0xC0 ? 2 : 1;
        if (result.size() + width > 120 || i + width > name.size()) break;
        if (width == 1 && (c < 32 || c == 127 || c == '/' || c == '\\' || c == ':' ||
                           c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|')) {
            result += '_';
        } else {
            result.append(name.substr(i, width));
        }
        i += width;
    }
    while (!result.empty() && (result.back() == '.' || result.back() == ' ')) result.pop_back();
    return result.empty() ? "unnamed" : result;
}
} // namespace

const char* status_name(Status status) {
    switch (status) {
    case Status::Resident: return "resident";
    case Status::FreeClusters: return "free-clusters";
    case Status::Reallocated: return "reallocated";
    case Status::UnknownBitmap: return "unknown-bitmap";
    case Status::Unsupported: return "unsupported";
    }
    return "unsupported";
}

Recovery::Recovery(const std::filesystem::path& volume_image,
                   std::optional<std::uint32_t> partition_index) : image_path_(volume_image), input_(volume_image) {
    if (partition_index && input_.live()) throw std::runtime_error("live volumes cannot use partition indexes");
    image_size_ = input_.size();
    volume_limit_ = image_size_;
    if (partition_index) {
        const auto partitions = list_partitions(volume_image);
        const auto found = std::find_if(partitions.begin(), partitions.end(),
                                        [&](const auto& p) { return p.index == *partition_index; });
        if (found == partitions.end()) throw std::runtime_error("partition index not found");
        volume_offset_ = found->offset;
        volume_limit_ = found->length;
    }
    if (volume_limit_ < 512) throw std::runtime_error("NTFS volume is too small");
    const auto boot = read_image(0, 512);
    if (std::string_view(reinterpret_cast<const char*>(boot.data() + 3), 8) != "NTFS    ")
        throw std::runtime_error("image is not an NTFS volume (partition images only)");
    geo_.sector_bytes = read_le(boot, 0x0B, 2);
    const auto sectors_per_cluster = read_le(boot, 0x0D, 1);
    if (!is_power_of_two(geo_.sector_bytes) || geo_.sector_bytes < 512 || geo_.sector_bytes > 4096 ||
        !is_power_of_two(sectors_per_cluster) || sectors_per_cluster > 128)
        throw std::runtime_error("invalid NTFS sector/cluster geometry");
    geo_.cluster_bytes = checked_mul(geo_.sector_bytes, sectors_per_cluster);
    geo_.volume_bytes = checked_mul(read_le(boot, 0x28, 8), geo_.sector_bytes);
    if (geo_.volume_bytes > volume_limit_ || geo_.volume_bytes < geo_.cluster_bytes * 16)
        throw std::runtime_error("NTFS volume size does not fit image");
    geo_.mft_lcn = read_le(boot, 0x30, 8);
    const auto record_exp = static_cast<std::int8_t>(boot[0x40]);
    if (record_exp == 0 || record_exp < -24 || record_exp > 64)
        throw std::runtime_error("invalid NTFS file record exponent");
    geo_.record_bytes = record_exp < 0 ? (std::uint64_t{1} << -record_exp)
                                       : checked_mul(static_cast<unsigned>(record_exp), geo_.cluster_bytes);
    if (geo_.record_bytes < 512 || geo_.record_bytes > 65536 || geo_.record_bytes % geo_.sector_bytes)
        throw std::runtime_error("unsupported NTFS file record size");
    const auto first_offset = checked_mul(geo_.mft_lcn, geo_.cluster_bytes);
    auto first = parse_record(read_image(first_offset, static_cast<size_t>(geo_.record_bytes)));
    if (!first || !first->in_use || !first->data || first->data->resident || !first->data->supported)
        throw std::runtime_error("cannot parse $MFT data stream");
    mft_ = *first->data;
    if (mft_.runs.empty() || mft_.runs.front().first_vcn != 0 ||
        !mft_.runs.front().lcn || *mft_.runs.front().lcn != geo_.mft_lcn ||
        mft_.size < 7 * geo_.record_bytes || mft_.size > geo_.volume_bytes)
        throw std::runtime_error("inconsistent $MFT data stream");
    if (first->has_attr_list) throw std::runtime_error("$MFT attribute lists are not yet supported");
    refresh_bitmap();
}

std::uint64_t Recovery::record_count() const noexcept { return mft_.size / geo_.record_bytes; }

std::vector<std::uint8_t> Recovery::read_image(std::uint64_t offset, std::size_t size) {
    if (offset > geo_.volume_bytes && geo_.volume_bytes) throw std::runtime_error("read outside volume");
    if (offset > volume_limit_ || size > volume_limit_ - offset ||
        (geo_.volume_bytes && size > geo_.volume_bytes - offset) ||
        volume_offset_ > image_size_ || offset > image_size_ - volume_offset_ ||
        size > image_size_ - volume_offset_ - offset ||
        volume_offset_ + offset > static_cast<std::uint64_t>(std::numeric_limits<std::streamoff>::max()) ||
        size > static_cast<std::size_t>(std::numeric_limits<std::streamsize>::max()))
        throw std::runtime_error("read exceeds image bounds");
    Bytes bytes(size);
    input_.read_at(volume_offset_ + offset, bytes.data(), size);
    return bytes;
}

std::vector<std::uint8_t> Recovery::read_stream(const DataStream& stream, std::uint64_t offset, std::size_t size) {
    if (offset > stream.size || size > stream.size - offset)
        throw std::runtime_error("read exceeds NTFS stream bounds");
    if (stream.resident) {
        if (offset > stream.value.size() || size > stream.value.size() - offset)
            throw std::runtime_error("truncated resident stream");
        return Bytes(stream.value.begin() + static_cast<std::ptrdiff_t>(offset),
                     stream.value.begin() + static_cast<std::ptrdiff_t>(offset + size));
    }
    if (!stream.supported) throw std::runtime_error("unsupported NTFS compression/encryption");
    Bytes out(size, 0);
    std::uint64_t read_pos = offset;
    size_t done = 0;
    while (done < size) {
        const auto vcn = read_pos / geo_.cluster_bytes;
        auto it = std::find_if(stream.runs.begin(), stream.runs.end(), [vcn](const Run& r) {
            return vcn >= r.first_vcn && vcn - r.first_vcn < r.count;
        });
        if (it == stream.runs.end()) throw std::runtime_error("unmapped NTFS data extent");
        const auto within_run = read_pos - it->first_vcn * geo_.cluster_bytes;
        const auto available = checked_mul(it->count, geo_.cluster_bytes) - within_run;
        const auto n = static_cast<size_t>(std::min<std::uint64_t>(size - done, available));
        if (it->lcn) {
            const auto physical = checked_add(checked_mul(*it->lcn, geo_.cluster_bytes), within_run);
            auto chunk = read_image(physical, n);
            std::copy(chunk.begin(), chunk.end(), out.begin() + static_cast<std::ptrdiff_t>(done));
        }
        done += n;
        read_pos += n;
    }
    return out;
}

std::vector<std::uint8_t> Recovery::read_mft_record(std::uint64_t record_id) {
    return read_stream(mft_, checked_mul(record_id, geo_.record_bytes), static_cast<size_t>(geo_.record_bytes));
}

std::optional<Recovery::Record> Recovery::parse_record(Bytes bytes) const {
    if (bytes.size() != geo_.record_bytes || std::string_view(reinterpret_cast<const char*>(bytes.data()), 4) != "FILE")
        return std::nullopt;
    try {
        // Update Sequence Array restores the final two bytes in each protected sector.
        const auto usa_pos = read_le(bytes, 4, 2);
        const auto usa_count = read_le(bytes, 6, 2);
        if (usa_count != geo_.record_bytes / geo_.sector_bytes + 1)
            throw std::runtime_error("invalid USA count");
        require_range(bytes, usa_pos, usa_count * 2);
        const auto usn = read_le(bytes, usa_pos, 2);
        for (std::uint64_t i = 1; i < usa_count; ++i) {
            const auto fix_pos = i * geo_.sector_bytes - 2;
            if (read_le(bytes, fix_pos, 2) != usn) throw std::runtime_error("NTFS USA mismatch");
            const auto prior = read_le(bytes, usa_pos + i * 2, 2);
            bytes[static_cast<size_t>(fix_pos)] = static_cast<std::uint8_t>(prior);
            bytes[static_cast<size_t>(fix_pos + 1)] = static_cast<std::uint8_t>(prior >> 8);
        }
        Record record;
        record.sequence = static_cast<std::uint16_t>(read_le(bytes, 0x10, 2));
        const auto flags = read_le(bytes, 0x16, 2);
        record.in_use = (flags & 1) != 0;
        record.directory = (flags & 2) != 0;
        if (read_le(bytes, 0x20, 8) != 0) return std::nullopt; // extension record
        auto offset = read_le(bytes, 0x14, 2);
        if (offset < 0x30 || offset >= bytes.size()) throw std::runtime_error("bad MFT attribute start");
        const auto used_bytes = read_le(bytes, 0x18, 4);
        if (used_bytes > bytes.size() || used_bytes <= offset) throw std::runtime_error("bad MFT used size");
        bool end_seen = false;
        while (offset < used_bytes) {
            if (used_bytes - offset < 4) throw std::runtime_error("truncated attribute type");
            const auto type = read_le(bytes, offset, 4);
            if (type == 0xFFFFFFFF) { end_seen = true; break; }
            if (used_bytes - offset < 0x18) throw std::runtime_error("truncated attribute header");
            const auto length = read_le(bytes, offset + 4, 4);
            if (length < 0x18 || length > used_bytes - offset || length % 8)
                throw std::runtime_error("invalid MFT attribute length");
            const auto nonresident = read_le(bytes, offset + 8, 1);
            const auto name_units = read_le(bytes, offset + 9, 1);
            if (nonresident > 1) throw std::runtime_error("invalid resident flag");
            if (name_units) {
                const auto name_off = read_le(bytes, offset + 10, 2);
                if (name_off > length || name_units * 2 > length - name_off)
                    throw std::runtime_error("bad attribute name");
            }
            if (type == 0x20) record.has_attr_list = true;
            if (type == 0x30 && !nonresident) {
                const auto val_len = read_le(bytes, offset + 0x10, 4);
                const auto val_off = read_le(bytes, offset + 0x14, 2);
                if (val_off > length || val_len > length - val_off || val_len < 0x42)
                    throw std::runtime_error("bad $FILE_NAME value");
                Bytes val(bytes.begin() + static_cast<std::ptrdiff_t>(offset + val_off),
                          bytes.begin() + static_cast<std::ptrdiff_t>(offset + val_off + val_len));
                const auto utf_units = read_le(val, 0x40, 1);
                const auto name_space = read_le(val, 0x41, 1);
                const int priority = name_space == 3 ? 4 : name_space == 1 ? 3 : name_space == 0 ? 2 : 1;
                if (utf_units && (!record.name || priority > record.name->priority)) {
                    const auto reference = read_le(val, 0, 8);
                    record.name = Name{decode_utf16(val, 0x42, utf_units), reference & 0x0000FFFFFFFFFFFFULL,
                                       static_cast<std::uint16_t>(reference >> 48), priority};
                }
            }
            // Multiple unnamed $DATA attributes without a supported extent
            // assembly mechanism must not be silently recovered as a partial file.
            if (type == 0x80 && name_units == 0 && record.data)
                record.data->supported = false;
            if (type == 0x80 && name_units == 0 && !record.data) {
                DataStream stream;
                if (nonresident) {
                    if (length < 0x40) throw std::runtime_error("truncated nonresident attribute");
                    const auto start_vcn = read_le(bytes, offset + 0x10, 8);
                    const auto last_vcn = read_le(bytes, offset + 0x18, 8);
                    const auto run_off = read_le(bytes, offset + 0x20, 2);
                    const auto attr_flags = read_le(bytes, offset + 0x0C, 2);
                    stream.size = read_le(bytes, offset + 0x30, 8);
                    stream.supported = (attr_flags & (0x0001 | 0x4000)) == 0;
                    if (start_vcn != 0 || last_vcn < start_vcn || run_off < 0x40 || run_off >= length)
                        throw std::runtime_error("unsupported fragmented NTFS attribute metadata");
                    stream.runs = parse_runs(bytes, offset + run_off, offset + length,
                                             start_vcn, geo_.volume_bytes / geo_.cluster_bytes);
                    if (stream.runs.back().first_vcn + stream.runs.back().count != last_vcn + 1)
                        throw std::runtime_error("nonresident VCN length mismatch");
                    if (stream.size > checked_mul(last_vcn + 1, geo_.cluster_bytes))
                        throw std::runtime_error("nonresident data length mismatch");
                } else {
                    const auto val_len = read_le(bytes, offset + 0x10, 4);
                    const auto val_off = read_le(bytes, offset + 0x14, 2);
                    if (val_off > length || val_len > length - val_off)
                        throw std::runtime_error("bad resident $DATA value");
                    stream.resident = true;
                    stream.size = val_len;
                    stream.value.assign(bytes.begin() + static_cast<std::ptrdiff_t>(offset + val_off),
                                        bytes.begin() + static_cast<std::ptrdiff_t>(offset + val_off + val_len));
                }
                record.data = std::move(stream);
            }
            offset += length;
        }
        if (!end_seen) throw std::runtime_error("missing MFT attribute terminator");
        return record;
    } catch (const std::exception&) {
        return std::nullopt; // individually corrupt records must not hide other candidates
    }
}

void Recovery::refresh_bitmap() {
    bitmap_.reset();
    try {
        auto allocated = parse_record(read_mft_record(6));
        if (allocated && allocated->in_use && allocated->data && allocated->data->supported &&
            allocated->data->size >= (geo_.volume_bytes / geo_.cluster_bytes + 7) / 8)
            bitmap_ = *allocated->data;
    } catch (const std::exception&) {
        // A damaged/missing bitmap must never imply a cluster is safe to recover.
    }
}

Status Recovery::assess(const DataStream& data) {
    if (!data.supported) return Status::Unsupported;
    if (data.resident) return Status::Resident;
    if (!bitmap_) return Status::UnknownBitmap;
    try {
        // Batch-read cluster allocation bits; avoid storing an entire giant bitmap in RAM.
        for (const auto& run : data.runs) {
            if (!run.lcn) continue; // sparse run: logical zeroes, no physical allocation
            const auto end = checked_add(*run.lcn, run.count);
            auto cluster = *run.lcn;
            while (cluster < end) {
                const auto start_byte = cluster / 8;
                const auto bytes_remaining = (end - 1) / 8 - start_byte + 1;
                const auto byte_count = static_cast<size_t>(std::min<std::uint64_t>(bytes_remaining, 65536));
                auto bits = read_stream(*bitmap_, start_byte, byte_count);
                const auto covered_clusters = std::min(end, checked_mul(start_byte + byte_count, 8));
                for (; cluster < covered_clusters; ++cluster) {
                    if (bits[static_cast<size_t>(cluster / 8 - start_byte)] & (1u << (cluster % 8)))
                        return Status::Reallocated;
                }
            }
        }
        return Status::FreeClusters;
    } catch (const std::exception&) {
        return Status::UnknownBitmap;
    }
}

std::string Recovery::build_path(const Candidate& file, const std::map<std::uint64_t, Record>& records) const {
    std::string result = file.name;
    auto parent = file.parent_id;
    auto parent_seq = file.parent_sequence;
    std::vector<std::uint64_t> visited{file.record_id};
    for (int depth = 0; depth < 128 && parent != 5; ++depth) {
        if (parent == 0 || std::find(visited.begin(), visited.end(), parent) != visited.end())
            return "[unknown-parent]/" + result;
        auto iter = records.find(parent);
        if (iter == records.end() || !iter->second.name || !iter->second.directory ||
            (parent_seq && parent_seq != iter->second.sequence))
            return "[unknown-parent]/" + result;
        visited.push_back(parent);
        result = iter->second.name->text + "/" + result;
        parent = iter->second.name->parent;
        parent_seq = iter->second.name->parent_sequence;
    }
    if (parent != 5) return "[unknown-parent]/" + result;
    return "/" + result;
}

std::vector<Candidate> Recovery::scan(std::uint64_t max_records) {
    const auto count = max_records == 0 ? record_count() : std::min(max_records, record_count());
    std::map<std::uint64_t, Record> records;
    std::vector<Candidate> found;
    for (std::uint64_t id = 0; id < count; ++id) {
        try {
            auto record = parse_record(read_mft_record(id));
            if (!record) continue;
            if (record->name && record->directory) records.emplace(id, *record);
            if (id < 16 || record->in_use || record->directory || !record->name) continue;
            Candidate candidate;
            candidate.record_id = id;
            candidate.record_sequence = record->sequence;
            candidate.parent_id = record->name->parent;
            candidate.parent_sequence = record->name->parent_sequence;
            candidate.name = record->name->text;
            if (record->data) candidate.content = *record->data;
            else candidate.content.supported = false;
            if (record->has_attr_list) candidate.content.supported = false;
            candidate.status = assess(candidate.content);
            found.push_back(std::move(candidate));
        } catch (const std::exception&) {
            // A single missing/corrupt MFT record must not abort the scan.
        }
    }
    for (auto& file : found) file.path = build_path(file, records);
    return found;
}

DataStream Recovery::verified_content(const Candidate& file) {
    if (file.record_id < 16 || file.record_id >= record_count())
        throw std::runtime_error("recovery blocked: invalid MFT candidate id");
    // Never trust a caller-supplied Candidate, including its prior allocation status.
    // A changed MFT record/bitmap cannot silently redirect reads to different clusters.
    const auto current = parse_record(read_mft_record(file.record_id));
    if (!current || current->in_use || current->directory || current->has_attr_list ||
        !current->name || !current->data)
        throw std::runtime_error("recovery blocked: candidate is no longer a supported deleted file");
    const auto& data = *current->data;
    refresh_bitmap(); // Allocation state may have changed since scan().
    const auto status = assess(data);
    if (status != Status::Resident && status != Status::FreeClusters)
        throw std::runtime_error("recovery blocked: current allocation status is unsafe");
    if (file.status != status || file.record_sequence != current->sequence ||
        file.parent_id != current->name->parent ||
        file.parent_sequence != current->name->parent_sequence ||
        file.name != current->name->text || file.content.size != data.size ||
        file.content.resident != data.resident || file.content.supported != data.supported ||
        file.content.value != data.value || file.content.runs.size() != data.runs.size())
        throw std::runtime_error("recovery blocked: candidate changed since scan");
    for (std::size_t i = 0; i < data.runs.size(); ++i) {
        const auto& a = data.runs[i];
        const auto& b = file.content.runs[i];
        if (a.first_vcn != b.first_vcn || a.count != b.count || a.lcn != b.lcn)
            throw std::runtime_error("recovery blocked: candidate extents changed since scan");
    }
    return data;
}

std::vector<std::uint8_t> Recovery::preview(const Candidate& file) {
    const auto data = verified_content(file);
    return read_stream(data, 0, static_cast<std::size_t>(std::min<std::uint64_t>(256, data.size)));
}

std::filesystem::path Recovery::extract(const Candidate& file, const std::filesystem::path& output_directory) {
    enforce_destination_separation(image_path_, output_directory);
    const auto data = verified_content(file);
    if (!std::filesystem::is_directory(output_directory))
        throw std::runtime_error("output directory must already exist");
    // MFT filenames are decoded into UTF-8. On Windows std::filesystem::path
    // constructed from std::string uses the current ANSI code page (CP949 etc.),
    // which rejects/garbles names containing Unicode outside that code page.
    // Construct from UTF-8 explicitly; MSVC then uses its native wide path.
    const auto utf8_name = "rec_" + std::to_string(file.record_id) + "_" + safe_filename(file.name);
    const auto output = output_directory / std::filesystem::path(
        std::u8string(utf8_name.begin(), utf8_name.end()));
    ExclusiveOutput out(output); // CREATE_NEW / O_EXCL, never truncate existing paths.
    constexpr std::size_t chunk_size = 1 << 20;
    for (std::uint64_t offset = 0; offset < data.size;) {
        const auto n = static_cast<size_t>(std::min<std::uint64_t>(chunk_size, data.size - offset));
        const auto chunk = read_stream(data, offset, n);
        out.write(chunk.data(), chunk.size());
        offset += n;
    }
    out.finish();
    return output;
}

} // namespace ntfs

#include "ntfs_recovery/image_copy.hpp"
#include "ntfs_recovery/exclusive_output.hpp"

#include <algorithm>
#include <vector>
#include <fstream>
#include <limits>
#include <stdexcept>

namespace ntfs {
namespace {
constexpr std::size_t kBlockSize = 1U << 20;

std::uint64_t image_size(const std::filesystem::path& path) {
    if (!std::filesystem::is_regular_file(path))
        throw std::runtime_error("image source must be a regular file");
    const auto length = std::filesystem::file_size(path);
    if (length > static_cast<std::uint64_t>(std::numeric_limits<std::streamoff>::max()))
        throw std::runtime_error("image exceeds supported seek range");
    return length;
}
void read_exact(std::ifstream& stream, std::uint8_t* data, std::size_t size) {
    if (!stream.read(reinterpret_cast<char*>(data), static_cast<std::streamsize>(size)))
        throw std::runtime_error("image changed during read or input read failed");
}
} // namespace

std::uint64_t verify_images(const std::filesystem::path& left,
                            const std::filesystem::path& right) {
    const auto length = image_size(left);
    if (image_size(right) != length) throw std::runtime_error("image sizes differ");
    std::ifstream a(left, std::ios::binary), b(right, std::ios::binary);
    if (!a || !b) throw std::runtime_error("cannot open image for verification");
    // Heap buffers: keep the Windows default 1 MiB thread stack safe.
    std::vector<std::uint8_t> first(kBlockSize), second(kBlockSize);
    for (std::uint64_t offset = 0; offset < length;) {
        const auto bytes = static_cast<std::size_t>(std::min<std::uint64_t>(kBlockSize, length - offset));
        read_exact(a, first.data(), bytes);
        read_exact(b, second.data(), bytes);
        if (!std::equal(first.begin(), first.begin() + static_cast<std::ptrdiff_t>(bytes), second.begin()))
            throw std::runtime_error("image byte mismatch at offset " + std::to_string(offset));
        offset += bytes;
    }
    // A resize during comparison must not be reported as a verified copy.
    if (image_size(left) != length || image_size(right) != length)
        throw std::runtime_error("image changed size during verification");
    return length;
}

ImageCopyResult copy_image_verified(const std::filesystem::path& source,
                                     const std::filesystem::path& destination_directory) {
    const auto length = image_size(source);
    if (!std::filesystem::is_directory(destination_directory))
        throw std::runtime_error("output directory must already exist");
    const auto name = source.filename();
    if (name.empty() || name == "." || name == "..")
        throw std::runtime_error("invalid image source name");
    const auto target = destination_directory / name;
    // The exclusive output also protects against symlinks and concurrent creators.
    ExclusiveOutput output(target);
    std::ifstream input(source, std::ios::binary);
    if (!input) throw std::runtime_error("cannot open image for copying");
    std::vector<std::uint8_t> buffer(kBlockSize);
    for (std::uint64_t offset = 0; offset < length;) {
        const auto bytes = static_cast<std::size_t>(std::min<std::uint64_t>(kBlockSize, length - offset));
        read_exact(input, buffer.data(), bytes);
        output.write(buffer.data(), bytes);
        offset += bytes;
    }
    // Verification happens AFTER the staging file is flushed/closed, but BEFORE
    // its final name is made visible. A mismatch leaves no published result.
    output.finish_verified([&](const std::filesystem::path& staging) {
        if (verify_images(source, staging) != length)
            throw std::runtime_error("copy verification length mismatch");
    });
    return {target, length};
}
} // namespace ntfs

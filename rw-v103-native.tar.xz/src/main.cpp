#include "ntfs_recovery/recovery.hpp"
#include "ntfs_recovery/carving.hpp"
#include "ntfs_recovery/partitions.hpp"
#include "ntfs_recovery/fat_recovery.hpp"
#include "ntfs_recovery/image_copy.hpp"
#include "cli_options.hpp"

#include <algorithm>
#include <charconv>
#include <filesystem>
#include <optional>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <string_view>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace {
void usage() {
    std::cerr << "Read-only NTFS/FAT32/exFAT recovery (image or Windows live drive)\n"
              << "Usage:\n"
              << "  ntfsrecover scan <image.img> [--limit N]\n"
              << "  ntfsrecover extract <image.img> <MFT-record-id> <existing-output-dir>\n"
              << "  ntfsrecover partitions <whole-disk-image>\n"
              << "  ntfsrecover scan-partition <whole-disk-image> <partition-index> [--limit N]\n"
              << "  ntfsrecover extract-partition <whole-disk-image> <partition-index> <MFT-id> <output-dir>\n"
              << "  ntfsrecover scan-fat <FAT32-or-exFAT-volume-image>\n"
              << "  ntfsrecover extract-fat <FAT32-or-exFAT-volume-image> <entry-id> <output-dir>\n"
              << "  ntfsrecover scan-fat-partition <disk-image> <partition-index>\n"
              << "  ntfsrecover extract-fat-partition <disk-image> <partition-index> <entry-id> <output-dir>\n"
              << "  ntfsrecover carve <any-raw-image> [--limit-bytes N]\n"
              << "  ntfsrecover carve-extract <any-raw-image> <byte-offset> <existing-output-dir>\n"
              << "  ntfsrecover image-copy <regular-image-file> <existing-output-dir>\n"
              << "  ntfsrecover image-compare <image-a> <image-b>\n"
              << "  ntfsrecover preview <ntfs|fat|carve|ntfs-part|fat-part> <image> [partition-index] <id> --json\n"
              << "  Append --json to a listing command for NDJSON records (WPF protocol v1).\n";
}
std::uint64_t parse_uint(std::string_view str) {
    std::uint64_t number = 0;
    const auto [end, ec] = std::from_chars(str.data(), str.data() + str.size(), number);
    if (ec != std::errc{} || end != str.data() + str.size())
        throw std::runtime_error("invalid unsigned decimal integer");
    return number;
}
std::string ascii_arg(const char* text) { return text; }
#ifdef _WIN32
std::string ascii_arg(const wchar_t* text) {
    std::string result;
    for (wchar_t c : std::wstring_view(text)) {
        if (c < 0 || c > 127) throw std::runtime_error("invalid command option");
        result.push_back(static_cast<char>(c));
    }
    return result;
}
#endif
std::string utf8_path(const std::filesystem::path& p) {
    const auto u8 = p.u8string();
    return std::string(u8.begin(), u8.end());
}

// Stable, line-delimited UTF-8 JSON records. Control characters cannot inject rows.
void json_string(std::ostream& out, std::string_view value) {
    constexpr char digits[] = "0123456789abcdef";
    out << '"';
    for (const char ch : value) {
        const auto c = static_cast<unsigned char>(ch);
        switch (c) {
            case '"': out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            default:
                if (c < 0x20) {
                    out << "\\u00" << digits[c >> 4] << digits[c & 0xf];
                } else {
                    out << static_cast<char>(c);
                }
        }
    }
    out << '"';
}
void print_file_json(std::uint64_t id, std::uint64_t size,
                     std::string_view status, std::string_view path) {
    std::cout << "{\"kind\":\"file\",\"id\":" << id << ",\"size\":" << size
              << ",\"status\":";
    json_string(std::cout, status);
    std::cout << ",\"path\":";
    json_string(std::cout, path);
    std::cout << "}\n";
}
void print_extraction(const std::filesystem::path& path, bool json) {
    if (!json) {
        std::cout << utf8_path(path) << '\n';
        return;
    }
    std::cout << "{\"kind\":\"extract\",\"path\":";
    json_string(std::cout, utf8_path(path));
    std::cout << "}\n";
}
template<typename Char>
int run(int argc, Char** argv) {
    if (argc < 3) { usage(); return 2; }
    try {
        bool json = false;
        if (argc > 3 && ntfs::cli::matches_ascii_option(argv[argc - 1], "--json")) {
            json = true;
            --argc;
        }
        const auto cmd = ascii_arg(argv[1]);
        if (cmd == "preview") {
            // The preview is deliberately small and never writes an output file.
            // JSON is mandatory so a binary filename cannot corrupt UI parsing.
            if (!json || (argc != 5 && argc != 6)) { usage(); return 2; }
            const auto mode = ascii_arg(argv[2]);
            const bool partitioned = mode == "ntfs-part" || mode == "fat-part";
            if ((partitioned && argc != 6) || (!partitioned && argc != 5)) {
                usage(); return 2;
            }
            if (mode != "ntfs" && mode != "fat" && mode != "carve" &&
                mode != "ntfs-part" && mode != "fat-part") { usage(); return 2; }
            const std::filesystem::path source(argv[3]);
            std::optional<std::uint32_t> partition;
            if (partitioned) {
                const auto number = parse_uint(ascii_arg(argv[4]));
                if (number == 0 || number > UINT32_MAX) throw std::runtime_error("invalid partition index");
                partition = static_cast<std::uint32_t>(number);
            }
            const auto id = parse_uint(ascii_arg(argv[partitioned ? 5 : 4]));
            std::vector<std::uint8_t> bytes;
            if (mode == "fat" || mode == "fat-part") {
                ntfs::FatRecovery recovery(source,partition);
                bytes = recovery.preview(id);
            } else if (mode == "carve") {
                ntfs::Carver carver(source);
                bytes = carver.preview(id);
            } else {
                ntfs::Recovery recovery(source,partition);
                if (id >= recovery.record_count()) throw std::runtime_error("record id out of bounds");
                const auto found = recovery.scan(id + 1);
                const auto it = std::find_if(found.begin(),found.end(),[id](const auto& item){
                    return item.record_id == id;
                });
                if (it == found.end()) throw std::runtime_error("deleted record not found");
                bytes = recovery.preview(*it);
            }
            constexpr char hex_digits[] = "0123456789abcdef";
            std::cout << "{\"kind\":\"preview\",\"id\":" << id << ",\"bytes\":" << bytes.size() << ",\"hex\":\"";
            for (const auto b : bytes) std::cout << hex_digits[b >> 4] << hex_digits[b & 15];
            std::cout << "\"}\n";
            return 0;
        }
        const std::filesystem::path image(argv[2]);
        if (cmd == "image-copy" || cmd == "image-compare") {
            if (argc != 4) { usage(); return 2; }
            if (cmd == "image-copy") {
                const auto result = ntfs::copy_image_verified(image, std::filesystem::path(argv[3]));
                if (json) {
                    std::cout << "{\"kind\":\"image-copy\",\"verified\":true,\"size\":"
                              << result.size << ",\"path\":";
                    json_string(std::cout, utf8_path(result.path));
                    std::cout << "}\n";
                } else {
                    std::cout << "VERIFIED\t" << result.size << "\t" << utf8_path(result.path) << '\n';
                }
            } else {
                const auto size = ntfs::verify_images(image, std::filesystem::path(argv[3]));
                if (json) std::cout << "{\"kind\":\"image-compare\",\"equal\":true,\"size\":" << size << "}\n";
                else std::cout << "IDENTICAL\t" << size << '\n';
            }
            return 0;
        }
        if (cmd == "partitions") {
            if (argc != 3) { usage(); return 2; }
            const auto entries = ntfs::list_partitions(image);
            if (!json) std::cout << "INDEX\tSCHEME\tOFFSET\tLENGTH\n";
            for (const auto& entry : entries) {
                if (json) {
                    std::cout << "{\"kind\":\"partition\",\"index\":" << entry.index
                              << ",\"scheme\":";
                    json_string(std::cout, entry.scheme);
                    std::cout << ",\"offset\":" << entry.offset << ",\"length\":" << entry.length << "}\n";
                } else {
                    std::cout << entry.index << '\t' << entry.scheme << '\t'
                              << entry.offset << '\t' << entry.length << '\n';
                }
            }
            return 0;
        }
        if (cmd == "carve") {
            std::uint64_t max_bytes = 0;
            if (argc == 5 && ascii_arg(argv[3]) == "--limit-bytes") max_bytes = parse_uint(ascii_arg(argv[4]));
            else if (argc != 3) { usage(); return 2; }
            ntfs::Carver carver(image);
            auto files = carver.scan(max_bytes);
            if (!json) std::cout << "OFFSET\tSIZE\tTYPE\n";
            for (const auto& item : files) {
                if (json) {
                    std::cout << "{\"kind\":\"carve\",\"offset\":" << item.offset
                              << ",\"size\":" << item.size << ",\"type\":";
                    json_string(std::cout, item.extension);
                    std::cout << "}\n";
                } else {
                    std::cout << item.offset << '\t' << item.size << '\t' << item.extension << '\n';
                }
            }
            return 0;
        }
        if (cmd == "carve-extract") {
            if (argc != 5) { usage(); return 2; }
            ntfs::Carver carver(image);
            const auto found = carver.inspect(parse_uint(ascii_arg(argv[3])));
            if (!found) throw std::runtime_error("no valid carved file at specified offset");
            print_extraction(carver.extract(*found, std::filesystem::path(argv[4])),json);
            return 0;
        }
        const bool fat_cmd = cmd == "scan-fat" || cmd == "extract-fat" ||
                             cmd == "scan-fat-partition" || cmd == "extract-fat-partition";
        if (fat_cmd) {
            const bool partitioned = cmd == "scan-fat-partition" || cmd == "extract-fat-partition";
            const bool extracting = cmd == "extract-fat" || cmd == "extract-fat-partition";
            if (argc != (partitioned ? (extracting ? 6 : 4) : (extracting ? 5 : 3))) {
                usage(); return 2;
            }
            std::optional<std::uint32_t> selected;
            if (partitioned) {
                auto id = parse_uint(ascii_arg(argv[3]));
                if (id == 0 || id > UINT32_MAX) throw std::runtime_error("invalid partition index");
                selected = static_cast<std::uint32_t>(id);
            }
            ntfs::FatRecovery recovery(image,selected);
            if (!extracting) {
                const auto files = recovery.scan();
                if (!json) std::cout << "ID\tSIZE\tSTATUS\tPATH\n";
                for (const auto& f : files) {
                    if (json) print_file_json(f.id, f.size, f.status, f.path);
                    else std::cout << f.id << '\t' << f.size << '\t' << f.status << '\t' << f.path << '\n';
                }
            } else {
                const auto id = parse_uint(ascii_arg(argv[partitioned ? 4 : 3]));
                print_extraction(recovery.extract(id,std::filesystem::path(argv[partitioned ? 5 : 4])),json);
            }
            return 0;
        }
        const bool partition_cmd = cmd == "scan-partition" || cmd == "extract-partition";
        std::optional<std::uint32_t> partition;
        if (partition_cmd) {
            if (argc < 4) { usage(); return 2; }
            const auto index = parse_uint(ascii_arg(argv[3]));
            if (index == 0 || index > UINT32_MAX) throw std::runtime_error("invalid partition index");
            partition = static_cast<std::uint32_t>(index);
        }
        if (cmd != "scan" && cmd != "extract" && !partition_cmd) { usage(); return 2; }
        ntfs::Recovery recovery(image, partition);
        if (cmd == "scan" || cmd == "scan-partition") {
            std::uint64_t limit = 0;
            const int opt_pos = partition_cmd ? 4 : 3;
            if (argc == opt_pos + 2 && ascii_arg(argv[opt_pos]) == "--limit")
                limit = parse_uint(ascii_arg(argv[opt_pos + 1]));
            else if (argc != opt_pos) { usage(); return 2; }
            const auto found = recovery.scan(limit);
            if (!json) std::cout << "ID\tSIZE\tSTATUS\tPATH\n";
            for (const auto& item : found) {
                if (json) print_file_json(item.record_id, item.content.size,
                                          ntfs::status_name(item.status), item.path);
                else std::cout << item.record_id << '\t' << item.content.size << '\t'
                               << ntfs::status_name(item.status) << '\t' << item.path << '\n';
            }
            std::cerr << "Scanned up to " << (limit ? std::min(limit, recovery.record_count()) : recovery.record_count())
                      << " MFT records; candidates: " << found.size() << "\n";
        } else if (cmd == "extract" || cmd == "extract-partition") {
            if (argc != (partition_cmd ? 6 : 5)) { usage(); return 2; }
            const auto id = parse_uint(ascii_arg(argv[partition_cmd ? 4 : 3]));
            if (id >= recovery.record_count()) throw std::runtime_error("record id is outside $MFT");
            // Scan through the requested id, not necessarily the whole $MFT.
            const auto found = recovery.scan(id + 1);
            for (const auto& item : found) {
                if (item.record_id == id) {
                    print_extraction(recovery.extract(item, std::filesystem::path(argv[partition_cmd ? 5 : 4])),json);
                    return 0;
                }
            }
            throw std::runtime_error("deleted file record not found");
        } else {
            usage(); return 2;
        }
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "error: " << e.what() << '\n';
        return 1;
    }
}
} // namespace

#ifdef _WIN32
int wmain(int argc, wchar_t** argv) {
    SetConsoleOutputCP(CP_UTF8);
    return run(argc, argv);
}
#else
int main(int argc, char** argv) { return run(argc, argv); }
#endif

#include "ntfs_recovery/carving.hpp"
#include "ntfs_recovery/exclusive_output.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <stdexcept>
#include <string_view>

namespace ntfs {
namespace {
constexpr std::uint64_t kMaxCarvedFile = 64ULL * 1024 * 1024;
constexpr std::size_t kReadChunk = 1 << 16;
constexpr std::array<std::uint8_t, 8> kPngSignature{137, 80, 78, 71, 13, 10, 26, 10};

std::uint32_t be32(const std::vector<std::uint8_t>& bytes, std::size_t offset) {
    return (static_cast<std::uint32_t>(bytes[offset]) << 24) |
           (static_cast<std::uint32_t>(bytes[offset + 1]) << 16) |
           (static_cast<std::uint32_t>(bytes[offset + 2]) << 8) | bytes[offset + 3];
}
std::uint32_t crc32_update(std::uint32_t crc, const std::uint8_t* bytes, std::size_t size) {
    for (std::size_t i = 0; i < size; ++i) {
        crc ^= bytes[i];
        for (int bit = 0; bit < 8; ++bit) crc = (crc >> 1) ^ ((crc & 1) ? 0xEDB88320U : 0U);
    }
    return crc;
}
bool ascii_chunk_type(const std::vector<std::uint8_t>& buffer) {
    for (std::size_t i = 4; i < 8; ++i)
        if (!((buffer[i] >= 'A' && buffer[i] <= 'Z') || (buffer[i] >= 'a' && buffer[i] <= 'z'))) return false;
    return true;
}
} // namespace

Carver::Carver(const std::filesystem::path& image) : image_path_(image), input_(image) {
    image_size_ = input_.size();
}
std::vector<std::uint8_t> Carver::read(std::uint64_t offset, std::size_t size) {
    if (offset > image_size_ || size > image_size_ - offset ||
        offset > static_cast<std::uint64_t>(std::numeric_limits<std::streamoff>::max()))
        throw std::runtime_error("carving read beyond image");
    std::vector<std::uint8_t> bytes(size);
    input_.read_at(offset, bytes.data(), size);
    return bytes;
}
std::uint8_t Carver::byte(std::uint64_t offset) {
    if (offset >= image_size_) throw std::runtime_error("carving byte beyond image");
    if (cache_.empty() || offset < cache_offset_ || offset - cache_offset_ >= cache_.size()) {
        cache_offset_ = offset;
        cache_ = read(offset, static_cast<size_t>(std::min<std::uint64_t>(kReadChunk, image_size_ - offset)));
    }
    return cache_[static_cast<size_t>(offset - cache_offset_)];
}

std::optional<CarvedFile> Carver::png(std::uint64_t offset) {
    const auto upper = std::min<std::uint64_t>(kMaxCarvedFile, image_size_ - offset);
    std::uint64_t pos = 8;
    bool seen_ihdr = false, seen_idat = false;
    while (pos <= upper && upper - pos >= 12) {
        auto header = read(offset + pos, 8);
        const auto length = be32(header, 0);
        if (!ascii_chunk_type(header) || length > upper - pos - 12) return std::nullopt;
        std::string_view type(reinterpret_cast<const char*>(header.data() + 4), 4);
        if (!seen_ihdr && (type != "IHDR" || length != 13)) return std::nullopt;
        if (type == "IHDR") {
            if (seen_ihdr || length != 13) return std::nullopt;
            auto dims = read(offset + pos + 8, 8);
            if (!be32(dims, 0) || !be32(dims, 4)) return std::nullopt;
            seen_ihdr = true;
        }
        if (type == "IDAT") seen_idat = true;
        std::uint32_t crc = crc32_update(0xFFFFFFFFU, header.data() + 4, 4);
        auto chunk_pos = offset + pos + 8;
        std::uint64_t remaining = length;
        while (remaining) {
            const auto n = static_cast<size_t>(std::min<std::uint64_t>(remaining, kReadChunk));
            auto bytes = read(chunk_pos, n);
            crc = crc32_update(crc, bytes.data(), bytes.size());
            chunk_pos += n;
            remaining -= n;
        }
        const auto expected = be32(read(offset + pos + 8 + length, 4), 0);
        if ((crc ^ 0xFFFFFFFFU) != expected) return std::nullopt;
        pos += 12 + length;
        if (type == "IEND") {
            if (length != 0 || !seen_ihdr || !seen_idat) return std::nullopt;
            return CarvedFile{offset, pos, "png"};
        }
    }
    return std::nullopt;
}

std::optional<CarvedFile> Carver::jpeg(std::uint64_t offset) {
    const auto upper = std::min<std::uint64_t>(kMaxCarvedFile, image_size_ - offset);
    std::uint64_t p = 2;
    bool seen_scan = false;
    bool seen_frame = false;
    bool entropy = false;
    while (p + 1 < upper) {
        if (entropy) {
            if (byte(offset + p++) != 0xFF) continue;
            const auto following = byte(offset + p);
            if (following == 0x00 || (following >= 0xD0 && following <= 0xD7)) { ++p; continue; }
            if (following == 0xFF) continue;
            --p; // process as a marker after entropy-coded data
            entropy = false;
        }
        if (byte(offset + p++) != 0xFF) return std::nullopt;
        while (p < upper && byte(offset + p) == 0xFF) ++p;
        if (p >= upper) return std::nullopt;
        const auto marker = byte(offset + p++);
        if (marker == 0xD9) return (seen_scan && seen_frame) ?
            std::optional<CarvedFile>{{offset, p, "jpg"}} : std::nullopt;
        if (marker == 0xD8 || marker == 0x00 || (marker >= 0xD0 && marker <= 0xD7)) return std::nullopt;
        if (marker == 0x01) continue;
        if (p + 2 > upper) return std::nullopt;
        const auto length = (static_cast<unsigned>(byte(offset + p)) << 8) | byte(offset + p + 1);
        if (length < 2 || length > upper - p) return std::nullopt;
        // All SOF types except DHT/DAC/jpg-reserved markers. Validate dimensions and
        // segment width before trusting SOS + EOI as a complete JPEG candidate.
        const bool sof = ((marker >= 0xC0 && marker <= 0xC3) ||
                          (marker >= 0xC5 && marker <= 0xC7) ||
                          (marker >= 0xC9 && marker <= 0xCB) ||
                          (marker >= 0xCD && marker <= 0xCF));
        if (sof) {
            if (seen_frame || length < 11 || p + 8 > upper) return std::nullopt;
            const auto height = (static_cast<unsigned>(byte(offset + p + 3)) << 8) | byte(offset + p + 4);
            const auto width  = (static_cast<unsigned>(byte(offset + p + 5)) << 8) | byte(offset + p + 6);
            const auto components = byte(offset + p + 7);
            if (width == 0 || height == 0 || components == 0 || length != 8U + 3U * components)
                return std::nullopt;
            seen_frame = true;
        }
        if (marker == 0xDA) {
            if (!seen_frame || length < 8) return std::nullopt;
            const auto components = byte(offset + p + 2);
            if (components == 0 || length != 6U + 2U * components) return std::nullopt;
            seen_scan = true;
            entropy = true;
        }
        p += length;
    }
    return std::nullopt;
}

std::optional<CarvedFile> Carver::pdf(std::uint64_t offset) {
    const auto upper = std::min<std::uint64_t>(kMaxCarvedFile, image_size_ - offset);
    if (upper < 16) return std::nullopt;
    const auto header = read(offset, 8);
    if (header[5] < '1' || header[5] > '2' || header[6] != '.' ||
        header[7] < '0' || header[7] > '9') return std::nullopt;
    // Heuristic: a valid-looking %%EOF is required; incremental-update PDFs may
    // contain several markers, so the first one may be shorter than the original.
    constexpr std::string_view marker = "%%EOF";
    unsigned matches = 0;
    for (std::uint64_t p = 8; p < upper; ++p) {
        const auto c = byte(offset + p);
        matches = c == static_cast<std::uint8_t>(marker[matches]) ? matches + 1 : (c == '%' ? 1U : 0U);
        if (matches == marker.size()) return CarvedFile{offset, p + 1, "pdf"};
    }
    return std::nullopt;
}


// Strict, single-disk non-Zip64 central-directory verification. Stored entries
// are additionally checked against their CRC32; DEFLATE payloads are not decoded.
std::optional<CarvedFile> Carver::zip(std::uint64_t offset) {
    const auto upper = std::min<std::uint64_t>(kMaxCarvedFile, image_size_ - offset);
    if (upper < 30+46+22) return std::nullopt;
    auto little = [](const std::vector<std::uint8_t>& d, std::size_t p, unsigned n) {
        std::uint64_t value = 0;
        for (unsigned i=0;i<n;++i) value |= static_cast<std::uint64_t>(d[p+i]) << (i*8);
        return value;
    };
    // EOCD is at the end of a ZIP. Search from after the first local header;
    // candidate starts are verified against central-directory local offsets.
    for (std::uint64_t p=30; p+22<=upper; ++p) {
        if (byte(offset+p)!='P' || byte(offset+p+1)!='K' ||
            byte(offset+p+2)!=5 || byte(offset+p+3)!=6) continue;
        const auto end = read(offset+p,22);
        if (little(end,4,2)!=0 || little(end,6,2)!=0 ||
            little(end,8,2)!=little(end,10,2) || little(end,10,2)==0) continue;
        const auto total = little(end,10,2);
        const auto central_size = little(end,12,4);
        const auto central_offset = little(end,16,4);
        const auto comment_size = little(end,20,2);
        if (central_size == 0xffffffffU || central_offset == 0xffffffffU ||
            central_size < total*46 || central_offset < 30 ||
            central_offset > p || central_size != p-central_offset ||
            comment_size > upper-p-22) continue;
        auto pos = central_offset;
        bool valid = true;
        bool has_content_types = false, has_word = false, has_excel = false, has_ppt = false;
        std::vector<std::pair<std::uint64_t, std::uint64_t>> local_ranges;
        for (std::uint64_t i=0; i<total; ++i) {
            if (pos+46 > p) { valid=false; break; }
            const auto central = read(offset+pos,46);
            if (little(central,0,4)!=0x02014b50 ||
                little(central,8,2)&1U || little(central,10,2)>8 ||
                (little(central,10,2)!=0 && little(central,10,2)!=8) ||
                little(central,16,4)==0xffffffffU ||
                little(central,20,4)==0xffffffffU ||
                little(central,24,4)==0xffffffffU ||
                little(central,34,2)!=0) { valid=false; break; }
            const auto name_size = little(central,28,2);
            const auto extra_size = little(central,30,2);
            const auto comment = little(central,32,2);
            const auto local_offset = little(central,42,4);
            const auto total_entry = 46+name_size+extra_size+comment;
            if (name_size==0 || total_entry > p-pos || local_offset+30 > central_offset) {
                valid=false; break;
            }
            const auto local = read(offset+local_offset,30);
            if (little(local,0,4)!=0x04034b50 ||
                little(local,8,2)!=little(central,10,2) ||
                little(local,6,2)!=little(central,8,2) ||
                little(local,26,2)!=name_size) { valid=false; break; }
            const auto local_name = read(offset+local_offset+30,static_cast<std::size_t>(name_size));
            const auto central_name = read(offset+pos+46,static_cast<std::size_t>(name_size));
            if (local_name != central_name) { valid=false; break; }
            const auto method = little(central,10,2);
            const auto flags = little(central,8,2);
            const auto checksum = little(central,16,4);
            const auto compressed = little(central,20,4);
            const auto uncompressed = little(central,24,4);
            // ZIP data descriptor mode deliberately leaves CRC and sizes zero in
            // local headers; otherwise the two headers must agree. Zip64 and
            // encrypted entries are not supported by this bounded carver.
            if (!(flags & 8U) &&
                (little(local,14,4)!=checksum || little(local,18,4)!=compressed ||
                 little(local,22,4)!=uncompressed)) { valid=false; break; }
            if (method==0 && compressed!=uncompressed) { valid=false; break; }
            const auto data_start = local_offset+30+name_size+little(local,28,2);
            const auto data_end = data_start+compressed;
            if (data_end > central_offset) { valid=false; break; }
            auto local_end = data_end;
            if (flags & 8U) {
                // Validate classic 12/16-byte descriptors, not Zip64.
                if (central_offset-data_end < 12) { valid=false; break; }
                const auto head = read(offset+data_end, 4);
                if (little(head,0,4)==0x08074b50U) local_end+=4;
                if (central_offset-local_end < 12) { valid=false; break; }
                const auto descriptor = read(offset+local_end,12);
                if (little(descriptor,0,4)!=checksum ||
                    little(descriptor,4,4)!=compressed ||
                    little(descriptor,8,4)!=uncompressed) { valid=false; break; }
                local_end+=12;
            }
            // Distinct central-directory entries must not alias/overlap the
            // same local header or payload. Otherwise forged metadata can
            // turn a partial archive into a false-positive recovery result.
            for (const auto& [range_begin, range_end] : local_ranges) {
                if (local_offset < range_end && range_begin < local_end) { valid=false; break; }
            }
            if (!valid) break;
            local_ranges.emplace_back(local_offset,local_end);
            if (method == 0) {
                std::uint32_t crc = 0xFFFFFFFFU;
                for (std::uint64_t done=0; done<compressed;) {
                    const auto n = static_cast<std::size_t>(
                        std::min<std::uint64_t>(kReadChunk, compressed-done));
                    const auto chunk = read(offset+data_start+done,n);
                    crc = crc32_update(crc,chunk.data(),chunk.size());
                    done+=n;
                }
                if ((crc ^ 0xFFFFFFFFU)!=checksum) { valid=false; break; }
            }
            const std::string name(local_name.begin(),local_name.end());
            has_content_types |= name == "[Content_Types].xml";
            has_word |= name == "word/document.xml";
            has_excel |= name == "xl/workbook.xml";
            has_ppt |= name == "ppt/presentation.xml";
            pos += total_entry;
        }
        if (!valid || pos!=p) continue;
        const auto ext = has_content_types && has_word ? "docx" :
                         has_content_types && has_excel ? "xlsx" :
                         has_content_types && has_ppt ? "pptx" : "zip";
        return CarvedFile{offset,p+22+comment_size,ext};
    }
    return std::nullopt;
}

std::optional<CarvedFile> Carver::inspect(std::uint64_t offset) {
    if (offset >= image_size_) return std::nullopt;
    if (image_size_ - offset >= 8) {
        const auto sig = read(offset, 8);
        if (std::equal(kPngSignature.begin(), kPngSignature.end(), sig.begin())) return png(offset);
        if (sig[0] == '%' && sig[1] == 'P' && sig[2] == 'D' && sig[3] == 'F' && sig[4] == '-') return pdf(offset);
        if (sig[0] == 0xFF && sig[1] == 0xD8 && sig[2] == 0xFF) return jpeg(offset);
        if (sig[0] == 'P' && sig[1] == 'K' && sig[2] == 3 && sig[3] == 4) return zip(offset);
    }
    return std::nullopt;
}

std::vector<CarvedFile> Carver::scan(std::uint64_t max_bytes) {
    const auto scan_end = max_bytes ? std::min(max_bytes, image_size_) : image_size_;
    std::vector<CarvedFile> result;
    constexpr std::size_t block_size = 1 << 18;
    for (std::uint64_t start = 0; start < scan_end;) {
        const auto step = static_cast<size_t>(std::min<std::uint64_t>(block_size, scan_end - start));
        const auto load = static_cast<size_t>(std::min<std::uint64_t>(step + 7, image_size_ - start));
        const auto buf = read(start, load);
        for (std::size_t i = 0; i < step && i + 8 <= buf.size(); ++i) {
            const auto p = buf.data() + i;
            if (p[0] != 137 && p[0] != '%' && p[0] != 0xFF && p[0] != 'P') continue;
            if (p[0] == 137 && !std::equal(kPngSignature.begin(), kPngSignature.end(), p)) continue;
            if (p[0] == '%' && !(p[1] == 'P' && p[2] == 'D' && p[3] == 'F' && p[4] == '-')) continue;
            if (p[0] == 0xFF && !(p[1] == 0xD8 && p[2] == 0xFF)) continue;
            if (p[0] == 'P' && !(p[1] == 'K' && p[2] == 3 && p[3] == 4)) continue;
            if (auto file = inspect(start + i)) result.push_back(*file);
            if (result.size() >= 100000) throw std::runtime_error("carving hit count exceeds limit");
        }
        start += step;
    }
    return result;
}

std::vector<std::uint8_t> Carver::preview(std::uint64_t offset) {
    const auto file = inspect(offset);
    if (!file) throw std::runtime_error("no verified carved file at offset");
    return read(offset,static_cast<std::size_t>(std::min<std::uint64_t>(256,file->size)));
}

std::filesystem::path Carver::extract(const CarvedFile& file, const std::filesystem::path& destination) {
    enforce_destination_separation(image_path_, destination);
    auto verified = inspect(file.offset);
    if (!verified || verified->size != file.size || verified->extension != file.extension)
        throw std::runtime_error("carved candidate failed revalidation");
    if (!std::filesystem::is_directory(destination))
        throw std::runtime_error("output directory must already exist");
    const auto output = destination / ("carved_" + std::to_string(file.offset) + "." + file.extension);
    ExclusiveOutput out(output);
    for (std::uint64_t p = 0; p < file.size;) {
        const auto n = static_cast<size_t>(std::min<std::uint64_t>(file.size - p, kReadChunk));
        const auto chunk = read(file.offset + p, n);
        out.write(chunk.data(), chunk.size());
        p += n;
    }
    out.finish();
    return output;
}

} // namespace ntfs

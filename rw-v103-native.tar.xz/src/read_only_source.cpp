#include "ntfs_recovery/read_only_source.hpp"
#include <algorithm>
#include <limits>
#include <stdexcept>
#include <string>
#ifdef _WIN32
#include <winioctl.h>
#include <vector>
#endif

namespace ntfs {
bool is_live_volume_name(const std::filesystem::path& path) noexcept {
#ifdef _WIN32
    const auto s = path.native();
    return s.size() == 6 && s[0] == L'\\' && s[1] == L'\\' && s[2] == L'.' &&
           s[3] == L'\\' && ((s[4] >= L'A' && s[4] <= L'Z') || (s[4] >= L'a' && s[4] <= L'z')) && s[5] == L':';
#else
    (void)path;
    return false;
#endif
}

#ifdef _WIN32
namespace {
std::runtime_error windows_error(const char* what) {
    return std::runtime_error(std::string(what) + " (Win32 " + std::to_string(GetLastError()) + ")");
}
std::wstring volume_root(const std::filesystem::path& name) {
    const auto s = name.native();
    return std::wstring(1,s[4]) + L":\\";
}
DWORD device_disk_number(const std::wstring& path) {
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                           nullptr, OPEN_EXISTING, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE) throw windows_error("cannot inspect volume disk extents");
    // Fail closed on Storage Spaces, spanned volumes, and unsupported providers.
    VOLUME_DISK_EXTENTS extents{};
    DWORD returned = 0;
    const BOOL ok = DeviceIoControl(h, IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, nullptr, 0,
                                    &extents, sizeof(extents), &returned, nullptr);
    CloseHandle(h);
    if (!ok || extents.NumberOfDiskExtents != 1)
        throw std::runtime_error("disk separation cannot be verified (multi-extent or unavailable)");
    return extents.Extents[0].DiskNumber;
}
void disallow_reparse_components(const std::filesystem::path& folder) {
    // Do not trust a junction/symlink that might redirect output to the source disk.
    const auto full = std::filesystem::absolute(folder);
    for (const auto& part : full.relative_path())
        if (part == L".." || part == L".")
            throw std::runtime_error("relative path traversal forbidden in live volume output");
    std::filesystem::path current = full.root_path();
    for (const auto& part : full.relative_path()) {
        current /= part;
        const DWORD attr = GetFileAttributesW(current.c_str());
        if (attr == INVALID_FILE_ATTRIBUTES) throw windows_error("output path is not accessible");
        if (attr & FILE_ATTRIBUTE_REPARSE_POINT)
            throw std::runtime_error("reparse points in output directory are not allowed for live volume recovery");
    }
}
} // namespace
#endif

void enforce_destination_separation(const std::filesystem::path& source,
                                    const std::filesystem::path& output_directory) {
    if (!is_live_volume_name(source)) return;
#ifdef _WIN32
    if (!std::filesystem::is_directory(output_directory))
        throw std::runtime_error("output directory must already exist");
    disallow_reparse_components(output_directory);
    const auto abs = std::filesystem::absolute(output_directory).native();
    if (abs.size() < 3 || abs[1] != L':' || abs[2] != L'\\')
        throw std::runtime_error("live recovery requires an existing local drive output directory");
    const std::wstring destination_volume = L"\\\\.\\" + abs.substr(0, 2);
    if (device_disk_number(source.native()) == device_disk_number(destination_volume))
        throw std::runtime_error("output is on the same physical disk as live source; choose another disk");
#else
    (void)output_directory;
    throw std::runtime_error("live volume input is Windows-only");
#endif
}

ReadOnlySource::ReadOnlySource(const std::filesystem::path& path) {
    live_ = is_live_volume_name(path);
#ifdef _WIN32
    if (live_) {
        device_ = CreateFileW(path.c_str(), GENERIC_READ,
                              FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                              nullptr, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, nullptr);
        if (device_ == INVALID_HANDLE_VALUE)
            throw windows_error("cannot open volume read-only (try running as administrator)");
        try {
            GET_LENGTH_INFORMATION length{};
            DWORD count = 0;
            if (!DeviceIoControl(device_, IOCTL_DISK_GET_LENGTH_INFO, nullptr, 0,
                                 &length, sizeof(length), &count, nullptr) || length.Length.QuadPart <= 0)
                throw windows_error("cannot determine volume size");
            size_ = static_cast<std::uint64_t>(length.Length.QuadPart);
            const auto root = volume_root(path);
            DWORD spc = 0, bps = 0, free_clusters = 0, total_clusters = 0;
            if (!GetDiskFreeSpaceW(root.c_str(), &spc, &bps, &free_clusters, &total_clusters) ||
                bps < 512 || bps > 4096 || (bps & (bps - 1)) != 0)
                throw windows_error("cannot determine volume sector alignment");
            sector_bytes_ = bps;
        } catch (...) {
            CloseHandle(device_);
            device_ = INVALID_HANDLE_VALUE;
            throw;
        }
        return;
    }
#endif
    if (!std::filesystem::is_regular_file(path))
        throw std::runtime_error("input must be a regular image or Windows volume device");
    size_ = std::filesystem::file_size(path);
    file_.open(path, std::ios::binary);
    if (!file_) throw std::runtime_error("cannot open input image read-only");
}
ReadOnlySource::~ReadOnlySource() {
#ifdef _WIN32
    if (device_ != INVALID_HANDLE_VALUE) CloseHandle(device_);
#endif
}
void ReadOnlySource::read_at(std::uint64_t offset, std::uint8_t* dest, std::size_t count) {
    if (offset > size_ || count > size_ - offset)
        throw std::runtime_error("read exceeds source bounds");
    if (count == 0) return;
#ifdef _WIN32
    if (live_) {
        // Volumes require sector-aligned reads. Copy the requested byte range
        // out of bounded, aligned chunks. All device access remains read-only.
        const std::uint64_t sector = sector_bytes_;
        std::uint64_t aligned = offset - offset % sector;
        const std::uint64_t finish = offset + count;
        std::size_t copied = 0;
        while (copied < count) {
            constexpr std::uint64_t kChunk = 1024 * 1024;
            const auto requested_end = std::min(finish, aligned + kChunk);
            const auto chunk_end = (requested_end + sector - 1) / sector * sector;
            if (chunk_end > size_) throw std::runtime_error("unaligned final device sector");
            const auto chunk_bytes = static_cast<DWORD>(chunk_end - aligned);
            std::vector<std::uint8_t> buf(chunk_bytes);
            LARGE_INTEGER pos{};
            pos.QuadPart = static_cast<LONGLONG>(aligned);
            if (!SetFilePointerEx(device_, pos, nullptr, FILE_BEGIN)) throw windows_error("volume seek failed");
            DWORD read_bytes = 0;
            if (!ReadFile(device_, buf.data(), chunk_bytes, &read_bytes, nullptr) || read_bytes != chunk_bytes)
                throw windows_error("live volume read failed (volume may be changing or inaccessible)");
            const auto begin = static_cast<std::size_t>(offset + copied - aligned);
            const auto n = std::min(count - copied, buf.size() - begin);
            std::copy_n(buf.data() + begin, n, dest + copied);
            copied += n;
            aligned = chunk_end;
        }
        return;
    }
#endif
    if (offset > static_cast<std::uint64_t>(std::numeric_limits<std::streamoff>::max()) ||
        count > static_cast<std::size_t>(std::numeric_limits<std::streamsize>::max()))
        throw std::runtime_error("image offset exceeds stream limits");
    file_.clear();
    file_.seekg(static_cast<std::streamoff>(offset));
    if (!file_ || !file_.read(reinterpret_cast<char*>(dest), static_cast<std::streamsize>(count)))
        throw std::runtime_error("image read failed");
}
} // namespace ntfs

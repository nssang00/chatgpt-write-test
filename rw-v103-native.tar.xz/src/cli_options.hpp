#pragma once

#include <cstddef>
#include <string_view>

namespace ntfs::cli {
// Arguments on Windows are UTF-16, including user-controlled paths. Comparing
// an optional ASCII flag must not attempt to decode an arbitrary path as ASCII.
template <typename Char>
bool matches_ascii_option(const Char* value, std::string_view ascii_option) noexcept {
    if (value == nullptr) return false;
    for (std::size_t i = 0; i < ascii_option.size(); ++i) {
        if (value[i] == Char{} || value[i] != static_cast<Char>(ascii_option[i]))
            return false;
    }
    return value[ascii_option.size()] == Char{};
}
} // namespace ntfs::cli

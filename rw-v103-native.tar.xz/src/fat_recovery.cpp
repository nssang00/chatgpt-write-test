#include "ntfs_recovery/fat_recovery.hpp"
#include "ntfs_recovery/exclusive_output.hpp"
#include "ntfs_recovery/partitions.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <unordered_set>
#include <stdexcept>
#include <string_view>

namespace ntfs {
namespace {
using Bytes = std::vector<std::uint8_t>;
std::uint64_t add(std::uint64_t a, std::uint64_t b) {
    if (b > UINT64_MAX - a) throw std::runtime_error("FAT arithmetic overflow");
    return a + b;
}
std::uint64_t mul(std::uint64_t a, std::uint64_t b) {
    if (a && b > UINT64_MAX / a) throw std::runtime_error("FAT arithmetic overflow");
    return a * b;
}
std::uint64_t le(const Bytes& b, std::size_t off, unsigned count) {
    if (count == 0 || count > 8 || off > b.size() || count > b.size() - off)
        throw std::runtime_error("truncated FAT metadata");
    std::uint64_t value = 0;
    for (unsigned n = 0; n < count; ++n) value |= static_cast<std::uint64_t>(b[off+n]) << (8*n);
    return value;
}
void put_utf8(std::string& out, std::uint32_t cp) {
    if (cp < 0x80) out.push_back(static_cast<char>(cp));
    else if (cp < 0x800) {
        out.push_back(static_cast<char>(0xc0 | (cp >> 6)));
        out.push_back(static_cast<char>(0x80 | (cp & 63)));
    } else if (cp < 0x10000) {
        out.push_back(static_cast<char>(0xe0 | (cp >> 12)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 63)));
        out.push_back(static_cast<char>(0x80 | (cp & 63)));
    } else {
        out.push_back(static_cast<char>(0xf0 | (cp >> 18)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 63)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 63)));
        out.push_back(static_cast<char>(0x80 | (cp & 63)));
    }
}
std::string utf16(const Bytes& units) {
    if (units.size() % 2) throw std::runtime_error("odd FAT UTF-16 byte count");
    std::string out;
    for (std::size_t i = 0; i < units.size(); i += 2) {
        std::uint32_t cp = static_cast<std::uint32_t>(le(units, i, 2));
        if (cp == 0) break;
        if (cp == 0xffff) continue;
        if (cp >= 0xd800 && cp <= 0xdbff) {
            if (i + 4 > units.size()) throw std::runtime_error("invalid FAT surrogate");
            const auto low = static_cast<std::uint32_t>(le(units, i+2, 2));
            if (low < 0xdc00 || low > 0xdfff) throw std::runtime_error("invalid FAT surrogate");
            cp = 0x10000 + ((cp - 0xd800) << 10) + (low - 0xdc00);
            i += 2;
        } else if (cp >= 0xdc00 && cp <= 0xdfff) throw std::runtime_error("invalid FAT surrogate");
        put_utf8(out, cp);
    }
    return out;
}
std::string safe_name(std::string_view name) {
    std::string result;
    for (std::size_t i=0; i<name.size();) {
        const auto c = static_cast<unsigned char>(name[i]);
        const auto width = c >= 0xf0 ? 4U : c >= 0xe0 ? 3U : c >= 0xc0 ? 2U : 1U;
        if (i + width > name.size() || result.size() + width > 120) break;
        if (width == 1 && (c < 32 || c == 127 || c == '/' || c == '\\' || c == ':' ||
                            c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|'))
            result += '_';
        else result.append(name.substr(i, width));
        i += width;
    }
    while (!result.empty() && (result.back() == '.' || result.back() == ' ')) result.pop_back();
    return result.empty() || result == "." || result == ".." ? "unnamed" : result;
}
std::string short_name(const Bytes& dir, std::size_t off, bool deleted) {
    std::string stem, ext;
    for (std::size_t i=0; i<8; ++i) {
        const auto c = dir[off+i];
        if (c == ' ') break;
        stem += static_cast<char>(deleted && i==0 ? '_' : (c==0x05 && i==0 ? 0xe5 : c));
    }
    for (std::size_t i=8; i<11; ++i) {
        if (dir[off+i] == ' ') break;
        ext += static_cast<char>(dir[off+i]);
    }
    return safe_name(stem + (ext.empty() ? "" : "." + ext));
}
Bytes lfn_fragment(const Bytes& dir, std::size_t off) {
    Bytes value;
    for (const auto& [start, count] : std::array<std::pair<std::size_t,std::size_t>,3>{{{1,5},{14,6},{28,2}}})
        for (std::size_t i=0; i<count; ++i) {
            value.push_back(dir[off+start+i*2]);
            value.push_back(dir[off+start+i*2+1]);
        }
    return value;
}
} // namespace

FatRecovery::FatRecovery(const std::filesystem::path& image,
                         std::optional<std::uint32_t> partition) : image_(image), partition_index_(partition), input_(image) {
    if (partition && input_.live()) throw std::runtime_error("live volumes cannot use partition indexes");
    volume_length_ = input_.size();
    if (partition) {
        const auto parts = list_partitions(image);
        const auto it = std::find_if(parts.begin(), parts.end(), [&](const auto& p){return p.index == *partition;});
        if (it == parts.end()) throw std::runtime_error("partition index not found");
        volume_offset_ = it->offset;
        volume_length_ = it->length;
    }
    if (volume_length_ < 512) throw std::runtime_error("FAT volume too small/unreadable");
    // exFAT stores a second, checksummed boot region at sector 12. If the
    // primary copy is damaged, accept ONLY a separately valid backup. Never
    // repair or modify either region in the input image.
    auto b = read(0, 512);
    const auto is_exfat = [](const Bytes& boot) {
        return boot.size() >= 512 && boot[510] == 0x55 && boot[511] == 0xaa &&
               std::string_view(reinterpret_cast<const char*>(boot.data() + 3), 8) == "EXFAT   ";
    };
    auto valid_boot_region = [&](std::uint64_t start, std::uint64_t sector_bytes) {
        if (start > volume_length_ || 12 * sector_bytes > volume_length_ - start) return false;
        const auto boot = read(start, 512);
        if (!is_exfat(boot) || (boot[0x6c] < 9 || boot[0x6c] > 12 || (std::uint64_t{1} << boot[0x6c]) != sector_bytes)) return false;
        const auto region = read(start, static_cast<std::size_t>(11 * sector_bytes));
        const auto checksum_sector = read(start + 11 * sector_bytes, static_cast<std::size_t>(sector_bytes));
        std::uint32_t checksum = 0;
        for (std::size_t i = 0; i < region.size(); ++i) {
            if (i == 106 || i == 107 || i == 112) continue;
            checksum = (checksum >> 1) | (checksum << 31);
            checksum += region[i];
        }
        for (std::size_t pos = 0; pos < checksum_sector.size(); pos += 4)
            if (le(checksum_sector, pos, 4) != checksum) return false;
        return true;
    };
    const bool primary_exfat = is_exfat(b);
    bool selected_exfat = false;
    if (primary_exfat && b[0x6c] >= 9 && b[0x6c] <= 12) {
        const auto sector_bytes = std::uint64_t{1} << b[0x6c];
        selected_exfat = valid_boot_region(0, sector_bytes);
    }
    // If the primary fails, verify the full checksum of the backup rather
    // than trusting an EXFAT magic string or unvalidated geometry fields.
    const bool looks_like_fat32 = le(b, 510, 2) == 0xaa55 &&
        std::string_view(reinterpret_cast<const char*>(b.data() + 82), 8) == "FAT32   ";
    if (!selected_exfat && !looks_like_fat32) {
        for (unsigned shift = 9; shift <= 12; ++shift) {
            const auto sector_bytes = std::uint64_t{1} << shift;
            const auto start = 12 * sector_bytes;
            if (valid_boot_region(start, sector_bytes)) {
                b = read(start, 512);
                selected_exfat = true;
                break;
            }
        }
    }
    if (primary_exfat && !selected_exfat)
        throw std::runtime_error("invalid primary and backup exFAT boot checksums");
    if (le(b, 510, 2) != 0xaa55)
        throw std::runtime_error("FAT boot signature missing");
    exfat_ = selected_exfat;
    if (exfat_) {
        const auto sector_shift = b[0x6c], cluster_shift = b[0x6d];
        if (sector_shift < 9 || sector_shift > 12 || cluster_shift > 16 ||
            sector_shift + cluster_shift > 21 || b[0x6e] < 1 || b[0x6e] > 2)
            throw std::runtime_error("unsupported exFAT geometry");
        sector_size_ = std::uint64_t{1} << sector_shift;
        cluster_size_ = std::uint64_t{1} << (sector_shift + cluster_shift);
        const auto sectors = le(b,0x48,8);
        volume_size_ = mul(sectors,sector_size_);
        fat_offset_ = mul(le(b,0x50,4),sector_size_);
        fat_bytes_ = mul(le(b,0x54,4),sector_size_);
        data_offset_ = mul(le(b,0x58,4),sector_size_);
        cluster_count_ = static_cast<std::uint32_t>(le(b,0x5c,4));
        root_cluster_ = static_cast<std::uint32_t>(le(b,0x60,4));
        const auto fats = b[0x6e];
        const auto active_fat = le(b,0x6a,2) & 1U;
        if (active_fat >= fats) throw std::runtime_error("invalid exFAT active FAT");
        fat_offset_ = add(fat_offset_,mul(active_fat,fat_bytes_));
        active_bitmap_id_ = static_cast<std::uint8_t>(active_fat);
    } else {
        sector_size_ = le(b,0x0b,2);
        const auto spc = b[0x0d];
        const auto reserved = le(b,0x0e,2);
        const auto fats = b[0x10];
        const auto fat_sectors = le(b,0x24,4);
        const auto total = le(b,0x20,4);
        const auto flags = le(b,0x28,2);
        const auto active_fat = (flags & 0x80) ? (flags & 0x0f) : 0;
        if ((sector_size_ != 512 && sector_size_ != 1024 && sector_size_ != 2048 && sector_size_ != 4096) ||
            spc == 0 || (spc & (spc - 1)) || spc > 128 ||
            reserved == 0 || fats == 0 || fats > 2 || fat_sectors == 0 || total == 0 ||
            le(b,0x11,2) != 0 || le(b,0x16,2) != 0 || le(b,0x2a,2) != 0 ||
            active_fat >= fats || std::string_view(reinterpret_cast<const char*>(b.data()+82),8) != "FAT32   ")
            throw std::runtime_error("unsupported FAT32 geometry");
        cluster_size_ = mul(sector_size_,spc);
        volume_size_ = mul(total,sector_size_);
        fat_bytes_ = mul(fat_sectors,sector_size_);
        fat_offset_ = mul(add(reserved,mul(active_fat,fat_sectors)),sector_size_);
        const auto data_sectors = add(reserved,mul(fats,fat_sectors));
        if (total <= data_sectors) throw std::runtime_error("FAT data region missing");
        data_offset_ = mul(data_sectors,sector_size_);
        cluster_count_ = static_cast<std::uint32_t>((total - data_sectors)/spc);
        root_cluster_ = static_cast<std::uint32_t>(le(b,0x2c,4));
    }
    if (volume_size_ > volume_length_ || volume_size_ < 16*sector_size_ ||
        cluster_count_ == 0 || cluster_count_ > 0xfffffff5U ||
        root_cluster_ < 2 || static_cast<std::uint64_t>(root_cluster_) >= static_cast<std::uint64_t>(cluster_count_)+2 ||
        fat_bytes_ < mul(static_cast<std::uint64_t>(cluster_count_)+2,4) ||
        add(fat_offset_,fat_bytes_) > volume_size_ ||
        data_offset_ < add(fat_offset_,fat_bytes_) ||
        add(data_offset_,mul(cluster_count_,cluster_size_)) > volume_size_ ||
        cluster_size_ > 2*1024*1024)
        throw std::runtime_error("invalid or out-of-bounds FAT layout");
}

std::string FatRecovery::filesystem_name() const { return exfat_ ? "exFAT" : "FAT32"; }

Bytes FatRecovery::read(std::uint64_t off, std::size_t size) {
    if (off > volume_length_ || size > volume_length_ - off ||
        off > static_cast<std::uint64_t>(std::numeric_limits<std::streamoff>::max()) ||
        size > static_cast<std::uint64_t>(std::numeric_limits<std::streamsize>::max()) ||
        add(volume_offset_, off) > static_cast<std::uint64_t>(std::numeric_limits<std::streamoff>::max()))
        throw std::runtime_error("FAT read outside image/partition");
    Bytes bytes(size);
    input_.read_at(add(volume_offset_,off), bytes.data(), size);
    return bytes;
}

std::uint32_t FatRecovery::fat_entry(std::uint32_t cluster) {
    if (cluster < 2 || static_cast<std::uint64_t>(cluster) >= static_cast<std::uint64_t>(cluster_count_)+2)
        throw std::runtime_error("invalid FAT cluster pointer");
    const auto off = add(fat_offset_,mul(cluster,4));
    if (off + 4 > add(fat_offset_,fat_bytes_)) throw std::runtime_error("FAT entry outside allocation table");
    const auto raw = static_cast<std::uint32_t>(le(read(off,4),0,4));
    return exfat_ ? raw : raw & 0x0fffffffU;
}

std::vector<std::uint32_t> FatRecovery::chain(std::uint32_t first, std::uint64_t bytes, bool contiguous) {
    if (bytes == 0) return {};
    const auto count = add(bytes,cluster_size_-1)/cluster_size_;
    if (count > cluster_count_ || count > 1000000)
        throw std::runtime_error("FAT cluster chain too large");
    if (first < 2 || static_cast<std::uint64_t>(first) >= static_cast<std::uint64_t>(cluster_count_)+2)
        throw std::runtime_error("invalid FAT first cluster");
    std::vector<std::uint32_t> result;
    std::unordered_set<std::uint32_t> seen;
    result.reserve(static_cast<std::size_t>(count));
    std::uint32_t next = first;
    for (std::uint64_t i=0; i<count; ++i) {
        if (next < 2 || static_cast<std::uint64_t>(next) >= static_cast<std::uint64_t>(cluster_count_)+2 ||
            !seen.insert(next).second)
            throw std::runtime_error("invalid/cyclic FAT chain");
        result.push_back(next);
        if (i+1 == count) break;
        if (contiguous) {
            if (next == UINT32_MAX) throw std::runtime_error("contiguous cluster overflow");
            ++next;
        } else {
            next = fat_entry(next);
        }
    }
    return result;
}

Bytes FatRecovery::directory(std::uint32_t first, bool contiguous, std::uint64_t bytes) {
    Bytes result;
    const auto max_dir = std::uint64_t{16}*1024*1024;
    if (bytes && bytes > max_dir) throw std::runtime_error("directory exceeds safe scan limit");
    if (bytes == 0 && contiguous) throw std::runtime_error("unknown contiguous directory size");
    auto cluster = first;
    const auto max_clusters = max_dir / cluster_size_;
    std::vector<std::uint32_t> seen;
    for (std::uint64_t i=0; i<max_clusters; ++i) {
        if (cluster < 2 || static_cast<std::uint64_t>(cluster) >= static_cast<std::uint64_t>(cluster_count_)+2 ||
            std::find(seen.begin(), seen.end(), cluster) != seen.end())
            throw std::runtime_error("invalid directory FAT chain");
        seen.push_back(cluster);
        auto part = read(add(data_offset_,mul(cluster-2,cluster_size_)),static_cast<std::size_t>(cluster_size_));
        result.insert(result.end(),part.begin(),part.end());
        if (bytes && result.size() >= bytes) { result.resize(static_cast<std::size_t>(bytes)); break; }
        if (contiguous) ++cluster;
        else {
            cluster = fat_entry(cluster);
            if (cluster >= (exfat_ ? 0xfffffff8U : 0x0ffffff8U)) break;
        }
    }
    if (result.empty() || (!bytes && result.size() >= max_dir))
        throw std::runtime_error("directory too large or unreadable");
    return result;
}

void FatRecovery::find_bitmap(const Bytes& root) {
    if (!exfat_) return;
    const auto min_bitmap_size = (static_cast<std::uint64_t>(cluster_count_)+7)/8;
    for (std::size_t p=0; p+32 <= root.size(); p+=32) {
        if (root[p] == 0) break;
        if (root[p] != 0x81) continue;
        if (root[p+1] != active_bitmap_id_) continue;
        const auto first = static_cast<std::uint32_t>(le(root,p+20,4));
        const auto size = le(root,p+24,8);
        if (size < min_bitmap_size || size > 64*1024*1024) continue;
        try {
            const auto clusters = chain(first, size, false);
            Bytes data;
            data.reserve(static_cast<std::size_t>(size));
            for (auto c : clusters) {
                auto chunk = read(add(data_offset_,mul(c-2,cluster_size_)),static_cast<std::size_t>(cluster_size_));
                const auto take = std::min<std::size_t>(static_cast<std::size_t>(size)-data.size(),chunk.size());
                data.insert(data.end(),chunk.begin(),chunk.begin()+static_cast<std::ptrdiff_t>(take));
            }
            bitmap_ = std::move(data);
            bitmap_found_ = true;
            return;
        } catch (const std::exception&) {
            // Fail closed: missing/broken bitmap prevents any extraction.
        }
    }
}

std::vector<std::uint32_t> FatRecovery::deleted_clusters(std::uint32_t first, std::uint64_t size,
                                                           bool contiguous, bool fat32) {
    if (!size) return {};
    const auto count = add(size,cluster_size_-1)/cluster_size_;
    if (!first || count > cluster_count_) return {};
    if (contiguous) return chain(first,size,true);
    if (fat32) {
        // FAT32 typically clears the FAT chain on deletion; a zero entry is
        // NEVER evidence of the original order. This is only a candidate.
        const auto first_fat = fat_entry(first);
        if (first_fat == 0) return chain(first,size,true);
    }
    return chain(first,size,false);
}

std::string FatRecovery::classify(const std::vector<std::uint32_t>& clusters, bool heuristic) const {
    if (exfat_ && !bitmap_found_) return "unknown-bitmap";
    for (auto c : clusters) {
        if (c < 2 || static_cast<std::uint64_t>(c) >= static_cast<std::uint64_t>(cluster_count_)+2)
            return "unsupported";
        if (exfat_) {
            const auto bit = c-2;
            if (bit/8 >= bitmap_.size()) return "unknown-bitmap";
            if (bitmap_[bit/8] & (1U << (bit%8))) return "reallocated";
        }
    }
    return heuristic ? "heuristic-contiguous" : "free-clusters";
}

void FatRecovery::visit(std::uint32_t first, bool contiguous, std::uint64_t size,
                        const std::string& path, unsigned depth) {
    if (depth > 16 || visited_dirs_.size() >= 4096) return;
    if (std::find(visited_dirs_.begin(),visited_dirs_.end(),first) != visited_dirs_.end()) return;
    visited_dirs_.push_back(first);
    const auto bytes = directory(first,contiguous,size);
    if (exfat_) {
        if (depth == 0) find_bitmap(bytes);
        for (std::size_t p=0; p+32<=bytes.size(); p+=32) {
            const auto kind = bytes[p];
            if (kind == 0) break;
            if (kind != 0x05 && kind != 0x85) continue;
            const bool deleted = kind == 0x05;
            const auto secondaries = bytes[p+1];
            if (secondaries < 2 || secondaries > 18 || secondaries > (bytes.size()-p)/32-1)
                continue;
            const auto stream = p+32;
            if (bytes[stream] != (deleted ? 0x40 : 0xc0)) continue;
            const auto name_length = bytes[stream+3];
            if (name_length == 0) continue;
            const auto name_entries = (static_cast<std::size_t>(name_length)+14)/15;
            if (name_entries+1 != secondaries) continue; // unknown critical secondary => skip
            Bytes utf16_bytes;
            for (std::size_t i=0; i<name_entries; ++i) {
                const auto np = stream+32*(i+1);
                if (bytes[np] != (deleted ? 0x41 : 0xc1)) { utf16_bytes.clear(); break; }
                for (std::size_t u=0; u<15; ++u) {
                    utf16_bytes.push_back(bytes[np+2+u*2]);
                    utf16_bytes.push_back(bytes[np+3+u*2]);
                }
            }
            if (utf16_bytes.size() < static_cast<std::size_t>(name_length)*2) continue;
            utf16_bytes.resize(static_cast<std::size_t>(name_length)*2);
            std::string name;
            try { name = safe_name(utf16(utf16_bytes)); } catch (const std::exception&) { continue; }
            const auto attr = le(bytes,p+4,2);
            const bool is_dir = (attr & 0x10) != 0;
            const bool no_fat_chain = (bytes[stream+1] & 0x02) != 0;
            const auto cluster = static_cast<std::uint32_t>(le(bytes,stream+20,4));
            const auto data_length = le(bytes,stream+24,8);
            const auto valid_length = le(bytes,stream+8,8);
            if (valid_length > data_length) continue;
            if (deleted && !is_dir) {
                Located candidate;
                candidate.info = {(static_cast<std::uint64_t>(first) << 32) | (p / 32), data_length,
                                  path + "/" + name, "unsupported"};
                candidate.cluster = cluster;
                candidate.contiguous = no_fat_chain;
                candidate.valid_data_bytes = valid_length;
                if (data_length == 0) candidate.info.status = bitmap_found_ ? "free-clusters" : "unknown-bitmap";
                else {
                    try {
                        candidate.chain = deleted_clusters(cluster,data_length,no_fat_chain,false);
                        if (!candidate.chain.empty()) candidate.info.status = classify(candidate.chain,false);
                    } catch (const std::exception&) { /* unsupported */ }
                }
                results_.push_back(std::move(candidate));
            } else if (!deleted && is_dir) {
                try { visit(cluster,no_fat_chain,data_length,path+"/"+name,depth+1); }
                catch (const std::exception&) { /* corrupted subtree ignored */ }
            }
            p += static_cast<std::size_t>(secondaries)*32;
        }
    } else {
        std::vector<Bytes> preceding_lfn;
        for (std::size_t p=0; p+32<=bytes.size(); p+=32) {
            const auto entry = bytes[p];
            if (entry == 0) break;
            const auto attrs = bytes[p+11];
            if (attrs == 0x0f && entry == 0xe5) {
                if (preceding_lfn.size() < 20) preceding_lfn.push_back(lfn_fragment(bytes,p));
                else preceding_lfn.clear();
                continue;
            }
            if (attrs == 0x0f || (attrs & 0x08) || entry == '.') { preceding_lfn.clear(); continue; }
            const bool deleted = entry == 0xe5;
            std::string name = short_name(bytes,p,deleted);
            if (deleted && !preceding_lfn.empty()) {
                Bytes lfns;
                for (auto it=preceding_lfn.rbegin(); it!=preceding_lfn.rend(); ++it)
                    lfns.insert(lfns.end(),it->begin(),it->end());
                try { const auto decoded = utf16(lfns); if (!decoded.empty()) name = safe_name(decoded); }
                catch (const std::exception&) { /* use 8.3 fallback */ }
            }
            preceding_lfn.clear();
            const bool is_dir = (attrs & 0x10) != 0;
            const auto cluster = static_cast<std::uint32_t>((le(bytes,p+20,2)<<16) | le(bytes,p+26,2));
            const auto data_length = le(bytes,p+28,4);
            if (deleted && !is_dir) {
                Located candidate;
                candidate.info = {(static_cast<std::uint64_t>(first) << 32) | (p / 32), data_length,
                                  path + "/" + name, "unsupported"};
                candidate.cluster = cluster;
                candidate.contiguous = true;
                candidate.valid_data_bytes = data_length;
                if (data_length == 0) candidate.info.status = "heuristic-contiguous";
                else {
                    try {
                        candidate.chain = deleted_clusters(cluster,data_length,false,true);
                        if (!candidate.chain.empty()) {
                            const bool guessed = fat_entry(cluster) == 0;
                            candidate.contiguous = guessed;
                            bool free = true;
                            for (auto c : candidate.chain) {
                                if (fat_entry(c) != 0) { free = false; break; }
                            }
                            candidate.info.status = !free ? "reallocated" : classify(candidate.chain,guessed);
                        }
                    } catch (const std::exception&) {
                        // An allocated first cluster is not safe, even when its
                        // claimed chain is damaged and cannot be followed.
                        try { if (fat_entry(cluster) != 0) candidate.info.status = "reallocated"; }
                        catch (const std::exception&) {}
                    }
                }
                results_.push_back(std::move(candidate));
            } else if (!deleted && is_dir && cluster >= 2) {
                try { visit(cluster,false,0,path+"/"+name,depth+1); }
                catch (const std::exception&) { /* corrupted subtree ignored */ }
            }
        }
    }
}

std::vector<FatCandidate> FatRecovery::scan() {
    results_.clear(); visited_dirs_.clear(); bitmap_.clear(); bitmap_found_=false;
    visit(root_cluster_,false,0,"",0);
    std::vector<FatCandidate> found;
    found.reserve(results_.size());
    for (const auto& entry : results_) found.push_back(entry.info);
    return found;
}

std::vector<std::uint8_t> FatRecovery::preview(std::uint64_t id) {
    // Never rely on a previously cached directory entry or bitmap. A preview is
    // still a data disclosure operation and must obey extract's safety policy.
    FatRecovery fresh(image_, partition_index_);
    fresh.scan();
    const auto it = std::find_if(fresh.results_.begin(),fresh.results_.end(),
                                 [&](const auto& e){return e.info.id == id;});
    if (it == fresh.results_.end()) throw std::runtime_error("deleted FAT entry not found");
    if (it->info.status != "free-clusters" && it->info.status != "heuristic-contiguous")
        throw std::runtime_error("FAT preview blocked: candidate is unsafe");
    const auto total = static_cast<std::size_t>(std::min<std::uint64_t>(it->info.size, 256));
    std::vector<std::uint8_t> out;
    out.reserve(total);
    std::uint64_t position = 0;
    for (const auto cluster : it->chain) {
        if (out.size() == total) break;
        const auto count = static_cast<std::size_t>(std::min<std::uint64_t>(total - out.size(),fresh.cluster_size_));
        const auto initialized = static_cast<std::size_t>(position < it->valid_data_bytes ?
            std::min<std::uint64_t>(count,it->valid_data_bytes-position) : 0);
        if (initialized) {
            auto chunk = fresh.read(add(fresh.data_offset_,mul(cluster-2,fresh.cluster_size_)),initialized);
            out.insert(out.end(),chunk.begin(),chunk.end());
        }
        out.insert(out.end(),count-initialized,0);
        position += count;
    }
    if (out.size() != total) throw std::runtime_error("FAT preview data truncated");
    return out;
}

std::filesystem::path FatRecovery::extract(std::uint64_t id, const std::filesystem::path& output_dir) {
    enforce_destination_separation(image_, output_dir);
    if (!std::filesystem::is_directory(output_dir)) throw std::runtime_error("output directory not found");
    // Recreate the parser to re-read all untrusted metadata, including the
    // bitmap/FAT, rather than trusting scan results after image modification.
    FatRecovery fresh(image_, partition_index_);
    fresh.scan();
    const auto it = std::find_if(fresh.results_.begin(),fresh.results_.end(),
                                 [&](const auto& e){return e.info.id == id;});
    if (it == fresh.results_.end()) throw std::runtime_error("deleted FAT entry not found");
    if (it->info.status != "free-clusters" && it->info.status != "heuristic-contiguous")
        throw std::runtime_error("FAT candidate is not safe to extract");
    // The result filename never includes any directory components.
    const std::string path = it->info.path;
    const auto slash = path.find_last_of('/');
    const auto name = safe_name(std::string_view(path).substr(slash == std::string::npos ? 0 : slash+1));
    const auto destination = output_dir / std::filesystem::path(std::u8string(name.begin(),name.end()));
    ExclusiveOutput file(destination);
    auto remaining = it->info.size;
    std::uint64_t written = 0;
    for (auto cluster : it->chain) {
        const auto count = static_cast<std::size_t>(std::min<std::uint64_t>(remaining,fresh.cluster_size_));
        Bytes bytes(count,0);
        const auto initialized = static_cast<std::size_t>(written < it->valid_data_bytes ?
            std::min<std::uint64_t>(count,it->valid_data_bytes-written) : 0);
        if (initialized) {
            const auto valid_bytes = fresh.read(add(fresh.data_offset_,mul(cluster-2,fresh.cluster_size_)),initialized);
            std::copy(valid_bytes.begin(),valid_bytes.end(),bytes.begin());
        }
        file.write(bytes.data(),bytes.size());
        remaining -= count;
        written += count;
    }
    if (remaining != 0) throw std::runtime_error("FAT file data truncated");
    file.finish();
    return destination;
}
} // namespace ntfs

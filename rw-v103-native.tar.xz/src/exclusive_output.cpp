#include "ntfs_recovery/exclusive_output.hpp"

#include <algorithm>
#include <cerrno>
#include <limits>
#include <random>
#include <cstdint>
#include <stdexcept>
#include <string>
#include <system_error>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

namespace ntfs {
namespace {
#ifdef _WIN32
std::system_error win_error(const char* operation) {
    return {static_cast<int>(GetLastError()), std::system_category(), operation};
}
#else
std::system_error posix_error(const char* operation) {
    return {errno, std::generic_category(), operation};
}
#endif
} // namespace

ExclusiveOutput::ExclusiveOutput(const std::filesystem::path& path) : path_(path) {
    // Create the staging file in the SAME directory as the final destination.
    // Even if a name collides with a hostile symlink or file, CREATE_NEW/O_EXCL
    // never follows or truncates it. Do not expose incomplete final results.
    std::random_device random;
    for (unsigned attempt = 0; attempt < 32; ++attempt) {
        const auto unique = (static_cast<std::uint64_t>(random()) << 32) | random();
        staging_path_ = path.parent_path() / (".ntfsrecover-" + std::to_string(unique) + ".part");
#ifdef _WIN32
        HANDLE handle = CreateFileW(staging_path_.c_str(), GENERIC_WRITE, 0,
                                    nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (handle != INVALID_HANDLE_VALUE) { handle_ = handle; return; }
        if (GetLastError() != ERROR_FILE_EXISTS && GetLastError() != ERROR_ALREADY_EXISTS)
            throw win_error("cannot create temporary output file");
#else
        int flags = O_WRONLY | O_CREAT | O_EXCL;
#ifdef O_CLOEXEC
        flags |= O_CLOEXEC;
#endif
#ifdef O_NOFOLLOW
        flags |= O_NOFOLLOW;
#endif
        fd_ = ::open(staging_path_.c_str(), flags, 0600);
        if (fd_ >= 0) return;
        if (errno != EEXIST) throw posix_error("cannot create temporary output file");
#endif
    }
    throw std::runtime_error("could not reserve a unique output staging file");
}

ExclusiveOutput::~ExclusiveOutput() noexcept {
#ifdef _WIN32
    if (handle_ != nullptr) CloseHandle(static_cast<HANDLE>(handle_));
#else
    if (fd_ >= 0) ::close(fd_);
#endif
    // A crashed process may leave an orphan .part file, but NOT a misleading
    // truncated final result. Remove only the staging path owned by this object.
    if (!staging_path_.empty()) {
        std::error_code ec;
        std::filesystem::remove(staging_path_, ec);
    }
}

void ExclusiveOutput::write(const std::uint8_t* data, std::size_t size) {
    while (size) {
#ifdef _WIN32
        auto amount = static_cast<DWORD>(std::min<std::size_t>(size, std::numeric_limits<DWORD>::max()));
        DWORD written = 0;
        if (!WriteFile(static_cast<HANDLE>(handle_), data, amount, &written, nullptr))
            throw win_error("output write failed");
#else
        // Bound each request to a size accepted by write(2).
        const auto amount = std::min<std::size_t>(size, static_cast<std::size_t>(std::numeric_limits<ssize_t>::max()));
        const auto n = ::write(fd_, data, amount);
        if (n < 0 && errno == EINTR) continue;
        if (n < 0) throw posix_error("output write failed");
        const auto written = static_cast<std::size_t>(n);
#endif
        if (written == 0) throw std::runtime_error("output write made no progress");
        data += written;
        size -= written;
    }
}

void ExclusiveOutput::finish() { finish_verified({}); }

void ExclusiveOutput::finish_verified(
    const std::function<void(const std::filesystem::path&)>& validator) {
#ifdef _WIN32
    if (!FlushFileBuffers(static_cast<HANDLE>(handle_))) throw win_error("output flush failed");
    if (!CloseHandle(static_cast<HANDLE>(handle_))) throw win_error("output close failed");
    handle_ = nullptr;
#else
    if (::fsync(fd_) != 0) throw posix_error("output flush failed");
    if (::close(fd_) != 0) {
        fd_ = -1;
        throw posix_error("output close failed");
    }
    fd_ = -1;
#endif
    if (validator) validator(staging_path_);
    // Publish only after successfully syncing/closing the complete payload.
#ifdef _WIN32
    // Deliberately omit MOVEFILE_REPLACE_EXISTING: concurrent publishers and
    // pre-existing files/symlinks must fail instead of being overwritten.
    if (!MoveFileExW(staging_path_.c_str(), path_.c_str(), MOVEFILE_WRITE_THROUGH))
        throw win_error("cannot exclusively publish recovered file");
#else
    // link(2) is an atomic no-clobber publish on the same filesystem.
    if (::link(staging_path_.c_str(), path_.c_str()) != 0)
        throw posix_error("cannot exclusively publish recovered file");
    // Failure to remove a staging name after publishing is not a data loss.
    (void)::unlink(staging_path_.c_str());
#endif
    staging_path_.clear();
    finished_ = true;
}
} // namespace ntfs

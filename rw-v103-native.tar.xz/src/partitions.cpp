#include "ntfs_recovery/partitions.hpp"

#include <algorithm>
#include <array>
#include <fstream>
#include <limits>
#include <set>
#include <string_view>
#include <stdexcept>
#include <vector>

namespace ntfs {
namespace {
using Bytes = std::vector<std::uint8_t>;

std::uint64_t add(std::uint64_t a, std::uint64_t b) {
    if (b > UINT64_MAX - a) throw std::runtime_error("partition arithmetic overflow");
    return a + b;
}
std::uint64_t mul(std::uint64_t a, std::uint64_t b) {
    if (a && b > UINT64_MAX / a) throw std::runtime_error("partition arithmetic overflow");
    return a * b;
}
std::uint64_t le(const Bytes& b, std::size_t p, unsigned n) {
    if (p > b.size() || n > 8 || n > b.size() - p) throw std::runtime_error("truncated partition metadata");
    std::uint64_t v = 0;
    for (unsigned i = 0; i < n; ++i) v |= static_cast<std::uint64_t>(b[p + i]) << (i * 8);
    return v;
}
std::uint32_t crc32(const Bytes& b, std::size_t length) {
    std::uint32_t crc = 0xffffffffU;
    for (std::size_t i = 0; i < length; ++i) {
        crc ^= b[i];
        for (int j = 0; j < 8; ++j) crc = (crc >> 1) ^ ((crc & 1) ? 0xedb88320U : 0U);
    }
    return crc ^ 0xffffffffU;
}
struct Image {
    std::ifstream stream;
    std::uint64_t size;
    explicit Image(const std::filesystem::path& path) : size(0) {
        if (!std::filesystem::is_regular_file(path)) throw std::runtime_error("image must be a regular file");
        size = std::filesystem::file_size(path);
        stream.open(path, std::ios::binary);
        if (!stream) throw std::runtime_error("cannot read partition image");
    }
    Bytes read(std::uint64_t off, std::uint64_t length) {
        if (off > size || length > size - off ||
            off > static_cast<std::uint64_t>(std::numeric_limits<std::streamoff>::max()) ||
            length > static_cast<std::uint64_t>(std::numeric_limits<std::streamsize>::max()))
            throw std::runtime_error("partition metadata outside image");
        Bytes bytes(static_cast<std::size_t>(length));
        stream.clear();
        stream.seekg(static_cast<std::streamoff>(off));
        if (!stream || !stream.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(length)))
            throw std::runtime_error("cannot read partition metadata");
        return bytes;
    }
};
void ensure_nonoverlap(std::vector<Partition>& result) {
    std::vector<Partition> sorted = result;
    std::sort(sorted.begin(), sorted.end(), [](const auto& a, const auto& b) { return a.offset < b.offset; });
    for (std::size_t i = 1; i < sorted.size(); ++i) {
        if (sorted[i].offset < add(sorted[i-1].offset, sorted[i-1].length))
            throw std::runtime_error("overlapping partition table entries");
    }
}
std::vector<Partition> gpt(Image& image, std::uint64_t sector_bytes, bool backup = false) {
    if (image.size < mul(sector_bytes, 4) || image.size % sector_bytes)
        throw std::runtime_error("truncated/unaligned GPT image");
    const auto last_lba = image.size / sector_bytes - 1;
    const auto header_lba = backup ? last_lba : 1;
    auto header = image.read(mul(header_lba,sector_bytes), sector_bytes);
    if (std::string_view(reinterpret_cast<const char*>(header.data()), 8) != "EFI PART")
        throw std::runtime_error("missing primary GPT header");
    const auto header_size = le(header, 12, 4);
    if (le(header, 8, 4) != 0x00010000 || header_size < 92 || header_size > sector_bytes ||
        le(header, 20, 4) || le(header, 24, 8) != header_lba)
        throw std::runtime_error("invalid GPT header");
    const auto original_crc = le(header, 16, 4);
    for (std::size_t i = 16; i < 20; ++i) header[i] = 0;
    if (crc32(header, static_cast<std::size_t>(header_size)) != original_crc)
        throw std::runtime_error("GPT header checksum mismatch");
    const auto backup_lba = le(header, 32, 8);
    const auto usable_start = le(header, 40, 8);
    const auto usable_end = le(header, 48, 8);
    if (backup_lba != (backup ? 1 : last_lba) || usable_start < 2 ||
        usable_end < usable_start || usable_end >= last_lba)
        throw std::runtime_error("invalid GPT usable range");
    const auto entries_lba = le(header, 72, 8);
    const auto count = le(header, 80, 4);
    const auto entry_size = le(header, 84, 4);
    if (count == 0 || count > 131072 || entry_size < 128 || entry_size > 4096 || entry_size % 8)
        throw std::runtime_error("unsupported GPT entries");
    const auto table_size = mul(count, entry_size);
    if (table_size > 16 * 1024 * 1024) throw std::runtime_error("GPT entry table too large");
    const auto table_start = mul(entries_lba, sector_bytes);
    const auto table_end = add(table_start, table_size);
    const auto table_after = add(entries_lba, (table_size + sector_bytes - 1) / sector_bytes);
    if (entries_lba <= 1 || table_end > image.size ||
        (backup ? (entries_lba <= usable_end || table_after > last_lba)
                : (table_after > usable_start)))
        throw std::runtime_error("GPT entry table outside safe region");
    const auto table = image.read(table_start, table_size);
    if (crc32(table, table.size()) != le(header, 88, 4))
        throw std::runtime_error("GPT entry table checksum mismatch");
    std::vector<Partition> result;
    for (std::uint64_t i = 0; i < count; ++i) {
        const auto off = static_cast<std::size_t>(i * entry_size);
        if (std::all_of(table.begin() + static_cast<std::ptrdiff_t>(off),
                        table.begin() + static_cast<std::ptrdiff_t>(off + 16),
                        [](std::uint8_t b) { return b == 0; })) continue;
        const auto first = le(table, off + 32, 8);
        const auto last = le(table, off + 40, 8);
        if (first < usable_start || last > usable_end || first > last)
            throw std::runtime_error("GPT partition outside usable range");
        result.push_back({static_cast<std::uint32_t>(i + 1), backup ? "GPT-backup" : "GPT", mul(first, sector_bytes),
                          mul(add(last - first, 1), sector_bytes)});
    }
    ensure_nonoverlap(result);
    return result;
}
} // namespace

namespace {
bool is_extended(std::uint64_t type) { return type == 0x05 || type == 0x0f || type == 0x85; }

void logical_mbr(Image& image, std::uint64_t base_lba, std::uint64_t length_lba,
                 std::vector<Partition>& result) {
    constexpr std::uint64_t sector_bytes = 512;
    const auto extended_end = add(base_lba, length_lba);
    std::uint64_t current = base_lba;
    std::set<std::uint64_t> visited;
    for (std::uint32_t index = 5; index < 133; ++index) {
        if (current < base_lba || current >= extended_end || !visited.insert(current).second)
            throw std::runtime_error("invalid/cyclic EBR chain");
        // An EBR header must not be embedded in a previously declared data
        // partition, even if the later logical data ranges do not overlap.
        const auto ebr_offset = mul(current, sector_bytes);
        for (const auto& entry : result) {
            if (ebr_offset >= entry.offset && ebr_offset < add(entry.offset, entry.length))
                throw std::runtime_error("EBR header overlaps data partition");
        }
        const auto sector = image.read(ebr_offset, sector_bytes);
        if (le(sector, 510, 2) != 0xaa55) throw std::runtime_error("bad EBR signature");
        const auto type = le(sector, 450, 1);
        const auto rel_lba = le(sector, 454, 4);
        const auto sectors = le(sector, 458, 4);
        if (type == 0 || is_extended(type) || rel_lba == 0 || sectors == 0)
            throw std::runtime_error("invalid logical MBR partition");
        const auto first = add(current, rel_lba);
        if (first < base_lba || first >= extended_end || sectors > extended_end - first)
            throw std::runtime_error("logical partition outside extended container");
        const auto next_type = le(sector, 466, 1);
        const auto next_rel = le(sector, 470, 4);
        const auto next_count = le(sector, 474, 4);
        if (next_type && (!is_extended(next_type) || next_rel == 0 || next_count == 0))
            throw std::runtime_error("invalid EBR next link");
        if (!next_type && (next_rel || next_count))
            throw std::runtime_error("invalid empty EBR link");
        // The EBR itself must not fall inside a referenced data partition.
        result.push_back({index, "MBR-logical", mul(first, sector_bytes), mul(sectors, sector_bytes)});
        if (!next_type) return;
        current = add(base_lba, next_rel);
    }
    throw std::runtime_error("EBR chain exceeds safety limit");
}
} // namespace

std::vector<Partition> list_partitions(const std::filesystem::path& path) {
    Image image(path);
    if (image.size < 512) throw std::runtime_error("partition image too small");
    const auto mbr = image.read(0, 512);
    if (le(mbr, 510, 2) != 0xaa55) throw std::runtime_error("missing MBR signature");
    std::vector<Partition> result;
    bool protective = false;
    std::uint64_t extended_lba = 0, extended_length = 0;
    for (std::uint32_t i = 0; i < 4; ++i) {
        const auto p = 446U + 16U * i;
        const auto type = le(mbr, p + 4, 1);
        const auto lba = le(mbr, p + 8, 4);
        const auto count = le(mbr, p + 12, 4);
        if (type == 0xee) protective = true;
        if (type == 0 && count == 0 && lba == 0) continue;
        if (type == 0 || count == 0) throw std::runtime_error("inconsistent MBR partition entry");
        if (lba == 0) throw std::runtime_error("invalid MBR partition starting LBA");
        const auto offset = mul(lba, 512);
        const auto length = mul(count, 512);
        if (offset > image.size || length > image.size - offset)
            throw std::runtime_error("MBR partition outside image");
        if (is_extended(type)) {
            if (extended_length != 0) throw std::runtime_error("multiple extended MBR containers");
            extended_lba = lba;
            extended_length = count;
        } else {
            result.push_back({i + 1, "MBR", offset, length});
        }
    }
    if (protective) {
        // A corrupt primary header is common after some partition-table loss.
        // Recovery is allowed ONLY from a fully CRC-validated backup header AND
        // backup entry array at the end of the regular-file image. Never guess
        // partition ranges using corrupted metadata.
        const bool appears_4kn = image.size >= 8192 &&
            std::string_view(reinterpret_cast<const char*>(image.read(4096, 8).data()),8) == "EFI PART";
        try { return gpt(image, appears_4kn ? 4096 : 512); }
        catch (const std::exception&) {
            try { return gpt(image, appears_4kn ? 4096 : 512,true); }
            catch (const std::exception&) {
                if (!appears_4kn && image.size % 4096 == 0)
                    return gpt(image,4096,true);
                throw std::runtime_error("GPT primary and backup metadata are both invalid");
            }
        }
    }
    if (extended_length) {
        const auto base = mul(extended_lba, 512);
        const auto end = add(base, mul(extended_length, 512));
        for (const auto& entry : result) {
            if (entry.offset < end && base < add(entry.offset, entry.length))
                throw std::runtime_error("extended MBR overlaps a primary partition");
        }
        logical_mbr(image, extended_lba, extended_length, result);
    }
    ensure_nonoverlap(result);
    return result;
}
} // namespace ntfs

# KiteFiles 2.0 — ES Lite workflow-inspired file manager

An original Android Java file manager with full shared-storage navigation, swipeable independent folder tabs, SMB2+ LAN shares and local ⇄ network file operations. Based on a static feature-map inspection of the user-supplied ES Lite APK; no original ES code or design assets are included.

## Main flows

1. On Home tap **내부 저장소**, grant Android **모든 파일 접근** in Settings, return to the app. Traverse shared folders directly. `Android/data`, other apps' private directories and OS-protected paths remain inaccessible.
2. Open additional locations with **+ 새 창** or add another local/SAF/SMB tab. Swipe left or right across the file-list region to switch between adjacent open tabs. Long-press a tab to close it.
3. **네트워크 · LAN / SMB2/3**: enter server IP/DNS hostname, share name, optional Windows domain, username and password. Connection is verified by listing the share before the tab opens. Credentials are never persisted; a new connection is needed after process restart. SMB1 is disabled.
4. Long press files for multi-selection; copy/cut, switch to the destination tab, paste. Move checks copied bytes before removing originals. ZIP/search/share/open/rename/delete/folder creation work through a shared file-store interface.

## Build

Use Android SDK 35, JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2:

```sh
gradle --no-daemon :app:assembleDebug
```

Test core + real disk storage:

```sh
LANG=C.UTF-8 LC_ALL=C.UTF-8 ./tests/local-store.sh
```

## Honest limitations

- **Not an identical copy of ES**. This release prioritizes the three user-reported missing flows; ES multimedia UI, cloud drives, LAN discovery, FTP, tab animations, themes, archive formats beyond ZIP are not yet reproduced.
- SMB2/3 is provided by `jcifs-ng 2.1.10` under LGPL. A **successful Android APK build alone does not establish successful connection to a real NAS**. Network integration depends on server authentication and dialect settings; VPN/LAN reachability is required.
- The app uses the high-risk `MANAGE_EXTERNAL_STORAGE` permission only as a file manager. Google Play requires a permissions declaration and approval for publication.
- The APK is debug-signed, not suitable for production release. Android storage and SMB behavior should be tested on a device and a reachable share.

See `docs/ES_LITE_APK_ANALYSIS.md` for findings from the uploaded APK, without redistributing it.

# ES File Explorer Lite APK — static structure audit

Input: user-supplied `es-lite-v15175-all-languages-dead-resource-clean.apk` (26,928,740 bytes). Inspected from its ZIP table and Android binary XML manifest/string pool; not executed in an Android device, and no ES bytecode/assets have been copied into KiteFiles.

## Facts actually present in the supplied APK

- Package `com.estrongs.android.poe`; APK `versionCode=15175`, `versionName=4.4.0.2.1` (the filename contains `v15175`, not a semantic version).
- `minSdkVersion=19`, `targetSdkVersion=27`. That is a legacy Android storage model, **not** compatible by itself with today's targetSdk 35 all-files behavior.
- Declares `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `READ_EXTERNAL_STORAGE`, and `WRITE_EXTERNAL_STORAGE` among its permissions.
- Contains 737 `res/layout/` entries and 52 `res/xml/` entries; observable feature-specific layouts include `port_multiwindow_pager`, `multiwindow_pager`, `window_history_page`, `window_addressbar`, `new_smb_server`, `my_network_page`, `new_ftp_server`, `new_oauth_netdisk`, `archive_extract_edit_dialog`, and `homepage_favorite_grid`.
- `FileExplorerActivity` is a launchable Activity.

**Interpretation**: this provides direct evidence for multiwindow/tab navigation, address/path UI, history, LAN server setup, FTP, network drive screens, favorites and archives. Layout filenames and manifest alone do not prove runtime functionality or exact touch gestures; those require execution against a real or emulated device and network server.

## Reimplementation priorities

- P0: traverse shared device storage with an explicit `MANAGE_EXTERNAL_STORAGE` permission flow (still subject to Android/data/obb OS restrictions).
- P0: multiple independent folder tabs, close/open windows and horizontal swipe between tabs.
- P0: SMB2/3 authenticated share browsing with credentials in process memory; copy in both directions by unified FileStore interface.
- P1: ZIP, search, multi-select, file open/share, SAF-selected providers, sort.
- Future: FTP/FTPS, SFTP, WebDAV, thumbnail/cache manager, richer ES home dashboard, theme variants, LAN discovery and file transfer queue.

## Scope and ownership

The application is an original, independently written implementation of comparable file-management interactions. It does not use ES package name, icons, bundled resources, or disassembled implementation.

## Outstanding verification

Static APK inspection does not include original app screenshots or behavior measurement. Automated Linux/JVM checks and Android builds are separate. SMB must also be tested against a live Windows/NAS share before making any compatibility guarantees.

package com.kitefiles.android;

import com.kitefiles.core.FileNode;
import com.kitefiles.core.FileStore;
import android.content.Context;
import android.net.Uri;
import java.io.*;
import java.util.*;

/** One FileStore contract for local file, SAF document and SMB share. Cross-store transfers use FileEngine. */
public final class UnifiedStore implements FileStore {
    private final LocalFileStore local;
    private final Map<String, DocumentStore> trees = new HashMap<>();
    private final Map<String, SmbFileStore> shares = new HashMap<>();
    private final Context app;
    public UnifiedStore(Context context, LocalFileStore local) { this.app = context.getApplicationContext(); this.local = local; }
    public String localRoot(int i) { return local.root(i); }
    public int localRootCount() { return local.rootCount(); }
    public String registerDocument(String tree) {
        DocumentStore doc = new DocumentStore(app, Uri.parse(tree));
        trees.put(tree,doc); return doc.root();
    }
    public void registerSmb(SmbFileStore remote) { shares.put(remote.root(),remote); }
    private FileStore delegate(String id) {
        if (id.startsWith("file:/")) return local;
        if (id.startsWith("smb://")) {
            for (Map.Entry<String,SmbFileStore> e : shares.entrySet()) if (id.startsWith(e.getKey())) return e.getValue();
        }
        if (id.startsWith("content://")) {
            for (Map.Entry<String,DocumentStore> e : trees.entrySet()) if (id.startsWith(e.getKey()+"/document/")) return e.getValue();
        }
        throw new SecurityException("연결된 저장소가 없습니다: " + id);
    }
    @Override public FileNode stat(String id) throws Exception { return delegate(id).stat(id); }
    @Override public List<FileNode> list(String id) throws Exception { return delegate(id).list(id); }
    @Override public FileNode mkdir(String id,String name) throws Exception { return delegate(id).mkdir(id,name); }
    @Override public FileNode mkfile(String id,String name,String mime) throws Exception { return delegate(id).mkfile(id,name,mime); }
    @Override public InputStream read(String id) throws Exception { return delegate(id).read(id); }
    @Override public OutputStream write(String id) throws Exception { return delegate(id).write(id); }
    @Override public void delete(String id) throws Exception { delegate(id).delete(id); }
    @Override public FileNode rename(String id,String name) throws Exception { return delegate(id).rename(id,name); }
}

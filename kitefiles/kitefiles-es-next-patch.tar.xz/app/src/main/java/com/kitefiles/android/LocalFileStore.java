package com.kitefiles.android;

import com.kitefiles.core.FileEngine;
import com.kitefiles.core.FileNode;
import com.kitefiles.core.FileStore;
import java.io.*;
import java.net.URI;
import java.util.*;

/** Shared-storage paths, not app-private /data. Canonical checks prevent symlink escape. */
public final class LocalFileStore implements FileStore {
    private final List<File> roots;
    public LocalFileStore(List<File> sharedRoots) throws IOException {
        roots = new ArrayList<>();
        for (File root : sharedRoots) if (root != null) {
            File canonical = root.getCanonicalFile();
            if (!roots.contains(canonical)) roots.add(canonical);
        }
    }
    public String root(int index) { return roots.get(index).toURI().toString(); }
    public int rootCount() { return roots.size(); }
    public String rootName(int index) { return roots.get(index).getName(); }
    private File resolve(String id) throws IOException {
        if (!id.startsWith("file:/")) throw new SecurityException("올바르지 않은 로컬 주소입니다.");
        final File candidate;
        try { candidate = new File(URI.create(id)).getCanonicalFile(); }
        catch (IllegalArgumentException e) { throw new IOException("경로 형식 오류", e); }
        String path = candidate.getPath();
        for (File base : roots) {
            String basePath = base.getPath();
            if (path.equals(basePath) || path.startsWith(basePath + File.separator)) return candidate;
        }
        throw new SecurityException("선택한 공유 저장소 바깥에는 접근할 수 없습니다.");
    }
    private FileNode node(File file) throws IOException {
        if (!file.exists()) throw new FileNotFoundException(file.getAbsolutePath());
        String name = file.getName();
        if (name.isEmpty()) name = "저장소";
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot >= 0 && dot < name.length()-1) ext = name.substring(dot+1).toLowerCase(Locale.ROOT);
        String mime = file.isDirectory() ? "vnd.android.document/directory" : FileEngine.mimeOf(name);
        if (mime == null) mime = "application/octet-stream";
        return new FileNode(file.toURI().toString(), name, file.isDirectory(), mime, file.isDirectory() ? -1 : file.length(), file.lastModified());
    }
    @Override public FileNode stat(String id) throws Exception { return node(resolve(id)); }
    @Override public List<FileNode> list(String id) throws Exception {
        File folder = resolve(id);
        if (!folder.isDirectory()) throw new IOException("폴더가 아닙니다.");
        File[] files = folder.listFiles();
        if (files == null) throw new IOException("저장소 접근 권한을 확인하세요.");
        List<FileNode> result = new ArrayList<>();
        for (File f : files) { try { result.add(node(resolve(f.toURI().toString()))); } catch (SecurityException ignored) { } }
        return result;
    }
    @Override public FileNode mkdir(String parent, String name) throws Exception {
        FileEngine.validateName(name);
        File file = resolve(new File(resolve(parent), name).toURI().toString());
        if (!file.mkdir()) throw new IOException("폴더를 생성할 수 없습니다.");
        return node(file);
    }
    @Override public FileNode mkfile(String parent, String name, String mime) throws Exception {
        FileEngine.validateName(name);
        File file = resolve(new File(resolve(parent), name).toURI().toString());
        if (!file.createNewFile()) throw new IOException("파일을 생성할 수 없습니다.");
        return node(file);
    }
    @Override public InputStream read(String id) throws Exception { return new FileInputStream(resolve(id)); }
    @Override public OutputStream write(String id) throws Exception { return new FileOutputStream(resolve(id), false); }
    @Override public void delete(String id) throws Exception {
        File target=resolve(id);
        if (roots.contains(target)) throw new SecurityException("공유 저장소 루트는 삭제할 수 없습니다.");
        recursiveDelete(target, 0);
    }
    private void recursiveDelete(File file, int depth) throws Exception {
        if (depth > FileEngine.MAX_DEPTH) throw new IOException("폴더 깊이 제한 초과");
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children == null) throw new IOException("폴더를 읽을 수 없습니다.");
            for (File f : children) recursiveDelete(resolve(f.toURI().toString()), depth + 1);
        }
        if (!file.delete()) throw new IOException("파일을 삭제할 수 없습니다: " + file.getName());
    }
    @Override public FileNode rename(String id, String name) throws Exception {
        FileEngine.validateName(name);
        File src = resolve(id), target = resolve(new File(src.getParentFile(), name).toURI().toString());
        if (roots.contains(src)) throw new SecurityException("공유 저장소 루트는 이름 변경할 수 없습니다.");
        if (target.exists()) throw new IOException("같은 이름이 이미 있습니다.");
        if (!src.renameTo(target)) throw new IOException("이름 변경에 실패했습니다.");
        return node(target);
    }
}

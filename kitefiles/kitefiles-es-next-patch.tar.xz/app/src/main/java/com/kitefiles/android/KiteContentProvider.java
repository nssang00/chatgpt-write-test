package com.kitefiles.android;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.provider.OpenableColumns;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/** Read-only temporary file-sharing bridge for local files and cached SMB downloads. */
public final class KiteContentProvider extends ContentProvider {
    public static Uri uriFor(String path) { return new Uri.Builder().scheme("content").authority("com.kitefiles.android.files").appendPath(path).build(); }
    @Override public boolean onCreate() { return true; }
    private File safeFile(Uri uri) throws FileNotFoundException {
        if (uri.getPathSegments().size()!=1) throw new FileNotFoundException("Bad URI");
        String path = uri.getPathSegments().get(0);
        try {
            File target = new File(path).getCanonicalFile();
            File shared = android.os.Environment.getExternalStorageDirectory().getCanonicalFile();
            File cache = getContext().getCacheDir().getCanonicalFile();
            String p=target.getPath();
            if ((!p.startsWith(shared.getPath()+File.separator) && !p.startsWith(cache.getPath()+File.separator)) || !target.isFile())
                throw new FileNotFoundException("Not an allowed regular file");
            return target;
        } catch(IOException e) { throw new FileNotFoundException(e.getMessage()); }
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("Read-only provider");
        return ParcelFileDescriptor.open(safeFile(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public String getType(Uri uri) {
        try { String name=safeFile(uri).getName(); int i=name.lastIndexOf('.');
            String mime=i<0?null:MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(i+1).toLowerCase(java.util.Locale.ROOT));
            return mime==null?"application/octet-stream":mime;
        } catch(Exception e) { return "application/octet-stream"; }
    }
    @Override public Cursor query(Uri uri,String[] proj,String selection,String[] args,String order) {
        try {
            File f=safeFile(uri);
            if(proj==null)proj=new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE};
            MatrixCursor cursor=new MatrixCursor(proj);
            Object[] values=new Object[proj.length];
            for(int i=0;i<proj.length;i++) {
                if(OpenableColumns.DISPLAY_NAME.equals(proj[i]))values[i]=f.getName();
                else if(OpenableColumns.SIZE.equals(proj[i])) values[i]=f.length();
            }
            cursor.addRow(values);return cursor;
        } catch(Exception e){return null;}
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri,String selection,String[] args) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri,ContentValues values,String selection,String[] args) { throw new UnsupportedOperationException(); }
}

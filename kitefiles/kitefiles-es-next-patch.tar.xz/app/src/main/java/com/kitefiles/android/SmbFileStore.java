package com.kitefiles.android;

import com.kitefiles.core.FileEngine;
import com.kitefiles.core.FileNode;
import com.kitefiles.core.FileStore;
import java.io.*;
import java.net.URLEncoder;
import java.util.*;
import jcifs.CIFSContext;
import jcifs.context.BaseContext;
import jcifs.config.PropertyConfiguration;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;

/** Authenticated SMB2+ share. Passwords live in this process only and are never written to preferences. */
public final class SmbFileStore implements FileStore {
    private final CIFSContext context;
    private final String root;
    public SmbFileStore(String host, String share, String domain, String username, String password) throws Exception {
        if (host == null || !host.matches("[A-Za-z0-9.-]{1,253}")) throw new IllegalArgumentException("서버 주소(IP 또는 DNS 이름)를 확인하세요.");
        FileEngine.validateName(share);
        if (share.contains(":")) throw new IllegalArgumentException("공유 폴더 이름이 올바르지 않습니다.");
        root = "smb://" + host.toLowerCase(Locale.ROOT) + "/" + encode(share) + "/";
        Properties options = new Properties();
        options.setProperty("jcifs.smb.client.minVersion", "SMB202");
        options.setProperty("jcifs.smb.client.maxVersion", "SMB311");
        options.setProperty("jcifs.smb.client.responseTimeout", "10000");
        options.setProperty("jcifs.smb.client.soTimeout", "12000");
        context = new BaseContext(new PropertyConfiguration(options))
            .withCredentials(new NtlmPasswordAuthenticator(domain == null ? "" : domain,
                    username == null ? "" : username, password == null ? "" : password));
    }
    public String root() { return root; }
    private static String encode(String name) {
        try { return URLEncoder.encode(name, "UTF-8").replace("+", "%20"); }
        catch (java.io.UnsupportedEncodingException e) { throw new AssertionError(e); }
    }
    private SmbFile handle(String id) throws Exception {
        if (!id.startsWith(root) || id.indexOf('?') >= 0 || id.indexOf('#') >= 0) throw new SecurityException("SMB 공유 폴더 바깥 주소입니다.");
        if (id.contains("/../") || id.contains("/%2e") || id.contains("/%2E")) throw new SecurityException("상위 폴더 경로는 허용하지 않습니다.");
        return new SmbFile(id, context);
    }
    private FileNode node(SmbFile f) throws Exception {
        boolean folder = f.isDirectory();
        String id = f.getCanonicalPath();
        String name = f.getName();
        if (folder && name.endsWith("/")) name = name.substring(0, name.length() - 1);
        if (id.equals(root)) name = root.substring(6, root.length()-1);
        return new FileNode(id, name, folder, folder ? "vnd.android.document/directory" : "application/octet-stream",
                folder ? -1 : f.length(), f.lastModified());
    }
    @Override public FileNode stat(String id) throws Exception { return node(handle(id)); }
    @Override public List<FileNode> list(String id) throws Exception {
        SmbFile directory = handle(id);
        if (!directory.isDirectory()) throw new IOException("SMB 폴더가 아닙니다.");
        List<FileNode> result = new ArrayList<>();
        for (SmbFile f : directory.listFiles()) result.add(node(f));
        return result;
    }
    private String child(String parent, String name, boolean dir) throws Exception {
        FileEngine.validateName(name);
        String base = parent.endsWith("/") ? parent : parent + "/";
        String id = base + encode(name) + (dir ? "/" : "");
        handle(id);
        return id;
    }
    @Override public FileNode mkdir(String parent, String name) throws Exception {
        SmbFile f = handle(child(parent,name,true)); f.mkdir(); return node(f);
    }
    @Override public FileNode mkfile(String parent, String name, String mime) throws Exception {
        SmbFile f = handle(child(parent,name,false)); f.createNewFile(); return node(f);
    }
    @Override public InputStream read(String id) throws Exception { return handle(id).getInputStream(); }
    @Override public OutputStream write(String id) throws Exception { return handle(id).getOutputStream(); }
    @Override public void delete(String id) throws Exception {
        deleteRecursive(id,0);
    }
    private void deleteRecursive(String id,int depth) throws Exception {
        if (root.equals(id)) throw new SecurityException("SMB 공유 루트는 삭제할 수 없습니다.");
        if (depth>FileEngine.MAX_DEPTH) throw new IOException("하위 폴더가 너무 깊습니다.");
        SmbFile file=handle(id);
        if (file.isDirectory()) for (SmbFile child : file.listFiles()) deleteRecursive(child.getCanonicalPath(),depth+1);
        file.delete();
    }
    @Override public FileNode rename(String id, String name) throws Exception {
        if (root.equals(id)) throw new SecurityException("공유 루트의 이름을 바꿀 수 없습니다.");
        SmbFile src = handle(id);
        String raw = id.endsWith("/") ? id.substring(0,id.length()-1) : id;
        int slash = raw.lastIndexOf('/');
        SmbFile dst = handle(child(raw.substring(0,slash+1), name, src.isDirectory()));
        src.renameTo(dst);
        return node(dst);
    }
}

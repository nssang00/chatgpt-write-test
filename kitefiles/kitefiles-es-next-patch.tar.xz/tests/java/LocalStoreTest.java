import com.kitefiles.android.LocalFileStore;
import com.kitefiles.core.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Runs actual LocalFileStore implementation on the JVM, including traversal and symlink cases. */
public class LocalStoreTest {
  static int passes=0;
  static void ok(boolean value,String name) {if(!value)throw new AssertionError(name);passes++;System.out.println("PASS "+name);}
  static void fail(RunnableException action,String name) throws Exception {
    boolean blocked=false;try{action.run();}catch(SecurityException e){blocked=true;}
    ok(blocked,name);
  }
  interface RunnableException {void run() throws Exception;}
  public static void main(String[] a) throws Exception {
    Path root=Files.createTempDirectory("kitefiles-store-");
    Path outside=Files.createTempDirectory("kitefiles-external-");
    try {
      LocalFileStore store=new LocalFileStore(Collections.singletonList(root.toFile()));
      String uri=store.root(0);
      FileEngine engine=new FileEngine(store);
      FileNode folder=engine.newFolder(uri,"자료");
      FileNode file=engine.newFile(folder.id,"hello.txt");
      try(OutputStream out=store.write(file.id)){out.write("안녕하세요".getBytes("UTF-8"));}
      ok(store.list(folder.id).size()==1,"list local child");
      ok(store.stat(file.id).size=="안녕하세요".getBytes("UTF-8").length,"stat bytes");
      engine.transfer(Collections.singletonList(file.id),uri,false,FileEngine.QUIET);
      ok(store.list(uri).size()==2,"copy directory file to root");
      String copied=store.list(uri).stream().filter(x->!x.directory).findFirst().get().id;
      ok(Arrays.equals(store.read(copied).readAllBytes(),store.read(file.id).readAllBytes()),"copy byte equality");
      fail(()->store.delete(uri),"cannot delete mount root");
      fail(()->store.rename(uri,"changed"),"cannot rename mount root");
      fail(()->store.stat(outside.toUri().toString()),"outside root blocked");
      Path symlink=root.resolve("escape");
      try{Files.createSymbolicLink(symlink,outside);}catch(UnsupportedOperationException|IOException ignored){}
      if(Files.isSymbolicLink(symlink)) fail(()->store.list(symlink.toUri().toString()),"symlink escape blocked");
      store.delete(folder.id);ok(!Files.exists(java.nio.file.Paths.get(java.net.URI.create(folder.id))),"recursive delete directory");
      System.out.println("LOCAL STORE RESULT: passed="+passes+" failed=0");
    } finally {
      try(java.util.stream.Stream<Path> st=Files.walk(root)){st.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(Exception ignored){}});}
      Files.deleteIfExists(outside);
    }
  }
}

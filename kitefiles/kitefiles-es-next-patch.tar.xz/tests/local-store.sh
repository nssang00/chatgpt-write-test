#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p .build/local
javac -encoding UTF-8 --release 17 -d .build/local app/src/main/java/com/kitefiles/core/*.java app/src/main/java/com/kitefiles/android/LocalFileStore.java tests/java/LocalStoreTest.java
java -cp .build/local LocalStoreTest

import com.kitefiles.core.FileEngine;
import com.kitefiles.core.FileNode;
import com.kitefiles.core.FileStore;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.stream.Stream;

/** Real disk integration tests; the production Android backend uses SAF, not this adapter. */
public final class RealFilesystemTests {
    static final class Disk implements FileStore {
        private final Path root;
        Disk(Path root) throws Exception { this.root=root.toRealPath(); }
        private Path checked(String id) throws Exception {
            Path path=Path.of(id).toAbsolutePath().normalize();
            if (!path.startsWith(root)) throw new SecurityException("outside root");
            Path probe=path;
            while(probe!=null && !probe.equals(root.getParent())) {
                if (Files.exists(probe,LinkOption.NOFOLLOW_LINKS) && Files.isSymbolicLink(probe))
                    throw new SecurityException("symlink disallowed");
                if(probe.equals(root)) break;
                probe=probe.getParent();
            }
            return path;
        }
        @Override public FileNode stat(String id) throws Exception {
            Path p=checked(id);
            return new FileNode(p.toString(),p.getFileName().toString(),Files.isDirectory(p),
                    Files.isDirectory(p)?"directory":FileEngine.mimeOf(p.toString()),
                    Files.isDirectory(p)?-1:Files.size(p),Files.getLastModifiedTime(p).toMillis());
        }
        @Override public List<FileNode> list(String id) throws Exception {
            List<FileNode> result=new ArrayList<>();
            try(Stream<Path> s=Files.list(checked(id))) {
                for(Path p:s.toList()) result.add(stat(p.toString()));
            }
            return result;
        }
        @Override public FileNode mkdir(String p,String name) throws Exception {
            return stat(Files.createDirectory(checked(p).resolve(name)).toString());
        }
        @Override public FileNode mkfile(String p,String name,String mime) throws Exception {
            return stat(Files.createFile(checked(p).resolve(name)).toString());
        }
        @Override public InputStream read(String id) throws Exception { return Files.newInputStream(checked(id)); }
        @Override public OutputStream write(String id) throws Exception { return Files.newOutputStream(checked(id),StandardOpenOption.TRUNCATE_EXISTING); }
        @Override public void delete(String id) throws Exception {
            Path path=checked(id);
            if (path.equals(root)) throw new SecurityException("cannot delete root");
            if (Files.isDirectory(path)) {
                try(Stream<Path> stream=Files.list(path)) {
                    for(Path item:stream.toList()) delete(item.toString());
                }
            }
            Files.delete(path);
        }
        @Override public FileNode rename(String id,String name) throws Exception {
            Path path=checked(id);
            return stat(Files.move(path,path.resolveSibling(name)).toString());
        }
        String id(Path path) throws Exception { return checked(path.toString()).toString(); }
    }
    static void ok(boolean value,String reason) { if(!value) throw new AssertionError(reason); }
    private static String hash(byte[] bytes) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(bytes);
        return HexFormat.of().formatHex(digest);
    }
    public static void main(String[] args) throws Exception {
        Path temp=Files.createTempDirectory("kitefiles-integration-");
        int pass=0;
        try {
            Disk disk=new Disk(temp);
            FileEngine engine=new FileEngine(disk);
            String root=disk.id(temp);
            FileNode drafts=engine.newFolder(root,"Drafts"); pass++; System.out.println("PASS actual mkdir");
            FileNode original=engine.newFile(root,"report.txt");
            byte[] content="다국어 파일 내용 / KiteFiles / ✅".getBytes(java.nio.charset.StandardCharsets.UTF_8);
            Files.write(Path.of(original.id),content);
            ok(Arrays.equals(Files.readAllBytes(Path.of(original.id)),content),"actual file write");
            pass++; System.out.println("PASS actual UTF-8 write/read");
            engine.transfer(List.of(original.id),drafts.id,false,FileEngine.QUIET);
            ok(Arrays.equals(Files.readAllBytes(Path.of(drafts.id,"report.txt")),content),"actual copy checksum");
            pass++; System.out.println("PASS actual copy SHA-256=" + hash(Files.readAllBytes(Path.of(drafts.id,"report.txt"))));
            FileNode staging=engine.newFolder(root,"Staging");
            engine.transfer(List.of(Path.of(drafts.id,"report.txt").toString()),staging.id,true,FileEngine.QUIET);
            ok(Files.exists(Path.of(staging.id,"report.txt")) && !Files.exists(Path.of(drafts.id,"report.txt")),"actual move");
            pass++; System.out.println("PASS actual move + original removal");
            FileNode zip=engine.makeZip(List.of(staging.id),root,"archive.zip",FileEngine.QUIET);
            ok(Files.size(Path.of(zip.id))>0,"real ZIP size"); pass++; System.out.println("PASS actual ZIP generation");
            FileNode extraction=engine.extractZip(zip.id,root,FileEngine.QUIET);
            Path unpacked=Path.of(extraction.id,"Staging","report.txt");
            ok(hash(Files.readAllBytes(unpacked)).equals(hash(content)),"roundtrip content hash");
            pass++; System.out.println("PASS actual ZIP extraction SHA-256="+hash(Files.readAllBytes(unpacked)));
            ok(engine.search(root,"REPORT",20).size()==3,"search files from source, move, extraction");
            pass++; System.out.println("PASS actual recursive search");
            FileNode renamed=engine.rename(Path.of(staging.id,"report.txt").toString(),"renamed.txt",staging.id);
            ok(Files.exists(Path.of(renamed.id)),"actual rename"); pass++; System.out.println("PASS actual rename");
            disk.delete(staging.id); ok(!Files.exists(Path.of(staging.id)),"actual recursive delete");
            pass++; System.out.println("PASS actual recursive delete");
            System.out.println("REAL DISK RESULT: passed="+pass+" failed=0");
        } finally {
            try(Stream<Path> contents=Files.walk(temp)) {
                for(Path path:contents.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
    }
}

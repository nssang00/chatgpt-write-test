import com.kitefiles.core.FileEngine;
import com.kitefiles.core.FileNode;
import com.kitefiles.core.FileStore;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public class CoreTests {
    private static int passed = 0, failed = 0;
    private interface Check { void run() throws Exception; }
    private static void check(String name, Check c) {
        try { c.run(); passed++; System.out.println("PASS " + name); }
        catch (Throwable t) { failed++; System.out.println("FAIL " + name + ": " + t); t.printStackTrace(System.out); }
    }
    private static void yes(boolean truth, String message) { if (!truth) throw new AssertionError(message); }
    private static void eq(Object a, Object b) { yes(Objects.equals(a,b), "expected " + b + " but got " + a); }
    private static void reject(Check c) throws Exception {
        try { c.run(); throw new AssertionError("Expected error, but succeeded"); }
        catch (IllegalArgumentException expected) { }
    }
    private static final class Mem implements FileStore {
        private static final class Entry {
            String id, name, parent, mime; byte[] bytes = new byte[0]; boolean dir; long modified = 100;
            Entry(String id, String parent, String name, boolean dir, String mime) {
                this.id=id; this.name=name; this.parent=parent; this.dir=dir; this.mime=mime;
            }
        }
        final Map<String,Entry> nodes = new LinkedHashMap<>();
        int serial=0; boolean failWrite; boolean corruptWrite;
        Mem() { add(null, "root", true, "directory"); }
        private Entry add(String parent, String name, boolean dir, String mime) {
            String id = "n" + serial++;
            Entry entry = new Entry(id,parent,name,dir,mime);
            nodes.put(id,entry); return entry;
        }
        private Entry get(String id) { Entry e=nodes.get(id); if(e==null) throw new IllegalArgumentException("not found: "+id); return e; }
        @Override public FileNode stat(String id) {
            Entry e=get(id); return new FileNode(e.id,e.name,e.dir,e.mime,e.dir?-1:e.bytes.length,e.modified);
        }
        @Override public List<FileNode> list(String id) {
            yes(get(id).dir, "not directory");
            List<FileNode> list=new ArrayList<>();
            for(Entry e:nodes.values()) if (id.equals(e.parent)) list.add(stat(e.id));
            return list;
        }
        private FileNode newNode(String parent, String name, boolean dir, String mime) {
            yes(get(parent).dir, "not directory");
            for(FileNode f:list(parent)) yes(!f.name.equalsIgnoreCase(name),"duplicate: "+name);
            return stat(add(parent,name,dir,mime).id);
        }
        @Override public FileNode mkdir(String p,String n) { return newNode(p,n,true,"directory"); }
        @Override public FileNode mkfile(String p,String n,String m) { return newNode(p,n,false,m); }
        @Override public InputStream read(String id) { return new ByteArrayInputStream(get(id).bytes); }
        @Override public OutputStream write(String id) {
            if (failWrite) return new OutputStream() { @Override public void write(int b) throws IOException { throw new IOException("disk full"); } };
            return new ByteArrayOutputStream() {
                @Override public void close() throws IOException { super.close(); get(id).bytes=toByteArray(); if(corruptWrite && get(id).bytes.length>0) get(id).bytes[0]^=1; }
            };
        }
        @Override public void delete(String id) {
            for(FileNode child:listIfDir(id)) delete(child.id);
            nodes.remove(id);
        }
        private List<FileNode> listIfDir(String id) { return get(id).dir ? list(id) : new ArrayList<>(); }
        @Override public FileNode rename(String id,String name) {
            Entry e=get(id);
            for(FileNode s:list(e.parent)) if(!s.id.equals(id)) yes(!s.name.equalsIgnoreCase(name),"conflict");
            e.name=name; return stat(id);
        }
        FileNode writeFile(String parent,String name,String body) throws Exception {
            FileNode f=mkfile(parent,name,FileEngine.mimeOf(name));
            try(OutputStream o=write(f.id)) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
            return f;
        }
        String body(String id) throws Exception { try(InputStream in=read(id)) { return new String(in.readAllBytes(),StandardCharsets.UTF_8); } }
        String child(String parent,String name) {
            for(FileNode f:list(parent)) if(f.name.equals(name)) return f.id;
            throw new AssertionError("child missing: "+name);
        }
    }
    private static String root(Mem m) { return "n0"; }
    private static byte[] zipBytes(Map<String,String> entries) throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        try(ZipOutputStream zip=new ZipOutputStream(out)) {
            for(Map.Entry<String,String> e:entries.entrySet()) {
                zip.putNextEntry(new ZipEntry(e.getKey()));
                zip.write(e.getValue().getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }
        }
        return out.toByteArray();
    }
    private static FileNode zipFile(Mem m,byte[] bytes) throws Exception {
        FileNode z=m.mkfile(root(m),"incoming.zip","application/zip");
        try(OutputStream o=m.write(z.id)) { o.write(bytes); }
        return z;
    }
    public static void main(String[] args) throws Exception {
        check("root list and create",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            e.newFolder(root(m),"Photos"); e.newFile(root(m),"hello.txt"); eq(m.list(root(m)).size(),2); });
        check("invalid blank",()->reject(()->FileEngine.validateName("  ")));
        check("invalid dot",()->reject(()->FileEngine.validateName("..")));
        check("invalid slash",()->reject(()->FileEngine.validateName("a/b")));
        check("invalid backslash",()->reject(()->FileEngine.validateName("a\\b")));
        check("invalid control",()->reject(()->FileEngine.validateName("a\nb")));
        check("unique duplicate extension",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            m.writeFile(root(m),"file.txt","hi"); eq(e.availableName(root(m),"FILE.txt"),"FILE (1).txt"); });
        check("unique many collisions",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            m.writeFile(root(m),"file.txt","a"); m.writeFile(root(m),"file (1).txt","b");
            eq(e.availableName(root(m),"file.txt"),"file (2).txt"); });
        check("rename conflict blocks",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode a=m.writeFile(root(m),"a.txt","a"); m.writeFile(root(m),"b.txt","b");
            reject(()->e.rename(a.id,"b.txt",root(m))); eq(m.stat(a.id).name,"a.txt"); });
        check("copy file intact",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode src=m.writeFile(root(m),"hello.txt","secret data"); FileNode dst=m.mkdir(root(m),"dest");
            e.transfer(List.of(src.id),dst.id,false,FileEngine.QUIET);
            eq(m.body(m.child(dst.id,"hello.txt")),"secret data"); eq(m.body(src.id),"secret data"); });
        check("copy same directory keeps both",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode a=m.writeFile(root(m),"one.txt","abc"); e.transfer(List.of(a.id),root(m),false,FileEngine.QUIET);
            eq(m.body(m.child(root(m),"one (1).txt")),"abc"); });
        check("move file removes source after copying",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode a=m.writeFile(root(m),"move.txt","hi"); FileNode dst=m.mkdir(root(m),"target");
            e.transfer(List.of(a.id),dst.id,true,FileEngine.QUIET);
            yes(!m.nodes.containsKey(a.id),"original should disappear"); eq(m.body(m.child(dst.id,"move.txt")),"hi"); });
        check("move to same parent is no op",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode a=m.writeFile(root(m),"x.txt","x"); e.transfer(List.of(a.id),root(m),true,FileEngine.QUIET);
            eq(m.list(root(m)).size(),1); eq(m.body(a.id),"x"); });
        check("copy nested directory",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode src=m.mkdir(root(m),"src"); FileNode inner=m.mkdir(src.id,"deep"); m.writeFile(inner.id,"a.txt","nested");
            FileNode dst=m.mkdir(root(m),"dst"); e.transfer(List.of(src.id),dst.id,false,FileEngine.QUIET);
            eq(m.body(m.child(m.child(m.child(dst.id,"src"),"deep"),"a.txt")),"nested"); });
        check("reject copy directory into descendant",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode a=m.mkdir(root(m),"A"); FileNode b=m.mkdir(a.id,"B");
            reject(()->e.transfer(List.of(a.id),b.id,false,FileEngine.QUIET)); eq(m.list(b.id).size(),0); });
        check("reject self transfer",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode a=m.mkdir(root(m),"A"); reject(()->e.transfer(List.of(a.id),a.id,true,FileEngine.QUIET)); });
        check("failed copy preserves original and cleans target",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode a=m.writeFile(root(m),"a.txt","important"); FileNode dst=m.mkdir(root(m),"dst");
            m.failWrite=true; try { e.transfer(List.of(a.id),dst.id,true,FileEngine.QUIET); throw new AssertionError("copy should fail"); }
            catch(IOException expected) {} eq(m.body(a.id),"important"); eq(m.list(dst.id).size(),0); });
        check("corrupted move copy preserves original",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode src=m.writeFile(root(m),"original.txt","don't lose me");
            FileNode dst=m.mkdir(root(m),"out"); m.corruptWrite=true;
            try { e.transfer(List.of(src.id),dst.id,true,FileEngine.QUIET); throw new AssertionError("verify must fail"); }
            catch(IOException expected) { }
            eq(m.body(src.id),"don't lose me"); eq(m.list(dst.id).size(),0);
        });
        check("zip folder and nested content",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode folder=m.mkdir(root(m),"docs"); m.writeFile(folder.id,"a.txt","alpha");
            FileNode zipped=e.makeZip(List.of(folder.id),root(m),"bundle.zip",FileEngine.QUIET);
            yes(m.stat(zipped.id).size>0,"zip not empty");
            try(ZipInputStream zis=new ZipInputStream(m.read(zipped.id))) {
                eq(zis.getNextEntry().getName(),"docs/"); zis.closeEntry();
                eq(zis.getNextEntry().getName(),"docs/a.txt");
                eq(new String(zis.readAllBytes(),StandardCharsets.UTF_8),"alpha");
            } });
        check("reject archive inside zipped folder",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode d=m.mkdir(root(m),"D"); reject(()->e.makeZip(List.of(d.id),d.id,"x.zip",FileEngine.QUIET)); });
        check("unzip new directory and nested file",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            byte[] bytes=zipBytes(Map.of("alpha/hi.txt","hello")); FileNode src=zipFile(m,bytes);
            FileNode out=e.extractZip(src.id,root(m),FileEngine.QUIET);
            eq(m.body(m.child(m.child(out.id,"alpha"),"hi.txt")),"hello"); });
        check("zip slip traversal rejected, rollback",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode source=zipFile(m,zipBytes(Map.of("../outside.txt","attack")));
            reject(()->e.extractZip(source.id,root(m),FileEngine.QUIET));
            eq(m.list(root(m)).size(),1); });
        check("invalid ZIP rejected with rollback",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode bad=zipFile(m,"not a ZIP".getBytes(StandardCharsets.UTF_8));
            reject(()->e.extractZip(bad.id,root(m),FileEngine.QUIET)); eq(m.list(root(m)).size(),1); });
        check("truncated ZIP header rejected",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode bad=zipFile(m,new byte[]{80,75,3,4});
            reject(()->e.extractZip(bad.id,root(m),FileEngine.QUIET)); eq(m.list(root(m)).size(),1); });
        check("zip slip absolute rejected",()->reject(()->FileEngine.safeZipPath("/etc/passwd")));
        check("zip slip windows rejected",()->reject(()->FileEngine.safeZipPath("C:/temp/file")));
        check("zip slip backslash rejected",()->reject(()->FileEngine.safeZipPath("foo\\..\\bar")));
        check("zip entry nested depth rejected",()->{
            String path="x/".repeat(33)+"file"; reject(()->FileEngine.safeZipPath(path)); });
        check("zip duplicate extraction without overwrite",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode source=zipFile(m,zipBytes(Map.of("a.txt","one")));
            FileNode out=e.extractZip(source.id,root(m),FileEngine.QUIET); eq(m.body(m.child(out.id,"a.txt")),"one");
            FileNode out2=e.extractZip(source.id,root(m),FileEngine.QUIET); yes(!out.id.equals(out2.id),"same directory"); });
        check("search case insensitive and nested",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode docs=m.mkdir(root(m),"Docs"); m.writeFile(docs.id,"REPORT.PDF","x");
            List<FileEngine.SearchHit> results=e.search(root(m),"report",10);
            eq(results.size(),1); eq(results.get(0).relativePath,"Docs/REPORT.PDF"); eq(results.get(0).parentId,docs.id); });
        check("search result limit",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            for(int i=0;i<20;i++) m.writeFile(root(m),"q"+i+".txt", "");
            eq(e.search(root(m),"q",5).size(),5); });
        check("search empty query",()->{ Mem m=new Mem(); eq(new FileEngine(m).search(root(m),"",5).size(),0); });
        check("mime mappings",()->{ eq(FileEngine.mimeOf("me.JPG"),"image/jpeg");
            eq(FileEngine.mimeOf("note.md"),"text/plain"); eq(FileEngine.mimeOf("x.unknown"),"application/octet-stream"); });
        check("zip output fails cleanly",()->{ Mem m=new Mem(); FileEngine e=new FileEngine(m);
            FileNode a=m.writeFile(root(m),"a.txt","hi"); m.failWrite=true;
            try { e.makeZip(List.of(a.id),root(m),"bad.zip",FileEngine.QUIET); throw new AssertionError("must fail"); }
            catch(IOException expected) { }
            eq(m.list(root(m)).size(),1); });
        System.out.printf("RESULT: passed=%d failed=%d%n",passed,failed);
        if (failed != 0) System.exit(1);
    }
}

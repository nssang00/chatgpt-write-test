package com.kitefiles.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.content.Context;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.kitefiles.core.FileEngine;
import com.kitefiles.core.FileNode;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** Framework-only Android UI: no network, ads, analytics, broad storage permission or third-party SDKs. */
public final class MainActivity extends Activity {
    private static final int PICK_TREE = 101;
    private static final int BG = 0xFFF7F9FE;
    private static final int INK = 0xFF17213D;
    private static final int MUTED = 0xFF72809C;
    private static final int BLUE = 0xFF3759D5;
    private static final int PALE = 0xFFEBF0FF;
    private static final int BORDER = 0xFFE7EBF4;
    private static final int DANGER = 0xFFC32940;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService jobs = Executors.newSingleThreadExecutor();
    private final ArrayList<Crumb> path = new ArrayList<>();
    private final ArrayList<FileNode> visible = new ArrayList<>();
    private final ArrayList<FileEngine.SearchHit> hits = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private final ArrayList<String> clipboard = new ArrayList<>();
    private final Map<String, String> parentOfHit = new HashMap<>();

    private enum Page { HOME, FOLDER, RESULTS }
    private Page page = Page.HOME;
    private LinearLayout frame;
    private LinearLayout body;
    private TextView info;
    private DocumentStore store;
    private String activeTree;
    private String folder;
    private String clipboardTree;
    private boolean cut = false;
    private boolean busy = false;
    private String busyLabel = "";
    private String query = "";
    private int sort = 0; // 0 name, 1 date, 2 size
    private int requestSerial = 0;
    private final DateFormat date = DateFormat.getDateInstance(DateFormat.SHORT, Locale.KOREA);

    private static final class Crumb {
        final String name, id;
        Crumb(String name, String id) { this.name = name; this.id = id; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        frame = new LinearLayout(this);
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            frame.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets system = insets.getInsets(WindowInsets.Type.systemBars());
                frame.setPadding(system.left, system.top, system.right, system.bottom);
                return insets;
            });
        }
        setContentView(frame);
        draw();
    }

    @Override protected void onDestroy() {
        jobs.shutdownNow();
        super.onDestroy();
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width < 0 ? width : dp(width), height < 0 ? height : dp(height));
    }
    private void space(LinearLayout parent, int height) { parent.addView(new View(this), lp(1, height)); }
    private TextView action(String label, boolean primary, Runnable onClick) {
        TextView t = text(label, 13, primary ? Color.WHITE : BLUE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(shape(primary ? BLUE : PALE, 12, 0));
        t.setMinHeight(dp(44));
        t.setContentDescription(label);
        t.setOnClickListener(v -> { if (!busy) onClick.run(); });
        return t;
    }
    private void actionInto(LinearLayout bar, String label, boolean primary, Runnable click) {
        TextView a = action(label, primary, click);
        LinearLayout.LayoutParams p = lp(-2, 44);
        p.setMargins(0, 0, dp(8), 0);
        bar.addView(a, p);
    }
    private void caption(LinearLayout into, String msg) {
        TextView t = text(msg, 12, MUTED, false);
        into.addView(t, lp(-1, -2));
    }
    private void snack(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private String message(Exception e) {
        Throwable t = e;
        while (t.getCause() != null && (t.getMessage() == null || t.getMessage().isEmpty())) t = t.getCause();
        return t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
    }

    private void draw() {
        frame.removeAllViews();
        LinearLayout header = vertical();
        header.setPadding(dp(20), dp(14), dp(20), dp(12));
        frame.addView(header, lp(-1, -2));

        LinearLayout top = horizontal();
        header.addView(top, lp(-1, 50));
        TextView logo = text("◈", 26, BLUE, true);
        top.addView(logo, lp(38, -1));
        LinearLayout brand = vertical();
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        brand.addView(text("KiteFiles", 23, INK, true));
        brand.addView(text("내 파일 작업공간", 11, MUTED, false));
        if (page != Page.HOME) actionInto(top, "홈", false, this::goHome);

        space(header, 16);
        if (page == Page.HOME) drawHomeHeader(header);
        else drawFolderHeader(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(16), dp(8), dp(16), dp(8));
        frame.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        body = vertical();
        scroll.addView(body);
        if (page == Page.HOME) drawLocations();
        else drawFiles();
        drawFooter();
    }

    private void drawHomeHeader(LinearLayout header) {
        LinearLayout intro = vertical();
        intro.setPadding(dp(18), dp(18), dp(18), dp(18));
        intro.setBackground(shape(PALE, 18, 0));
        header.addView(intro, lp(-1, -2));
        intro.addView(text("파일을 쉽고 안전하게", 19, INK, true));
        space(intro, 8);
        caption(intro, "원하는 폴더만 연결하여 탐색하고 정리하세요.\n파일은 기기 안에서 처리하며 서버로 전송하지 않습니다.");
        space(intro, 16);
        LinearLayout bar = horizontal();
        intro.addView(bar);
        actionInto(bar, "+ 폴더 연결", true, this::pickFolder);
    }

    private void drawFolderHeader(LinearLayout header) {
        TextView section = text(page == Page.RESULTS ? "검색 결과" : "폴더 탐색", 19, INK, true);
        header.addView(section, lp(-1, 34));
        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        header.addView(scroller, lp(-1, 46));
        LinearLayout trail = horizontal();
        scroller.addView(trail);
        for (int i = 0; i < path.size(); i++) {
            Crumb c = path.get(i);
            final int index = i;
            TextView crumb = text(c.name, 13, i == path.size() - 1 ? INK : BLUE, i == path.size() - 1);
            crumb.setMinHeight(dp(40));
            crumb.setPadding(dp(4), 0, dp(4), 0);
            crumb.setOnClickListener(v -> { if (!busy) navigateBackTo(index); });
            trail.addView(crumb);
            if (i != path.size() - 1) trail.addView(text("  ›  ", 13, MUTED, false));
        }
        LinearLayout actions = horizontal();
        header.addView(actions, lp(-1, 44));
        actionInto(actions, "⌕ 검색", false, this::promptSearch);
        actionInto(actions, sort == 0 ? "이름순" : sort == 1 ? "최신순" : "크기순", false, () -> { sort = (sort + 1) % 3; draw(); });
        actionInto(actions, "+ 만들기", false, this::showCreateMenu);
        if (page == Page.RESULTS) {
            TextView count = text("‘" + query + "’", 12, MUTED, false);
            header.addView(count);
        }
    }

    private SharedPreferences prefs() { return getSharedPreferences("places", MODE_PRIVATE); }
    private Set<String> savedTrees() { return new HashSet<>(prefs().getStringSet("trees", Collections.emptySet())); }
    private String labelOf(String tree) { return prefs().getString("label:" + tree, "연결된 폴더"); }

    private void drawLocations() {
        TextView title = text("연결된 폴더", 17, INK, true);
        body.addView(title, lp(-1, 46));
        List<String> trees = new ArrayList<>(savedTrees());
        trees.sort(Comparator.comparing(this::labelOf, String.CASE_INSENSITIVE_ORDER));
        if (trees.isEmpty()) {
            LinearLayout empty = vertical();
            empty.setPadding(dp(18), dp(28), dp(18), dp(30));
            empty.setGravity(Gravity.CENTER_HORIZONTAL);
            empty.setBackground(shape(Color.WHITE, 16, BORDER));
            body.addView(empty, lp(-1, -2));
            empty.addView(text("📂", 38, BLUE, true));
            space(empty, 8);
            empty.addView(text("연결된 폴더가 없습니다", 16, INK, true));
            space(empty, 8);
            caption(empty, "‘폴더 연결’을 눌러 문서, 사진 또는 작업 폴더를 선택하세요.");
        }
        for (String tree : trees) {
            LinearLayout card = horizontal();
            card.setPadding(dp(16), dp(13), dp(12), dp(13));
            card.setBackground(shape(Color.WHITE, 16, BORDER));
            LinearLayout.LayoutParams margins = lp(-1, 78);
            margins.bottomMargin = dp(10);
            body.addView(card, margins);
            card.addView(text("📁", 27, BLUE, false), lp(48, -1));
            LinearLayout names = vertical();
            card.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
            names.addView(text(labelOf(tree), 15, INK, true));
            names.addView(text("탭하여 열기 · 길게 눌러 연결 해제", 11, MUTED, false));
            card.addView(text("›", 25, BLUE, true), lp(20, -1));
            card.setOnClickListener(v -> { if (!busy) openTree(tree); });
            card.setOnLongClickListener(v -> { if (!busy) confirmRemove(tree); return true; });
        }
        space(body, 18);
        caption(body, "보안: 선택한 폴더와 하위 파일에만 접근합니다. Android 시스템에서 접근 권한을 언제든 해제할 수 있습니다.");
    }

    private String subtitle(FileNode node) {
        if (node.directory) return "폴더" + (node.modified > 0 ? "  ·  " + date.format(node.modified) : "");
        return (node.size < 0 ? "크기 알 수 없음" : readableSize(node.size)) +
                (node.modified > 0 ? "  ·  " + date.format(node.modified) : "");
    }
    private String readableSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double d = bytes; String[] units = {"B", "KB", "MB", "GB", "TB"}; int i = 0;
        while (d >= 1024 && i < units.length - 1) { d /= 1024; i++; }
        return String.format(Locale.KOREA, "%.1f %s", d, units[i]);
    }
    private String iconFor(FileNode node) {
        if (node.directory) return "📁";
        String m = node.mime;
        if (m.startsWith("image/")) return "🖼";
        if (m.startsWith("video/")) return "🎬";
        if (m.startsWith("audio/")) return "🎵";
        if (node.name.toLowerCase(Locale.ROOT).endsWith(".zip")) return "🗜";
        return "📄";
    }

    private void drawFiles() {
        List<FileNode> items = new ArrayList<>(visible);
        items.sort((a,b) -> {
            if (a.directory != b.directory) return a.directory ? -1 : 1;
            if (sort == 1) return Long.compare(b.modified, a.modified);
            if (sort == 2) return Long.compare(b.size, a.size);
            return a.name.compareToIgnoreCase(b.name);
        });
        LinearLayout heading = horizontal();
        body.addView(heading, lp(-1, 42));
        heading.addView(text(page == Page.RESULTS ? "일치하는 항목" : "파일 및 폴더", 16, INK, true), new LinearLayout.LayoutParams(0, -1, 1));
        String summary = busy ? "작업 중…" : items.size() + "개 항목";
        heading.addView(text(summary, 12, MUTED, false));
        if (busy) {
            TextView loading = text("◌ " + busyLabel, 14, BLUE, false);
            loading.setPadding(dp(16), dp(16), dp(16), dp(16));
            body.addView(loading);
        }
        if (!busy && items.isEmpty()) {
            LinearLayout empty = vertical();
            empty.setPadding(dp(22), dp(35), dp(22), dp(35));
            empty.setGravity(Gravity.CENTER_HORIZONTAL);
            empty.setBackground(shape(Color.WHITE, 16, BORDER));
            body.addView(empty, lp(-1, -2));
            empty.addView(text("🗂", 35, BLUE, false));
            space(empty, 10);
            empty.addView(text(page == Page.RESULTS ? "일치하는 파일이 없습니다" : "빈 폴더입니다", 16, INK, true));
        }
        for (FileNode file : items) {
            LinearLayout row = horizontal();
            row.setPadding(dp(12), dp(11), dp(12), dp(11));
            row.setBackground(shape(selected.contains(file.id) ? PALE : Color.WHITE, 14, BORDER));
            LinearLayout.LayoutParams p = lp(-1, 74);
            p.bottomMargin = dp(7);
            body.addView(row, p);
            if (!selected.isEmpty()) {
                CheckBox check = new CheckBox(this);
                check.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
                check.setChecked(selected.contains(file.id));
                check.setOnClickListener(v -> toggle(file.id));
                row.addView(check, lp(40, 48));
            }
            TextView glyph = text(iconFor(file), 26, BLUE, false);
            row.addView(glyph, lp(46, -1));
            LinearLayout column = vertical();
            row.addView(column, new LinearLayout.LayoutParams(0, -2, 1));
            TextView name = text(file.name, 14, INK, true);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            column.addView(name);
            column.addView(text(page == Page.RESULTS ? resultLocation(file) : subtitle(file), 11, MUTED, false));
            row.addView(text(file.directory ? "›" : "⋯", 20, MUTED, false), lp(20, -1));
            row.setOnClickListener(v -> { if (!busy) { if (!selected.isEmpty()) toggle(file.id); else openItem(file); } });
            row.setOnLongClickListener(v -> { if (!busy) toggle(file.id); return true; });
        }
    }

    private String resultLocation(FileNode node) {
        for (FileEngine.SearchHit hit : hits) if (hit.file.id.equals(node.id)) return hit.relativePath;
        return subtitle(node);
    }

    private void drawFooter() {
        if (page == Page.HOME) return;
        LinearLayout footer = vertical();
        footer.setPadding(dp(16), dp(10), dp(10), dp(12));
        footer.setBackgroundColor(Color.WHITE);
        frame.addView(footer, lp(-1, -2));
        if (!selected.isEmpty()) {
            TextView note = text(selected.size() + "개 선택됨  ·  길게 눌러 선택 / 해제", 12, BLUE, true);
            footer.addView(note, lp(-1, 28));
            HorizontalScrollView scroll = new HorizontalScrollView(this);
            scroll.setHorizontalScrollBarEnabled(false);
            footer.addView(scroll);
            LinearLayout tools = horizontal(); scroll.addView(tools);
            actionInto(tools, "복사", false, () -> chooseClipboard(false));
            actionInto(tools, "이동", false, () -> chooseClipboard(true));
            actionInto(tools, "ZIP", false, this::zipSelected);
            actionInto(tools, "공유", false, this::shareSelected);
            if (selected.size() == 1) actionInto(tools, "이름 변경", false, this::renameSelected);
            actionInto(tools, "삭제", false, this::deleteSelected);
            actionInto(tools, "선택 해제", false, () -> { selected.clear(); draw(); });
        } else {
            LinearLayout bar = horizontal();
            footer.addView(bar);
            if (!clipboard.isEmpty()) {
                actionInto(bar, (cut ? "이동 붙여넣기" : "복사 붙여넣기") + " (" + clipboard.size() + ")", true, this::paste);
                actionInto(bar, "취소", false, () -> { clipboard.clear(); draw(); });
            } else {
                caption(bar, "파일을 길게 누르면 여러 개를 선택할 수 있습니다.");
            }
        }
    }

    private void pickFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_TREE); }
        catch (ActivityNotFoundException e) { snack("이 기기는 폴더 선택을 지원하지 않습니다."); }
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != PICK_TREE || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (SecurityException e) { snack("폴더 권한을 유지할 수 없습니다: " + e.getMessage()); return; }
        String tree = uri.toString();
        runJob("폴더 연결 중", () -> {
            DocumentStore newStore = new DocumentStore(this, uri);
            return newStore.stat(newStore.root()).name;
        }, label -> {
            Set<String> trees = savedTrees(); trees.add(tree);
            prefs().edit().putStringSet("trees", trees).putString("label:" + tree, label).apply();
            openTree(tree);
        });
    }

    private void confirmRemove(String tree) {
        new AlertDialog.Builder(this).setTitle("폴더 연결 해제")
                .setMessage("목록에서 이 폴더를 제거합니다. 파일은 삭제하지 않습니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("해제", (d, w) -> {
                    Set<String> trees = savedTrees(); trees.remove(tree);
                    prefs().edit().putStringSet("trees", trees).remove("label:" + tree).apply();
                    try { getContentResolver().releasePersistableUriPermission(Uri.parse(tree),
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
                    catch (Exception ignored) { }
                    draw();
                }).show();
    }

    private void openTree(String tree) {
        activeTree = tree;
        store = new DocumentStore(this, Uri.parse(tree));
        folder = store.root();
        path.clear(); path.add(new Crumb(labelOf(tree), folder));
        selected.clear(); page = Page.FOLDER;
        refresh();
    }

    private void goHome() {
        requestSerial++;
        page = Page.HOME;
        selected.clear(); hits.clear(); visible.clear();
        draw();
    }

    private void navigateBackTo(int index) {
        while (path.size() > index + 1) path.remove(path.size() - 1);
        folder = path.get(path.size() - 1).id;
        selected.clear(); hits.clear();
        page = Page.FOLDER;
        refresh();
    }

    private void enterFolder(FileNode file) {
        if (page == Page.RESULTS) {
            path.clear(); path.add(new Crumb(labelOf(activeTree), store.root()));
        }
        path.add(new Crumb(file.name, file.id));
        folder = file.id;
        selected.clear(); hits.clear(); page = Page.FOLDER;
        refresh();
    }

    private void refresh() {
        if (busy) return;
        selected.clear();
        String requestFolder = folder;
        int version = ++requestSerial;
        runJob("파일 불러오는 중", () -> store.list(requestFolder), files -> {
            if (version != requestSerial || page != Page.FOLDER || !requestFolder.equals(folder)) return;
            visible.clear(); visible.addAll(files); draw();
        });
    }

    private <T> void runJob(String title, Callable<T> action, Consumer<T> success) {
        if (busy) return;
        busy = true; busyLabel = title;
        draw();
        jobs.execute(() -> {
            T result = null; Exception error = null;
            try { result = action.call(); } catch (Exception ex) { error = ex; }
            T value = result; Exception fail = error;
            ui.post(() -> {
                if (isFinishing() || isDestroyed()) return;
                busy = false; busyLabel = "";
                if (fail != null) {
                    snack("작업 실패: " + message(fail));
                    draw();
                } else {
                    success.accept(value);
                }
            });
        });
    }

    private void openItem(FileNode node) {
        if (node.directory) { enterFolder(node); return; }
        if (node.name.toLowerCase(Locale.ROOT).endsWith(".zip")) {
            new AlertDialog.Builder(this).setTitle(node.name)
                    .setItems(new String[]{"다른 앱으로 열기", "현재 폴더에 압축 풀기"}, (d, which) -> {
                        if (which == 0) viewFile(node); else extract(node);
                    }).show();
        } else viewFile(node);
    }

    private void viewFile(FileNode node) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse(node.id), node.mime);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(intent, "파일 열기")); }
        catch (Exception e) { snack("이 파일을 열 수 있는 앱이 없습니다."); }
    }

    private void toggle(String id) {
        if (!selected.add(id)) selected.remove(id);
        draw();
    }

    private void promptSearch() {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setHint("파일 이름 검색");
        edit.setText(query);
        new AlertDialog.Builder(this).setTitle("이 폴더 안에서 검색")
                .setView(edit).setNegativeButton("취소", null)
                .setPositiveButton("검색", (d, w) -> search(edit.getText().toString())).show();
    }

    private void search(String term) {
        if (term.trim().isEmpty()) { snack("검색어를 입력하세요."); return; }
        query = term.trim();
        String searchRoot = folder;
        runJob("하위 폴더 검색 중", () -> new FileEngine(store).search(searchRoot, query, 500), result -> {
            selected.clear(); visible.clear(); hits.clear(); parentOfHit.clear();
            hits.addAll(result);
            for (FileEngine.SearchHit hit : result) {
                visible.add(hit.file);
                parentOfHit.put(hit.file.id, hit.parentId);
            }
            page = Page.RESULTS;
            draw();
            if (result.size() == 500) snack("검색 결과는 최대 500개까지 표시합니다.");
        });
    }

    private void showCreateMenu() {
        if (page != Page.FOLDER) { snack("새 파일은 폴더 화면에서 만들 수 있습니다."); return; }
        new AlertDialog.Builder(this).setTitle("새로 만들기")
                .setItems(new String[]{"새 폴더", "빈 파일"}, (d, item) -> promptCreate(item == 0)).show();
    }

    private void promptCreate(boolean directory) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setHint(directory ? "새 폴더" : "새 파일.txt");
        new AlertDialog.Builder(this).setTitle(directory ? "폴더 만들기" : "빈 파일 만들기")
                .setView(edit).setNegativeButton("취소", null)
                .setPositiveButton("만들기", (d, w) -> {
                    String name = edit.getText().toString();
                    runJob("만드는 중", () -> {
                        FileEngine engine = new FileEngine(store);
                        return directory ? engine.newFolder(folder, name) : engine.newFile(folder, name);
                    }, file -> { snack("생성 완료: " + file.name); refresh(); });
                }).show();
    }

    private List<String> picked() { return new ArrayList<>(selected); }
    private void chooseClipboard(boolean move) {
        clipboard.clear(); clipboard.addAll(picked());
        clipboardTree = activeTree;
        cut = move;
        selected.clear(); draw();
        snack(move ? "이동할 폴더로 이동한 후 붙여넣기를 누르세요." : "복사할 폴더로 이동한 후 붙여넣기를 누르세요.");
    }

    private void paste() {
        if (page != Page.FOLDER) { snack("폴더 안에서 붙여넣기를 실행하세요."); return; }
        if (!activeTree.equals(clipboardTree)) { snack("현재 버전은 같은 연결 폴더 안에서만 붙여넣을 수 있습니다."); return; }
        List<String> ids = new ArrayList<>(clipboard);
        boolean moving = cut;
        String target = folder;
        runJob(moving ? "이동 중" : "복사 중", () -> {
            new FileEngine(store).transfer(ids, target, moving, name -> {});
            return ids.size();
        }, count -> {
            if (moving) clipboard.clear();
            snack(count + "개 항목 처리 완료"); refresh();
        });
    }

    private void zipSelected() {
        if (page != Page.FOLDER) { snack("ZIP은 폴더 화면에서 생성하세요."); return; }
        List<String> ids = picked();
        EditText edit = new EditText(this);
        edit.setSingleLine(true); edit.setText("선택한 파일.zip");
        new AlertDialog.Builder(this).setTitle("ZIP으로 압축")
                .setView(edit).setNegativeButton("취소", null)
                .setPositiveButton("압축", (d,w) -> runJob("ZIP 압축 중", () ->
                        new FileEngine(store).makeZip(ids, folder, edit.getText().toString(), FileEngine.QUIET),
                        item -> { snack("ZIP 생성 완료: " + item.name); refresh(); })).show();
    }

    private void extract(FileNode zip) {
        if (page != Page.FOLDER && page != Page.RESULTS) return;
        String dest = folder;
        runJob("ZIP 압축 해제 중", () -> new FileEngine(store).extractZip(zip.id, dest, FileEngine.QUIET),
                item -> { snack("압축 해제 완료: " + item.name); page = Page.FOLDER; refresh(); });
    }

    private void renameSelected() {
        if (selected.size() != 1) return;
        String id = selected.iterator().next();
        FileNode node = null;
        for (FileNode f : visible) if (id.equals(f.id)) { node = f; break; }
        if (node == null) return;
        EditText edit = new EditText(this);
        edit.setSingleLine(true); edit.setText(node.name); edit.selectAll();
        final String parent = page == Page.RESULTS ? parentOfHit.get(id) : folder;
        if (parent == null) { snack("원본 폴더를 찾지 못했습니다."); return; }
        new AlertDialog.Builder(this).setTitle("이름 변경")
                .setView(edit).setNegativeButton("취소", null)
                .setPositiveButton("변경", (d, w) -> runJob("이름 변경 중", () ->
                        new FileEngine(store).rename(id, edit.getText().toString(), parent),
                        updated -> { snack("변경 완료: " + updated.name); refreshOrSearch(); })).show();
    }

    private void refreshOrSearch() {
        selected.clear();
        if (page == Page.RESULTS) search(query); else refresh();
    }

    private void deleteSelected() {
        List<String> ids = picked();
        new AlertDialog.Builder(this).setTitle("정말 삭제할까요?")
                .setMessage(ids.size() + "개 항목을 영구 삭제합니다. 휴지통 기능이 없으므로 복구할 수 없습니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("영구 삭제", (d, w) -> runJob("삭제 중", () -> {
                    int done = 0;
                    for (String id : ids) { store.delete(id); done++; }
                    return done;
                }, count -> { snack(count + "개 항목 삭제 완료"); refreshOrSearch(); }))
                .show().getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(DANGER);
    }

    private void shareSelected() {
        ArrayList<Uri> uris = new ArrayList<>();
        for (FileNode item : visible) if (selected.contains(item.id) && !item.directory) uris.add(Uri.parse(item.id));
        if (uris.isEmpty()) { snack("공유할 파일을 선택하세요(폴더는 제외). "); return; }
        Intent intent = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (uris.size() == 1) intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        else intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        ClipData clip = ClipData.newUri(getContentResolver(), "공유 파일", uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        intent.setClipData(clip);
        try { startActivity(Intent.createChooser(intent, "파일 공유")); }
        catch (Exception e) { snack("공유할 앱이 없습니다."); }
    }

    @Override public void onBackPressed() {
        if (!selected.isEmpty()) { selected.clear(); draw(); return; }
        if (page == Page.RESULTS) { page = Page.FOLDER; hits.clear(); refresh(); return; }
        if (page == Page.FOLDER && path.size() > 1) { navigateBackTo(path.size() - 2); return; }
        if (page != Page.HOME) { goHome(); return; }
        super.onBackPressed();
    }
}

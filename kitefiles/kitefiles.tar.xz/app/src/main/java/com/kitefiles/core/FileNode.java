package com.kitefiles.core;

/** Stable identifier only within a FileStore. Document providers may change IDs after rename. */
public final class FileNode {
    public final String id;
    public final String name;
    public final boolean directory;
    public final String mime;
    public final long size;
    public final long modified;

    public FileNode(String id, String name, boolean directory, String mime, long size, long modified) {
        this.id = id;
        this.name = name;
        this.directory = directory;
        this.mime = mime;
        this.size = size;
        this.modified = modified;
    }
}

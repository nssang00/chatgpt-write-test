package com.kitefiles.android;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import com.kitefiles.core.FileNode;
import com.kitefiles.core.FileStore;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** DocumentsContract implementation. All operations are constrained by a user-granted tree URI. */
public final class DocumentStore implements FileStore {
    private static final String[] COLUMNS = {
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE,
        DocumentsContract.Document.COLUMN_LAST_MODIFIED
    };

    private final ContentResolver resolver;
    private final Uri tree;
    public DocumentStore(Context context, Uri tree) {
        this.resolver = context.getContentResolver();
        this.tree = tree;
    }

    public String root() {
        return DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree)).toString();
    }

    private FileNode fromRow(Cursor cur) {
        String id = cur.getString(0);
        String name = cur.getString(1);
        String mime = cur.getString(2);
        long size = cur.isNull(3) ? -1 : cur.getLong(3);
        long modified = cur.isNull(4) ? 0 : cur.getLong(4);
        String nodeUri = DocumentsContract.buildDocumentUriUsingTree(tree, id).toString();
        return new FileNode(nodeUri, name == null ? "이름 없음" : name,
                DocumentsContract.Document.MIME_TYPE_DIR.equals(mime), mime == null ? "application/octet-stream" : mime,
                size, modified);
    }

    @Override public FileNode stat(String id) throws Exception {
        try (Cursor cursor = resolver.query(Uri.parse(id), COLUMNS, null, null, null)) {
            if (cursor == null || !cursor.moveToFirst()) throw new IllegalStateException("문서를 읽을 수 없습니다.");
            return fromRow(cursor);
        }
    }

    @Override public List<FileNode> list(String parent) throws Exception {
        Uri doc = Uri.parse(parent);
        String parentDocId = DocumentsContract.getDocumentId(doc);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentDocId);
        List<FileNode> result = new ArrayList<>();
        try (Cursor cursor = resolver.query(children, COLUMNS, null, null, null)) {
            if (cursor == null) throw new IllegalStateException("폴더 내용을 읽을 수 없습니다.");
            while (cursor.moveToNext()) result.add(fromRow(cursor));
        }
        return result;
    }

    @Override public FileNode mkdir(String parent, String name) throws Exception {
        Uri newUri = DocumentsContract.createDocument(resolver, Uri.parse(parent),
                DocumentsContract.Document.MIME_TYPE_DIR, name);
        if (newUri == null) throw new IllegalStateException("폴더 생성이 거부되었습니다.");
        return stat(newUri.toString());
    }

    @Override public FileNode mkfile(String parent, String name, String mime) throws Exception {
        Uri newUri = DocumentsContract.createDocument(resolver, Uri.parse(parent), mime, name);
        if (newUri == null) throw new IllegalStateException("파일 생성이 거부되었습니다.");
        return stat(newUri.toString());
    }

    @Override public InputStream read(String id) throws Exception {
        InputStream stream = resolver.openInputStream(Uri.parse(id));
        if (stream == null) throw new IllegalStateException("파일 읽기가 거부되었습니다.");
        return stream;
    }

    @Override public OutputStream write(String id) throws Exception {
        OutputStream stream = resolver.openOutputStream(Uri.parse(id), "wt");
        if (stream == null) throw new IllegalStateException("파일 쓰기가 거부되었습니다.");
        return stream;
    }

    @Override public void delete(String id) throws Exception {
        if (!DocumentsContract.deleteDocument(resolver, Uri.parse(id)))
            throw new IllegalStateException("삭제가 거부되었습니다.");
    }

    @Override public FileNode rename(String id, String name) throws Exception {
        Uri changed = DocumentsContract.renameDocument(resolver, Uri.parse(id), name);
        if (changed == null) throw new IllegalStateException("이름 변경이 거부되었습니다.");
        return stat(changed.toString());
    }
}

package com.kitefiles.core;

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.security.MessageDigest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Synchronous filesystem engine. Call on a worker thread; UI does so for every potentially blocking action. */
public final class FileEngine {
    public static final long MAX_ARCHIVE_BYTES = 1024L * 1024 * 1024; // 1 GiB inflated/output limit
    public static final int MAX_ZIP_ENTRIES = 10_000;
    public static final int MAX_DEPTH = 32;
    private static final int BUFFER = 32 * 1024;

    public interface Progress { void update(String name); }
    public static final Progress QUIET = name -> {};

    private final FileStore store;
    public FileEngine(FileStore store) { this.store = store; }

    public static void validateName(String name) {
        if (name == null || name.trim().isEmpty() || name.equals(".") || name.equals("..") ||
                name.contains("/") || name.contains("\\") || name.length() > 240) {
            throw new IllegalArgumentException("올바르지 않은 파일 이름입니다.");
        }
        for (char c : name.toCharArray()) {
            if (Character.isISOControl(c)) throw new IllegalArgumentException("제어 문자는 이름에 사용할 수 없습니다.");
        }
    }

    public String availableName(String parent, String requested) throws Exception {
        validateName(requested);
        Set<String> existing = new HashSet<>();
        for (FileNode f : store.list(parent)) existing.add(f.name.toLowerCase(Locale.ROOT));
        if (!existing.contains(requested.toLowerCase(Locale.ROOT))) return requested;
        int dot = requested.lastIndexOf('.');
        String base = dot > 0 ? requested.substring(0, dot) : requested;
        String ext = dot > 0 ? requested.substring(dot) : "";
        for (int n = 1; n < 10_000; n++) {
            String candidate = base + " (" + n + ")" + ext;
            if (candidate.length() > 240) throw new IllegalArgumentException("파일 이름이 너무 깁니다.");
            if (!existing.contains(candidate.toLowerCase(Locale.ROOT))) return candidate;
        }
        throw new IllegalStateException("고유한 이름을 만들 수 없습니다.");
    }

    public FileNode newFolder(String parent, String name) throws Exception {
        validateName(name);
        return store.mkdir(parent, availableName(parent, name));
    }

    public FileNode newFile(String parent, String name) throws Exception {
        validateName(name);
        return store.mkfile(parent, availableName(parent, name), mimeOf(name));
    }

    public FileNode rename(String id, String name, String parentId) throws Exception {
        validateName(name);
        for (FileNode sibling : store.list(parentId)) {
            if (!sibling.id.equals(id) && sibling.name.equalsIgnoreCase(name)) {
                throw new IllegalArgumentException("같은 이름의 파일이 이미 있습니다.");
            }
        }
        return store.rename(id, name);
    }

    /** Copy all selected items into destination; move deletes each original only after complete copy. */
    public void transfer(List<String> ids, String destination, boolean move, Progress progress) throws Exception {
        if (ids.isEmpty()) return;
        for (String id : ids) {
            FileNode source = store.stat(id);
            if (id.equals(destination)) throw new IllegalArgumentException("폴더를 자기 자신에 넣을 수 없습니다.");
            if (source.directory && contains(source.id, destination, 0, new HashSet<>())) {
                throw new IllegalArgumentException("폴더를 자신의 하위 폴더로 옮길 수 없습니다.");
            }
        }
        for (String id : ids) {
            FileNode source = store.stat(id);
            boolean alreadyInDestination = false;
            for (FileNode child : store.list(destination)) {
                if (child.id.equals(id)) { alreadyInDestination = true; break; }
            }
            if (move && alreadyInDestination) continue;
            copyNode(source, destination, 0, move, progress);
            if (move) store.delete(id);
        }
    }

    private boolean contains(String ancestor, String target, int depth, Set<String> visited) throws Exception {
        if (ancestor.equals(target)) return true;
        if (depth >= MAX_DEPTH) throw new IllegalArgumentException("폴더 중첩 깊이가 제한을 초과했습니다.");
        if (!visited.add(ancestor)) return false;
        for (FileNode child : store.list(ancestor)) {
            if (child.id.equals(target)) return true;
            if (child.directory && contains(child.id, target, depth + 1, visited)) return true;
        }
        return false;
    }

    private void copyNode(FileNode node, String dest, int depth, boolean verify, Progress progress) throws Exception {
        if (depth > MAX_DEPTH) throw new IllegalArgumentException("폴더가 너무 깊습니다.");
        progress.update(node.name);
        String newName = availableName(dest, node.name);
        if (node.directory) {
            FileNode copied = store.mkdir(dest, newName);
            try {
                for (FileNode child : store.list(node.id)) copyNode(child, copied.id, depth + 1, verify, progress);
            } catch (Exception e) {
                // Best-effort cleanup of a partially created destination; original stays intact.
                try { store.delete(copied.id); } catch (Exception ignored) { }
                throw e;
            }
        } else {
            FileNode copied = store.mkfile(dest, newName, node.mime);
            try {
                MessageDigest sourceHash = verify ? MessageDigest.getInstance("SHA-256") : null;
                try (InputStream in = store.read(node.id); OutputStream out = store.write(copied.id)) {
                    byte[] block = new byte[BUFFER]; int size;
                    while ((size = in.read(block)) != -1) {
                        out.write(block, 0, size);
                        if (verify) sourceHash.update(block, 0, size);
                    }
                }
                // Before removing the original, verify the destination bytes on the actual provider.
                if (verify) {
                    MessageDigest targetHash = MessageDigest.getInstance("SHA-256");
                    try (InputStream in = store.read(copied.id)) {
                        byte[] block = new byte[BUFFER]; int size;
                        while ((size = in.read(block)) != -1) targetHash.update(block, 0, size);
                    }
                    if (!Arrays.equals(sourceHash.digest(), targetHash.digest())) {
                        throw new IOException("이동 사본 검증에 실패했습니다. 원본은 유지됩니다.");
                    }
                }
            } catch (Exception e) {
                try { store.delete(copied.id); } catch (Exception ignored) { }
                throw e;
            }
        }
    }

    public static long pump(InputStream in, OutputStream out, long max) throws Exception {
        byte[] bytes = new byte[BUFFER];
        long count = 0;
        int read;
        while ((read = in.read(bytes)) != -1) {
            count += read;
            if (count > max) throw new IllegalArgumentException("용량 제한을 초과했습니다.");
            out.write(bytes, 0, read);
        }
        return count;
    }

    public FileNode makeZip(List<String> ids, String directory, String requested, Progress progress) throws Exception {
        if (ids.isEmpty()) throw new IllegalArgumentException("압축할 파일을 선택하세요.");
        validateName(requested);
        if (!requested.toLowerCase(Locale.ROOT).endsWith(".zip")) requested += ".zip";
        for (String id : ids) {
            FileNode node = store.stat(id);
            if (node.directory && contains(node.id, directory, 0, new HashSet<>())) {
                throw new IllegalArgumentException("압축할 폴더 내부에는 ZIP을 만들 수 없습니다.");
            }
        }
        FileNode zip = store.mkfile(directory, availableName(directory, requested), "application/zip");
        int[] entries = {0}; long[] total = {0};
        try (OutputStream stream = store.write(zip.id); ZipOutputStream out = new ZipOutputStream(stream)) {
            Set<String> visited = new HashSet<>();
            for (String id : ids) addToZip(store.stat(id), "", out, 0, entries, total, visited, progress);
        } catch (Exception e) {
            try { store.delete(zip.id); } catch (Exception ignored) { }
            throw e;
        }
        return zip;
    }

    private void addToZip(FileNode node, String prefix, ZipOutputStream out, int depth,
                          int[] entries, long[] total, Set<String> visited, Progress progress) throws Exception {
        if (depth > MAX_DEPTH || ++entries[0] > MAX_ZIP_ENTRIES) throw new IllegalArgumentException("ZIP 항목/깊이 제한을 초과했습니다.");
        if (!visited.add(node.id)) throw new IllegalArgumentException("순환 폴더가 감지되었습니다.");
        String path = prefix + node.name + (node.directory ? "/" : "");
        out.putNextEntry(new ZipEntry(path));
        if (!node.directory) {
            progress.update(node.name);
            try (InputStream in = store.read(node.id)) {
                byte[] buf = new byte[BUFFER]; int read;
                while ((read = in.read(buf)) != -1) {
                    total[0] += read;
                    if (total[0] > MAX_ARCHIVE_BYTES) throw new IllegalArgumentException("ZIP 총 용량 제한을 초과했습니다.");
                    out.write(buf, 0, read);
                }
            }
        }
        out.closeEntry();
        if (node.directory) {
            for (FileNode child : store.list(node.id)) addToZip(child, path, out, depth + 1, entries, total, visited, progress);
        }
        visited.remove(node.id);
    }

    /** All extracted paths stay under a new folder; reject traversal, absolute paths, and huge archives. */
    public FileNode extractZip(String zipId, String destination, Progress progress) throws Exception {
        FileNode zip = store.stat(zipId);
        if (zip.directory || !zip.name.toLowerCase(Locale.ROOT).endsWith(".zip")) {
            throw new IllegalArgumentException("ZIP 파일만 압축 해제할 수 있습니다.");
        }
        String stem = zip.name.substring(0, zip.name.length() - 4);
        FileNode output = store.mkdir(destination, availableName(destination, stem + " (압축 해제)"));
        Map<String, String> dirs = new HashMap<>();
        dirs.put("", output.id);
        int count = 0;
        long total = 0;
        try (PushbackInputStream stream = new PushbackInputStream(store.read(zipId), 4)) {
            byte[] signature = new byte[4];
            int length = stream.read(signature);
            if (length != 4 || signature[0] != 'P' || signature[1] != 'K' ||
                    (signature[2] != 3 && signature[2] != 5 && signature[2] != 7) ||
                    (signature[3] != 4 && signature[3] != 6 && signature[3] != 8)) {
                throw new IllegalArgumentException("유효하지 않은 ZIP 형식입니다.");
            }
            stream.unread(signature);
            try (ZipInputStream in = new ZipInputStream(stream)) {
            ZipEntry entry;
            while ((entry = in.getNextEntry()) != null) {
                if (++count > MAX_ZIP_ENTRIES) throw new IllegalArgumentException("ZIP 항목 수 제한을 초과했습니다.");
                String name = entry.getName();
                List<String> components = safeZipPath(name);
                String parent = "";
                int end = entry.isDirectory() ? components.size() : components.size() - 1;
                for (int i = 0; i < end; i++) {
                    String segment = components.get(i);
                    String key = parent + "/" + segment;
                    if (!dirs.containsKey(key)) {
                        dirs.put(key, store.mkdir(dirs.get(parent), segment).id);
                    }
                    parent = key;
                }
                if (!entry.isDirectory()) {
                    String filename = components.get(components.size() - 1);
                    progress.update(filename);
                    String folder = dirs.get(parent);
                    FileNode outputFile = store.mkfile(folder, availableName(folder, filename), mimeOf(filename));
                    try (OutputStream out = store.write(outputFile.id)) {
                        byte[] buf = new byte[BUFFER]; int n;
                        while ((n = in.read(buf)) != -1) {
                            total += n;
                            if (total > MAX_ARCHIVE_BYTES) throw new IllegalArgumentException("ZIP 해제 용량 제한을 초과했습니다.");
                            out.write(buf, 0, n);
                        }
                    }
                }
                in.closeEntry();
            }
            if (count == 0 && !(signature[2] == 5 && signature[3] == 6)) {
                throw new IllegalArgumentException("ZIP 항목을 확인할 수 없습니다.");
            }
            }
        } catch (Exception e) {
            try { store.delete(output.id); } catch (Exception ignored) { }
            throw e;
        }
        return output;
    }

    public static List<String> safeZipPath(String path) {
        if (path == null || path.isEmpty() || path.startsWith("/") || path.startsWith("\\") ||
                path.contains("\\") || (path.length() > 1 && path.charAt(1) == ':')) {
            throw new IllegalArgumentException("위험한 ZIP 경로입니다.");
        }
        List<String> parts = new ArrayList<>();
        for (String part : path.split("/")) {
            if (part.isEmpty()) continue;
            validateName(part);
            parts.add(part);
        }
        if (parts.isEmpty() || parts.size() > MAX_DEPTH) throw new IllegalArgumentException("ZIP 경로 길이 제한을 초과했습니다.");
        return parts;
    }

    public static String mimeOf(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".mp4")) return "video/mp4";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".zip")) return "application/zip";
        if (n.endsWith(".txt") || n.endsWith(".md") || n.endsWith(".csv")) return "text/plain";
        if (n.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    public static final class SearchHit {
        public final FileNode file;
        public final String relativePath;
        public final String parentId;
        public SearchHit(FileNode file, String relativePath, String parentId) { this.file = file; this.relativePath = relativePath; this.parentId = parentId; }
    }

    public List<SearchHit> search(String start, String term, int maxResults) throws Exception {
        if (term == null || term.trim().isEmpty()) return Collections.emptyList();
        List<SearchHit> result = new ArrayList<>();
        searchIn(start, "", term.toLowerCase(Locale.ROOT), result, maxResults, 0, new int[]{0});
        return result;
    }

    private void searchIn(String parent, String path, String term, List<SearchHit> result,
                          int limit, int depth, int[] scanned) throws Exception {
        if (depth > MAX_DEPTH || result.size() >= limit || scanned[0] >= 20_000) return;
        for (FileNode node : store.list(parent)) {
            if (++scanned[0] > 20_000 || result.size() >= limit) return;
            String rel = path + node.name;
            if (node.name.toLowerCase(Locale.ROOT).contains(term)) result.add(new SearchHit(node, rel, parent));
            if (node.directory) searchIn(node.id, rel + "/", term, result, limit, depth + 1, scanned);
        }
    }
}

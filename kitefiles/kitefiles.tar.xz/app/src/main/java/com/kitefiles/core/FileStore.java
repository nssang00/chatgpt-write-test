package com.kitefiles.core;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/** Storage-provider-neutral API, keeping Android ContentResolver out of the tested engine. */
public interface FileStore {
    FileNode stat(String id) throws Exception;
    List<FileNode> list(String directoryId) throws Exception;
    FileNode mkdir(String parentId, String name) throws Exception;
    FileNode mkfile(String parentId, String name, String mime) throws Exception;
    InputStream read(String id) throws Exception;
    OutputStream write(String id) throws Exception;
    void delete(String id) throws Exception;
    FileNode rename(String id, String name) throws Exception;
}

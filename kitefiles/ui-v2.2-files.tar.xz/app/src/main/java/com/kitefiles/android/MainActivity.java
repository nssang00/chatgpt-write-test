package com.kitefiles.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.widget.PopupWindow;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.view.MotionEvent;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.content.Context;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.FrameLayout;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;
import android.widget.Toast;

import com.kitefiles.core.FileEngine;
import com.kitefiles.core.FileNode;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** File manager: multiwindow local + SAF + SMB. No ads/analytics. */
public final class MainActivity extends Activity {
    private static final int PICK_TREE = 101;
    private static final int STORAGE_PERM = 102;
    private int pendingLocal = -1;
    private float gestureX, gestureY;
    private final ArrayList<TabState> tabs = new ArrayList<>();
    private int activeTab = -1;
    private static final class TabState {
        String name, root, folder;
        Page page = Page.FOLDER;
        final ArrayList<Crumb> path = new ArrayList<>();
        final ArrayList<FileNode> files = new ArrayList<>();
        TabState(String name, String root) {
            this.name=name; this.root=root; this.folder=root;
            this.path.add(new Crumb(name,root));
        }
    }
    private static final int BG = 0xFFFFFFFF;
    private static final int INK = 0xFF30445A;
    private static final int MUTED = 0xFF89929F;
    private static final int BLUE = 0xFF1769DF;
    private static final int ES_FOLDER = 0xFF78AFF6;
    private static final int PALE = 0xFFEAF3FF;
    private static final int BORDER = 0xFFF0F2F6;
    private static final int DANGER = 0xFFC32940;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService jobs = Executors.newSingleThreadExecutor();
    private final ArrayList<Crumb> path = new ArrayList<>();
    private final ArrayList<FileNode> visible = new ArrayList<>();
    private final ArrayList<FileEngine.SearchHit> hits = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private final ArrayList<String> clipboard = new ArrayList<>();
    private final Map<String, String> parentOfHit = new HashMap<>();

    private enum Page { HOME, FOLDER, RESULTS }
    private Page page = Page.HOME;
    private LinearLayout frame;
    private FrameLayout rootOverlay;
    private View drawerShade;
    private View drawerView;
    private LinearLayout drawerPanel;
    private ScrollView fileScroller;
    private PopupWindow topOptions;
    private View floatingCreate;
    private boolean compactRows;
    private boolean showHidden;
    private boolean foldersFirst = true;
    private boolean reverseSort;
    private String nameFilter = "";
    private final Map<String, Integer> childrenCache = new HashMap<>();
    private boolean drawerOpen;
    private boolean swipeTracking;
    private boolean swipeHorizontal;
    private float startX, startY;

    private LinearLayout body;
    private TextView info;
    private UnifiedStore store;
    private String activeTree;
    private String folder;
    private String clipboardTree;
    private boolean cut = false;
    private boolean busy = false;
    private String busyLabel = "";
    private String query = "";
    private int sort = 0; // 0 name, 1 date, 2 size
    private int requestSerial = 0;
    private final DateFormat date = DateFormat.getDateInstance(DateFormat.SHORT, Locale.KOREA);

    private static final class Crumb {
        final String name, id;
        Crumb(String name, String id) { this.name = name; this.id = id; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF1465D6);
        getWindow().setNavigationBarColor(0xFF111317);
        getWindow().getDecorView().setSystemUiVisibility(0);
        try {
            ArrayList<File> roots = new ArrayList<>();
            roots.add(Environment.getExternalStorageDirectory());
            if (Build.VERSION.SDK_INT >= 30) {
                StorageManager sm = (StorageManager) getSystemService(STORAGE_SERVICE);
                if (sm != null) for (StorageVolume volume : sm.getStorageVolumes()) {
                    File directory = volume.getDirectory();
                    if (directory != null && !roots.contains(directory)) roots.add(directory);
                }
            }
            store = new UnifiedStore(this, new LocalFileStore(roots));
            for (String tree : savedTrees()) {
                try { store.registerDocument(tree); } catch (Exception ignored) { }
            }
        } catch (Exception e) { Toast.makeText(this,"저장소 초기화 오류: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
        compactRows = prefs().getBoolean("compact_rows",false);
        showHidden = prefs().getBoolean("show_hidden",false);
        foldersFirst = prefs().getBoolean("folders_first",true);
        reverseSort = prefs().getBoolean("reverse_sort",false);
        frame = new LinearLayout(this);
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            frame.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets system = insets.getInsets(WindowInsets.Type.systemBars());
                frame.setPadding(system.left, system.top, system.right, system.bottom);
                return insets;
            });
        }
        rootOverlay = new FrameLayout(this);
        rootOverlay.addView(frame, new FrameLayout.LayoutParams(-1, -1));
        setContentView(rootOverlay);
        draw();
    }

    @Override protected void onDestroy() {
        jobs.shutdownNow();
        super.onDestroy();
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width < 0 ? width : dp(width), height < 0 ? height : dp(height));
    }
    private void space(LinearLayout parent, int height) { parent.addView(new View(this), lp(1, height)); }
    private TextView action(String label, boolean primary, Runnable onClick) {
        TextView t = text(label, 13, primary ? Color.WHITE : BLUE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(shape(primary ? BLUE : PALE, 12, 0));
        t.setMinHeight(dp(44));
        t.setContentDescription(label);
        t.setOnClickListener(v -> { if (!busy) onClick.run(); });
        return t;
    }
    private void actionInto(LinearLayout bar, String label, boolean primary, Runnable click) {
        TextView a = action(label, primary, click);
        LinearLayout.LayoutParams p = lp(-2, 44);
        p.setMargins(0, 0, dp(8), 0);
        bar.addView(a, p);
    }
    private void caption(LinearLayout into, String msg) {
        TextView t = text(msg, 12, MUTED, false);
        into.addView(t, lp(-1, -2));
    }
    private void snack(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    private String message(Exception e) {
        Throwable t = e;
        while (t.getCause() != null && (t.getMessage() == null || t.getMessage().isEmpty())) t = t.getCause();
        return t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
    }

    private void draw() {
        if (topOptions != null && topOptions.isShowing()) topOptions.dismiss();
        if (floatingCreate != null && rootOverlay != null && floatingCreate.getParent() == rootOverlay)
            rootOverlay.removeView(floatingCreate);
        floatingCreate = null;
        frame.removeAllViews();
        LinearLayout header = vertical();
        header.setBackgroundColor(BLUE);
        frame.addView(header, lp(-1, -2));
        LinearLayout top = horizontal();
        top.setPadding(dp(6), dp(3), dp(8), dp(3));
        header.addView(top, lp(-1, 57));
        TextView logo = toolbarIcon("☰", "탐색 메뉴", this::showDrawer);
        top.addView(logo, lp(52, 50));
        LinearLayout brand = vertical();
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        String location = path.isEmpty() || page == Page.HOME ? "내 파일" : path.get(path.size() - 1).name;
        TextView title = text(location, 19, Color.WHITE, true);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        brand.addView(title);
        brand.addView(text(page == Page.HOME ? "로컬 · 네트워크 · 탐색 창" : visible.size() + "개 항목", 11, 0xFFE1EBFF, false));
        if (page != Page.HOME) top.addView(toolbarIcon("+", "새로 만들기", this::showCreateMenu), lp(43, 49));
        top.addView(toolbarIcon("⌕", "파일 검색", () -> {
            if (page != Page.HOME) promptSearch(); else openLocal(0);
        }), lp(43,49));
        TextView more = toolbarIcon("⋮", "옵션", () -> {});
        more.setOnClickListener(v -> showTopOptions(more));
        top.addView(more, lp(39, 49));

        drawTabs(header);
        if (page == Page.HOME) {
            header.setPadding(0,0,0,dp(8));
        } else {
            drawFolderHeaderBelowBar();
        }
        ScrollView scroll = new ScrollView(this);
        fileScroller = scroll;
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(page == Page.HOME ? dp(14) : dp(3), dp(6), page == Page.HOME ? dp(14) : dp(3), dp(8));
        frame.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        body = vertical();
        scroll.addView(body);
        if (page == Page.HOME) drawLocations();
        else drawFiles();
        drawFooter();
        if (page == Page.FOLDER && selected.isEmpty() && clipboard.isEmpty()) {
            TextView fab = text("+", 34, Color.WHITE, false);
            fab.setGravity(Gravity.CENTER);
            fab.setBackground(shape(0xFF80507D, 60, 0));
            fab.setElevation(dp(8));
            fab.setContentDescription("새로 만들기");
            fab.setOnClickListener(v -> showCreateMenu());
            FrameLayout.LayoutParams fabParams = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM | Gravity.END);
            fabParams.setMargins(0,0,dp(16),dp(25));
            rootOverlay.addView(fab, fabParams);
            floatingCreate = fab;
        }
    }

    private TextView toolbarIcon(String glyph, String description, Runnable callback) {
        TextView view = text(glyph, 27, Color.WHITE, false);
        view.setGravity(Gravity.CENTER);
        view.setContentDescription(description);
        view.setOnClickListener(v -> { if (!busy) callback.run(); });
        return view;
    }

    private void drawFolderHeaderBelowBar() {
        LinearLayout pathBar = horizontal();
        pathBar.setPadding(dp(9), dp(5), dp(6), dp(5));
        pathBar.setBackgroundColor(Color.WHITE);
        frame.addView(pathBar, lp(-1, 49));
        TextView homeButton = text("⌂", 27, 0xFF9EA6AE, true);
        homeButton.setGravity(Gravity.CENTER);
        homeButton.setBackground(shape(0xFFF0F4FA, 7, BORDER));
        homeButton.setOnClickListener(v -> goHome());
        homeButton.setContentDescription("홈");
        pathBar.addView(homeButton, lp(42, 40));
        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout.LayoutParams trailParams = new LinearLayout.LayoutParams(0, -1, 1);
        trailParams.leftMargin=dp(8);
        pathBar.addView(scroller, trailParams);
        LinearLayout trail = horizontal(); scroller.addView(trail);
        for (int i=0; i<path.size(); i++) {
            Crumb crumb=path.get(i); final int index=i;
            TextView textCrumb=text(crumb.name, 14, INK, i==path.size()-1);
            textCrumb.setSingleLine(true);
            textCrumb.setPadding(dp(4),0,dp(4),0);
            textCrumb.setOnClickListener(v -> { if (!busy) navigateBackTo(index); });
            trail.addView(textCrumb);
            if (i < path.size()-1) trail.addView(text(" › ", 16, MUTED, false));
        }
        scroller.post(() -> scroller.fullScroll(View.FOCUS_RIGHT));
        TextView percent = text("내 파일", 11, BLUE, true);
        percent.setGravity(Gravity.CENTER);
        percent.setBackground(shape(0xFFEAF3FF, 7, BORDER));
        percent.setPadding(dp(8),0,dp(8),0);
        pathBar.addView(percent, lp(-2, 34));
    }

    private void showTopOptions(View anchor) {
        if (topOptions != null && topOptions.isShowing()) { topOptions.dismiss(); return; }
        LinearLayout container = vertical();
        container.setPadding(dp(3),dp(6),dp(3),dp(6));
        container.setBackground(shape(0xFF20232B, 15, 0));
        int width = Math.min(dp(253), (int)(getResources().getDisplayMetrics().widthPixels * 0.76f));
        topOptions = new PopupWindow(container, width, -2, true);
        topOptions.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        topOptions.setOutsideTouchable(true);
        topOptions.setElevation(dp(14));
        topOption(container, "▣", "분석", () -> analyzeFolder());
        topOption(container, "▦", "모두 선택", () -> {
            if (page == Page.HOME) { snack("폴더를 열고 선택하세요."); return; }
            List<FileNode> shown = listedItems();
            selected.clear(); for (FileNode f : shown) selected.add(f.id);
            draw();
        });
        topOption(container, "ⓘ", "속성", this::showProperties);
        topOption(container, "☷", "보기 옵션", this::showViewOptions);
        topOption(container, "≡", "필터", this::showNameFilter);
        topOption(container, "☷", "폴더 옵션  ›", this::showFolderOptions);
        topOption(container, "↗", "작업", this::showTaskOptions);
        topOptions.showAsDropDown(anchor, 0, -dp(7), Gravity.END);
    }

    private void topOption(LinearLayout into, String glyph, String label, Runnable action) {
        LinearLayout row = horizontal();
        row.setPadding(dp(15),0,dp(10),0);
        into.addView(row, lp(-1, 49));
        TextView icon = text(glyph, 21, 0xFFA8C6FF, true);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, lp(34,-1));
        TextView title=text(label, 16, 0xFFF1F2F5, true);
        title.setPadding(dp(9),0,0,0);
        row.addView(title, new LinearLayout.LayoutParams(0,-1,1));
        row.setContentDescription(label);
        row.setOnClickListener(v -> {
            if (topOptions != null) topOptions.dismiss();
            if (!busy) action.run();
        });
    }

    private void analyzeFolder() {
        if (page == Page.HOME) { snack("분석할 폴더를 먼저 열어주세요."); return; }
        int directories=0, files=0; long bytes=0;
        for (FileNode item:visible) {
            if (item.directory) directories++; else { files++; bytes+=Math.max(0,item.size); }
        }
        new AlertDialog.Builder(this).setTitle("현재 폴더 분석")
                .setMessage("폴더: " + directories + "개\n파일: " + files + "개\n직접 포함된 파일 크기: " + readableSize(bytes)
                        + "\n\n하위 폴더 전체 크기는 포함하지 않습니다.")
                .setPositiveButton("확인",null).show();
    }

    private void showProperties() {
        if (page == Page.HOME) { snack("폴더를 먼저 열어주세요."); return; }
        String current = folder;
        runJob("속성 확인 중", () -> store.stat(current), item ->
            new AlertDialog.Builder(this).setTitle(item.name)
                .setMessage("위치: " + item.id + "\n형식: " + (item.directory ? "폴더" : item.mime)
                    + "\n현재 폴더 항목: " + visible.size() + "개"
                    + "\n수정: " + (item.modified > 0 ? date.format(item.modified) : "알 수 없음"))
                .setPositiveButton("확인",null).show());
    }

    private void showViewOptions() {
        new AlertDialog.Builder(this).setTitle("보기 옵션")
            .setSingleChoiceItems(new String[]{"이름순", "수정일순", "크기순", "간격: " + (compactRows ? "좁게" : "넓게"),
                    "정렬 방향: " + (reverseSort ? "내림차순" : "오름차순")},sort,(d,choice)->{
                if (choice <= 2) sort=choice;
                else if (choice == 3) { compactRows=!compactRows; prefs().edit().putBoolean("compact_rows",compactRows).apply(); }
                else { reverseSort=!reverseSort; prefs().edit().putBoolean("reverse_sort",reverseSort).apply(); }
                d.dismiss(); draw();
            }).setNegativeButton("닫기",null).show();
    }

    private void showNameFilter() {
        if (page == Page.HOME) { snack("폴더를 먼저 열어주세요."); return; }
        EditText filter = new EditText(this); filter.setSingleLine(true);
        filter.setHint("이름에 포함된 단어"); filter.setText(nameFilter);
        new AlertDialog.Builder(this).setTitle("현재 폴더 필터")
            .setView(filter)
            .setNeutralButton("필터 해제",(d,w)-> { nameFilter="";draw(); })
            .setNegativeButton("취소",null)
            .setPositiveButton("적용",(d,w)->{ nameFilter=filter.getText().toString().trim();draw(); }).show();
    }

    private void showFolderOptions() {
        final boolean[] chosen = {showHidden,foldersFirst,compactRows};
        new AlertDialog.Builder(this).setTitle("폴더 옵션")
            .setMultiChoiceItems(new String[]{"숨김 파일 표시", "폴더를 파일보다 먼저 표시", "촘촘한 파일 목록"},chosen,
                (d,index,value)->chosen[index]=value)
            .setNegativeButton("취소",null)
            .setPositiveButton("적용",(d,w)->{
                showHidden=chosen[0];foldersFirst=chosen[1];compactRows=chosen[2];
                prefs().edit().putBoolean("show_hidden",showHidden)
                    .putBoolean("folders_first",foldersFirst).putBoolean("compact_rows",compactRows).apply();
                draw();
            }).show();
    }

    private void showTaskOptions() {
        new AlertDialog.Builder(this).setTitle("파일 작업")
            .setItems(new String[]{"새로 고침", "새 폴더 / 파일", "붙여넣기 ("+clipboard.size()+"개)", "선택 해제"},
                (d,which)->{
                    if (which==0) { if (page!=Page.HOME) refresh(); else draw(); }
                    else if (which==1) showCreateMenu();
                    else if (which==2) { if (clipboard.isEmpty()) snack("복사하거나 이동할 파일을 먼저 선택하세요."); else paste(); }
                    else { selected.clear(); draw(); }
                }).show();
    }

    private void drawHomeHeader(LinearLayout header) {
        LinearLayout intro = vertical();
        intro.setPadding(dp(18), dp(18), dp(18), dp(18));
        intro.setBackground(shape(PALE, 18, 0));
        header.addView(intro, lp(-1, -2));
        intro.addView(text("저장소 · 탐색 창 · LAN", 19, INK, true));
        space(intro, 8);
        caption(intro, "전체 공유 저장소를 탐색하거나 SMB 네트워크 폴더에 연결하세요.\n상단 창을 누르거나 좌우로 밀어 작업 공간을 전환합니다.");
        space(intro, 16);
        LinearLayout bar = horizontal();
        intro.addView(bar);
        actionInto(bar, "내부 저장소", true, () -> openLocal(0));
        actionInto(bar, "+ 폴더 연결", false, this::pickFolder);
        space(intro, 8);
        LinearLayout networkBar = horizontal(); intro.addView(networkBar);
        actionInto(networkBar, "LAN · SMB 연결", false, this::promptSmb);
    }

    private void drawTabs(LinearLayout header) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        header.addView(scroll, lp(-1, 45));
        LinearLayout bar = horizontal(); scroll.addView(bar);
        for (int i=0;i<tabs.size();i++) {
            final int index=i;
            TabState tab=tabs.get(i);
            TextView chip = text("▣  " + tab.name, 13,
                    Color.WHITE, i==activeTab && page!=Page.HOME);
            chip.setPadding(dp(12),0,dp(12),0); chip.setGravity(Gravity.CENTER);
            chip.setBackground(shape((i==activeTab && page!=Page.HOME) ? 0xFF61A1EB : 0xFF3280E6,20,0));
            LinearLayout.LayoutParams pp=lp(-2,39); pp.rightMargin=dp(7); bar.addView(chip,pp);
            chip.setOnClickListener(v -> { if (!busy) activateTab(index); });
            chip.setOnLongClickListener(v -> { if (!busy) new AlertDialog.Builder(this)
                    .setTitle("탐색 창 닫기").setMessage(tab.name)
                    .setNegativeButton("취소",null).setPositiveButton("닫기",(d,w)->closeTab(index)).show(); return true; });
        }
        TextView newTab=text("+ 새 창", 13, Color.WHITE, true);
        newTab.setGravity(Gravity.CENTER);
        newTab.setBackground(shape(0xFF3280E6,20,0));
        newTab.setPadding(dp(13),0,dp(13),0);
        bar.addView(newTab, lp(-2,39));
        newTab.setOnClickListener(v -> {
            if (page==Page.FOLDER && activeTab>=0) createTab("새 창",tabs.get(activeTab).root);
            else openLocal(0);
        });
    }
    private void saveActive() {
        if (activeTab<0 || activeTab>=tabs.size() || page==Page.HOME) return;
        TabState tab=tabs.get(activeTab);
        tab.folder=folder; tab.page=page;
        tab.path.clear(); tab.path.addAll(path);
        tab.files.clear(); tab.files.addAll(visible);
    }
    private void activateTab(int index) {
        if (index<0 || index>=tabs.size()) return;
        saveActive(); activeTab=index;
        TabState tab=tabs.get(index);
        activeTree=tab.root; folder=tab.folder; page=tab.page==Page.RESULTS ? Page.FOLDER : tab.page;
        path.clear(); path.addAll(tab.path);
        visible.clear(); visible.addAll(tab.files);
        selected.clear(); hits.clear();
        refresh();
    }
    private void createTab(String name,String root) {
        if (tabs.size() >= 10) { snack("창은 최대 10개까지 열 수 있습니다."); return; }
        tabs.add(new TabState(name,root));
        activateTab(tabs.size()-1);
    }
    private void closeTab(int index) {
        if (index<0 || index>=tabs.size()) return;
        tabs.remove(index);
        activeTab=-1; page=Page.HOME;
        if (!tabs.isEmpty()) activateTab(Math.min(index,tabs.size()-1));
        else goHome();
    }
    private void drawFolderHeader(LinearLayout header) {
        TextView section = text(page == Page.RESULTS ? "검색 결과" : "폴더 탐색", 19, INK, true);
        header.addView(section, lp(-1, 34));
        HorizontalScrollView scroller = new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        header.addView(scroller, lp(-1, 46));
        LinearLayout trail = horizontal();
        scroller.addView(trail);
        for (int i = 0; i < path.size(); i++) {
            Crumb c = path.get(i);
            final int index = i;
            TextView crumb = text(c.name, 13, i == path.size() - 1 ? INK : BLUE, i == path.size() - 1);
            crumb.setMinHeight(dp(40));
            crumb.setPadding(dp(4), 0, dp(4), 0);
            crumb.setOnClickListener(v -> { if (!busy) navigateBackTo(index); });
            trail.addView(crumb);
            if (i != path.size() - 1) trail.addView(text("  ›  ", 13, MUTED, false));
        }
        LinearLayout actions = horizontal();
        header.addView(actions, lp(-1, 44));
        actionInto(actions, "⌕ 검색", false, this::promptSearch);
        actionInto(actions, sort == 0 ? "이름순" : sort == 1 ? "최신순" : "크기순", false, () -> { sort = (sort + 1) % 3; draw(); });
        actionInto(actions, "+ 만들기", false, this::showCreateMenu);
        if (page == Page.RESULTS) {
            TextView count = text("‘" + query + "’", 12, MUTED, false);
            header.addView(count);
        }
    }

    private SharedPreferences prefs() { return getSharedPreferences("places", MODE_PRIVATE); }
    private Set<String> savedTrees() { return new HashSet<>(prefs().getStringSet("trees", Collections.emptySet())); }
    private String labelOf(String tree) { return prefs().getString("label:" + tree, "연결된 폴더"); }

    private void drawLocations() {
        if (store != null) for (int i=0;i<store.localRootCount();i++) {
            final int index=i;
            LinearLayout disk = horizontal();
            disk.setPadding(dp(18),dp(12),dp(12),dp(12));
            disk.setBackground(shape(Color.WHITE,16,BORDER));
            LinearLayout.LayoutParams dp=lp(-1,76); dp.bottomMargin=dp(10);body.addView(disk,dp);
            disk.addView(text("▣",29,BLUE,true),lp(48,-1));
            LinearLayout lines=vertical();disk.addView(lines,new LinearLayout.LayoutParams(0,-2,1));
            lines.addView(text(i==0?"내부 저장소":"외장 저장소 " + i,16,INK,true));
            lines.addView(text("전체 폴더 · 접근 권한 필요",11,MUTED,false));
            disk.addView(text("›",25,BLUE,true));
            disk.setOnClickListener(v -> openLocal(index));
        }
        LinearLayout net = horizontal(); net.setPadding(dp(18),dp(12),dp(12),dp(12));
        net.setBackground(shape(Color.WHITE,16,BORDER));
        LinearLayout.LayoutParams np=lp(-1,72); np.bottomMargin=dp(10);body.addView(net,np);
        net.addView(text("☷",27,BLUE,true),lp(48,-1));
        net.addView(text("네트워크 · LAN / SMB2/3",16,INK,true),new LinearLayout.LayoutParams(0,-2,1));
        net.addView(text("+",24,BLUE,true));
        net.setOnClickListener(v -> promptSmb());
        TextView title = text("선택한 문서 폴더(SAF)", 17, INK, true);
        body.addView(title, lp(-1, 46));
        List<String> trees = new ArrayList<>(savedTrees());
        trees.sort(Comparator.comparing(this::labelOf, String.CASE_INSENSITIVE_ORDER));
        if (trees.isEmpty()) {
            LinearLayout empty = vertical();
            empty.setPadding(dp(18), dp(28), dp(18), dp(30));
            empty.setGravity(Gravity.CENTER_HORIZONTAL);
            empty.setBackground(shape(Color.WHITE, 16, BORDER));
            body.addView(empty, lp(-1, -2));
            empty.addView(text("📂", 38, BLUE, true));
            space(empty, 8);
            empty.addView(text("연결된 폴더가 없습니다", 16, INK, true));
            space(empty, 8);
            caption(empty, "‘폴더 연결’을 눌러 문서, 사진 또는 작업 폴더를 선택하세요.");
        }
        for (String tree : trees) {
            LinearLayout card = horizontal();
            card.setPadding(dp(16), dp(13), dp(12), dp(13));
            card.setBackground(shape(Color.WHITE, 16, BORDER));
            LinearLayout.LayoutParams margins = lp(-1, 78);
            margins.bottomMargin = dp(10);
            body.addView(card, margins);
            card.addView(text("📁", 27, BLUE, false), lp(48, -1));
            LinearLayout names = vertical();
            card.addView(names, new LinearLayout.LayoutParams(0, -2, 1));
            names.addView(text(labelOf(tree), 15, INK, true));
            names.addView(text("탭하여 열기 · 길게 눌러 연결 해제", 11, MUTED, false));
            card.addView(text("›", 25, BLUE, true), lp(20, -1));
            card.setOnClickListener(v -> { if (!busy) openTree(tree); });
            card.setOnLongClickListener(v -> { if (!busy) confirmRemove(tree); return true; });
        }
        space(body, 18);
        caption(body, "전체 저장소: Android의 '모든 파일 접근' 허용이 필요합니다.\n보호된 Android/data·obb 및 시스템 폴더는 접근이 제한될 수 있습니다.\nLAN 비밀번호는 기기에 저장하지 않습니다.");
    }

    private String subtitle(FileNode node) {
        if (node.directory) return "폴더" + (node.modified > 0 ? "  ·  " + date.format(node.modified) : "");
        return (node.size < 0 ? "크기 알 수 없음" : readableSize(node.size)) +
                (node.modified > 0 ? "  ·  " + date.format(node.modified) : "");
    }
    private String readableSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double d = bytes; String[] units = {"B", "KB", "MB", "GB", "TB"}; int i = 0;
        while (d >= 1024 && i < units.length - 1) { d /= 1024; i++; }
        return String.format(Locale.KOREA, "%.1f %s", d, units[i]);
    }
    private String iconFor(FileNode node) {
        if (node.directory) return "📁";
        String m = node.mime;
        if (m.startsWith("image/")) return "🖼";
        if (m.startsWith("video/")) return "🎬";
        if (m.startsWith("audio/")) return "🎵";
        if (node.name.toLowerCase(Locale.ROOT).endsWith(".zip")) return "🗜";
        return "📄";
    }

    private List<FileNode> listedItems() {
        List<FileNode> items = new ArrayList<>();
        for (FileNode item:visible) {
            if (!showHidden && item.name.startsWith(".")) continue;
            if (!nameFilter.isEmpty() && !item.name.toLowerCase(Locale.ROOT)
                    .contains(nameFilter.toLowerCase(Locale.ROOT))) continue;
            items.add(item);
        }
        items.sort((a,b) -> {
            if (foldersFirst && a.directory != b.directory) return a.directory ? -1 : 1;
            int result;
            if (sort==1) result=Long.compare(b.modified,a.modified);
            else if (sort==2) result=Long.compare(b.size,a.size);
            else result=a.name.compareToIgnoreCase(b.name);
            return reverseSort ? -result : result;
        });
        return items;
    }

    private String folderCount(FileNode item) {
        if (!item.directory || !item.id.startsWith("file:/")) return "폴더";
        Integer amount = childrenCache.get(item.id);
        if (amount == null) {
            try {
                String[] entries=new File(URI.create(item.id)).list();
                amount=entries==null ? -1 : entries.length;
            } catch (Exception ex) { amount=-1; }
            childrenCache.put(item.id,amount);
        }
        return amount<0 ? "폴더" : amount+"개 항목";
    }

    private void drawFiles() {
        List<FileNode> items = listedItems();
        if (busy) {
            TextView loading=text("◌  " + busyLabel,14,BLUE,false);
            loading.setPadding(dp(18),dp(15),0,dp(15)); body.addView(loading);
        }
        if (!busy && items.isEmpty()) {
            TextView empty=text(nameFilter.isEmpty() ? "이 폴더는 비어 있습니다" : "필터에 일치하는 항목이 없습니다",16,MUTED,false);
            empty.setGravity(Gravity.CENTER); body.addView(empty, lp(-1,110));
        }
        for (FileNode file:items) {
            LinearLayout row=horizontal();
            row.setPadding(dp(12),dp(5),dp(12),dp(5));
            row.setBackgroundColor(selected.contains(file.id) ? PALE : Color.WHITE);
            body.addView(row, lp(-1,compactRows ? 62 : 78));
            if (!selected.isEmpty()) {
                CheckBox checkbox=new CheckBox(this);
                checkbox.setButtonTintList(android.content.res.ColorStateList.valueOf(BLUE));
                checkbox.setChecked(selected.contains(file.id));
                checkbox.setOnClickListener(v->toggle(file.id));
                row.addView(checkbox,lp(37,45));
            }
            FileItemIcon icon = new FileItemIcon(file.directory);
            LinearLayout.LayoutParams ip = lp(compactRows ? 44 : 53,compactRows ? 43 : 52);
            ip.rightMargin=dp(12);
            row.addView(icon,ip);
            LinearLayout column=vertical();
            row.addView(column,new LinearLayout.LayoutParams(0,-2,1));
            TextView name=text(file.name,compactRows ? 15 : 17,INK,true);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            column.addView(name);
            String detail;
            if (page == Page.RESULTS) detail=resultLocation(file);
            else detail=file.directory ? folderCount(file) : readableSize(Math.max(0,file.size));
            if (file.modified>0) detail+="  ·  "+date.format(file.modified);
            TextView detailView=text(detail,compactRows ? 11 : 12,MUTED,false);
            detailView.setSingleLine(true);
            detailView.setEllipsize(android.text.TextUtils.TruncateAt.END);
            column.addView(detailView);
            TextView more=text("⋮",23,0xFFB5BBC4,false);
            more.setGravity(Gravity.CENTER);
            more.setContentDescription(file.name + " 옵션");
            more.setOnClickListener(v->showFileOptions(file));
            row.addView(more,lp(38,-1));
            row.setOnClickListener(v->{ if (!busy) { if (!selected.isEmpty()) toggle(file.id); else openItem(file); }});
            row.setOnLongClickListener(v->{ if (!busy) toggle(file.id); return true; });
        }
    }

    /** Vector folder/file glyphs painted in-app, not copied from the ES Lite APK. */
    private final class FileItemIcon extends View {
        private final boolean directory;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        FileItemIcon(boolean directory) { super(MainActivity.this); this.directory=directory;
            setContentDescription(directory ? "폴더" : "파일"); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(),h=getHeight(),sx=w/56f,sy=h/56f;
            c.save();c.scale(sx,sy);
            if (directory) {
                paint.setColor(0xFF4692E5);
                c.drawRoundRect(new RectF(3,10,34,29),5,5,paint);
                paint.setColor(ES_FOLDER);
                c.drawRoundRect(new RectF(2,17,54,51),5,5,paint);
            } else {
                paint.setColor(0xFF8499A8);
                Path file=new Path();file.moveTo(12,3);file.lineTo(35,3);file.lineTo(48,16);
                file.lineTo(48,52);file.lineTo(12,52);file.close();c.drawPath(file,paint);
                paint.setColor(0xFFD4E1EA);
                Path fold=new Path();fold.moveTo(35,3);fold.lineTo(35,16);fold.lineTo(48,16);fold.close();c.drawPath(fold,paint);
            }
            c.restore();
        }
    }

    private void showFileOptions(FileNode file) {
        new AlertDialog.Builder(this).setTitle(file.name)
            .setItems(new String[]{"열기", "선택", "속성", "이름 변경", "삭제"},(dialog,which)->{
                if (which==0) openItem(file);
                else if (which==1) toggle(file.id);
                else if (which==2) new AlertDialog.Builder(this).setTitle(file.name)
                    .setMessage("형식: "+(file.directory ? "폴더" : file.mime)
                        +"\n크기: "+(file.directory ? "폴더" : readableSize(Math.max(0,file.size)))
                        +"\n수정: "+(file.modified>0?date.format(file.modified):"알 수 없음"))
                    .setPositiveButton("확인",null).show();
                else if (which==3 || which==4) {
                    selected.clear(); selected.add(file.id);
                    if (which==3) renameSelected(); else deleteSelected();
                }
            }).show();
    }

    private String resultLocation(FileNode node) {
        for (FileEngine.SearchHit hit : hits) if (hit.file.id.equals(node.id)) return hit.relativePath;
        return subtitle(node);
    }

    private void drawFooter() {
        if (page == Page.HOME || (selected.isEmpty() && clipboard.isEmpty())) return;
        LinearLayout footer = vertical();
        footer.setPadding(dp(16), dp(10), dp(10), dp(12));
        footer.setBackgroundColor(Color.WHITE);
        frame.addView(footer, lp(-1, -2));
        if (!selected.isEmpty()) {
            TextView note = text(selected.size() + "개 선택됨  ·  길게 눌러 선택 / 해제", 12, BLUE, true);
            footer.addView(note, lp(-1, 28));
            HorizontalScrollView scroll = new HorizontalScrollView(this);
            scroll.setHorizontalScrollBarEnabled(false);
            footer.addView(scroll);
            LinearLayout tools = horizontal(); scroll.addView(tools);
            actionInto(tools, "복사", false, () -> chooseClipboard(false));
            actionInto(tools, "이동", false, () -> chooseClipboard(true));
            actionInto(tools, "ZIP", false, this::zipSelected);
            actionInto(tools, "공유", false, this::shareSelected);
            if (selected.size() == 1) actionInto(tools, "이름 변경", false, this::renameSelected);
            actionInto(tools, "삭제", false, this::deleteSelected);
            actionInto(tools, "선택 해제", false, () -> { selected.clear(); draw(); });
        } else {
            LinearLayout bar = horizontal();
            footer.addView(bar);
            if (!clipboard.isEmpty()) {
                actionInto(bar, (cut ? "이동 붙여넣기" : "복사 붙여넣기") + " (" + clipboard.size() + ")", true, this::paste);
                actionInto(bar, "취소", false, () -> { clipboard.clear(); draw(); });
            } else {
                caption(bar, "파일을 길게 누르면 여러 개를 선택할 수 있습니다.");
            }
        }
    }

    private void pickFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, PICK_TREE); }
        catch (ActivityNotFoundException e) { snack("이 기기는 폴더 선택을 지원하지 않습니다."); }
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != PICK_TREE || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (SecurityException e) { snack("폴더 권한을 유지할 수 없습니다: " + e.getMessage()); return; }
        String tree = uri.toString();
        runJob("폴더 연결 중", () -> {
            String root=store.registerDocument(tree);
            return store.stat(root).name;
        }, label -> {
            Set<String> trees = savedTrees(); trees.add(tree);
            prefs().edit().putStringSet("trees", trees).putString("label:" + tree, label).apply();
            openTree(tree);
        });
    }

    private void confirmRemove(String tree) {
        new AlertDialog.Builder(this).setTitle("폴더 연결 해제")
                .setMessage("목록에서 이 폴더를 제거합니다. 파일은 삭제하지 않습니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("해제", (d, w) -> {
                    Set<String> trees = savedTrees(); trees.remove(tree);
                    prefs().edit().putStringSet("trees", trees).remove("label:" + tree).apply();
                    try { getContentResolver().releasePersistableUriPermission(Uri.parse(tree),
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
                    catch (Exception ignored) { }
                    draw();
                }).show();
    }

    private void openTree(String tree) {
        String root=store.registerDocument(tree);
        createTab(labelOf(tree),root);
    }

    private void goHome() {
        saveActive();
        requestSerial++;
        page = Page.HOME;
        selected.clear(); hits.clear(); visible.clear();
        draw();
    }

    private void navigateBackTo(int index) {
        while (path.size() > index + 1) path.remove(path.size() - 1);
        folder = path.get(path.size() - 1).id;
        selected.clear(); hits.clear();
        page = Page.FOLDER;
        refresh();
    }

    private void enterFolder(FileNode file) {
        if (page == Page.RESULTS) {
            path.clear(); path.add(new Crumb(tabs.get(activeTab).name, tabs.get(activeTab).root));
        }
        path.add(new Crumb(file.name, file.id));
        folder = file.id;
        selected.clear(); hits.clear(); page = Page.FOLDER;
        refresh();
    }

    private void refresh() {
        if (busy) return;
        selected.clear();
        String requestFolder = folder;
        int version = ++requestSerial;
        runJob("파일 불러오는 중", () -> store.list(requestFolder), files -> {
            if (version != requestSerial || page != Page.FOLDER || !requestFolder.equals(folder)) return;
            visible.clear(); visible.addAll(files); draw();
        });
    }

    private <T> void runJob(String title, Callable<T> action, Consumer<T> success) {
        if (busy) return;
        busy = true; busyLabel = title;
        draw();
        jobs.execute(() -> {
            T result = null; Exception error = null;
            try { result = action.call(); } catch (Exception ex) { error = ex; }
            T value = result; Exception fail = error;
            ui.post(() -> {
                if (isFinishing() || isDestroyed()) return;
                busy = false; busyLabel = "";
                if (fail != null) {
                    snack("작업 실패: " + message(fail));
                    draw();
                } else {
                    success.accept(value);
                }
            });
        });
    }

    private void openItem(FileNode node) {
        if (node.directory) { enterFolder(node); return; }
        if (node.name.toLowerCase(Locale.ROOT).endsWith(".zip")) {
            new AlertDialog.Builder(this).setTitle(node.name)
                    .setItems(new String[]{"다른 앱으로 열기", "현재 폴더에 압축 풀기"}, (d, which) -> {
                        if (which == 0) viewFile(node); else extract(node);
                    }).show();
        } else viewFile(node);
    }

    private void viewFile(FileNode node) {
        if (node.id.startsWith("smb://")) {
            runJob("네트워크 파일 받는 중", () -> cacheRemote(node), uri -> openUri(uri,node.mime));
        } else if (node.id.startsWith("file:/")) {
            try { openUri(KiteContentProvider.uriFor(new File(URI.create(node.id)).getAbsolutePath()),node.mime); }
            catch (Exception e) { snack(message(e)); }
        } else openUri(Uri.parse(node.id),node.mime);
    }
    private Uri cacheRemote(FileNode item) throws Exception {
        if (item.size>256L*1024*1024) throw new IllegalArgumentException("256MB보다 큰 원격 파일은 로컬 폴더로 복사하세요.");
        String safe=item.name.replaceAll("[^a-zA-Z0-9._-]", "_");
        File temp=File.createTempFile("kf_", "_"+safe, getCacheDir());
        try (InputStream in=store.read(item.id);OutputStream out=new java.io.FileOutputStream(temp)) {
            FileEngine.pump(in,out,256L*1024*1024);
        } catch (Exception e) { temp.delete(); throw e; }
        return KiteContentProvider.uriFor(temp.getAbsolutePath());
    }
    private void openUri(Uri uri,String mime) {
        Intent intent=new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri,mime);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(intent,"파일 열기")); }
        catch(Exception e) { snack("파일을 열 수 있는 앱이 없습니다."); }
    }

    private void toggle(String id) {
        if (!selected.add(id)) selected.remove(id);
        draw();
    }

    private void promptSearch() {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setHint("파일 이름 검색");
        edit.setText(query);
        new AlertDialog.Builder(this).setTitle("이 폴더 안에서 검색")
                .setView(edit).setNegativeButton("취소", null)
                .setPositiveButton("검색", (d, w) -> search(edit.getText().toString())).show();
    }

    private void search(String term) {
        if (term.trim().isEmpty()) { snack("검색어를 입력하세요."); return; }
        query = term.trim();
        String searchRoot = folder;
        runJob("하위 폴더 검색 중", () -> new FileEngine(store).search(searchRoot, query, 500), result -> {
            selected.clear(); visible.clear(); hits.clear(); parentOfHit.clear();
            hits.addAll(result);
            for (FileEngine.SearchHit hit : result) {
                visible.add(hit.file);
                parentOfHit.put(hit.file.id, hit.parentId);
            }
            page = Page.RESULTS;
            draw();
            if (result.size() == 500) snack("검색 결과는 최대 500개까지 표시합니다.");
        });
    }

    private void showCreateMenu() {
        if (page != Page.FOLDER) { snack("새 파일은 폴더 화면에서 만들 수 있습니다."); return; }
        new AlertDialog.Builder(this).setTitle("새로 만들기")
                .setItems(new String[]{"새 폴더", "빈 파일"}, (d, item) -> promptCreate(item == 0)).show();
    }

    private void promptCreate(boolean directory) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setHint(directory ? "새 폴더" : "새 파일.txt");
        new AlertDialog.Builder(this).setTitle(directory ? "폴더 만들기" : "빈 파일 만들기")
                .setView(edit).setNegativeButton("취소", null)
                .setPositiveButton("만들기", (d, w) -> {
                    String name = edit.getText().toString();
                    runJob("만드는 중", () -> {
                        FileEngine engine = new FileEngine(store);
                        return directory ? engine.newFolder(folder, name) : engine.newFile(folder, name);
                    }, file -> { snack("생성 완료: " + file.name); refresh(); });
                }).show();
    }

    private List<String> picked() { return new ArrayList<>(selected); }
    private void chooseClipboard(boolean move) {
        clipboard.clear(); clipboard.addAll(picked());
        clipboardTree = activeTree;
        cut = move;
        selected.clear(); draw();
        snack(move ? "이동할 폴더로 이동한 후 붙여넣기를 누르세요." : "복사할 폴더로 이동한 후 붙여넣기를 누르세요.");
    }

    private void paste() {
        if (page != Page.FOLDER) { snack("폴더 안에서 붙여넣기를 실행하세요."); return; }
        List<String> ids = new ArrayList<>(clipboard);
        boolean moving = cut;
        String target = folder;
        runJob(moving ? "이동 중" : "복사 중", () -> {
            new FileEngine(store).transfer(ids, target, moving, name -> {});
            return ids.size();
        }, count -> {
            if (moving) clipboard.clear();
            snack(count + "개 항목 처리 완료"); refresh();
        });
    }

    private void zipSelected() {
        if (page != Page.FOLDER) { snack("ZIP은 폴더 화면에서 생성하세요."); return; }
        List<String> ids = picked();
        EditText edit = new EditText(this);
        edit.setSingleLine(true); edit.setText("선택한 파일.zip");
        new AlertDialog.Builder(this).setTitle("ZIP으로 압축")
                .setView(edit).setNegativeButton("취소", null)
                .setPositiveButton("압축", (d,w) -> runJob("ZIP 압축 중", () ->
                        new FileEngine(store).makeZip(ids, folder, edit.getText().toString(), FileEngine.QUIET),
                        item -> { snack("ZIP 생성 완료: " + item.name); refresh(); })).show();
    }

    private void extract(FileNode zip) {
        if (page != Page.FOLDER && page != Page.RESULTS) return;
        String dest = folder;
        runJob("ZIP 압축 해제 중", () -> new FileEngine(store).extractZip(zip.id, dest, FileEngine.QUIET),
                item -> { snack("압축 해제 완료: " + item.name); page = Page.FOLDER; refresh(); });
    }

    private void renameSelected() {
        if (selected.size() != 1) return;
        String id = selected.iterator().next();
        FileNode node = null;
        for (FileNode f : visible) if (id.equals(f.id)) { node = f; break; }
        if (node == null) return;
        EditText edit = new EditText(this);
        edit.setSingleLine(true); edit.setText(node.name); edit.selectAll();
        final String parent = page == Page.RESULTS ? parentOfHit.get(id) : folder;
        if (parent == null) { snack("원본 폴더를 찾지 못했습니다."); return; }
        new AlertDialog.Builder(this).setTitle("이름 변경")
                .setView(edit).setNegativeButton("취소", null)
                .setPositiveButton("변경", (d, w) -> runJob("이름 변경 중", () ->
                        new FileEngine(store).rename(id, edit.getText().toString(), parent),
                        updated -> { snack("변경 완료: " + updated.name); refreshOrSearch(); })).show();
    }

    private void refreshOrSearch() {
        selected.clear();
        if (page == Page.RESULTS) search(query); else refresh();
    }

    private void deleteSelected() {
        List<String> ids = picked();
        new AlertDialog.Builder(this).setTitle("정말 삭제할까요?")
                .setMessage(ids.size() + "개 항목을 영구 삭제합니다. 휴지통 기능이 없으므로 복구할 수 없습니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("영구 삭제", (d, w) -> runJob("삭제 중", () -> {
                    int done = 0;
                    for (String id : ids) { store.delete(id); done++; }
                    return done;
                }, count -> { snack(count + "개 항목 삭제 완료"); refreshOrSearch(); }))
                .show().getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(DANGER);
    }

    private void shareSelected() {
        List<FileNode> files=new ArrayList<>();
        for (FileNode item:visible) if (selected.contains(item.id)&&!item.directory) files.add(item);
        if (files.isEmpty()) { snack("공유할 파일을 선택하세요(폴더는 제외)."); return; }
        runJob("공유할 파일 준비 중",()->{
            ArrayList<Uri> uris=new ArrayList<>();
            for (FileNode item:files) {
                if (item.id.startsWith("smb://")) uris.add(cacheRemote(item));
                else if (item.id.startsWith("file:/")) uris.add(KiteContentProvider.uriFor(new File(URI.create(item.id)).getAbsolutePath()));
                else uris.add(Uri.parse(item.id));
            }
            return uris;
        }, this::launchShare);
    }
    private void launchShare(ArrayList<Uri> uris) {
        Intent intent = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (uris.size() == 1) intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        else intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        ClipData clip = ClipData.newUri(getContentResolver(), "공유 파일", uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        intent.setClipData(clip);
        try { startActivity(Intent.createChooser(intent, "파일 공유")); }
        catch (Exception e) { snack("공유할 앱이 없습니다."); }
    }

    private boolean hasAllFiles() {
        if (Build.VERSION.SDK_INT>=30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
    }
    private void openLocal(int index) {
        if (store==null) { snack("저장소를 초기화하지 못했습니다."); return; }
        if (!hasAllFiles()) {
            pendingLocal=index;
            new AlertDialog.Builder(this).setTitle("전체 저장소 권한")
                .setMessage("내부 저장소 전체를 관리하려면 Android 설정에서 모든 파일 접근 권한을 허용해야 합니다. 보호된 앱 폴더는 여전히 제외됩니다.")
                .setPositiveButton("권한 설정",(d,w)->requestStorage())
                .setNegativeButton("취소",(d,w)->pendingLocal=-1).show();
            return;
        }
        if (index<0 || index>=store.localRootCount()) return;
        createTab(index==0?"내부 저장소":"외장 저장소 "+index,store.localRoot(index));
    }
    private void requestStorage() {
        if (Build.VERSION.SDK_INT>=30) {
            try {
                Intent intent=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:"+getPackageName()));
                startActivity(intent);
            } catch(Exception e) { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
        } else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE},STORAGE_PERM);
    }
    @Override protected void onResume() {
        super.onResume();
        if (pendingLocal>=0 && store!=null && hasAllFiles()) {
            int target=pendingLocal;pendingLocal=-1;
            ui.post(()->openLocal(target));
        }
    }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] grants) {
        super.onRequestPermissionsResult(code,perms,grants);
        if (code==STORAGE_PERM && pendingLocal>=0 && hasAllFiles()) {
            int target=pendingLocal;pendingLocal=-1;openLocal(target);
        }
    }
    private EditText field(String hint, String initial, boolean secret) {
        EditText edit=new EditText(this); edit.setSingleLine(true);edit.setHint(hint);
        edit.setText(initial); edit.setTextSize(15);
        if (secret) edit.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return edit;
    }
    private void promptSmb() {
        LinearLayout form=vertical();form.setPadding(dp(20),0,dp(20),0);
        EditText host=field("서버 주소 (예: 192.168.1.20)","",false);
        EditText share=field("공유 이름 (예: Public)","",false);
        EditText domain=field("도메인 (선택)","",false);
        EditText user=field("사용자 이름", "",false);
        EditText pass=field("암호 (기기에 저장하지 않음)","",true);
        for(EditText edit:new EditText[]{host,share,domain,user,pass}) form.addView(edit,lp(-1,52));
        new AlertDialog.Builder(this).setTitle("LAN · SMB2/3 연결")
            .setMessage("동일한 LAN/VPN에서 접속 가능한 NAS 또는 Windows 공유 폴더를 지정하세요. SMB1은 비활성화됩니다.")
            .setView(form).setNegativeButton("취소",null)
            .setPositiveButton("연결",(d,w)->{
                String h=host.getText().toString().trim(),sh=share.getText().toString().trim();
                String dm=domain.getText().toString().trim(),un=user.getText().toString().trim();
                String pw=pass.getText().toString();pass.setText("");
                runJob("SMB 서버 연결 중",()->{
                    SmbFileStore remote=new SmbFileStore(h,sh,dm,un,pw);
                    remote.list(remote.root()); // authenticates and validates share before opening tab
                    return remote;
                }, remote->{
                    store.registerSmb(remote);
                    createTab("LAN:"+sh,remote.root());
                });
            }).show();
    }

    private void showDrawer() {
        if (drawerOpen || rootOverlay == null) return;
        drawerOpen = true;
        drawerShade = new View(this);
        drawerShade.setBackgroundColor(0x99000000);
        drawerShade.setAlpha(0);
        drawerShade.setOnClickListener(v -> hideDrawer());
        rootOverlay.addView(drawerShade, new FrameLayout.LayoutParams(-1, -1));
        ScrollView menu = new ScrollView(this);
        menu.setBackgroundColor(0xFFF9FBFF);
        menu.setFillViewport(false);
        drawerPanel = vertical();
        menu.addView(drawerPanel);
        int width = Math.min(dp(306), (int)(getResources().getDisplayMetrics().widthPixels * 0.85f));
        rootOverlay.addView(menu, new FrameLayout.LayoutParams(width, -1, Gravity.START));
        drawerView = menu;
        menu.setTranslationX(-width);
        LinearLayout banner = vertical();
        banner.setPadding(dp(20), dp(35), dp(12), dp(27));
        banner.setBackgroundColor(0xFF2869B6);
        drawerPanel.addView(banner, lp(-1,-2));
        banner.addView(text("KiteFiles", 25, Color.WHITE, true));
        banner.addView(text("내 파일 · 네트워크 · 멀티탭", 14, Color.WHITE, true));
        menuHeading("내 저장소");
        menuEntry("▤", "내부 저장소", () -> openLocal(0));
        menuEntry("↓", "다운로드", () -> openLocalFolder("Download"));
        menuEntry("▧", "문서", () -> openLocalFolder("Documents"));
        menuEntry("▧", "사진", () -> openLocalFolder("Pictures"));
        menuHeading("네트워크");
        menuEntry("▣", "SMB (Windows / NAS)", this::promptSmb);
        menuEntry("＋", "폴더 연결", this::pickFolder);
        menuHeading("탭 및 기타");
        menuEntry("▤", "열린 탭 (" + tabs.size() + ")", () -> {
            if (!tabs.isEmpty()) activateTab(Math.max(0, activeTab)); else goHome();
        });
        menuEntry("＋", "새 탭", () -> {
            if (activeTab >= 0) createTab("새 창", tabs.get(activeTab).root); else openLocal(0);
        });
        menuEntry("⌂", "홈", this::goHome);
        drawerShade.animate().alpha(1f).setDuration(200).start();
        menu.animate().translationX(0).setDuration(250).setInterpolator(new DecelerateInterpolator()).start();
    }

    private void menuHeading(String title) {
        TextView h = text(title, 17, 0xFF28618F, true);
        h.setPadding(dp(20),dp(22),dp(10),0);
        drawerPanel.addView(h, lp(-1,65));
    }
    private void menuEntry(String icon, String title, Runnable click) {
        TextView row = text("  " + icon + "     " + title, 17, 0xFF263746, true);
        row.setMinHeight(dp(62));
        row.setPadding(dp(15),0,dp(8),0);
        row.setContentDescription(title);
        drawerPanel.addView(row, lp(-1,62));
        row.setOnClickListener(v -> { hideDrawer(); ui.postDelayed(click,230); });
    }
    private void openLocalFolder(String name) {
        if (!hasAllFiles()) { openLocal(0); return; }
        File directory = new File(Environment.getExternalStorageDirectory(),name);
        if (!directory.isDirectory()) { snack("폴더가 없습니다: " + name); return; }
        openLocal(0);
        // A new tab is created synchronously; navigate after root loading starts.
        ui.postDelayed(() -> {
            if (activeTab >= 0) enterFolder(new FileNode(directory.toURI().toString(), name, true, "vnd.android.document/directory", 0, 0));
        },120);
    }
    private void hideDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        final View panel=drawerView, shade=drawerShade;
        if (panel != null) panel.animate().translationX(-panel.getWidth()).setDuration(210).start();
        if (shade != null) shade.animate().alpha(0).setDuration(210).withEndAction(() -> {
            if (panel != null && panel.getParent()==rootOverlay) rootOverlay.removeView(panel);
            if (shade.getParent()==rootOverlay) rootOverlay.removeView(shade);
        }).start();
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        float x=event.getRawX(), y=event.getRawY();
        if (action==MotionEvent.ACTION_DOWN) {
            startX=x; startY=y; swipeTracking=false; swipeHorizontal=false;
        } else if (action==MotionEvent.ACTION_MOVE && !drawerOpen && !busy && page==Page.FOLDER && tabs.size()>1) {
            float dx=x-startX, dy=y-startY;
            if (!swipeTracking && Math.abs(dx)>dp(18) && Math.abs(dx)>Math.abs(dy)*1.3f) {
                int next=activeTab+(dx>0?-1:1);
                if (next>=0 && next<tabs.size()) { swipeTracking=true; swipeHorizontal=true;
                    MotionEvent cancel=MotionEvent.obtain(event);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel); cancel.recycle();
                }
            }
            if (swipeHorizontal) {
                if (fileScroller!=null) fileScroller.setTranslationX(dx*.70f);
                return true;
            }
        } else if ((action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL) && swipeHorizontal) {
            float dx=x-startX;
            if (fileScroller!=null) {
                final ScrollView view=fileScroller;
                int target=activeTab+(dx>0?-1:1);
                float velocityThreshold=Math.max(dp(75), view.getWidth()*.22f);
                if (action==MotionEvent.ACTION_UP && Math.abs(dx)>=velocityThreshold && target>=0 && target<tabs.size()) {
                    view.animate().translationX(dx>0?view.getWidth():-view.getWidth())
                        .setDuration(130).withEndAction(() -> activateTab(target)).start();
                } else view.animate().translationX(0).setDuration(200)
                        .setInterpolator(new DecelerateInterpolator()).start();
            }
            swipeHorizontal=false;swipeTracking=false;
            return true;
        }
        return super.dispatchTouchEvent(event);
    }
    @Override public void onBackPressed() {
        if (topOptions != null && topOptions.isShowing()) { topOptions.dismiss(); return; }
        if (drawerOpen) { hideDrawer(); return; }
        if (!selected.isEmpty()) { selected.clear(); draw(); return; }
        if (page == Page.RESULTS) { page = Page.FOLDER; hits.clear(); refresh(); return; }
        if (page == Page.FOLDER && path.size() > 1) { navigateBackTo(path.size() - 2); return; }
        if (page != Page.HOME) { goHome(); return; }
        super.onBackPressed();
    }
}

#pragma once
#include <stdint.h>
#ifdef _WIN32
#define FR_EXPORT extern "C" __declspec(dllexport)
#define FR_CALL __cdecl
#else
#define FR_EXPORT extern "C"
#define FR_CALL
#endif

// 0=scan progress, 1=deleted-file candidate. Returning zero requests cancellation.
typedef int (FR_CALL *FR_ScanCallback)(uint32_t kind, uint64_t index,
    uint64_t total, const wchar_t* name, uint64_t bytes, uint32_t flags, void* user);
// flags: bit0 supported, bit1 resident
// Returning zero requests cancellation.
typedef int (FR_CALL *FR_ProgressCallback)(uint64_t completed, uint64_t total, void* user);

// Result: 0=success, 1=canceled, -1=failed. Paths to sources must be \\.\X:
// or absolute .img/.dd/.raw image files. Caller owns errorBuffer.
FR_EXPORT int FR_CALL FR_Scan(const wchar_t* source, uint64_t maxRecords,
    FR_ScanCallback callback, void* user, wchar_t* errorBuffer, uint32_t errorCapacity);
FR_EXPORT int FR_CALL FR_Recover(const wchar_t* source, uint64_t recordIndex,
    const wchar_t* destination, FR_ProgressCallback callback, void* user,
    wchar_t* errorBuffer, uint32_t errorCapacity);

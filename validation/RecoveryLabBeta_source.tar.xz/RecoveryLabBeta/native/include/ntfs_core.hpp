#pragma once
#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace recovery {

class Reader {
public:
    virtual ~Reader() = default;
    virtual bool read(uint64_t offset, void* target, size_t length) = 0;
};

struct FoundFile {
    uint64_t recordIndex = 0;
    std::u16string name;
    uint64_t size = 0;
    bool supported = false;
    bool resident = false;
};

enum class ScanResult { Complete, Canceled, Error };
using ScanCallback = std::function<bool(uint32_t kind, uint64_t current, uint64_t total, const FoundFile*)>;
using WriteCallback = std::function<bool(const uint8_t*, size_t)>;
using ProgressCallback = std::function<bool(uint64_t, uint64_t)>;

class NtfsVolume {
public:
    explicit NtfsVolume(Reader& source);
    bool initialize(std::string& error);
    ScanResult scan(uint64_t maxRecords, const ScanCallback& cb, std::string& error);
    bool recover(uint64_t recordIndex, const WriteCallback& write,
                 const ProgressCallback& progress, std::string& error);
    uint64_t recordCount() const { return recordCount_; }

private:
    struct Run {
        uint64_t vcn = 0;
        uint64_t clusters = 0;
        int64_t lcn = -1;
    };
    struct Payload {
        bool exists = false;
        bool supported = false;
        bool resident = false;
        uint64_t size = 0;
        std::vector<uint8_t> data;
        std::vector<Run> runs;
    };
    Reader& reader_;
    uint32_t sectorSize_ = 0;
    uint32_t clusterSize_ = 0;
    uint32_t recordSize_ = 0;
    uint64_t volumeBytes_ = 0;
    uint64_t recordCount_ = 0;
    std::vector<Run> mftRuns_;

    bool fixup(std::vector<uint8_t>& record) const;
    bool parseRuns(const uint8_t* data, size_t length, uint64_t startVcn,
                   std::vector<Run>& runs, std::string& error) const;
    bool readFromRuns(const std::vector<Run>& runs, uint64_t position,
                      uint8_t* out, size_t count, std::string& error) const;
    bool readRecord(uint64_t index, std::vector<uint8_t>& record,
                    std::string& error) const;
    bool parseFile(const std::vector<uint8_t>& record, uint64_t index,
                   FoundFile& file, Payload* payload) const;
};

} // namespace recovery

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "recovery_api.h"
#include "ntfs_core.hpp"
#include <algorithm>
#include <cstring>
#include <cwchar>
#include <cwctype>
#include <memory>
#include <string>
#include <vector>

namespace {
void setError(wchar_t* buffer, uint32_t capacity, const std::wstring& message) {
    if (!buffer || capacity == 0) return;
    const size_t length = std::min<size_t>(capacity - 1, message.size());
    std::wmemcpy(buffer, message.data(), length);
    buffer[length] = 0;
}
std::wstring fromAscii(const std::string& message) {
    return std::wstring(message.begin(), message.end()); // Engine errors are ASCII.
}
std::wstring winError(const wchar_t* what) {
    return std::wstring(what) + L" (Windows error " + std::to_wstring(GetLastError()) + L")";
}
bool isVolume(const std::wstring& path) {
    return path.size() == 6 && path.compare(0, 4, L"\\\\.\\") == 0 &&
           std::iswalpha(path[4]) && path[5] == L':';
}
bool supportedSource(const std::wstring& path) {
    if (isVolume(path)) return true;
    if (path.size() < 6 || !( (std::iswalpha(path[0]) && path[1] == L':' && path[2] == L'\\') || path.rfind(L"\\\\", 0) == 0 )) return false;
    size_t dot = path.find_last_of(L'.');
    if (dot == std::wstring::npos) return false;
    std::wstring ext = path.substr(dot);
    std::transform(ext.begin(), ext.end(), ext.begin(),
                   [](wchar_t c) { return static_cast<wchar_t>(std::towlower(c)); });
    return ext == L".img" || ext == L".dd" || ext == L".raw";
}

class WinReader final : public recovery::Reader {
    HANDLE handle_ = INVALID_HANDLE_VALUE;
    bool device_ = false;
public:
    explicit WinReader(const std::wstring& name) : device_(isVolume(name)) {
        handle_ = CreateFileW(name.c_str(), GENERIC_READ,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    }
    ~WinReader() override { if (handle_ != INVALID_HANDLE_VALUE) CloseHandle(handle_); }
    bool opened() const { return handle_ != INVALID_HANDLE_VALUE; }
    bool read(uint64_t offset, void* target, size_t length) override {
        if (!opened()) return false;
        if (length == 0) return true;
        if (length > 2 * 1024 * 1024 || offset > INT64_MAX) return false;
        uint64_t base = device_ ? offset & ~uint64_t(4095) : offset;
        uint64_t adjustment = offset - base;
        uint64_t requested = adjustment + length;
        if (requested > (2u * 1024 * 1024 + 8192)) return false;
        uint64_t padded = device_ ? (requested + 4095) & ~uint64_t(4095) : requested;
        if (padded > MAXDWORD || base > INT64_MAX) return false;
        // Sector-align the address as well as the offset and I/O length.
        // This also supports devices that enforce unbuffered-style alignment.
        std::vector<uint8_t> storage(static_cast<size_t>(padded) + 4095);
        uintptr_t pointer = reinterpret_cast<uintptr_t>(storage.data());
        auto* bytes = reinterpret_cast<uint8_t*>((pointer + 4095) & ~uintptr_t(4095));
        LARGE_INTEGER location; location.QuadPart = static_cast<LONGLONG>(base);
        if (!SetFilePointerEx(handle_, location, nullptr, FILE_BEGIN)) return false;
        DWORD fetched = 0;
        if (!ReadFile(handle_, bytes, static_cast<DWORD>(padded), &fetched, nullptr)
            || fetched != padded) return false;
        std::memcpy(target, bytes + adjustment, length);
        return true;
    }
};

bool destinationIsSeparateVolume(const std::wstring& source, const std::wstring& destination,
                                  std::wstring& error) {
    if (destination.size() < 4 || !std::iswalpha(destination[0]) || destination[1] != L':' ||
        destination[2] != L'\\') {
        error = L"Choose an absolute destination path on a drive (for example D:\\Recovered\\file.jpg).";
        return false;
    }
    if (!isVolume(source)) return true; // Image file, not a mounted source volume.
    wchar_t destRoot[MAX_PATH] = {};
    if (!GetVolumePathNameW(destination.c_str(), destRoot, MAX_PATH)) {
        error = winError(L"Cannot determine destination volume"); return false;
    }
    std::wstring sourceRoot;
    sourceRoot.push_back(source[4]);
    sourceRoot += L":\\";
    wchar_t sourceGuid[MAX_PATH] = {}, destGuid[MAX_PATH] = {};
    if (!GetVolumeNameForVolumeMountPointW(sourceRoot.c_str(), sourceGuid, MAX_PATH) ||
        !GetVolumeNameForVolumeMountPointW(destRoot, destGuid, MAX_PATH)) {
        error = L"Cannot validate source/destination volumes (recovery blocked).";
        return false;
    }
    if (_wcsicmp(sourceGuid, destGuid) == 0) {
        error = L"Destination is the source volume. Choose a DIFFERENT drive.";
        return false;
    }
    return true;
}
} // namespace

FR_EXPORT int FR_CALL FR_Scan(const wchar_t* source, uint64_t limit,
    FR_ScanCallback callback, void* user, wchar_t* errorBuffer, uint32_t errorCapacity) {
    setError(errorBuffer, errorCapacity, L"");
    if (!source || !callback || !supportedSource(source)) {
        setError(errorBuffer, errorCapacity, L"Choose a drive letter or an absolute .img/.dd/.raw disk image.");
        return -1;
    }
    WinReader reader(source);
    if (!reader.opened()) { setError(errorBuffer,errorCapacity,winError(L"Cannot open source read-only")); return -1; }
    recovery::NtfsVolume volume(reader);
    std::string error;
    if (!volume.initialize(error)) { setError(errorBuffer,errorCapacity,fromAscii(error)); return -1; }
    auto result = volume.scan(limit, [&](uint32_t kind, uint64_t current, uint64_t total,
                                          const recovery::FoundFile* file) {
        std::wstring name;
        uint64_t bytes = 0;
        uint32_t flags = 0;
        if (file) {
            name.assign(file->name.begin(), file->name.end());
            bytes = file->size;
            flags = (file->supported ? 1u : 0u) | (file->resident ? 2u : 0u);
        }
        return callback(kind, current, total, file ? name.c_str() : nullptr,
                        bytes, flags, user) != 0;
    }, error);
    if (result == recovery::ScanResult::Error) {
        setError(errorBuffer,errorCapacity,fromAscii(error)); return -1;
    }
    return result == recovery::ScanResult::Canceled ? 1 : 0;
}

FR_EXPORT int FR_CALL FR_Recover(const wchar_t* source, uint64_t index,
    const wchar_t* destination, FR_ProgressCallback callback, void* user,
    wchar_t* errorBuffer, uint32_t errorCapacity) {
    setError(errorBuffer,errorCapacity,L"");
    if (!source || !destination || !supportedSource(source)) {
        setError(errorBuffer,errorCapacity,L"Invalid source or destination."); return -1;
    }
    std::wstring error;
    if (!destinationIsSeparateVolume(source, destination, error)) {
        setError(errorBuffer,errorCapacity,error); return -1;
    }
    WinReader reader(source);
    if (!reader.opened()) { setError(errorBuffer,errorCapacity,winError(L"Cannot open source read-only")); return -1; }
    recovery::NtfsVolume volume(reader);
    std::string engineError;
    if (!volume.initialize(engineError)) {
        setError(errorBuffer,errorCapacity,fromAscii(engineError)); return -1;
    }
    // CREATE_NEW prevents accidentally replacing an existing destination file.
    HANDLE out = CreateFileW(destination, GENERIC_WRITE, FILE_SHARE_READ,
                             nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (out == INVALID_HANDLE_VALUE) {
        setError(errorBuffer,errorCapacity,winError(L"Cannot create new destination file")); return -1;
    }
    bool canceled = false;
    bool ok = volume.recover(index, [&](const uint8_t* bytes, size_t size) {
        DWORD written = 0;
        return WriteFile(out, bytes, static_cast<DWORD>(size), &written, nullptr) && written == size;
    }, [&](uint64_t done, uint64_t total) {
        if (callback && !callback(done,total,user)) { canceled = true; return false; }
        return true;
    }, engineError);
    if (ok && !FlushFileBuffers(out)) { ok = false; engineError = "Cannot flush destination file"; }
    CloseHandle(out);
    if (!ok) {
        DeleteFileW(destination); // Remove partial recovery output; never touch source.
        setError(errorBuffer,errorCapacity,fromAscii(engineError));
        return canceled ? 1 : -1;
    }
    return 0;
}

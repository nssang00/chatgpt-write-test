#include "ntfs_core.hpp"
#include <algorithm>
#include <cstring>
#include <limits>

namespace recovery {
namespace {
uint16_t u16(const uint8_t* p) { return uint16_t(p[0]) | (uint16_t(p[1]) << 8); }
uint32_t u32(const uint8_t* p) { return uint32_t(u16(p)) | (uint32_t(u16(p+2)) << 16); }
uint64_t u64(const uint8_t* p) { return uint64_t(u32(p)) | (uint64_t(u32(p+4)) << 32); }

bool validRange(size_t size, uint64_t pos, uint64_t len) {
    return pos <= size && len <= size - pos;
}

bool checkedMul(uint64_t a, uint64_t b, uint64_t& out) {
    if (b && a > std::numeric_limits<uint64_t>::max() / b) return false;
    out = a * b;
    return true;
}
}

NtfsVolume::NtfsVolume(Reader& source) : reader_(source) {}

bool NtfsVolume::fixup(std::vector<uint8_t>& record) const {
    if (record.size() < 48 || std::memcmp(record.data(), "FILE", 4) != 0) return false;
    const uint32_t usaOffset = u16(record.data() + 4);
    const uint32_t usaCount = u16(record.data() + 6);
    if (sectorSize_ == 0 || record.size() % sectorSize_ != 0 ||
        usaCount != record.size() / sectorSize_ + 1 ||
        !validRange(record.size(), usaOffset, usaCount * 2ull)) return false;
    uint16_t marker = u16(record.data() + usaOffset);
    for (uint32_t i = 1; i < usaCount; ++i) {
        auto position = size_t(i) * sectorSize_ - 2;
        if (u16(record.data() + position) != marker) return false;
        record[position] = record[usaOffset + 2 * i];
        record[position + 1] = record[usaOffset + 2 * i + 1];
    }
    return true;
}

bool NtfsVolume::parseRuns(const uint8_t* data, size_t length, uint64_t startVcn,
                            std::vector<Run>& runs, std::string& error) const {
    uint64_t vcn = startVcn;
    int64_t lcn = 0;
    size_t cursor = 0;
    bool terminated = false;
    while (cursor < length) {
        const uint8_t header = data[cursor++];
        if (header == 0) { terminated = true; break; }
        unsigned lenBytes = header & 15, offBytes = header >> 4;
        if (lenBytes < 1 || lenBytes > 8 || offBytes > 8 ||
            cursor + lenBytes + offBytes > length) {
            error = "Invalid NTFS data run";
            return false;
        }
        uint64_t count = 0;
        for (unsigned i = 0; i < lenBytes; ++i) count |= uint64_t(data[cursor+i]) << (8*i);
        cursor += lenBytes;
        if (count == 0 || vcn > UINT64_MAX - count) {
            error = "Invalid NTFS run length";
            return false;
        }
        int64_t currentLcn = -1;
        if (offBytes) {
            uint64_t encoded = 0;
            for (unsigned i = 0; i < offBytes; ++i) encoded |= uint64_t(data[cursor+i]) << (8*i);
            if (offBytes < 8 && (data[cursor+offBytes-1] & 0x80)) encoded |= (~0ull << (offBytes*8));
            // Use subtraction/addition without signed overflow or implementation-defined casts.
            bool negative = (encoded >> 63) != 0;
            if (negative) {
                uint64_t magnitude = ~encoded + 1;
                if (magnitude > uint64_t(lcn)) { error = "Negative NTFS cluster"; return false; }
                lcn -= static_cast<int64_t>(magnitude);
            } else {
                if (encoded > uint64_t(INT64_MAX - lcn)) { error = "NTFS LCN overflow"; return false; }
                lcn += static_cast<int64_t>(encoded);
            }
            currentLcn = lcn;
        }
        cursor += offBytes;
        runs.push_back({vcn, count, currentLcn});
        vcn += count;
        if (runs.size() > 1000000) { error = "Too many data runs"; return false; }
    }
    if (!terminated) { error = "Missing NTFS run terminator"; return false; }
    return true;
}

bool NtfsVolume::readFromRuns(const std::vector<Run>& runs, uint64_t position,
                              uint8_t* out, size_t count, std::string& error) const {
    size_t copied = 0;
    while (copied < count) {
        uint64_t bytePos = position + copied;
        if (bytePos < position) { error = "Stream offset overflow"; return false; }
        uint64_t vcn = bytePos / clusterSize_;
        auto it = std::find_if(runs.begin(), runs.end(), [vcn](const Run& r) {
            return vcn >= r.vcn && vcn - r.vcn < r.clusters;
        });
        if (it == runs.end() || it->lcn < 0) {
            error = "Missing/sparse data cluster (cannot safely recover)";
            return false;
        }
        uint64_t withinRun = bytePos - it->vcn * uint64_t(clusterSize_);
        uint64_t runBytes;
        if (!checkedMul(it->clusters, clusterSize_, runBytes) || withinRun >= runBytes) {
            error = "Invalid NTFS run size"; return false;
        }
        uint64_t amount = std::min<uint64_t>(count - copied, runBytes - withinRun);
        uint64_t physical = 0;
        if (!checkedMul(uint64_t(it->lcn), clusterSize_, physical) ||
            physical > UINT64_MAX - withinRun ||
            physical + withinRun > volumeBytes_ ||
            amount > volumeBytes_ - (physical + withinRun)) {
            error = "Data cluster outside NTFS volume";
            return false;
        }
        if (!reader_.read(physical + withinRun, out + copied, static_cast<size_t>(amount))) {
            error = "Source read failed";
            return false;
        }
        copied += static_cast<size_t>(amount);
    }
    return true;
}

bool NtfsVolume::initialize(std::string& error) {
    std::vector<uint8_t> boot(4096);
    if (!reader_.read(0, boot.data(), boot.size())) {
        error = "Cannot read NTFS boot sector (4 KiB)"; return false;
    }
    if (std::memcmp(boot.data() + 3, "NTFS    ", 8) != 0) {
        error = "Not an NTFS volume; FAT/exFAT not supported"; return false;
    }
    sectorSize_ = u16(boot.data() + 11);
    uint8_t sectorsPerCluster = boot[13];
    if ((sectorSize_ != 512 && sectorSize_ != 1024 && sectorSize_ != 2048 && sectorSize_ != 4096) ||
        !sectorsPerCluster || (sectorsPerCluster & (sectorsPerCluster - 1)) ||
        uint64_t(sectorSize_) * sectorsPerCluster > 2 * 1024 * 1024) {
        error = "Invalid NTFS sector/cluster size"; return false;
    }
    clusterSize_ = sectorSize_ * sectorsPerCluster;
    uint64_t totalSectors = u64(boot.data() + 40);
    if (!checkedMul(totalSectors, sectorSize_, volumeBytes_) || volumeBytes_ == 0) {
        error = "Invalid NTFS volume size"; return false;
    }
    auto encodedSize = static_cast<int8_t>(boot[64]);
    if (encodedSize < 0) {
        if (encodedSize < -16) { error = "Invalid file record exponent"; return false; }
        recordSize_ = 1u << (-encodedSize);
    } else {
        if (!encodedSize || uint64_t(encodedSize) * clusterSize_ > 65536) {
            error = "Invalid file record cluster count"; return false;
        }
        recordSize_ = uint32_t(encodedSize) * clusterSize_;
    }
    if (recordSize_ < sectorSize_ || recordSize_ > 65536 || recordSize_ % sectorSize_) {
        error = "Unsupported NTFS file record size"; return false;
    }
    uint64_t mftLocation;
    if (!checkedMul(u64(boot.data() + 48), clusterSize_, mftLocation) ||
        mftLocation > volumeBytes_ || recordSize_ > volumeBytes_ - mftLocation) {
        error = "Invalid $MFT address"; return false;
    }
    std::vector<uint8_t> first(recordSize_);
    if (!reader_.read(mftLocation, first.data(), first.size()) || !fixup(first)) {
        error = "Cannot read/fix up $MFT record zero"; return false;
    }
    uint16_t attrStart = u16(first.data() + 20);
    if (attrStart < 48 || attrStart >= first.size()) {
        error = "Invalid $MFT attributes"; return false;
    }
    for (size_t p = attrStart; validRange(first.size(), p, 16); ) {
        uint32_t type = u32(first.data()+p);
        if (type == 0xffffffff) break;
        uint32_t size = u32(first.data()+p+4);
        if (size < 24 || !validRange(first.size(), p, size)) break;
        const uint8_t* a = first.data()+p;
        if (type == 0x80 && a[9] == 0 && a[8] == 1) {
            // Beta supports the unnamed base $MFT::$DATA extent only.
            uint16_t runOffset = u16(a+32);
            uint64_t startVcn = u64(a+16);
            uint64_t streamSize = u64(a+48);
            if (startVcn != 0 || runOffset >= size || !streamSize) break;
            if (!parseRuns(a+runOffset, size-runOffset, startVcn, mftRuns_, error)) return false;
            recordCount_ = streamSize / recordSize_;
            if (recordCount_ == 0 || recordCount_ > 50000000) {
                error = "Unreasonable $MFT length"; return false;
            }
            // Verify that the entire logical $MFT stream is mapped in the base record.
            uint64_t covered = 0;
            for (const auto& run : mftRuns_) {
                if (run.vcn != covered || run.clusters > UINT64_MAX-covered) {
                    error = "Discontinuous $MFT data runs"; return false;
                }
                covered += run.clusters;
            }
            if (covered < (streamSize / clusterSize_ + (streamSize % clusterSize_ != 0))) {
                error = "Split $MFT attribute list not supported in Beta 0.1"; return false;
            }
            return true;
        }
        p += size;
    }
    error = "Base $MFT::$DATA not found (attribute-list extents unsupported)";
    return false;
}

bool NtfsVolume::readRecord(uint64_t index, std::vector<uint8_t>& record,
                             std::string& error) const {
    if (index >= recordCount_) { error = "File record out of range"; return false; }
    record.resize(recordSize_);
    if (!readFromRuns(mftRuns_, index * uint64_t(recordSize_), record.data(), record.size(), error)) return false;
    return true; // fixup applied by parser; corruption in an individual record is not fatal for the scan.
}

bool NtfsVolume::parseFile(const std::vector<uint8_t>& raw, uint64_t index,
                            FoundFile& file, Payload* payload) const {
    std::vector<uint8_t> record = raw;
    if (!fixup(record)) return false;
    const uint16_t flags = u16(record.data()+22);
    if ((flags & 1) != 0 || (flags & 2) != 0 || u64(record.data()+32) != 0) return false;
    const uint32_t used = u32(record.data()+24);
    if (used < 48 || used > record.size()) return false;
    uint16_t firstAttr = u16(record.data()+20);
    if (firstAttr < 48 || firstAttr >= used) return false;

    std::u16string bestName;
    int nameRank = -1;
    Payload parsed;
    bool foundUnnamedData = false;
    for (size_t p = firstAttr; validRange(used, p, 16); ) {
        const uint8_t* a = record.data()+p;
        uint32_t type = u32(a);
        if (type == 0xffffffff) break;
        uint32_t attrSize = u32(a+4);
        if (attrSize < 24 || !validRange(used, p, attrSize)) return false;
        uint8_t nonResident = a[8];
        uint8_t nameLength = a[9];
        if (nonResident > 1) return false;
        uint32_t valueSize = 0;
        uint16_t valueOffset = 0;
        if (nonResident == 0) {
            valueSize = u32(a+16);
            valueOffset = u16(a+20);
            if (!validRange(attrSize, valueOffset, valueSize)) return false;
        }
        if (type == 0x30 && nonResident == 0 && valueSize >= 66) {
            const uint8_t* nameAttr = a + valueOffset;
            uint8_t characters = nameAttr[64];
            uint8_t nameSpace = nameAttr[65];
            if (characters && 66u + characters*2u <= valueSize) {
                int rank = (nameSpace == 1 || nameSpace == 3) ? 3 : (nameSpace == 0 ? 2 : 1);
                if (rank > nameRank) {
                    bestName.clear();
                    for (unsigned n=0; n<characters; ++n)
                        bestName.push_back(static_cast<char16_t>(u16(nameAttr+66+n*2)));
                    nameRank = rank;
                }
            }
        }
        if (type == 0x80 && nameLength == 0) {
            // Multiple unnamed $DATA fragments require $ATTRIBUTE_LIST handling.
            if (foundUnnamedData) parsed.supported = false;
            else {
                foundUnnamedData = true;
                parsed.exists = true;
                if (nonResident == 0) {
                    parsed.resident = true;
                    parsed.supported = true;
                    parsed.size = valueSize;
                    if (payload) parsed.data.assign(a+valueOffset, a+valueOffset+valueSize);
                } else if (attrSize >= 64) {
                    parsed.size = u64(a+48);
                    uint16_t runOffset = u16(a+32);
                    uint64_t startVcn = u64(a+16);
                    uint16_t attrFlags = u16(a+12);
                    if (startVcn == 0 && runOffset >= 64 && runOffset < attrSize &&
                        !(attrFlags & (0x0001 | 0x4000 | 0x8000))) {
                        std::string ignored;
                        parsed.supported = parseRuns(a+runOffset, attrSize-runOffset, startVcn,
                                                      parsed.runs, ignored);
                        uint64_t covered = 0;
                        for (const auto& run : parsed.runs) {
                            if (run.vcn != covered || run.lcn < 0 || run.clusters > UINT64_MAX-covered)
                                parsed.supported = false;
                            covered = run.vcn + run.clusters;
                        }
                        if (parsed.supported && covered < (parsed.size / clusterSize_ + (parsed.size % clusterSize_ != 0)))
                            parsed.supported = false;
                    }
                }
            }
        }
        p += attrSize;
    }
    if (bestName.empty() || !parsed.exists) return false;
    file = {index, std::move(bestName), parsed.size, parsed.supported, parsed.resident};
    if (payload) *payload = std::move(parsed);
    return true;
}

ScanResult NtfsVolume::scan(uint64_t maxRecords, const ScanCallback& cb, std::string& error) {
    uint64_t total = maxRecords ? std::min(recordCount_, maxRecords) : recordCount_;
    std::vector<uint8_t> buffer;
    for (uint64_t i = 0; i < total; ++i) {
        if ((i % 1024) == 0 && !cb(0, i, total, nullptr)) return ScanResult::Canceled;
        std::string failure;
        if (!readRecord(i, buffer, failure)) { error = failure; return ScanResult::Error; }
        FoundFile candidate;
        if (parseFile(buffer, i, candidate, nullptr) && !cb(1, i, total, &candidate))
            return ScanResult::Canceled;
    }
    cb(0, total, total, nullptr);
    return ScanResult::Complete;
}

bool NtfsVolume::recover(uint64_t recordIndex, const WriteCallback& write,
                          const ProgressCallback& progress, std::string& error) {
    std::vector<uint8_t> buffer;
    if (!readRecord(recordIndex, buffer, error)) return false;
    FoundFile file;
    Payload payload;
    if (!parseFile(buffer, recordIndex, file, &payload) || !payload.supported) {
        error = "Deleted record is not recoverable with this beta"; return false;
    }
    if (!progress(0, payload.size)) { error = "Canceled"; return false; }
    if (payload.resident) {
        if (!payload.data.empty() && !write(payload.data.data(), payload.data.size())) {
            error = "Destination write failed"; return false;
        }
        if (!progress(payload.size, payload.size)) { error = "Canceled"; return false; }
        return true;
    }
    std::vector<uint8_t> chunk(1024 * 1024);
    uint64_t pos = 0;
    while (pos < payload.size) {
        size_t length = static_cast<size_t>(std::min<uint64_t>(chunk.size(), payload.size-pos));
        if (!readFromRuns(payload.runs, pos, chunk.data(), length, error)) return false;
        if (!write(chunk.data(), length)) { error = "Destination write failed"; return false; }
        pos += length;
        if (!progress(pos, payload.size)) { error = "Canceled"; return false; }
    }
    return true;
}

} // namespace recovery

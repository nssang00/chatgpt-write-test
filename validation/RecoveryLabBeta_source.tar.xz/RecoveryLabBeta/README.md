# RecoveryLab Beta 0.1

**Windows x64 / C# WPF + C++17 / NTFS only.** EaseUS 소스코드를 사용하지 않고 독자적으로 구현한 학습·실험용 파일 복구 프로젝트입니다. 출시 제품 수준의 정확도, 보안성, 성능을 보장하지 않습니다.

## 구현된 기능

- NTFS 부트 섹터 검사(섹터/클러스터/MFT 레코드 크기)
- `$MFT::$DATA`의 데이터런을 읽고, 삭제된 기본 FILE 레코드와 파일 이름 추출
- Update Sequence Array(USA) 고정/검증 (찢어진 레코드 탐지)
- NTFS resident(`$MFT` 내부) 파일 데이터 복구
- 일반 nonresident 데이터런(분할/음수 상대 LCN 지원) 기반 파일 복구
- C# WPF: NTFS 볼륨 선택, `.img/.dd/.raw` 이미지 선택, 검색 결과 표, 진행률, 취소, 파일 복구
- **원본 열기: `CreateFileW(..., GENERIC_READ, ..., OPEN_EXISTING, ...)`만 사용**. Windows 드라이브 열기 시 관리자 권한이 필요합니다.
- 출력: `CreateFileW(..., GENERIC_WRITE, ..., CREATE_NEW, ...)`. 기존 파일 덮어쓰기 금지, 취소/실패 시 부분 출력 파일 삭제.
- 실 볼륨에서 스캔한 경우 출력이 동일 볼륨인지 Volume GUID로 검증해 차단. **가능하면 다른 물리적 드라이브에 저장**.
- 파일명 접두사에 MFT 레코드 번호를 붙여 이름 충돌 완화.

## Beta 0.1에서 지원하지 않는 기능

- FAT32/exFAT/ReFS, BitLocker로 암호화된 원시 NTFS, 물리 디스크 전체(`\\.\PhysicalDriveN`) 파티션 탐색
- Deep Scan/카빙, 삭제된 파티션 자동 복원, 폴더 계층 복원, 미리보기
- 압축·암호화·sparse 파일, NTFS 재분석 지점, ADS 복구, `$ATTRIBUTE_LIST`에 분리된 스트림/조각난 특성
- 파일이 이미 덮어써졌는지 검사 / CRC·해시·파일 포맷 기반 복구 검증
- 강제로 회수한 클러스터가 **삭제 이후 다른 데이터로 재할당**되었는지 실시간 검증
- 잠긴/변경 중인 볼륨의 일관된 스냅샷 생성; VSS 지원 없음

**주의:** 리스트에 "복구 시도 가능"으로 표시된 것은 *메타데이터를 읽을 수 있다는 의미*입니다. 실제 콘텐츠가 정상인지 보장하지 않습니다. SSD TRIM 후에는 원본 데이터가 없어질 수 있습니다. 스캔·복구 중 원본에 새 데이터를 쓰지 마세요. 중요 자료는 먼저 다른 디스크에 이미징하고 전문가 복구를 검토하세요.

## Windows 빌드

필요: 64비트 Windows 10/11, Visual Studio 2022 이상의 **Desktop development with C++**(MSVC + Windows SDK + CMake), .NET 8 SDK. 배포 환경에 .NET Desktop Runtime 8 x64 필요(`--self-contained false`).

저장소 루트에서 **PowerShell**을 열고 실행:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build-windows.ps1
```

이 스크립트는 C++ DLL을 빌드하고 합성 NTFS 단위 테스트를 실행한 뒤, C# WPF 앱을 publish하고 `RecoveryNative.dll`을 옆에 복사합니다.

```powershell
.\publish\RecoveryLab.exe
```

앱 매니페스트의 `requireAdministrator` 때문에 UAC 권한 상승 확인 창이 나타납니다. 원본 디스크/볼륨에 대한 쓰기 권한은 요청하지 않습니다. UAC 권한이 있다고 해서 관리자 계정에서 데이터를 무분별하게 복구해도 된다는 의미는 아닙니다.

## 첫 실행 (실제 디스크 이전에 권장)

1. ZIP에 포함된 `tests/synthetic-ntfs.img`를 그대로 사용합니다. 필요하면 아래 명령으로 다시 생성할 수 있습니다:

   ```powershell
   .\build\native\Release\ntfs_tests.exe --make-image .\tests\synthetic-ntfs.img
   ```

   `tests/synthetic-ntfs.img`는 256 KiB 크기의 인공 NTFS 데이터만 포함합니다. 개인 정보가 없습니다.

2. 앱에서 **이미지 선택**으로 `tests/synthetic-ntfs.img`를 고릅니다.
3. **삭제 파일 검색**을 누릅니다. `deleted.txt`, `photo.jpg`, `compressed.bin`, `fragmented-mft.txt`가 표시되어야 합니다.
4. `deleted.txt`를 선택하고 원하는 별도 파일 이름으로 저장하면 `hello recovered`와 줄바꿈이 저장됩니다. `photo.jpg`는 **JPEG처럼 이름만 붙인 인공 데이터**로, 실제 사진이 아닙니다.
5. 정상 테스트 후에만 권한을 가진 NTFS 드라이브의 읽기 전용 검사를 시도하세요.

### Linux/macOS에서 엔진 단위 테스트

GUI와 Native Windows DLL은 Windows 전용이지만 NTFS 파서는 이식 가능하므로 Unix 계열에서도 테스트할 수 있습니다.

```bash
cmake -S native -B build/test -DCMAKE_BUILD_TYPE=Release
cmake --build build/test --parallel
ctest --test-dir build/test --output-on-failure
./build/test/ntfs_tests --make-image tests/synthetic-ntfs.img
```

## 구성

```text
RecoveryLabBeta/
├── native/
│   ├── CMakeLists.txt
│   ├── include/ntfs_core.hpp       # 파일 시스템 파서 인터페이스
│   ├── include/recovery_api.h      # C ABI (C# P/Invoke)
│   └── src/
│       ├── ntfs_core.cpp          # NTFS 부트/FILE/$DATA/MFT 처리
│       └── recovery_native_win.cpp # Win32 전용 read-only 장치와 출력
├── src/RecoveryGui/
│   ├── RecoveryGui.csproj
│   ├── App.xaml / App.xaml.cs
│   ├── MainWindow.xaml / MainWindow.xaml.cs
│   ├── NativeApi.cs
│   └── app.manifest
├── tests/ntfs_tests.cpp
└── scripts/build-windows.ps1
```

## API 및 보안 경계

- `FR_Scan(sourcePath, maxRecords, callback, user, errorBuffer, capacity)`
  - `sourcePath`: `\\.\C:` 같은 볼륨 경로 또는 절대 `.img/.dd/.raw` 파일 경로.
  - `maxRecords`: `0`이면 $MFT 전체(최대 5천만 레코드 안전 제한), 나머지는 상한.
  - 콜백 반환 `0`이면 중지. 파일명 포인터는 콜백 실행 중에만 유효.
- `FR_Recover(sourcePath, recordIndex, destinationPath, callback, user, errorBuffer, capacity)`
  - 출력 경로는 드라이브 문자로 시작하는 절대 경로이어야 합니다.
  - 반환 `0` 성공(무결성 미검증), `1` 사용자 취소, `-1` 오류.

대응 기능을 추가하려면 먼저 이미지 기반 회귀 테스트부터 작성하고, 그 후 실제 장치에서 시험하는 방식이 안전합니다. 별도의 디스크 이미지 도구로 **원본 미디어 이미징을 먼저 수행**하는 것을 권장합니다.

## 환경별 검증 상태

- C++ NTFS 엔진: Linux g++에서 합성 이미지 기반 단위 테스트 실행 가능.
- Windows 전용 C++ DLL 및 C# WPF: 실제 Windows + Visual Studio/.NET 도구 체인에서 빌드해야 합니다. Linux 환경에서는 GUI EXE를 직접 컴파일하거나 실행할 수 없습니다.

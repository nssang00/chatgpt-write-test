using System.Windows;
namespace RecoveryLab;
public partial class App : Application { }

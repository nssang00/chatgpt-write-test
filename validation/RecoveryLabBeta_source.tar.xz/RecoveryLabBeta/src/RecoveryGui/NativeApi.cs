using System.Runtime.InteropServices;
using System.Text;

namespace RecoveryLab;

internal static class NativeApi
{
    // Pointer to file name is valid only during the callback.
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate int ScanCallback(uint kind, ulong index, ulong total,
        IntPtr fileName, ulong bytes, uint flags, IntPtr user);

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
    internal delegate int ProgressCallback(ulong completed, ulong total, IntPtr user);

    [DllImport("RecoveryNative.dll", CallingConvention = CallingConvention.Cdecl,
        CharSet = CharSet.Unicode, EntryPoint = "FR_Scan", ExactSpelling = true)]
    internal static extern int Scan(string source, ulong maxRecords, ScanCallback callback,
        IntPtr user, [Out] StringBuilder error, uint errorCapacity);

    [DllImport("RecoveryNative.dll", CallingConvention = CallingConvention.Cdecl,
        CharSet = CharSet.Unicode, EntryPoint = "FR_Recover", ExactSpelling = true)]
    internal static extern int Recover(string source, ulong recordIndex, string destination,
        ProgressCallback callback, IntPtr user, [Out] StringBuilder error, uint errorCapacity);
}

using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace RecoveryLab;

public sealed record SourceDrive(string Label, string DevicePath);

public sealed class FileCandidate
{
    public ulong RecordIndex { get; init; }
    public string FileName { get; init; } = "";
    public ulong ByteLength { get; init; }
    public bool Supported { get; init; }
    public bool Resident { get; init; }
    public string SizeLabel => $"{ByteLength:N0} B";
    public string ModeLabel => Resident ? "MFT 내부" : "클러스터 기반";
    public string StatusLabel => Supported ? "복구 시도 가능" : "이 버전 미지원";
}

public partial class MainWindow : Window
{
    private readonly ObservableCollection<FileCandidate> _files = new();
    private CancellationTokenSource? _cancel;
    private bool _busy;
    private string? _scannedSource;
    private const int MaxUiResults = 20_000;

    public MainWindow()
    {
        InitializeComponent();
        FilesGrid.ItemsSource = _files;
        RefreshDrives();
    }

    private void RefreshDrives()
    {
        var drives = new List<SourceDrive>();
        foreach (var disk in DriveInfo.GetDrives())
        {
            try
            {
                if (!disk.IsReady || !string.Equals(disk.DriveFormat, "NTFS", StringComparison.OrdinalIgnoreCase))
                    continue;
                string letter = disk.Name.TrimEnd('\\');
                drives.Add(new SourceDrive($"{letter}  [{disk.DriveType}]", @"\\.\" + letter));
            }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
        DrivePicker.ItemsSource = drives;
        if (drives.Count > 0) DrivePicker.SelectedIndex = 0;
    }

    private void Refresh_Click(object sender, RoutedEventArgs e)
    {
        if (!_busy) RefreshDrives();
    }

    private void DrivePicker_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (DrivePicker.SelectedItem is SourceDrive drive)
            SourceBox.Text = drive.DevicePath;
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        var dialog = new OpenFileDialog
        {
            Title = "읽기 전용으로 분석할 NTFS 볼륨 이미지 선택",
            Filter = "NTFS 디스크 이미지|*.img;*.dd;*.raw",
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) == true)
            SourceBox.Text = dialog.FileName;
    }

    private void SetBusy(bool busy)
    {
        _busy = busy;
        ScanButton.IsEnabled = !busy;
        CancelButton.IsEnabled = busy;
        RecoverButton.IsEnabled = !busy && FilesGrid.SelectedItem is FileCandidate { Supported: true }
            && _scannedSource == SourceBox.Text;
        DrivePicker.IsEnabled = !busy;
        BrowseButton.IsEnabled = !busy;
        RefreshButton.IsEnabled = !busy;
        FullScanCheck.IsEnabled = !busy;
    }

    private async void Scan_Click(object sender, RoutedEventArgs e)
    {
        if (_busy || string.IsNullOrWhiteSpace(SourceBox.Text)) return;
        string source = SourceBox.Text;
        _files.Clear();
        _scannedSource = null;
        _cancel = new CancellationTokenSource();
        WorkProgress.Value = 0;
        StatusText.Text = "NTFS $MFT 분석 시작...";
        SetBusy(true);
        int received = 0;
        ulong limit = FullScanCheck.IsChecked == true ? 0UL : 200_000UL;
        try
        {
            var error = new StringBuilder(1024);
            NativeApi.ScanCallback cb = (kind, recordIndex, total, fileName, bytes, flags, user) =>
            {
                if (_cancel?.IsCancellationRequested == true) return 0;
                if (kind == 0)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        WorkProgress.Value = total == 0 ? 0 : (double)recordIndex / total * 100;
                        StatusText.Text = $"MFT 검사 중: {recordIndex:N0} / {total:N0} 레코드  |  후보 {received:N0}개";
                    }));
                }
                else if (kind == 1)
                {
                    var number = Interlocked.Increment(ref received);
                    if (number > MaxUiResults) return 0; // Protect GUI memory.
                    var candidate = new FileCandidate
                    {
                        RecordIndex = recordIndex,
                        FileName = Marshal.PtrToStringUni(fileName) ?? "(이름 없음)",
                        ByteLength = bytes,
                        Supported = (flags & 1) != 0,
                        Resident = (flags & 2) != 0
                    };
                    Dispatcher.BeginInvoke(new Action(() => _files.Add(candidate)));
                }
                return 1;
            };
            int code = await Task.Run(() => NativeApi.Scan(source, limit, cb, IntPtr.Zero,
                                                          error, (uint)error.Capacity));
            GC.KeepAlive(cb);
            _scannedSource = source;
            string ending = code switch
            {
                0 => "검색 완료",
                1 when received > MaxUiResults => "표시 제한(20,000개)에 도달하여 검색 중단",
                1 => "검색 취소",
                _ => "검색 오류: " + error
            };
            StatusText.Text = $"{ending}  |  검색 후보 {Math.Min(received, MaxUiResults):N0}개";
            if (code == 0) WorkProgress.Value = 100;
        }
        catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException
                                   or BadImageFormatException or IOException)
        {
            StatusText.Text = $"실행 구성 오류: {ex.Message}";
            MessageBox.Show(this, "RecoveryNative.dll(x64)이 실행 파일 옆에 있는지 확인하세요.\n\n" + ex.Message,
                "엔진 로딩 오류", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            SetBusy(false);
            _cancel?.Dispose();
            _cancel = null;
        }
    }

    private void Cancel_Click(object sender, RoutedEventArgs e) => _cancel?.Cancel();

    private void FilesGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        RecoverButton.IsEnabled = !_busy && FilesGrid.SelectedItem is FileCandidate { Supported: true }
            && _scannedSource == SourceBox.Text;
    }

    private async void Recover_Click(object sender, RoutedEventArgs e)
    {
        if (_busy || FilesGrid.SelectedItem is not FileCandidate { Supported: true } entry ||
            _scannedSource != SourceBox.Text) return;
        string source = SourceBox.Text;
        string safeName = SanitizeName(entry.FileName);
        var dialog = new SaveFileDialog
        {
            Title = "다른 볼륨에 복구 파일 저장 (기존 파일 덮어쓰지 않음)",
            FileName = $"{entry.RecordIndex:D8}_{safeName}",
            Filter = "모든 파일|*.*",
            OverwritePrompt = false,
            AddExtension = false
        };
        if (dialog.ShowDialog(this) != true) return;
        string output = dialog.FileName;
        if (File.Exists(output))
        {
            MessageBox.Show(this, "이미 있는 파일입니다. 다른 파일 이름을 선택하세요.");
            return;
        }
        string sourceLetter = source.StartsWith(@"\\.\", StringComparison.Ordinal) && source.Length == 6
            ? source.Substring(4, 2) : "";
        if (sourceLetter.Length != 0 &&
            string.Equals(Path.GetPathRoot(output)?.Substring(0, 2), sourceLetter,
                StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show(this, "원본 볼륨에 복구 파일을 저장할 수 없습니다. 다른 드라이브를 선택하세요.",
                "원본 보호", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        _cancel = new CancellationTokenSource();
        SetBusy(true);
        WorkProgress.Value = 0;
        StatusText.Text = $"복구 중: {entry.FileName}";
        try
        {
            var error = new StringBuilder(1024);
            NativeApi.ProgressCallback cb = (completed, total, _) =>
            {
                if (_cancel?.IsCancellationRequested == true) return 0;
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    WorkProgress.Value = total == 0 ? 100 : (double)completed / total * 100;
                }));
                return 1;
            };
            int code = await Task.Run(() => NativeApi.Recover(source, entry.RecordIndex, output,
                cb, IntPtr.Zero, error, (uint)error.Capacity));
            GC.KeepAlive(cb);
            StatusText.Text = code switch
            {
                0 => $"복구 파일 저장 완료(무결성 미검증): {output}",
                1 => "복구 취소 — 부분 출력 파일 제거됨",
                _ => $"복구 실패: {error}"
            };
        }
        catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException
                                   or BadImageFormatException or IOException)
        {
            StatusText.Text = $"복구 엔진 오류: {ex.Message}";
        }
        finally
        {
            SetBusy(false);
            _cancel?.Dispose();
            _cancel = null;
        }
    }

    private static string SanitizeName(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        string safe = new string(name.Select(c => invalid.Contains(c) ? '_' : c).ToArray()).Trim(' ', '.');
        if (safe.Length > 110) safe = safe[..110];
        return string.IsNullOrWhiteSpace(safe) ? "unnamed.bin" : safe;
    }
}

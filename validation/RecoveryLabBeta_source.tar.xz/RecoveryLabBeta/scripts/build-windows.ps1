# Run in a Windows x64 environment with Visual Studio C++ tools, CMake, and .NET 8 SDK.
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$nativeBuild = Join-Path $root 'build\native'
$publish = Join-Path $root 'publish'

cmake -S (Join-Path $root 'native') -B $nativeBuild -A x64 -DBUILD_TESTING=ON
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed' }
cmake --build $nativeBuild --config Release --parallel
if ($LASTEXITCODE -ne 0) { throw 'Native compilation failed' }
ctest --test-dir $nativeBuild -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw 'Native tests failed' }

dotnet publish (Join-Path $root 'src\RecoveryGui\RecoveryGui.csproj') `
    -c Release -r win-x64 --self-contained false -o $publish
if ($LASTEXITCODE -ne 0) { throw 'WPF compilation failed' }

$dll = Join-Path $nativeBuild 'Release\RecoveryNative.dll'
if (-not (Test-Path $dll)) { throw "Expected native DLL not found: $dll" }
Copy-Item $dll (Join-Path $publish 'RecoveryNative.dll') -Force
Write-Host "Built: $publish\RecoveryLab.exe" -ForegroundColor Green
Write-Host 'Run as administrator (UAC prompt). Raw NTFS source is opened with GENERIC_READ only.'

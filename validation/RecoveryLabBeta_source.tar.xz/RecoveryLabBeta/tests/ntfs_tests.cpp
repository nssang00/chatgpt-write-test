#include "ntfs_core.hpp"
#ifdef NDEBUG
#undef NDEBUG // Verify assertions even in Release test builds.
#endif
#include <cassert>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace recovery;
namespace {
constexpr size_t sector = 512, cluster = 4096, recordSize = 1024;
void put16(uint8_t* p, uint16_t v) {p[0]=uint8_t(v);p[1]=uint8_t(v>>8);}
void put32(uint8_t* p, uint32_t v) {put16(p, uint16_t(v));put16(p+2,uint16_t(v>>16));}
void put64(uint8_t* p, uint64_t v) {put32(p,uint32_t(v));put32(p+4,uint32_t(v>>32));}
size_t align8(size_t x) { return (x+7)&~size_t(7); }

class MemoryReader : public Reader {
public:
    std::vector<uint8_t> bytes;
    explicit MemoryReader(size_t length) : bytes(length,0) {}
    bool read(uint64_t offset, void* target, size_t length) override {
        if (offset > bytes.size() || length > bytes.size() - offset) return false;
        std::memcpy(target, bytes.data()+offset, length);
        return true;
    }
};

struct Builder {
    std::vector<uint8_t> data = std::vector<uint8_t>(recordSize,0);
    size_t pos = 0x38;
    explicit Builder(bool allocated, bool directory=false) {
        std::memcpy(data.data(), "FILE", 4);
        put16(data.data()+4,0x30);
        put16(data.data()+6,3);
        put16(data.data()+16,7);
        put16(data.data()+20,0x38);
        put16(data.data()+22,uint16_t((allocated?1:0)|(directory?2:0)));
        put32(data.data()+28,recordSize);
    }
    void name(const std::u16string& text) {
        size_t valueLen=66+2*text.size(), attrLen=align8(24+valueLen);
        assert(pos+attrLen+8<recordSize);
        uint8_t* a=data.data()+pos;
        put32(a,0x30); put32(a+4,static_cast<uint32_t>(attrLen));
        put32(a+16,static_cast<uint32_t>(valueLen));put16(a+20,24);
        a[24+64]=uint8_t(text.size());a[24+65]=1;
        for(size_t i=0;i<text.size();++i)put16(a+24+66+2*i,text[i]);
        pos+=attrLen;
    }
    void resident(const std::string& text) {
        size_t attrLen=align8(24+text.size());
        assert(pos+attrLen+8<recordSize);
        uint8_t* a=data.data()+pos;
        put32(a,0x80);put32(a+4,static_cast<uint32_t>(attrLen));
        put32(a+16,static_cast<uint32_t>(text.size()));put16(a+20,24);
        std::memcpy(a+24,text.data(),text.size());
        pos+=attrLen;
    }
    void nonresident(uint64_t length, const std::vector<uint8_t>& runs, uint16_t flags = 0) {
        size_t attrLen=align8(64+runs.size());
        assert(pos+attrLen+8<recordSize);
        uint8_t* a=data.data()+pos;
        put32(a,0x80);put32(a+4,static_cast<uint32_t>(attrLen));a[8]=1;
        put16(a+12,flags);
        // Last VCN is one less than allocated cluster count.
        put64(a+24,(length+cluster-1)/cluster-1);
        put16(a+32,64);put64(a+40,((length+cluster-1)/cluster)*cluster);
        put64(a+48,length);put64(a+56,length);
        std::memcpy(a+64,runs.data(),runs.size());
        pos+=attrLen;
    }
    std::vector<uint8_t> finish() {
        assert(pos+4<=recordSize);
        put32(data.data()+pos,0xffffffff);
        put32(data.data()+24,static_cast<uint32_t>(pos+4));
        // Multi-sector fixup protection on both 512-byte sector tails.
        uint16_t marker=0xBEEF;
        put16(data.data()+0x30,marker);
        put16(data.data()+0x32,uint16_t(data[510]|(data[511]<<8)));
        put16(data.data()+0x34,uint16_t(data[1022]|(data[1023]<<8)));
        put16(data.data()+510,marker);put16(data.data()+1022,marker);
        return data;
    }
};

void writeRecord(MemoryReader& image, int index, const std::vector<uint8_t>& bytes) {
    // $MFT VCNs 0..1 at LCN 4..5, and VCN 2 at LCN 10.
    size_t offset=index*recordSize;
    size_t actual=offset < cluster*2 ? cluster*4+offset : cluster*10+(offset-cluster*2);
    std::memcpy(image.bytes.data()+actual,bytes.data(),bytes.size());
}
}

int main(int argc, char** argv) {
    MemoryReader image(64*cluster);
    auto* b=image.bytes.data();
    std::memcpy(b+3,"NTFS    ",8);
    put16(b+11,sector);b[13]=8;
    put64(b+40,image.bytes.size()/sector);
    put64(b+48,4);b[64]=uint8_t(-10);

    // Three logical MFT clusters: [LCN 4, LCN 5], then [LCN 10].
    Builder mft(true);
    mft.nonresident(12*recordSize,{0x11,2,4,0x11,1,6,0});
    writeRecord(image,0,mft.finish());

    Builder r1(false);
    r1.name(u"deleted.txt");r1.resident("hello recovered\n");
    writeRecord(image,1,r1.finish());

    // Nonresident 5,000-byte file: LCN 30, then LCN 28 (negative relative offset).
    Builder r2(false);
    r2.name(u"photo.jpg");r2.nonresident(5000,{0x11,1,30,0x11,1,0xFE,0});
    writeRecord(image,2,r2.finish());
    std::memset(b+30*cluster,'X',cluster);
    std::memset(b+28*cluster,'Y',cluster);

    Builder r3(true);
    r3.name(u"active.txt");r3.resident("not deleted");
    writeRecord(image,3,r3.finish());

    Builder r4(false);
    r4.name(u"broken.bin");r4.resident("broken USA");
    auto corrupt = r4.finish();
    corrupt[510] = 0; // Reject bad fixup rather than giving unsafe result.
    writeRecord(image,4,corrupt);

    Builder r5(false);
    r5.name(u"compressed.bin");r5.nonresident(100,{0x11,1,40,0},0x0001);
    writeRecord(image,5,r5.finish());

    Builder r6(false,true);
    r6.name(u"oldfolder");r6.resident("fake dir");
    writeRecord(image,6,r6.finish());

    Builder r9(false);
    r9.name(u"fragmented-mft.txt");r9.resident("mft extent");
    writeRecord(image,9,r9.finish());

    if (argc == 3 && std::string(argv[1]) == "--make-image") {
        std::ofstream out(argv[2], std::ios::binary | std::ios::trunc);
        assert(out.good());
        out.write(reinterpret_cast<const char*>(image.bytes.data()),
                  static_cast<std::streamsize>(image.bytes.size()));
        assert(out.good());
    }
    NtfsVolume ntfs(image);
    std::string error;
    assert(ntfs.initialize(error) && "Synthetic image should initialize");
    assert(ntfs.recordCount()==12);
    std::vector<FoundFile> found;
    uint64_t lastProgress = 0;
    auto scan=ntfs.scan(0,[&](uint32_t kind,uint64_t current,uint64_t,
                               const FoundFile* item) {
        if(kind==1 && item) found.push_back(*item);
        if(kind==0) lastProgress=current;
        return true;
    },error);
    assert(scan==ScanResult::Complete);
    assert(lastProgress==12);
    assert(found.size()==4); // deleted.txt, photo.jpg, compressed.bin, fragmented-mft.txt
    assert(found[0].recordIndex==1 && found[0].supported && found[0].resident);
    assert(found[1].recordIndex==2 && found[1].supported && !found[1].resident);
    assert(found[1].size==5000);
    assert(found[2].recordIndex==5 && !found[2].supported);
    assert(found[3].recordIndex==9 && found[3].supported);

    std::string bytes;
    auto writer=[&](const uint8_t* p,size_t n) { bytes.append(reinterpret_cast<const char*>(p),n);return true; };
    auto progress=[](uint64_t,uint64_t) { return true; };
    assert(ntfs.recover(1,writer,progress,error));
    assert(bytes=="hello recovered\n");
    bytes.clear();
    assert(ntfs.recover(2,writer,progress,error));
    assert(bytes.size()==5000);
    assert(bytes.substr(0,4096)==std::string(4096,'X'));
    assert(bytes.substr(4096)==std::string(904,'Y'));
    bytes.clear();
    assert(ntfs.recover(9,writer,progress,error));
    assert(bytes=="mft extent");
    assert(!ntfs.recover(3,writer,progress,error)); // allocated file must never recover
    assert(!ntfs.recover(5,writer,progress,error)); // compressed unsupported
    std::cout << "PASS: NTFS USA, fragmented $MFT, deleted vs active records, "
                 "resident/nonresident streams, signed data runs, invalid/unsupported files\n";
    return 0;
}

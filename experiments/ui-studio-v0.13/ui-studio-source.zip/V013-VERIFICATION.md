# UI Studio v0.13 — Component-first verification

## Scope

Create a component with Designer, publish typed props and events, compose that component inside another UserControl (multiple levels), create independent instances for preview, and export a standalone React package that runs within a separate React app.

## Commands

```sh
npm install
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v013
mkdir -p tests/component-v013
unzip -q examples/CustomerBrowser-react-component-v0.13.zip -d tests/component-v013
(cd tests/component-v013 && npm install && npm run build)
(cd tests/consumer-v013 && npm install && npm run build)
UI_STUDIO_USE_SYSTEM_CHROME=1 CI=1 npm run test:e2e
UI_STUDIO_USE_SYSTEM_CHROME=1 CI=1 npx playwright test --config=e2e/consumer-v013.config.js
```

## v0.13 additions

- `createBlankComponentWorkspace`: no app-building assumptions; page is a preview/test harness.
- `addComponentToPreview`: references Definition with unique instance ID, default public props, not copied UI tree.
- `componentUsage`: reverse references across other Definitions and preview pages.
- UI Designer: named component creation modal, Component Library, navigate Instance → Definition, Preview Instance button.
- New Core regression, browser authoring + nested navigation E2E, independently installed React consumer E2E.

## Final CI evidence

Use the GitHub Actions run details, job logs and Playwright artifacts. Only mark browser E2E success after its actual run completes.

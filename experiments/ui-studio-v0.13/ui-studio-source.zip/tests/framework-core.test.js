import test from 'node:test';
import assert from 'node:assert/strict';
import {createSearchBoxDocument,validateDocument,parseDocument,serializeDocument,literal,binding,migrateV5ToV6,findNode} from '../packages/schema/index.js';
import {ControlRegistry,createDefaultRegistry,ReactiveStore,RuntimeSession,DataContext,readProperty,writeBinding,controlProperty,setControlProperty,patchDefinitionProperty,patchInstanceBinding,patchInstanceOverride,patchInstanceProp,matchesPublicEvent,instancePropertyProviders} from '../packages/core/index.js';
import {createProject} from '../src/model.js';
const reg=createDefaultRegistry();
const demo=()=>createSearchBoxDocument();
function twoInstances(doc){const session=new RuntimeSession(doc),root=doc.pages.main.root,definition=doc.definitions.SearchBox;return {
  session,definition,customer:session.instanceScope(root.children[1],definition,session.rootScope(),'main/customerSearch'),
  product:session.instanceScope(root.children[2],definition,session.rootScope(),'main/productSearch')
};}
test('v6 canonical schema: SearchBox document validates',()=>assert.equal(validateDocument(demo(),reg).schemaVersion,6));
test('Registry metadata is renderer-independent and extensible',()=>{
  const r=new ControlRegistry();r.register({typeId:'acme/Rating',displayName:'Rating',category:'Inputs',properties:{score:{type:'number',bindable:true,twoWay:true,defaultValue:0}},events:{change:{}}});
  assert.equal(r.list().length,1);assert.equal(r.get('acme/Rating').properties.score.twoWay,true);
  assert.throws(()=>r.register({typeId:'acme/Rating',properties:{}}),/중복/);
});
test('Registry rejects unsafe TwoWay without bindable',()=>assert.throws(()=>reg.register({typeId:'Invalid',properties:{bad:{type:'string',twoWay:true}},events:{}}),/bindable/));
test('ReactiveStore handles deep reads/writes with immutable snapshots',()=>{
  const store=new ReactiveStore({user:{name:'Alice'}});
  const original=store.snapshot();store.set(['user','name'],'Bob');
  assert.equal(store.get(['user','name']),'Bob');assert.equal(original.user.name,'Alice');
});
test('ReactiveStore notifies path-sensitive subscribers only',()=>{
  const store=new ReactiveStore({customer:{keyword:''},product:{keyword:''}});
  let customer=0,product=0,ancestor=0;
  const stop1=store.subscribe(['customer','keyword'],()=>customer++);
  store.subscribe(['product','keyword'],()=>product++);
  store.subscribe(['customer'],()=>ancestor++);
  store.set(['customer','keyword'],'kim');assert.deepEqual([customer,product,ancestor],[1,0,1]);
  stop1();store.set(['customer'],{keyword:'lee'});assert.deepEqual([customer,product,ancestor],[1,0,2]);
});
test('read only source and prototype pollution writes are refused',()=>{
  const readonly=new ReactiveStore({users:[]},true);
  assert.throws(()=>readonly.set(['users'],[]),/읽기 전용/);
  const store=new ReactiveStore({});assert.throws(()=>store.set(['__proto__','polluted'],1),/안전하지/);
  assert.equal({}.polluted,undefined);
});
test('DataContext inherits state and can override local source',()=>{
  const state=new ReactiveStore({keyword:'outer'}),local=new ReactiveStore({keyword:'inner'});
  const scope=new DataContext({state});const child=scope.child({local});
  assert.equal(child.resolve('state').get(['keyword']),'outer');assert.equal(child.resolve('local').get(['keyword']),'inner');
});
test('OneWay bindings reject writing and TwoWay write propagates',()=>{
  const state=new ReactiveStore({keyword:''});const scope=new DataContext({state});
  assert.throws(()=>writeBinding(binding('state',['keyword'],'OneWay'),scope,'x'),/OneWay/);
  assert.equal(writeBinding(binding('state',['keyword'],'TwoWay'),scope,'updated'),true);
  assert.equal(readProperty(binding('state',['keyword']),scope),'updated');
});
test('blur binding defers write until blur phase',()=>{
  const state=new ReactiveStore({keyword:''});const scope=new DataContext({state});
  const value=binding('state',['keyword'],'TwoWay','blur');
  assert.equal(writeBinding(value,scope,'later','change'),false);
  assert.equal(state.get(['keyword']),'');
  assert.equal(writeBinding(value,scope,'later','blur'),true);
  assert.equal(state.get(['keyword']),'later');
});
test('literal and resource values resolve consistently',()=>{
  const scope=new DataContext({});
  assert.equal(readProperty(literal('abc'),scope),'abc');
  assert.equal(readProperty({kind:'resource',key:'primary'},scope,{primary:'#3366ee'}),'#3366ee');
});
test('SearchBox two instances independently route TwoWay inputs through props scope',()=>{
  const doc=demo(),{session,definition,customer,product}=twoInstances(doc);
  const input=findNode(definition.root,'searchInput');
  setControlProperty(input,'value','Kim',reg,customer.scope,{});
  assert.equal(session.state.get(['customer','keyword']),'Kim');
  assert.equal(session.state.get(['product','keyword']),'');
  setControlProperty(input,'value','Mac',reg,product.scope,{});
  assert.equal(session.state.get(['product','keyword']),'Mac');
  assert.equal(controlProperty(input,'value',reg,customer.scope,{}),'Kim');
  assert.equal(controlProperty(input,'value',reg,product.scope,{}),'Mac');
});
test('public props and scoped DataContext fallback are independent',()=>{
  const doc=demo(),{customer,product,definition}=twoInstances(doc),input=findNode(definition.root,'searchInput');
  assert.equal(controlProperty(input,'placeholder',reg,customer.scope,{}),'고객명 입력');
  assert.equal(controlProperty(input,'placeholder',reg,product.scope,{}),'상품명 입력');
  assert.throws(()=>product.propsStore.set(['placeholder'],'change'),/TwoWay/);
});
test('definition edit propagates to all instances while color override survives',()=>{
  const doc=demo();
  const changed=patchDefinitionProperty(doc,'SearchBox','searchButton','text',literal('찾기'),reg);
  const a=changed.pages.main.root.children[1],b=changed.pages.main.root.children[2];
  const button=findNode(changed.definitions.SearchBox.root,'searchButton');
  const session=new RuntimeSession(changed);
  const as=session.instanceScope(a,changed.definitions.SearchBox,session.rootScope(),'main/A');
  const bs=session.instanceScope(b,changed.definitions.SearchBox,session.rootScope(),'main/B');
  assert.equal(changed.definitions.SearchBox.revision,2);
  assert.equal(controlProperty(button,'text',reg,as.scope,a.overrides),'찾기');
  assert.equal(controlProperty(button,'text',reg,bs.scope,b.overrides),'찾기');
  assert.equal(controlProperty(button,'color',reg,as.scope,a.overrides),'#3764df');
  assert.equal(controlProperty(button,'color',reg,bs.scope,b.overrides),'#16a34a');
});
test('overrides can be changed/reset without changing original definition',()=>{
  const d1=patchInstanceOverride(demo(),'customerSearch','searchButton','color',literal('#ff0000'),reg);
  assert.equal(d1.pages.main.root.children[1].overrides.searchButton.color.value,'#ff0000');
  assert.equal(findNode(d1.definitions.SearchBox.root,'searchButton').props.color.value,'#3764df');
  const d2=patchInstanceOverride(d1,'customerSearch','searchButton','color',null,reg);
  assert.deepEqual(d2.pages.main.root.children[1].overrides,{});
});
test('override permissions and public binding conflict are validated',()=>{
  const bad=demo();bad.pages.main.root.children[2].overrides.searchInput={value:literal('bad')};
  assert.throws(()=>validateDocument(bad,reg),/미허용/);
  const collision=demo();collision.definitions.SearchBox.overridePolicy.searchInput=['value'];collision.pages.main.root.children[2].overrides.searchInput={value:literal('bad')};
  assert.throws(()=>validateDocument(collision,reg),/충돌/);
});
test('state binding target changes for only selected instance',()=>{
  const doc=patchInstanceBinding(demo(),'productSearch','value',binding('state',['customer','keyword'],'TwoWay'),reg);
  assert.deepEqual(doc.pages.main.root.children[2].bindings.value.path,['customer','keyword']);
  assert.deepEqual(doc.pages.main.root.children[1].bindings.value.path,['customer','keyword']);
  assert.deepEqual(demo().pages.main.root.children[2].bindings.value.path,['product','keyword']);
});
test('JSON save/load round trip preserves bindings, definitions, IDs, overrides',()=>{
  const doc=patchDefinitionProperty(demo(),'SearchBox','searchButton','text',literal('검색하기'),reg);
  assert.deepEqual(parseDocument(serializeDocument(doc,reg),reg),doc);
});
test('instance state persists through schema edits when session is retained',()=>{
  const initial=demo(),session=new RuntimeSession(initial);
  session.state.set(['customer','keyword'],'Kim');
  const changed=patchDefinitionProperty(initial,'SearchBox','searchButton','text',literal('찾기'),reg);
  session.document=changed;
  assert.equal(session.state.get(['customer','keyword']),'Kim');
  assert.equal(changed.data.state.customer.keyword,'');
});
test('schema detects missing definition and cycles',()=>{
  const missing=demo();missing.pages.main.root.children[1].definitionId='Missing';
  assert.throws(()=>validateDocument(missing,reg),/없는 Definition/);
  const cycle=demo();cycle.definitions.SearchBox.root.children.push({id:'recursive',kind:'instance',definitionId:'SearchBox'});
  assert.throws(()=>validateDocument(cycle,reg),/순환 참조/);
});
test('schema detects duplicate node IDs within definition',()=>{
  const doc=demo();doc.definitions.SearchBox.root.children[1].id='searchInput';
  assert.throws(()=>validateDocument(doc,reg),/중복/);
});
test('v5 Designer can be migrated to v6 without mutating the source project',()=>{
  const before=createProject(),snapshot=structuredClone(before);
  const next=migrateV5ToV6(before);
  assert.equal(next.schemaVersion,6);
  assert.ok(validateDocument(next,reg));
  assert.deepEqual(before,snapshot);
  const input=findNode(next.pages.main.root,'search-input');
  assert.equal(input.props.value.kind,'binding');
  assert.deepEqual(input.props.value.path,['keyword']);
});
test('Headless schema and Core packages do not import React or AntD',async()=>{
  const fs=await import('node:fs');
  for(const filename of ['packages/schema/index.js','packages/core/registry.js','packages/core/store.js','packages/core/binding.js','packages/core/properties.js','packages/core/session.js','packages/core/layout.js','packages/core/document.js']){
    const source=fs.readFileSync(filename,'utf8');
    assert.doesNotMatch(source,/from\s+['"](?:react|antd)['"]/,filename);
  }
});

test('public event only fires from explicitly mapped internal control event',()=>{
  const definition=demo().definitions.SearchBox;
  assert.equal(matchesPublicEvent(definition,'search','searchButton','click'),true);
  assert.equal(matchesPublicEvent(definition,'search','searchInput','click'),false);
  assert.equal(matchesPublicEvent(definition,'search','searchButton','change'),false);
  assert.equal(matchesPublicEvent(definition,'delete','searchButton','click'),false);
});
test('DataContext supports nested scoped store bindings with TwoWay writes',()=>{
  const state=new ReactiveStore({customer:{keyword:'before'}});
  const outer=new DataContext({state});
  const scope=outer.child({context:{
    get:path=>state.get(['customer',...path]),
    set:(path,value)=>state.set(['customer',...path],value),
    subscribe:(path,fn)=>state.subscribe(['customer',...path],fn)
  }});
  const spec=binding('context',['keyword'],'TwoWay');
  assert.equal(readProperty(spec,scope),'before');
  writeBinding(spec,scope,'after');
  assert.equal(state.get(['customer','keyword']),'after');
});

test('public instance prop editing changes only that instance',()=>{
  const doc=patchInstanceProp(demo(),'customerSearch','placeholder',literal('이름 검색'),reg);
  assert.equal(doc.pages.main.root.children[1].props.placeholder.value,'이름 검색');
  assert.equal(doc.pages.main.root.children[2].props.placeholder.value,'상품명 입력');
  assert.equal(demo().pages.main.root.children[1].props.placeholder.value,'고객명 입력');
});
test('registry metadata is authoritative for new component property validation',()=>{
  const document=demo();
  document.definitions.SearchBox.root.children[1].props.unknown=literal(10);
  assert.throws(()=>validateDocument(document,reg),/미등록 Property/);
  const other=demo();other.definitions.SearchBox.root.children[0].props.value=literal(99);
  assert.throws(()=>validateDocument(other,reg),/Property 타입 오류/);
});

test('public property target mapping works even if original child has a literal value',()=>{
  const doc=demo();const definition=doc.definitions.SearchBox;
  const input=findNode(definition.root,'searchInput');
  input.props.placeholder=literal('원본 placeholder');
  const instance=doc.pages.main.root.children[1];
  const {scope}=new RuntimeSession(doc).instanceScope(instance,definition,new RuntimeSession(doc).rootScope(),'instanceCustomer');
  const mapped=instancePropertyProviders(definition,instance);
  assert.equal(controlProperty(input,'placeholder',reg,scope,mapped),'고객명 입력');
});
test('public mapped property cannot also be overridden',()=>{
  const doc=demo();doc.definitions.SearchBox.overridePolicy.searchInput=['placeholder'];
  doc.pages.main.root.children[1].overrides.searchInput={placeholder:literal('conflict')};
  assert.throws(()=>validateDocument(doc,reg),/충돌/);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {createSearchBoxDocument,findNode,literal,binding,validateDocument,serializeDocument,parseDocument} from '../packages/schema/index.js';
import {createDefaultRegistry,RuntimeSession,createEditorNode,insertEditorNode,moveEditorNode,removeEditorNode,patchEditorNode,setEditorProperty,setEditorLayout,allocateNodeId,geometryInsertion,bindableFields,extractDefinition,exposeDefinitionProperty,exposeDefinitionEvent,allowInstanceOverride,instancePropertyProviders,controlProperty,patchDefinitionProperty,patchInstanceOverride} from '../packages/core/index.js';
import {printV6Dsl,parseV6Dsl} from '../packages/format-dsl/index.js';
import {readFileSync} from 'node:fs';
const r=createDefaultRegistry(),fresh=()=>createSearchBoxDocument();
test('v6 DSL prints a readable Page and preserves SearchBox instances',()=>{
  const doc=fresh(),s=printV6Dsl(doc.pages.main.root).text;
  assert.match(s,/<Page id="pageRoot"/);
  assert.match(s,/<Use id="customerSearch"/);
  assert.match(s,/overrides=/);
  const next=parseV6Dsl(s,doc,r).document;
  assert.deepEqual(next,doc);
});
test('v6 DSL edits layout by tag while preserving instance ID and bindings',()=>{
  const doc=fresh(),s=printV6Dsl(doc.pages.main.root).text.replace('<Page id="pageRoot" name="Page" layout="column"','<Row id="pageRoot" name="Page"').replace('</Page>','</Row>');
  const parsed=parseV6Dsl(s,doc,r).document;
  assert.equal(parsed.pages.main.root.layout.type,'row');
  assert.equal(findNode(parsed.pages.main.root,'productSearch').bindings.value.path[0],'product');
  assert.deepEqual(parsed.definitions,doc.definitions);
});
test('v6 DSL accepts ergonomic one-way/two-way binding strings',()=>{
  const src='<Page id="root"><Input id="name" value="{{state.customer.keyword}}" placeholder="검색어" /><Button id="ok" text="검색" /></Page>';
  const doc=parseV6Dsl(src,fresh(),r).document;const input=findNode(doc.pages.main.root,'name');
  assert.equal(input.props.value.kind,'binding');assert.equal(input.props.value.mode,'TwoWay');
  assert.deepEqual(input.props.value.path,['customer','keyword']);
  assert.equal(findNode(doc.pages.main.root,'ok').props.text.value,'검색');
});
test('v6 DSL safely rejects executable attributes, unknown controls and invalid modes',()=>{
  const base=fresh();
  assert.throws(()=>parseV6Dsl('<Page><Input value={window.alert(1)} /></Page>',base,r),/JSON/);
  assert.throws(()=>parseV6Dsl('<Page><Scary /></Page>',base,r),/등록되지/);
  assert.throws(()=>parseV6Dsl('<Page><Input value={{"kind":"binding","source":"state","path":["x"],"mode":"TwoWay"}} /></Page><Page/>',base,r),/루트 뒤/);
  assert.throws(()=>parseV6Dsl('<Page><Row gap={-1} /></Page>',base,r),/gap 오류/);
});
test('v6 DSL preserves strings and nested JSON literals',()=>{
  const sample='<Page id="root"><Text id="a" text="Say \\"Hi\\" & 한국어" /><Table id="t" dataSource={[{"name":"Kim"}]} /></Page>';
  const doc=parseV6Dsl(sample,fresh(),r).document;
  assert.equal(findNode(doc.pages.main.root,'a').props.text.value,'Say "Hi" & 한국어');
  assert.deepEqual(findNode(doc.pages.main.root,'t').props.dataSource.value,[{name:'Kim'}]);
  const text=printV6Dsl(doc.pages.main.root).text;
  assert.deepEqual(parseV6Dsl(text,doc,r).document.pages.main.root,doc.pages.main.root);
});
test('v6 editor Insert from Registry creates component without copying meta defaults',()=>{
  const doc=fresh(),node=createEditorNode(doc,'core/Input',r);
  assert.ok(node.id.startsWith('node_'));assert.deepEqual(node.props,{});
  const next=insertEditorNode(doc,'pageRoot',1,node,r);
  assert.equal(findNode(next.pages.main.root,node.id).typeId,'core/Input');
  assert.deepEqual(doc.pages.main.root.children.map(n=>n.id),['demoTitle','customerSearch','productSearch']);
});
test('v6 editor changes Frame layout without losing descendants, IDs or bindings',()=>{
  const doc=fresh();const node=createEditorNode(doc,'layout/row',r);
  const withFrame=insertEditorNode(doc,'pageRoot',3,node,r);
  const moved=moveEditorNode(withFrame,'productSearch',node.id,0,r);
  const grid=setEditorLayout(moved,node.id,{type:'grid',columns:2},r);
  assert.equal(findNode(grid.pages.main.root,node.id).children[0].id,'productSearch');
  assert.equal(findNode(grid.pages.main.root,'productSearch').bindings.value.mode,'TwoWay');
  assert.equal(findNode(grid.pages.main.root,node.id).layout.type,'grid');
});
test('v6 editor rejects moving into own descendants and forbids root deletion',()=>{
  const d=fresh();const child=createEditorNode(d,'layout/column',r);
  const n=insertEditorNode(d,'pageRoot',2,child,r);
  assert.throws(()=>moveEditorNode(n,'pageRoot',child.id,0,r),/루트/);
  assert.throws(()=>moveEditorNode(n,child.id,child.id,0,r),/자기 자신/);
  assert.throws(()=>removeEditorNode(n,'pageRoot',r),/루트/);
});
test('v6 editor drag reorder maintains node IDs and literal edits',()=>{
  const d=fresh();const moved=moveEditorNode(d,'demoTitle','pageRoot',3,r);
  assert.equal(moved.pages.main.root.children[2].id,'demoTitle');
  const edited=setEditorProperty(moved,'demoTitle','text',literal('바뀐 제목'),r);
  assert.equal(findNode(edited.pages.main.root,'demoTitle').props.text.value,'바뀐 제목');
});
test('v6 instance overrides actually map to unexposed Button properties',()=>{
  const doc=fresh(),inst=doc.pages.main.root.children[2],def=doc.definitions.SearchBox;
  const mapping=instancePropertyProviders(def,inst);
  assert.equal(mapping.searchButton.color.value,'#16a34a');
  const session=new RuntimeSession(doc);const ctx=session.instanceScope(inst,def,session.rootScope(),'main/productSearch');
  const button=findNode(def.root,'searchButton');
  assert.equal(controlProperty(button,'color',r,ctx.scope,mapping),'#16a34a');
});
test('definition edit propagates through v6 DSL and JSON after override',()=>{
  const d1=patchDefinitionProperty(fresh(),'SearchBox','searchButton','text',literal('찾기'),r);
  const d2=patchInstanceOverride(d1,'productSearch','searchButton','color',literal('#ff0000'),r);
  const d3=parseV6Dsl(printV6Dsl(d2.pages.main.root).text,d2,r).document;
  const d4=parseDocument(serializeDocument(d3,r),r);
  assert.equal(findNode(d4.definitions.SearchBox.root,'searchButton').props.text.value,'찾기');
  assert.equal(findNode(d4.pages.main.root,'productSearch').overrides.searchButton.color.value,'#ff0000');
  assert.equal(findNode(d4.pages.main.root,'customerSearch').overrides?.searchButton,undefined);
});
test('Geometry: Column / Row / Grid insertion works with measured rectangles',()=>{
  const xs=[{left:0,top:0,width:80,height:40,right:80,bottom:40},{left:90,top:0,width:80,height:40,right:170,bottom:40}];
  assert.equal(geometryInsertion(xs,{x:85,y:20},'row').index,1);
  assert.equal(geometryInsertion(xs,{x:180,y:20},'row').index,2);
  const ys=[{left:0,top:0,width:80,height:40,right:80,bottom:40},{left:0,top:55,width:80,height:40,right:80,bottom:95}];
  assert.equal(geometryInsertion(ys,{x:15,y:45},'column').index,1);
  assert.equal(geometryInsertion(xs,{x:20,y:18},'grid').index,0);
  assert.equal(geometryInsertion([], {x:0,y:0},'grid').index,0);
});
test('v6 editor JSON with inserted tree and typed binding survives save/load',()=>{
  const d=fresh(),id=allocateNodeId(d);let next=insertEditorNode(d,'pageRoot',0,{id,kind:'component',typeId:'core/Input',props:{value:binding('state',['customer','keyword'],'TwoWay')}},r);
  next=setEditorLayout(next,'pageRoot',{gap:12},r);
  assert.deepEqual(parseDocument(serializeDocument(next,r),r),next);
});
test('v6 workspace is default, legacy remains explicit, and no React imports leak to headless Core',()=>{
  const app=readFileSync('src/App.jsx','utf8'),studio=readFileSync('src/framework/UnifiedStudio.jsx','utf8'),core=readFileSync('packages/core/editor.js','utf8');
  assert.match(app,/useState\('core'\)/);assert.match(app,/<UnifiedStudio legacyProject=\{project\}\/>/);
  assert.match(studio,/parseV6Dsl\(value,doc,registry,'main',editingDef\)/);assert.match(studio,/moveEditorNode\(doc,data.id/);
  assert.match(studio,/createEditorNode\(doc,typeId,registry\)/);
  assert.doesNotMatch(core,/from ['"](?:react|antd)['"]/);
});

test('Create UserControl from Frame replaces it with an Instance and preserves internal IDs',()=>{
  const d=fresh(),frame=createEditorNode(d,'layout/row',r);
  const d1=insertEditorNode(d,'pageRoot',2,frame,r);
  const input=createEditorNode(d1,'core/Input',r);
  const d2=insertEditorNode(d1,frame.id,0,input,r);
  const out=extractDefinition(d2,frame.id,r);
  const root=out.document.pages.main.root;
  assert.equal(findNode(root,frame.id),undefined);
  assert.equal(findNode(root,out.instanceId).definitionId,out.definitionId);
  assert.equal(findNode(out.document.definitions[out.definitionId].root,input.id).typeId,'core/Input');
  assert.equal(out.document.definitions[out.definitionId].root.id,frame.id);
  assert.equal(validateDocument(out.document,r),out.document);
});
test('Extracting Page root is forbidden; name collision creates a stable alternate ID',()=>{
  const d=fresh();assert.throws(()=>extractDefinition(d,'pageRoot',r),/하위 Frame/);
  const a=createEditorNode(d,'layout/row',r);a.name='SearchBox';
  const d1=insertEditorNode(d,'pageRoot',0,a,r);
  const out=extractDefinition(d1,a.id,r);
  assert.equal(out.definitionId,'SearchBox_2');
  assert.ok(out.document.definitions.SearchBox);
});
test('Expose UserControl Public Property with default from internal literal and TwoWay contract',()=>{
  const d=fresh(),frame=createEditorNode(d,'layout/row',r);
  let doc=insertEditorNode(d,'pageRoot',0,frame,r);
  const input=createEditorNode(doc,'core/Input',r);
  doc=insertEditorNode(doc,frame.id,0,input,r);
  doc=setEditorProperty(doc,input.id,'value',literal('초기값'),r);
  const out=extractDefinition(doc,frame.id,r);
  const published=exposeDefinitionProperty(out.document,out.definitionId,input.id,'value','keyword',r);
  assert.equal(published.definitions[out.definitionId].publicProps.keyword.defaultValue,'초기값');
  assert.equal(published.definitions[out.definitionId].publicProps.keyword.twoWay,true);
  assert.throws(()=>exposeDefinitionProperty(published,out.definitionId,input.id,'value','other',r),/이미 공개/);
  assert.deepEqual(parseDocument(serializeDocument(published,r),r),published);
});
test('Published event maps Button click to public callback without duplicating the tree',()=>{
  const d=fresh(),frame=createEditorNode(d,'layout/row',r);
  let doc=insertEditorNode(d,'pageRoot',0,frame,r);
  const button=createEditorNode(doc,'core/Button',r);
  doc=insertEditorNode(doc,frame.id,0,button,r);
  const out=extractDefinition(doc,frame.id,r);
  const after=exposeDefinitionEvent(out.document,out.definitionId,button.id,'click','search',r);
  assert.deepEqual(after.definitions[out.definitionId].publicEvents.search,{nodeId:button.id,event:'click'});
  assert.equal(findNode(after.definitions[out.definitionId].root,button.id).events.click.event,'search');
  assert.ok(validateDocument(after,r));
});
test('Override declaration can be enabled only for properties not exported as public',()=>{
  const d=fresh(),p=allowInstanceOverride(d,'SearchBox','searchButton','text',r);
  assert.deepEqual(p.definitions.SearchBox.overridePolicy.searchButton,['color','text']);
  assert.throws(()=>allowInstanceOverride(d,'SearchBox','searchInput','value',r),/공개 속성/);
});
test('Editing a Definition through DSL retains page instances and bumps revision',()=>{
  const d=fresh(),old=d.definitions.SearchBox.revision,s=printV6Dsl(d.definitions.SearchBox.root).text;
  const changed=parseV6Dsl(s.replace('text="검색"','text="검색하기"'),d,r,'main','SearchBox').document;
  assert.equal(changed.definitions.SearchBox.revision,old+1);
  assert.equal(findNode(changed.definitions.SearchBox.root,'searchButton').props.text.value,'검색하기');
  assert.deepEqual(changed.pages,d.pages);
});
test('IR dimensions persist in JSX DSL and JSON; rejects unsafe sizes',()=>{
  const d=fresh(),changed=patchEditorNode(d,'demoTitle',n=>({...n,size:{width:280,height:55}}),r);
  const printed=printV6Dsl(changed.pages.main.root).text;
  const parsed=parseV6Dsl(printed,changed,r).document;
  assert.deepEqual(findNode(parsed.pages.main.root,'demoTitle').size,{width:280,height:55});
  assert.deepEqual(parseDocument(serializeDocument(parsed,r),r),parsed);
  assert.throws(()=>patchEditorNode(d,'demoTitle',n=>({...n,size:{width:-2}}),r),/크기 오류/);
});
test('Registry covers all selectable v6 control types with concrete property metadata',()=>{
  const list=r.list();assert.ok(list.length>=9);
  for(const ctrl of list){assert.ok(ctrl.typeId.startsWith('core/'));assert.ok(ctrl.properties);assert.ok(ctrl.events);}
});
test('v6 public property type must match the underlying Registry metadata',()=>{
  const doc=fresh();doc.definitions.SearchBox.publicProps.value.type='number';
  assert.throws(()=>validateDocument(doc,r),/공개 속성 (기본값 타입|대상 Property)/);
});
test('v6 public instance props reject mistyped values and improperly placed Binding',()=>{
  const wrong=fresh();wrong.pages.main.root.children[1].props.placeholder=literal(true);
  assert.throws(()=>validateDocument(wrong,r),/공개 Property 타입/);
  const misplaced=fresh();misplaced.pages.main.root.children[1].props.placeholder=binding('state',['customer','keyword']);
  assert.throws(()=>validateDocument(misplaced,r),/bindings에 저장/);
});
test('v6 instance override rejects incorrect literal type even if policy permits the property',()=>{
  const wrong=fresh();wrong.pages.main.root.children[2].overrides.searchButton.color=literal(123);
  assert.throws(()=>validateDocument(wrong,r),/Override Property 타입/);
});
test('v6 runtime-backed React exporter embeds canonical JSON and uses shared Core/AntD adapters',async()=>{
  const {generateRuntimeTsx}=await import('../packages/exporter-react/index.js');
  const source=generateRuntimeTsx(fresh(),r);
  assert.match(source,/export default function GeneratedPageV6\(/);
  assert.match(source,/new RuntimeSession\(document\)/);
  assert.match(source,/createAntdRenderer\(\)/);
  assert.match(source,/RuntimeView document=/);
  assert.match(source,/SearchBox/);
  assert.throws(()=>generateRuntimeTsx(fresh(),r,{runtimePrefix:'https://evil/'}),/안전한/);
});

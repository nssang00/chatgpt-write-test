import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createProject,validateProject} from '../src/model.js';
import {generateTsx} from '../src/generator.js';
import {parseImportedProject} from '../src/legacy.js';

test('legacy loader recognises v0.4 and yields valid v0.5',()=>{
 const old=fs.readFileSync('./examples/legacy-v0.4.json','utf8');
 assert.ok(validateProject(parseImportedProject(old)));
});
test('generated TSX contains AntD render nodes and mock filtering',()=>{
 const output=generateTsx(createProject());
 assert.match(output,/export default function GeneratedPage/);
 assert.match(output,/<Table/);
 assert.match(output,/setState/);
 assert.match(output,/mockSources/);
 assert.match(output,/onClick/);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {createDefaultRegistry,createSlotExampleDocument,createComponentDefinition,createEditorNode,insertEditorNode,exposeDefinitionSlot,insertSlotChild,removeSlotChildren,resetSlotChildren,slotNodes,exposeDefinitionProperty,removeEditorNode,patchEditorNode,createComponentExportDocument,componentDependencies,RuntimeSession} from '../packages/core/index.js';
import {createSearchBoxDocument,validateDocument,parseDocument,serializeDocument,literal,findNode,binding} from '../packages/schema/index.js';
import {printV6Dsl,parseV6Dsl} from '../packages/format-dsl/index.js';
import {generateComponentSource,createPortablePackageFiles} from '../packages/exporter-react/component-package.js';
import {readFileSync} from 'node:fs';
const registry=createDefaultRegistry();
function fixture(){
  let doc=createSearchBoxDocument();
  doc=createComponentDefinition(doc,'Panel',registry);
  const root=doc.definitions.Panel.root;
  const area=createEditorNode(doc,'layout/column',registry);area.name='Container';
  doc=insertEditorNode(doc,root.id,0,area,registry,'definition:Panel');
  const fallback=createEditorNode(doc,'core/Text',registry);
  doc=insertEditorNode(doc,area.id,0,fallback,registry,'definition:Panel');
  doc=exposeDefinitionSlot(doc,'Panel',area.id,'content',registry);
  const instance=createEditorNode(doc,'module/Panel',registry);
  doc=insertEditorNode(doc,'pageRoot',0,instance,registry);
  return {doc,area,fallback,instance};
}
test('Definition has a named slot with fallback children and stable Frame address',()=>{
  const {doc,area,fallback,instance}=fixture();
  assert.equal(doc.definitions.Panel.slots.content.nodeId,area.id);
  assert.deepEqual(slotNodes(doc.definitions.Panel,instance,area.id,[fallback]),{name:'content',nodes:[fallback],filled:false});
  assert.deepEqual(parseDocument(serializeDocument(doc,registry),registry),doc);
});
test('Instance content overrides fallback without modifying Definition',()=>{
  let {doc,area,fallback,instance}=fixture();
  const label=createEditorNode(doc,'core/Button',registry);
  doc=insertSlotChild(doc,instance.id,'content',0,label,registry);
  const stored=findNode(doc.pages.main.root,instance.id);
  assert.equal(slotNodes(doc.definitions.Panel,stored,area.id,[fallback]).nodes[0].id,label.id);
  assert.equal(doc.definitions.Panel.root.children[0].children[0].id,fallback.id);
  doc=removeSlotChildren(doc,instance.id,'content',registry);
  assert.deepEqual(slotNodes(doc.definitions.Panel,findNode(doc.pages.main.root,instance.id),area.id,[fallback]),{name:'content',nodes:[],filled:true});
});
test('Slot data is first-class JSON and semantic DSL roundtrips',()=>{
  let {doc,instance}=fixture();
  const button=createEditorNode(doc,'core/Button',registry);
  doc=insertSlotChild(doc,instance.id,'content',0,button,registry);
  const restored=parseDocument(serializeDocument(doc,registry),registry);
  assert.deepEqual(restored,doc);
  const source=printV6Dsl(restored.pages.main.root).text;
  assert.match(source,/slots=\{/);
  assert.deepEqual(parseV6Dsl(source,doc,registry).document.pages.main.root,doc.pages.main.root);
});
test('No duplicate slot names or two names targeting same frame',()=>{
  const {doc,area}=fixture();
  assert.throws(()=>exposeDefinitionSlot(doc,'Panel',area.id,'content',registry),/중복/);
  assert.throws(()=>exposeDefinitionSlot(doc,'Panel',area.id,'secondary',registry),/하나의 Frame/);
  assert.throws(()=>exposeDefinitionSlot(doc,'Panel',area.id,'bad space',registry),/Slot 이름/);
});
test('Slot fill rejects invalid name, unknown component and duplicate node IDs',()=>{
  const {doc,instance,fallback}=fixture();
  assert.throws(()=>insertSlotChild(doc,instance.id,'missing',0,fallback,registry),/Slot/);
  assert.throws(()=>insertSlotChild(doc,instance.id,'content',0,fallback,registry),/중복/);
  assert.throws(()=>validateDocument({...doc,pages:{...doc.pages,main:{...doc.pages.main,root:{...doc.pages.main.root,children:doc.pages.main.root.children.map(n=>n.id===instance.id?{...n,slots:{content:[{id:'badControl',kind:'component',typeId:'fake/Unknown',props:{}}]}}:n)}}}},registry),/미등록 컨트롤/);
});
test('Removed slot Frame is rejected, and no silent relocation occurs',()=>{
  const {doc,area}=fixture();
  const next=structuredClone(doc);
  next.definitions.Panel.root.children=[];
  assert.throws(()=>validateDocument(next,registry),/Slot 대상 Frame/);
  assert.equal(findNode(doc.definitions.Panel.root,area.id).id,area.id);
});
test('A component inserted in a slot is editable and removable by node ID',()=>{
  let {doc,instance}=fixture();
  const button=createEditorNode(doc,'core/Button',registry);
  doc=insertSlotChild(doc,instance.id,'content',0,button,registry);
  doc=patchEditorNode(doc,button.id,n=>({...n,props:{text:literal('새 버튼')}}),registry);
  assert.equal(findNode(doc.pages.main.root,button.id).props.text.value,'새 버튼');
  doc=removeEditorNode(doc,button.id,registry);
  assert.deepEqual(findNode(doc.pages.main.root,instance.id).slots.content,[]);
});
test('Cycle detection also sees nested UserControl references inside slots',()=>{
  let {doc,instance}=fixture();
  const other=createEditorNode(doc,'module/SearchBox',registry);
  doc=insertSlotChild(doc,instance.id,'content',0,other,registry);
  const cyclic=structuredClone(doc);
  const slotFrame=cyclic.definitions.Panel.root.children[0];
  slotFrame.children.push({id:'recursion',kind:'instance',definitionId:'Panel',props:{},bindings:{},overrides:{}});
  assert.throws(()=>validateDocument(cyclic,registry),/순환 참조/);
});
test('Exporter collects transitive Definition dependencies of content in a slot',()=>{
  let {doc,instance}=fixture();
  const nested=createEditorNode(doc,'module/SearchBox',registry);
  doc=insertSlotChild(doc,instance.id,'content',0,nested,registry);
  doc=createComponentDefinition(doc,'Host',registry);
  const hostInstance=createEditorNode(doc,'module/Panel',registry);
  doc=insertEditorNode(doc,doc.definitions.Host.root.id,0,hostInstance,registry,'definition:Host');
  const fill=createEditorNode(doc,'module/SearchBox',registry);
  doc=insertSlotChild(doc,hostInstance.id,'content',0,fill,registry,'definition:Host');
  assert.deepEqual(new Set(componentDependencies(doc,'Host',registry)),new Set(['SearchBox','Panel','Host']));
  const exported=createComponentExportDocument(doc,'Host',registry);
  assert.ok(exported.definitions.Panel&&exported.definitions.SearchBox);
  assert.equal(exported.definitions.Host.root.children[0].slots.content[0].definitionId,'SearchBox');
  assert.match(generateComponentSource(doc,registry,'Host'),/"slots"/);
});
test('Export rejects application state bindings hidden inside slot content',()=>{
  let {doc,instance}=fixture();
  const text=createEditorNode(doc,'core/Text',registry);
  text.props.text=binding('state',['customer','keyword'],'OneWay');
  doc=insertSlotChild(doc,instance.id,'content',0,text,registry);
  doc=createComponentDefinition(doc,'Host',registry);
  const hostInstance=createEditorNode(doc,'module/Panel',registry);
  doc=insertEditorNode(doc,doc.definitions.Host.root.id,0,hostInstance,registry,'definition:Host');
  const filledText=createEditorNode(doc,'core/Text',registry);
  filledText.props.text=binding('state',['customer','keyword'],'OneWay');
  doc=insertSlotChild(doc,hostInstance.id,'content',0,filledText,registry,'definition:Host');
  assert.throws(()=>createComponentExportDocument(doc,'Host',registry),/외부 state/);
});
test('Portable runtime ZIP embeds slot resolver module',()=>{
  const {doc}=fixture();
  const needed=['schema/index.js','runtime-react/Runtime.jsx','renderer-antd/index.jsx',...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic'].map(x=>'core/'+x+'.js')];
  const sources=Object.fromEntries(needed.map(n=>['packages/'+n,readFileSync('packages/'+n,'utf8')]));
  const files=createPortablePackageFiles(doc,registry,'Panel',sources);
  assert.ok(files['src/runtime/core/slots.js'].includes('slotNodes'));
  assert.match(files['src/runtime/runtime-react/Runtime.jsx'],/slotFills/);
});
test('Parent binding context is not copied to child instances by slot resolution',()=>{
  const {doc,instance,area,fallback}=fixture();
  const s=new RuntimeSession(doc),scope=s.rootScope();
  assert.equal(slotNodes(doc.definitions.Panel,instance,area.id,[fallback]).filled,false);
  assert.equal(scope.resolve('state'),s.state);
  assert.equal(instance.slots,undefined);
});

test('Complete slot example composes, forwards and exports as reusable SearchCard',()=>{
  const doc=createSlotExampleDocument(registry);
  const host=doc.definitions.SearchCard;
  const panel=host.root.children[0];
  const search=panel.slots.content[0];
  assert.equal(panel.definitionId,'SlotPanel');
  assert.equal(search.definitionId,'SearchBox');
  assert.equal(host.publicProps.value.target.nodeId,search.id);
  assert.equal(host.publicEvents.search.nodeId,search.id);
  assert.deepEqual(doc.pages.main.root.children.map(n=>n.definitionId),['SearchCard','SearchCard']);
  assert.deepEqual(parseDocument(serializeDocument(doc,registry),registry),doc);
  assert.match(generateComponentSource(doc,registry,'SearchCard'),/onValueChange/);
});


test('Resetting a filled slot restores Definition fallback content',()=>{
  let {doc,area,fallback,instance}=fixture();
  const text=createEditorNode(doc,'core/Text',registry);
  doc=insertSlotChild(doc,instance.id,'content',0,text,registry);
  doc=resetSlotChildren(doc,instance.id,'content',registry);
  const stored=findNode(doc.pages.main.root,instance.id);
  assert.equal(slotNodes(doc.definitions.Panel,stored,area.id,[fallback]).filled,false);
  assert.deepEqual(slotNodes(doc.definitions.Panel,stored,area.id,[fallback]).nodes,[fallback]);
});


test('External React children is a typed public API on exported SlotPanel',()=>{
  const doc=createSlotExampleDocument(registry);
  const source=generateComponentSource(doc,registry,'SlotPanel');
  assert.match(source,/children\?: React\.ReactNode/);
  assert.match(source,/externalSlots=\{externalSlots\}/);
  assert.match(source,/"content":"children"/);
});

test('External public slot name collision with a public property is rejected by exporter',()=>{
  let doc=createSlotExampleDocument(registry);
  const def=doc.definitions.SlotPanel;
  // Build deliberately invalid exported-name conflict (schema validates mapping, exporter owns React naming).
  def.publicProps.children={type:'string',defaultValue:'',bindable:true,target:{nodeId:def.root.children[0].children[0].id,property:'text'}};
  validateDocument(doc,registry);
  assert.throws(()=>generateComponentSource(doc,registry,'SlotPanel'),/충돌/);
});

test('Non-bindable public property is exported as literal + dynamic external React prop',()=>{
  let doc=createSearchBoxDocument();
  doc=createComponentDefinition(doc,'ColorPanel',registry);
  const button=createEditorNode(doc,'core/Button',registry);
  doc=insertEditorNode(doc,doc.definitions.ColorPanel.root.id,0,button,registry,'definition:ColorPanel');
  doc=exposeDefinitionProperty(doc,'ColorPanel',button.id,'color','color',registry);
  assert.equal(doc.definitions.ColorPanel.publicProps.color.bindable,false);
  const isolated=createComponentExportDocument(doc,'ColorPanel',registry);
  assert.equal(isolated.pages.main.root.children[0].props.color.kind,'literal');
  assert.equal(isolated.pages.main.root.children[0].bindings.color,undefined);
  const source=generateComponentSource(doc,registry,'ColorPanel');
  assert.match(source,/staticNames/);
  assert.match(source,/externalProps=\{externalProps\}/);
});

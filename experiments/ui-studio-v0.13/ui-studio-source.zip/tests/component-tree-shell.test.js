import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';

const source=readFileSync(new URL('../src/App.jsx',import.meta.url),'utf8');
const css=readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');

test('Component Tree is persistent instead of a Layers/Insert replacement tab',()=>{
  assert.match(source, /<aside className="left-sidebar" aria-label="Component Tree">/);
  assert.match(source, /<ComponentTree node=\{root\}/);
  assert.doesNotMatch(source,/leftTab|setLeftTab|>☷ Layers</);
  assert.ok(source.includes('className="tree-toolbar-title"') && source.includes('Component Tree</div>'));
  assert.match(source,/aria-label="UI 컴포넌트 계층"/);
});
test('Insert and Data are independent closable flyouts, with optional pinning',()=>{
  assert.match(source,/auxPanel==='insert'\?<ToolBox/);
  assert.match(source,/onClick=\{\(\)=>toggleAux\('insert'\)\}/);
  assert.match(source,/onClick=\{\(\)=>toggleAux\('data'\)\}/);
  assert.match(source,/aria-pressed=\{panelPinned\}/);
  assert.match(source,/workspace-with-pinned-panel/);
  assert.match(css,/\.component-flyout\.flyout-pinned/);
  assert.match(css,/\.workspace\.workspace-with-pinned-panel\{grid-template-columns:/);
});
test('toolbox click and pointer drag are preserved with alias filtering',()=>{
  assert.match(source,/onPointerDown=\{e=>onPointerStart\(e,\{kind:'new',type\},label\)\}/);
  assert.match(source,/onClick=\{\(\)=>onAdd\(type\)\}/);
  assert.match(source,/컴포넌트 검색/);
  assert.match(source,/TextBox TextField QLineEdit/);
});

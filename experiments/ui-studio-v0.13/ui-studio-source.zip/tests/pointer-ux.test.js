import test from 'node:test';
import assert from 'node:assert/strict';
import {DRAG_THRESHOLD,pointMoved,insertionIndex,insideRect,mayDrop,dropGuide,nextFixedWidth,nextFrameHeight} from '../src/interaction.js';
import {createProject,createNode,findLocation,addChild,moveChild,validateProject} from '../src/model.js';
import {printDsl,applyDsl} from '../src/dsl.js';
import {generateTsx} from '../src/generator.js';
const rect=(left,top,width=100,height=35)=>({left,top,right:left+width,bottom:top+height});

test('pointer drag starts only after threshold, so click-to-insert remains available',()=>{
  assert.equal(DRAG_THRESHOLD,6);
  assert.equal(pointMoved({x:5,y:5},{x:9,y:8}),false);
  assert.equal(pointMoved({x:5,y:5},{x:11,y:5}),true);
});
test('Column uses pointer Y to preview every insert slot',()=>{
  const children=[rect(0,0),rect(0,50),rect(0,100)];
  assert.deepEqual([0,15,55,78,115,165].map(y=>insertionIndex(children,{x:15,y},'column')),[0,0,1,2,2,3]);
});
test('Row uses pointer X, not Y, even when child sizes vary',()=>{
  const children=[rect(0,0,60),rect(70,5,80),rect(160,-15,50)];
  assert.deepEqual([0,40,100,180,250].map(x=>insertionIndex(children,{x,y:0},'row')),[0,1,1,2,3]);
});
test('Grid pointer targets cells across visual rows',()=>{
  const grid=[rect(0,0),rect(115,0),rect(0,50),rect(115,50)];
  assert.equal(insertionIndex(grid,{x:140,y:65},'grid'),3);
  assert.equal(insertionIndex(grid,{x:190,y:80},'grid'),4);
  assert.equal(insertionIndex(grid,{x:10,y:58},'grid'),2);
});
test('Wrapped Row respects visual rows',()=>{
  const cells=[rect(0,0),rect(120,0),rect(0,80),rect(120,80)];
  assert.equal(insertionIndex(cells,{x:15,y:88},'row',true),2);
});
test('empty Frame previews drop; guide never adds a layout child',()=>{
  assert.equal(insertionIndex([],{x:10,y:10},'grid'),0);
  assert.equal(dropGuide([],0,'row',rect(0,0,300,160)).kind,'line');
  assert.equal(dropGuide([],0,'grid',rect(0,0,300,160),true).kind,'cell');
  assert.equal(insideRect({x:5,y:5},rect(0,0,10,10)),true);
});
test('Frame drop guide is external geometry, independent of child layout',()=>{
  const guide=dropGuide([rect(12,12),rect(12,72)],1,'column',rect(0,0,300,160));
  assert.equal(guide.kind,'line');
  assert.ok(guide.width>=36);
  assert.equal(guide.top,69);
});
test('move to itself/descendant is rejected, but sibling and new are valid',()=>{
  const project=createProject(),root=project.root;
  assert.equal(mayDrop(root,{kind:'move',id:'search-row'},'search-row',findLocation),false);
  assert.equal(mayDrop(root,{kind:'move',id:'search-row'},'table-panel',findLocation),true);
  assert.equal(mayDrop(root,{kind:'move',id:'page-root'},'search-row',findLocation),false);
  assert.equal(mayDrop(root,{kind:'new',type:'Input'},'search-row',findLocation),true);
});
test('moving an IR child to another frame retains ID and DSL selection mapping',()=>{
  const project=createProject();
  const result=moveChild(project.root,'reset-button','table-panel',0);
  assert.ok(validateProject({...project,root:result}));
  assert.equal(findLocation(result,'reset-button').parent.id,'table-panel');
  const code=printDsl(result);
  assert.ok(code.ranges['reset-button']);
  assert.deepEqual(applyDsl({...project,root:result},'page',code.text).project.root,result);
  assert.match(generateTsx({...project,root:result}),/초기화/);
});
test('resize uses actual zoom factor and clamps dimensions',()=>{
  assert.equal(nextFixedWidth(200,100,130,0.75),240);
  assert.equal(nextFrameHeight(110,0,45,0.75),170);
  assert.equal(nextFixedWidth(80,0,-50,1),72);
  assert.equal(nextFrameHeight(40,0,-50,1),40);
});
test('Grid projects empty future cells and stays in IR flow order',async()=>{
  const {gridInsertion}=await import('../src/interaction.js');
  const frame=rect(100,50,500,200);
  const r=[rect(112,62,230,50),rect(352,62,230,50)];
  const x=gridInsertion(r,frame,{x:550,y:160},2,10,12,1);
  assert.equal(x.index,2); // after the existing two cells, never a phantom absolute child
  assert.equal(x.guide.kind,'cell');
  assert.equal(x.guide.top,122);
  assert.ok(x.guide.width>200);
});

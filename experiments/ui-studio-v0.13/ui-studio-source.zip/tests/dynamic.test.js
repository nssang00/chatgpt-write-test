import test from 'node:test';
import assert from 'node:assert/strict';
import {createDefaultRegistry,createDynamicExampleDocument,createComponentExportDocument,addDefinitionProperty,createComponentDefinition,createEditorNode,insertEditorNode,exposeDefinitionProperty,componentDependencies,repeatEntries,iterationScope,RuntimeSession} from '../packages/core/index.js';
import {literal,binding,validateDocument,serializeDocument,parseDocument,findNode} from '../packages/schema/index.js';
import {printV6Dsl,parseV6Dsl} from '../packages/format-dsl/index.js';
import {generateComponentSource} from '../packages/exporter-react/component-package.js';
const r=createDefaultRegistry();
const fresh=()=>createDynamicExampleDocument(r);
test('Dynamic sample is a reusable Definition, not a copied page tree',()=>{
  const doc=fresh();assert.equal(doc.pages.main.root.children.length,2);
  assert.deepEqual(doc.pages.main.root.children.map(x=>x.definitionId),['ItemList','ItemList']);
  assert.equal(doc.definitions.ItemList.publicProps.items.target,undefined);
  assert.equal(doc.definitions.ItemList.publicProps.showTitle.type,'boolean');
  assert.notEqual(doc.pages.main.root.children[0].props.items.value[0].label,doc.pages.main.root.children[1].props.items.value[0].label);
  assert.equal(validateDocument(doc,r),doc);
});
test('When and Repeat syntax survives DSL and canonical JSON roundtrip, preserving item bindings',()=>{
  const doc=fresh(),root=doc.definitions.ItemList.root;
  const printed=printV6Dsl(root).text;
  assert.match(printed,/when=\{\{/);assert.match(printed,/repeat=\{\{/);
  const round=parseV6Dsl(printed,doc,r,'main','ItemList').document;
  assert.deepEqual(round.definitions.ItemList.root,root);
  assert.deepEqual(parseDocument(serializeDocument(round,r),r).definitions.ItemList.root,root);
  const repeated=root.children[1];assert.deepEqual(repeated.repeat.keyPath,['id']);
  assert.equal(repeated.children[0].props.text.source,'context');
});
test('Structural providers reject unsafe paths, TwoWay, invalid values and impossible keys',()=>{
  const bad=patch=>{const d=fresh();patch(d.definitions.ItemList.root.children[1]);return d;};
  assert.throws(()=>validateDocument(bad(n=>n.repeat.items=binding('props',['items'],'TwoWay')),r),/Repeat는 OneWay/);
  assert.throws(()=>validateDocument(bad(n=>n.repeat.items=literal('not-an-array')),r),/Repeat에는 배열/);
  assert.throws(()=>validateDocument(bad(n=>n.repeat.keyPath=['__proto__']),r),/keyPath/);
  assert.throws(()=>validateDocument(bad(n=>n.when=literal('truthy')),r),/boolean/);
  assert.throws(()=>validateDocument(bad(n=>n.when=binding('context',['item','visible'],'TwoWay')),r),/OneWay/);
  assert.throws(()=>validateDocument(bad(n=>n.repeat={items:literal([]),arbitrary:true}),r),/미등록 Repeat/);
});
test('Repeat keys are stable on reorders and fallback safely for missing or duplicate keys',()=>{
  assert.deepEqual(repeatEntries([{id:2},{id:1}],['id']).map(x=>x.key),['number:2','number:1']);
  assert.deepEqual(repeatEntries([{id:'z'},{id:'z'},{}],['id']).map(x=>x.key),['string:z','index:1','index:2']);
  assert.deepEqual(repeatEntries(null,['id']),[]);
  assert.deepEqual(repeatEntries({not:'array'},['id']),[]);
});
test('Nested repeats can access context.item, context.index and context.parent safely',()=>{
  const s=new RuntimeSession(fresh()),scope=s.rootScope();
  const outer=iterationScope(scope,{name:'first'},3);
  const inner=iterationScope(outer,{name:'second'},2);
  assert.equal(inner.resolve('context').get(['item','name']),'second');
  assert.equal(inner.resolve('context').get(['parent','name']),'first');
  assert.equal(inner.resolve('context').get(['index']),2);
  assert.equal(outer.resolve('context').get(['index']),3);
  assert.throws(()=>inner.resolve('context').set(['item','name'],'bad'),/읽기 전용/);
});
test('Independent public array/bool props can be published without a dummy Control mapping',()=>{
  let d=createComponentDefinition(fresh(),'ExampleList',r);
  d=addDefinitionProperty(d,'ExampleList','rows','array',[],r);
  d=addDefinitionProperty(d,'ExampleList','enabled','boolean',true,r);
  assert.throws(()=>addDefinitionProperty(d,'ExampleList','rows','array',[],r),/중복/);
  assert.throws(()=>addDefinitionProperty(d,'ExampleList','bad_name','array','oops',r),/기본값 타입/);
  assert.equal(d.definitions.ExampleList.publicProps.rows.target,undefined);
  assert.ok(validateDocument(d,r));
});
test('Renderer-agnostic portable export exposes arrays, boolean and nested dynamic IR',()=>{
  const doc=fresh();const portable=createComponentExportDocument(doc,'ItemList',r);
  assert.deepEqual(Object.keys(portable.definitions),['ItemList']);
  assert.equal(findNode(portable.definitions.ItemList.root,'node_2').repeat.items.source,'props');
  assert.equal(portable.pages.main.root.children[0].bindings.items.source,'state');
  const source=generateComponentSource(doc,r,'ItemList');
  assert.match(source,/items\?: unknown\[\]/);assert.match(source,/showTitle\?: boolean/);
  assert.doesNotMatch(source,/\.\.\/\.\.\/packages/);
});
test('Exporter rejects hidden state/sources dependencies in conditional or repeat provider',()=>{
  const doc=fresh();doc.definitions.ItemList.root.children[1].repeat.items=binding('state',['private']);
  assert.throws(()=>createComponentExportDocument(doc,'ItemList',r),/외부 state/);
  const second=fresh();second.definitions.ItemList.root.children[0].when=binding('sources',['private']);
  assert.throws(()=>createComponentExportDocument(second,'ItemList',r),/외부 state\/sources\/context/);
});
test('Behavior attributes also work on a nested reusable Instance',()=>{
  let doc=fresh();const copy=createEditorNode(doc,'module/ItemList',r);
  copy.when=literal(false);copy.repeat={items:literal([{id:'c'},{id:'d'}]),keyPath:['id']};
  doc=insertEditorNode(doc,'pageRoot',2,copy,r);
  assert.deepEqual(parseDocument(serializeDocument(doc,r),r).pages.main.root.children[2].repeat,copy.repeat);
});

test('Lego composition: a parent UserControl republishes a child list prop without cloning',()=>{
  let d=createComponentDefinition(fresh(),'ItemGallery',r);
  const instance=createEditorNode(d,'module/ItemList',r);
  d=insertEditorNode(d,d.definitions.ItemGallery.root.id,0,instance,r,'definition:ItemGallery');
  d=exposeDefinitionProperty(d,'ItemGallery',instance.id,'items','entries',r);
  assert.deepEqual(componentDependencies(d,'ItemGallery',r),['ItemList','ItemGallery']);
  assert.equal(d.definitions.ItemGallery.publicProps.entries.type,'array');
  assert.equal(d.definitions.ItemGallery.publicProps.entries.target.nodeId,instance.id);
  const exported=createComponentExportDocument(d,'ItemGallery',r);
  assert.equal(exported.definitions.ItemGallery.root.children[0].definitionId,'ItemList');
  assert.equal(exported.definitions.ItemList.root.children[1].repeat.items.source,'props');
  assert.deepEqual(parseDocument(serializeDocument(d,r),r),d);
});

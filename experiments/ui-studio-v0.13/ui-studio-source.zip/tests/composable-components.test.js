import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createSearchBoxDocument,validateDocument,parseDocument,serializeDocument,findNode,binding,literal} from '../packages/schema/index.js';
import {
  createDefaultRegistry, createComponentDefinition, createComponentExportDocument, createDefinitionPreviewDocument,patchInstanceProp,
  createEditorNode, insertEditorNode,extractDefinition,exposeDefinitionProperty,exposeDefinitionEvent,
  instancePropertyProviders,projectNestedInstance,RuntimeSession,setControlProperty,controlProperty,
  matchesPublicEvent,componentDependencies,moveEditorNode,patchDefinitionProperty
} from '../packages/core/index.js';
import {generateComponentSource,createPortablePackageFiles} from '../packages/exporter-react/component-package.js';
import {encodeZip} from '../packages/exporter-react/zip.js';
import * as moduleWorkspace from '../packages/core/workspace.js';
const r=createDefaultRegistry();
function compose(){
  let doc=createSearchBoxDocument();
  doc=createComponentDefinition(doc,'FilterBar',r);
  const filterId=doc.definitions.FilterBar.root.id;
  const nestedSearch=createEditorNode(doc,'module/SearchBox',r);
  doc=insertEditorNode(doc,filterId,0,nestedSearch,r,'definition:FilterBar');
  const select=createEditorNode(doc,'core/Select',r);
  doc=insertEditorNode(doc,filterId,1,select,r,'definition:FilterBar');
  doc=exposeDefinitionProperty(doc,'FilterBar',nestedSearch.id,'value','keyword',r);
  doc=exposeDefinitionProperty(doc,'FilterBar',nestedSearch.id,'placeholder','placeholder',r);
  doc=exposeDefinitionEvent(doc,'FilterBar',nestedSearch.id,'search','search',r);
  doc=createComponentDefinition(doc,'CustomerBrowser',r);
  const browserId=doc.definitions.CustomerBrowser.root.id;
  const nestedFilter=createEditorNode(doc,'module/FilterBar',r);
  doc=insertEditorNode(doc,browserId,0,nestedFilter,r,'definition:CustomerBrowser');
  const table=createEditorNode(doc,'core/Table',r);
  doc=insertEditorNode(doc,browserId,1,table,r,'definition:CustomerBrowser');
  doc=exposeDefinitionProperty(doc,'CustomerBrowser',nestedFilter.id,'keyword','value',r);
  doc=exposeDefinitionEvent(doc,'CustomerBrowser',nestedFilter.id,'search','search',r);
  return {doc,nestedFilter,nestedSearch,table};
}
test('Lego: compose SearchBox → FilterBar → CustomerBrowser as references, not copies',()=>{
  const {doc,nestedFilter,nestedSearch}=compose();
  assert.equal(validateDocument(doc,r),doc);
  assert.deepEqual(componentDependencies(doc,'CustomerBrowser',r),['SearchBox','FilterBar','CustomerBrowser']);
  assert.equal(nestedSearch.definitionId,'SearchBox');
  assert.equal(nestedFilter.definitionId,'FilterBar');
  assert.equal(doc.definitions.FilterBar.root.children.length,2);
  assert.equal(doc.definitions.CustomerBrowser.root.children.length,2);
});
test('Lego: nested public TwoWay binding routes into correct ancestor state',()=>{
  const {doc,nestedFilter,nestedSearch}=compose();
  doc.pages.main.root.children.push(
    {kind:'instance',id:'browserA',definitionId:'CustomerBrowser',bindings:{value:binding('state',['customer','keyword'],'TwoWay')},props:{},overrides:{}},
    {kind:'instance',id:'browserB',definitionId:'CustomerBrowser',bindings:{value:binding('state',['product','keyword'],'TwoWay')},props:{},overrides:{}}
  );
  validateDocument(doc,r);
  const session=new RuntimeSession(doc),topDef=doc.definitions.CustomerBrowser,midDef=doc.definitions.FilterBar,innerDef=doc.definitions.SearchBox;
  function innerScope(instanceId){
    const top=doc.pages.main.root.children.find(n=>n.id===instanceId);
    const outerScope=session.instanceScope(top,topDef,session.rootScope(),'page/'+instanceId).scope;
    const midNode=projectNestedInstance(nestedFilter,instancePropertyProviders(topDef,top));
    const midScope=session.instanceScope(midNode,midDef,outerScope,`page/${instanceId}/mid`).scope;
    const innerNode=projectNestedInstance(nestedSearch,instancePropertyProviders(midDef,midNode));
    return session.instanceScope(innerNode,innerDef,midScope,`page/${instanceId}/inner`).scope;
  }
  const input=findNode(innerDef.root,'searchInput');
  setControlProperty(input,'value','Kim',r,innerScope('browserA'),{});
  assert.equal(session.state.get(['customer','keyword']),'Kim');
  assert.equal(session.state.get(['product','keyword']),'');
  setControlProperty(input,'value','Laptop',r,innerScope('browserB'),{});
  assert.equal(controlProperty(input,'value',r,innerScope('browserA'),{}),'Kim');
  assert.equal(session.state.get(['product','keyword']),'Laptop');
});
test('Nested public events use matching instance node and event contract',()=>{
  const {doc,nestedFilter,nestedSearch}=compose();
  assert.ok(matchesPublicEvent(doc.definitions.FilterBar,'search',nestedSearch.id,'search'));
  assert.ok(matchesPublicEvent(doc.definitions.CustomerBrowser,'search',nestedFilter.id,'search'));
  assert.equal(matchesPublicEvent(doc.definitions.CustomerBrowser,'search',nestedFilter.id,'other'),false);
});
test('A base Definition edit propagates to nested subcomponents without clones',()=>{
  const {doc}=compose();
  const changed=patchDefinitionProperty(doc,'SearchBox','searchButton','text',literal('Find!'),r);
  assert.equal(findNode(changed.definitions.SearchBox.root,'searchButton').props.text.value,'Find!');
  assert.deepEqual(changed.definitions.FilterBar,doc.definitions.FilterBar);
  assert.deepEqual(changed.definitions.CustomerBrowser,doc.definitions.CustomerBrowser);
});
test('Circular nesting and invalid exposed nested target are rejected',()=>{
  const {doc}=compose();
  const self=createEditorNode(doc,'module/CustomerBrowser',r);
  assert.throws(()=>insertEditorNode(doc,doc.definitions.CustomerBrowser.root.id,0,self,r,'definition:CustomerBrowser'),/순환 참조/);
  assert.throws(()=>exposeDefinitionProperty(doc,'FilterBar',doc.definitions.FilterBar.root.children[0].id,'noSuchProp','bad',r),/등록되지/);
});
test('Definition editor supports insert/move/extract while keeping originals stable',()=>{
  const {doc}=compose();
  const root=doc.definitions.CustomerBrowser.root;
  const frame=createEditorNode(doc,'layout/row',r);
  const withFrame=insertEditorNode(doc,root.id,1,frame,r,'definition:CustomerBrowser');
  const moved=moveEditorNode(withFrame,withFrame.definitions.CustomerBrowser.root.children.at(-1).id,frame.id,0,r,'definition:CustomerBrowser');
  const extracted=extractDefinition(moved,frame.id,r,'definition:CustomerBrowser');
  assert.equal(findNode(extracted.document.definitions.CustomerBrowser.root,extracted.instanceId).definitionId,extracted.definitionId);
  assert.equal(extracted.document.definitions[extracted.definitionId].root.id,frame.id);
  assert.ok(extracted.document.definitions.CustomerBrowser.revision>doc.definitions.CustomerBrowser.revision);
});
test('Component preview builds an Instance harness with all public props, not a flattened tree',()=>{
  const {doc}=compose();const preview=createDefinitionPreviewDocument(doc,'CustomerBrowser',r);
  assert.equal(preview.pages.main.root.children[0].definitionId,'CustomerBrowser');
  assert.equal(preview.pages.main.root.children[0].kind,'instance');
  assert.equal(preview.pages.main.root.children[0].props.value.kind,'literal');
});
test('Component export selects only transitive dependencies and survives JSON round trip',()=>{
  const {doc}=compose(),out=createComponentExportDocument(doc,'CustomerBrowser',r);
  assert.deepEqual(Object.keys(out.definitions).sort(),['CustomerBrowser','FilterBar','SearchBox']);
  assert.equal(out.pages.main.root.children[0].definitionId,'CustomerBrowser');
  assert.equal(out.pages.main.root.children[0].bindings.value.mode,'TwoWay');
  assert.equal(out.data.state.__component.value,'');
  assert.deepEqual(parseDocument(serializeDocument(out,r),r),out);
});
test('Component exporter rejects hidden coupling to app state',()=>{
  const {doc}=compose();
  doc.definitions.FilterBar.root.children[1].props.value=binding('state',['customer','keyword'],'TwoWay');
  assert.throws(()=>createComponentExportDocument(doc,'CustomerBrowser',r),/외부 state/);
});
test('Portable source exposes typed public React props, event callbacks, and shared runtime',()=>{
  const {doc}=compose(),source=generateComponentSource(doc,r,'CustomerBrowser');
  assert.match(source,/export interface CustomerBrowserProps/);
  assert.match(source,/onValueChange\?: \(nextValue: string\) => void/);
  assert.match(source,/onSearch\?: \(payload: Record<string, unknown>\) => void/);
  assert.match(source,/useEffect/);
  assert.match(source,/RuntimeView/);
  assert.doesNotMatch(source,/GeneratedPageV6|\.\.\/\.\.\/packages/);
});
test('Portable files require actual embedded runtime sources and remain Studio-independent',()=>{
  const {doc}=compose();
  const needed=['schema/index.js','runtime-react/Runtime.jsx','renderer-antd/index.jsx',
    ...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic'].map(x=>'core/'+x+'.js')];
  const sources=Object.fromEntries(needed.map(x=>['packages/'+x,readFileSync('packages/'+x,'utf8')]));
  assert.throws(()=>createPortablePackageFiles(doc,r,'CustomerBrowser',{}),/누락/);
  const files=createPortablePackageFiles(doc,r,'CustomerBrowser',sources);
  assert.ok(files['src/CustomerBrowser.tsx']);
  assert.ok(files['src/runtime/core/index.js']);
  assert.ok(files['src/runtime/renderer-antd/index.jsx']);
  assert.deepEqual(Object.keys(files).filter(x=>x.includes('App.jsx')),[]);
  const bytes=encodeZip(files);assert.equal(new DataView(bytes.buffer).getUint32(0,true),0x04034b50);
  assert.ok(bytes.length>20000);
});
test('Schema persists nested published APIs and independent instances',()=>{
  const {doc}=compose();const next=parseDocument(serializeDocument(doc,r),r);
  assert.deepEqual(next.definitions.FilterBar.publicProps,doc.definitions.FilterBar.publicProps);
  assert.deepEqual(next.definitions.CustomerBrowser.publicEvents,doc.definitions.CustomerBrowser.publicEvents);
});

test('Portable export rejects hidden DataContext coupling across nested Definitions',()=>{
  const {doc,nestedSearch}=compose();
  const node=findNode(doc.definitions.FilterBar.root,nestedSearch.id);
  node.dataContext={source:'state',path:['customer']};
  assert.throws(()=>createComponentExportDocument(doc,'CustomerBrowser',r),/DataContext/);
});
test('Lego example offers reusable references and independently bound preview Instances',()=>{
  const {createLegoExampleDocument}=moduleWorkspace;
  const doc=createLegoExampleDocument(r);
  const [a,b]=doc.pages.main.root.children;
  assert.equal(a.definitionId,'CustomerBrowser');
  assert.equal(b.definitionId,'CustomerBrowser');
  assert.deepEqual(a.bindings.value.path,['customer','keyword']);
  assert.deepEqual(b.bindings.value.path,['product','keyword']);
  assert.deepEqual(parseDocument(serializeDocument(doc,r),r),doc);
});
test('React exporter only forwards public events from the selected root Instance',()=>{
  const source=generateComponentSource(compose().doc,r,'CustomerBrowser');
  assert.match(source,/if \(_nodeId !== 'exportInstance'\) return/);
  assert.match(source,/if \(raw === undefined\) continue/);
});
test('Extracted UserControls always get a PascalCase exportable Definition ID',()=>{
  let doc=createSearchBoxDocument();
  const frame=createEditorNode(doc,'layout/row',r);frame.name='검색 패널';
  doc=insertEditorNode(doc,'pageRoot',0,frame,r);
  const {definitionId}=extractDefinition(doc,frame.id,r);
  assert.match(definitionId,/^[A-Z][A-Za-z0-9_]*$/);
});

test('Instance edits address the active Definition scope even when IDs repeat elsewhere',()=>{
  const {doc,nestedSearch}=compose();
  const filterNode=findNode(doc.definitions.FilterBar.root,nestedSearch.id);
  filterNode.id='shared';
  for(const property of Object.values(doc.definitions.FilterBar.publicProps))property.target.nodeId='shared';
  doc.definitions.FilterBar.publicEvents.search.nodeId='shared';
  doc.pages.main.root.children.push({id:'shared',kind:'instance',definitionId:'SearchBox',props:{},bindings:{},overrides:{}});
  validateDocument(doc,r);
  const updated=patchInstanceProp(doc,'shared','placeholder',literal('Inner placeholder'),r,'definition:FilterBar');
  assert.equal(updated.definitions.FilterBar.root.children[0].props.placeholder.value,'Inner placeholder');
  assert.deepEqual(updated.pages.main.root.children.at(-1).props,{});
  assert.ok(updated.definitions.FilterBar.revision>doc.definitions.FilterBar.revision);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { createDefaultRegistry, createBlankComponentWorkspace, createComponentDefinition, createEditorNode, insertEditorNode, addComponentToPreview, componentUsage, exposeDefinitionProperty, exposeDefinitionEvent, componentDependencies, patchEditorNode } from '../packages/core/index.js';
import { serializeDocument, parseDocument, literal } from '../packages/schema/index.js';
import { createPortablePackageFiles } from '../packages/exporter-react/component-package.js';
import { readFileSync } from 'node:fs';
const registry=createDefaultRegistry();
const basic=()=>createBlankComponentWorkspace('MiniSearch', registry);
const tree=(doc,name)=>doc.definitions[name].root;
function add(doc,name,type){const node=createEditorNode(doc,type,registry);return {node,doc:insertEditorNode(doc,tree(doc,name).id,tree(doc,name).children.length,node,registry,`definition:${name}`)};}
function setup(){
  let doc=basic(); const input=add(doc,'MiniSearch','core/Input');doc=input.doc;
  const btn=add(doc,'MiniSearch','core/Button');doc=btn.doc;
  doc=exposeDefinitionProperty(doc,'MiniSearch',input.node.id,'value','value',registry);
  doc=exposeDefinitionEvent(doc,'MiniSearch',btn.node.id,'click','search',registry);
  doc=createComponentDefinition(doc,'FilterBar',registry);
  const mini=add(doc,'FilterBar','module/MiniSearch');doc=mini.doc;
  doc=exposeDefinitionProperty(doc,'FilterBar',mini.node.id,'value','keyword',registry);
  doc=exposeDefinitionEvent(doc,'FilterBar',mini.node.id,'search','search',registry);
  doc=createComponentDefinition(doc,'CustomerBrowser',registry);
  const filter=add(doc,'CustomerBrowser','module/FilterBar');doc=filter.doc;
  doc=exposeDefinitionProperty(doc,'CustomerBrowser',filter.node.id,'keyword','value',registry);
  doc=exposeDefinitionEvent(doc,'CustomerBrowser',filter.node.id,'search','search',registry);
  return {doc,input:input.node,btn:btn.node,mini:mini.node,filter:filter.node};
}
test('v0.13 project root is a blank, reusable Definition; page is only a preview harness',()=>{
  const doc=basic();assert.deepEqual(Object.keys(doc.definitions),['MiniSearch']);
  assert.equal(doc.pages.main.root.children.length,0);
  assert.equal(tree(doc,'MiniSearch').children.length,0);
  assert.throws(()=>createBlankComponentWorkspace('bad-name',registry),/이름/);
});
test('v0.13 recursive construction is by reference, not copied subtrees',()=>{
  const {doc}=setup();assert.deepEqual(componentDependencies(doc,'CustomerBrowser',registry),['MiniSearch','FilterBar','CustomerBrowser']);
  assert.equal(tree(doc,'CustomerBrowser').children[0].kind,'instance');
  assert.equal(tree(doc,'FilterBar').children[0].definitionId,'MiniSearch');
  assert.deepEqual(componentUsage(doc,'MiniSearch',registry).map(x=>x.owner),['definition:FilterBar']);
});
test('v0.13 preview adds two independent instances retaining one Definition',()=>{
  let {doc}=setup();doc=addComponentToPreview(doc,'CustomerBrowser',registry);doc=addComponentToPreview(doc,'CustomerBrowser',registry);
  assert.equal(doc.pages.main.root.children.length,2);
  assert.notEqual(doc.pages.main.root.children[0].id,doc.pages.main.root.children[1].id);
  assert.equal(doc.pages.main.root.children[0].definitionId,'CustomerBrowser');
  assert.deepEqual(componentUsage(doc,'CustomerBrowser',registry).map(x=>x.owner),['page:main','page:main']);
  assert.equal(Object.keys(doc.definitions).length,3);
});
test('v0.13 editing original propagates through all nested instances including JSON round trip',()=>{
  let {doc,input}=setup();doc=addComponentToPreview(doc,'CustomerBrowser',registry);
  doc=patchEditorNode(doc,input.id,node=>({...node,props:{...node.props,placeholder:literal('Renamed!')}}),registry,'definition:MiniSearch');
  const restored=parseDocument(serializeDocument(doc,registry),registry);
  assert.equal(restored.definitions.MiniSearch.root.children[0].props.placeholder.value,'Renamed!');
  assert.equal(restored.definitions.FilterBar.root.children[0].kind,'instance');
  assert.equal(restored.definitions.CustomerBrowser.root.children[0].kind,'instance');
});
test('v0.13 nested components export with typed props/events and only transitive definitions',()=>{
  const {doc}=setup();
  const needed=['packages/schema/index.js','packages/runtime-react/Runtime.jsx','packages/renderer-antd/index.jsx',
    ...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic'].map(x=>`packages/core/${x}.js`)];
  const files=createPortablePackageFiles(doc,registry,'CustomerBrowser',Object.fromEntries(needed.map(x=>[x,readFileSync(x,'utf8')])));
  const source=files['src/CustomerBrowser.tsx'];
  assert.match(source,/value\?: string/);assert.match(source,/onSearch\?:/);
  assert.match(source,/MiniSearch/);assert.match(source,/FilterBar/);
  assert.equal(JSON.parse(files['package.json']).name,'ui-studio-customer-browser');
  assert.doesNotMatch(source,/createSearchBoxDocument/);
});
test('v0.13 malformed Definition and references fail closed',()=>{
  const doc=basic();assert.throws(()=>addComponentToPreview(doc,'UnknownControl',registry),/없는 컴포넌트/);
  assert.throws(()=>createComponentDefinition(doc,'MiniSearch',registry),/이미 있는/);
  let cyclic=createComponentDefinition(doc,'FilterBar',registry);
  const first=add(cyclic,'FilterBar','module/MiniSearch');cyclic=first.doc;
  assert.throws(()=>insertEditorNode(cyclic,tree(cyclic,'MiniSearch').id,0,createEditorNode(cyclic,'module/FilterBar',registry),registry,'definition:MiniSearch'),/순환|cycle|재귀/);
});

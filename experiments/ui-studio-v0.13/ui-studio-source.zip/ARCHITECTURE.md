# UI Studio v0.11 architecture

## Product center: reusable Component Definitions

The product is a **Visual React Component IDE**, not an application/page builder. Users assemble Standard Controls and nested reusable Instances into new Definitions, which can themselves be inserted into other Definitions. A preview Page remains a test harness for v6 compatibility.

```text
Visual Designer / Code DSL  --edit--> Canonical JSON v6
                                          |
                           Definitions (referenced, not cloned)
                                          |
                         Registry + Property + Binding Core
                                          |
                                   React Runtime
                                          |
                                  AntD renderer
                                          |
                              Portable component ZIP
```

## Stable contracts

- Definition has a stable `id`, original node `id`s, `publicProps`, `publicEvents`, `overridePolicy`, revision, and a Frame tree.
- Instance has `definitionId`, independent `props`, `bindings`, `overrides`; a separate runtime path distinguishes identical Definition nodes used by multiple Instances.
- Component metadata and DataContext are **headless** (`packages/schema`, `packages/core`). React and Ant Design imports stay in `packages/runtime-react`, `packages/renderer-antd`.
- Nested public Property mapping may target a Standard Control **or another Instance's public Property**; projected providers are applied to that nested Instance before entering its DataContext.
- Nested public Events can be forwarded through Instance node/public Event mappings. Only events explicitly exported at a given Definition level are forwarded.
- No cycles in the Definition dependency graph. A Definition can be modified without copying/rebuilding consumers.

## New v0.10 modules

- `packages/core/workspace.js`: create reusable definitions, resolve recursive dependencies, construct a Definition preview harness, isolate exportable component documents, create a Lego example.
- `packages/core/components.js`: nested Instance property projection in addition to direct Control projection.
- `packages/exporter-react/component-package.js`: generate a typed React component and portable source package containing only required referenced Definitions, Core and the AntD renderer.
- `packages/exporter-react/zip.js`: deterministic UTF-8 ZIP with verified CRC32. No runtime ZIP dependency.
- `src/framework/runtimeSources.js`: Vite `?raw` source imports for browser-side ZIP creation.
- `tools/export-lego.mjs`: reproducible Node-based example export without npm dependencies.

## Export contract

Exported React value props are controlled when provided; `onValueChange` is a standard callback for TwoWay public property `value`. `onSearch` corresponds to a public `search` event. Each mounted exported React component owns its own `RuntimeSession`. Library-specific behavior is behind an AntD adapter; switching to MUI would require a separate renderer package, not Schema changes.

The exporter rejects app-specific `state`, `sources`, and `context` bindings inside any transitive Definition. These must be exposed through Props or handled by an explicitly exported custom adapter in future versions. Runtime-backed export is supported; native no-runtime TSX generation is not.

## v0.11: Named Slot 계약

- Definition의 `slots: { content: { nodeId: "frameId" } }`는 기존 Frame을 슬롯 위치로 공개합니다. Frame 안의 원래 자식은 기본 콘텐츠입니다.
- Instance는 `slots: { content: [Node, ...] }`에 자신만의 콘텐츠를 보관합니다. 미지정 Slot은 기본 콘텐츠, 빈 배열은 명시적으로 빈 콘텐츠입니다. `resetSlotChildren()`로 기본 콘텐츠를 복원합니다.
- Slot filler 노드는 복제된 Definition에 삽입하지 않으며 해당 Instance의 변경 가능한 IR 영역입니다. Schema/Node traversal/ID 검증/Definition 의존성 분석에서 슬롯 노드를 방문합니다.
- 런타임의 Slot content는 **삽입 주체(parent) DataContext**에서 평가됩니다. 내부 자식에 설정한 Public Props 전달과 Events 매핑도 원래 부모 문맥에서 유지됩니다.
- 내보낸 `content` Slot은 React `children`으로, 다른 이름의 Slot은 동일 이름의 `ReactNode` 속성으로 공개됩니다. 외부 ReactNode는 IR에 저장하지 않고 렌더링 경계에서만 삽입합니다.
- 바인딩 불가능 공개 Property는 export 시 Literal Instance Property로 직렬화하고, 외부 React Props 변경은 export Runtime의 `externalProps`를 통해 전달합니다.
- ReactNode Slot은 렌더링 시 전달되는 값으로, Designer 안에서 임의 JSX를 실행하는 기능이 아닙니다. 외부 코드 실행/검증과 보안은 소비하는 React 앱의 책임입니다.
- 슬롯 입력 패널·Component Tree 선택을 지원하지만, 캔버스에서 **Slot으로 직접 드래그하는 상호작용은 아직 지원하지 않습니다**.

## Remaining architecture work

- Schema can evolve to a fully component-first root in a future version; v0.10 intentionally retains validated v6 JSON to avoid breaking the working editor.
- Extend nested Override policies, direct drag-to-slot, custom control registration/code sandbox, type-safe Action/Command execution, dynamic Repeat/If, SVG/Canvas primitives, and external data-source adapters.
- Provide true browser E2E tests for pointer interactions and an npm-backed build matrix for both the Studio and portable packages.


## v0.12: 구조적 조건과 반복 렌더링

- v6 IR은 기존 `frame/component/instance`에 선택적 `when: PropertyValue`와 `repeat: {items:PropertyValue,keyPath?:Path}`를 추가합니다. 새로운 노드 종류나 임의 JS 식 평가를 요구하지 않습니다.
- `repeat`는 먼저 확장되고, `when`은 각 반복 항목의 `context.item`에 대해 평가됩니다. `when`의 Literal은 boolean이어야 하고 `repeat.items`의 Literal은 배열이어야 합니다. 두 Provider 모두 Binding 사용 시 OneWay 전용이며 경로 키는 안전성 검사 대상입니다.
- headless Core의 `dynamic.js`는 항목 키와 계층 `context.item/context.index/context.parent`를 정의합니다. React Runtime의 별도 hook 컴포넌트는 `useSyncExternalStore`로 변경을 구독합니다. 조건·반복이 붙은 일반 Button, Frame, 중첩 UserControl에도 같은 원칙을 적용합니다.
- `publicProps`의 `target`을 선택적으로 만들었습니다. 매핑 없는 Public Prop은 컴포넌트의 own API이며, `props.items` 등 선언형 동작의 입력으로 사용할 수 있습니다. 기존 target-based Public Props와 중첩 projection도 계속 지원합니다.
- DSL은 `when={{...}}`, `repeat={{...}}` 형태의 JSON Provider만 허용하며 원본 텍스트를 보존하는 것이 아니라 의미를 왕복합니다.
- Exporter는 동적 Provider의 숨은 `state` 또는 `sources` 의존성을 거부합니다. 데이터는 명시적인 Public Props로 노출해야 재사용 가능합니다. `context.item`은 반복 항목의 지역 문맥이므로 허용합니다.
- Designer의 Component Tree에서는 Repeat를 하나의 원본 노드로 표시하고, Preview에서 실제 목록 개수대로 렌더링합니다. 디자인 뷰가 실행 인스턴스를 트리에 모두 복제하지 않습니다.
- **현재 제한:** 반복 가상 자식 하나만 따로 캔버스에서 수정하는 편집 UX, 대량 목록 가상화, 비동기/스트리밍 데이터, TypeScript 코드 CustomControl, SVG/Canvas, Animation, 실제 브라우저 E2E는 후속 작업입니다.

<Column nodeId="layout-gallery" name="Layout Gallery" gap={16} padding={24}>
  <Text nodeId="gallery-title" text="레이아웃 갤러리" weight="heading" />
  <Row nodeId="sample-row" name="Row example" gap={8} padding={10}>
    <Button nodeId="row-one" text="저장" />
    <Button nodeId="row-two" text="취소" variant="default" />
  </Row>
  <Column nodeId="sample-column" name="Column example" gap={8} padding={10}>
    <Input nodeId="col-input" label="고객명" />
    <Button nodeId="col-button" text="검색" />
  </Column>
  <Grid nodeId="sample-grid" name="Grid example" columns={2} gap={8} padding={10}>
    <Card nodeId="card-a" title="A" />
    <Card nodeId="card-b" title="B" />
  </Grid>
  <Wrap nodeId="sample-wrap" name="Wrap example" gap={6} padding={10}>
    <Tag nodeId="tag-1" text="React" />
    <Tag nodeId="tag-2" text="Ant Design" />
    <Tag nodeId="tag-3" text="UI Studio" />
  </Wrap>
  <Overlay nodeId="sample-overlay" name="Overlay example" padding={12} minHeight={110}>
    <Card nodeId="overlay-back" title="Overlay background" />
    <Tag nodeId="overlay-front" text="겹치는 요소" color="blue" />
  </Overlay>
</Column>

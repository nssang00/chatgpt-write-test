import { SlotPanel } from 'ui-studio-slot-panel';
export default function Demo(){return <SlotPanel><button onClick={()=>alert('clicked')}>사용자 버튼</button></SlotPanel>;}

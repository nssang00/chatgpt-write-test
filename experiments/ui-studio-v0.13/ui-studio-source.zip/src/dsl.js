/** Strict, JSX-shaped UI DSL. This is not JavaScript and never evaluates expressions. */
import {createNode, COMPONENT_TYPES, isBinding, validateProject, setTargetRoot} from './model.js';

const FRAME_KEYS=['nodeId','name','layout','gap','padding','columns','align','wrap','background','width','widthPx','minHeight'];
const NODE_KEYS=['nodeId','name','width','widthPx'];
const IND='  ';
// Ergonomic aliases are converted to the same canonical Frame/Component IR.
const FRAME_TAG_LAYOUT={Frame:null,Page:'column',Column:'column',Row:'row',Grid:'grid',Wrap:'row',Overlay:'overlay',Stack:'column'};
const COMPONENT_ALIASES={TextBox:'Input',DataGrid:'Table'};
export class DslError extends Error {
  constructor(message,index,source){
    const line=source.slice(0,index).split('\n').length;
    const col=index-source.lastIndexOf('\n',index-1);
    super(`${message} (${line}:${col})`);
    this.index=index;this.line=line;this.column=col;
  }
}
const jsonValue=x=>JSON.stringify(x);
function attr(k,v){return ` ${k}=${typeof v==='string'?jsonValue(v):`{${jsonValue(v)}}`}`;}
function getAttrs(n,tag){
  if(n.kind==='frame')return FRAME_KEYS.map(k=>[k,k==='nodeId'?n.id:n[k]]).filter(([k,v])=>v!==undefined && !(k==='layout'&&tag!=='Frame'&&tag!=='Page') && !(k==='wrap'&&(tag==='Wrap'||v===false)));
  if(n.kind==='instance')return [['nodeId',n.id],['name',n.name],['moduleId',n.moduleId],['width',n.width],['widthPx',n.widthPx]];
  return [...NODE_KEYS.map(k=>[k,k==='nodeId'?n.id:n[k]]),...Object.entries(n.props||{})].filter(([,v])=>v!==undefined);
}
export function printDsl(root){
  const ranges={};let text='';
  const put=s=>{text+=s;};
  function walk(n,level){
    const start=text.length;
    const kind=n.kind==='frame'?(n.layout==='overlay'?'Overlay':n.layout==='grid'?'Grid':n.layout==='row'?(n.wrap?'Wrap':'Row'):'Column'):n.kind==='instance'?'Use':n.component;
    put(IND.repeat(level)+'<'+kind);
    for(const [k,v] of getAttrs(n,kind)){const a=attr(k,v);const current=text.slice(text.lastIndexOf('\n')+1);if(current.length+a.length>108&&current.length>IND.repeat(level).length+kind.length+2)put('\n'+IND.repeat(level+1)+a.trimStart());else put(a);}
    let openEnd;
    if(n.kind==='frame'){
      put('>\n');openEnd=text.length;
      for(const c of n.children||[])walk(c,level+1);
      put(IND.repeat(level)+`</${kind}>\n`);
    }else {put(' />\n');openEnd=text.length;}
    ranges[n.id]={start,end:text.length,openEnd};
  }
  walk(root,0);
  return {text,ranges};
}
class Reader {
  constructor(text){this.s=text;this.i=0;this.ranges={};this.ids=new Set();this.depth=0;this.autoId=0;}
  fail(msg){throw new DslError(msg,this.i,this.s);}
  ws(){while(this.i<this.s.length){if(/\s/.test(this.s[this.i])){this.i++;continue;}
    if(this.s.startsWith('<!--',this.i)){const end=this.s.indexOf('-->',this.i+4);if(end<0)this.fail('닫히지 않은 주석');this.i=end+3;continue;}
    if(this.s.startsWith('{/*',this.i)){const end=this.s.indexOf('*/}',this.i+3);if(end<0)this.fail('닫히지 않은 JSX 주석');this.i=end+3;continue;}
    if(this.s.startsWith('//',this.i)){const end=this.s.indexOf('\n',this.i+2);this.i=end<0?this.s.length:end;continue;}
    break;
  }}
  identifier(){const m=this.s.slice(this.i).match(/^[A-Za-z_$][A-Za-z0-9_$-]*/);if(!m)this.fail('태그 또는 속성 이름이 필요합니다');this.i+=m[0].length;return m[0];}
  string(){const mark=this.s[this.i++];let value='';while(this.i<this.s.length){const c=this.s[this.i++];if(c===mark)return value;if(c==='\\'){const nxt=this.s[this.i++];if(nxt===undefined)this.fail('잘못된 문자열 이스케이프');const escapes={n:'\n',r:'\r',t:'\t','\\':'\\','"':'"',"'":"'"};value+=escapes[nxt]??nxt;}else value+=c;}this.fail('문자열 닫는 따옴표가 없습니다');}
  brace(){const start=++this.i;let level=1,quote=null,escaped=false;
    for(;this.i<this.s.length;this.i++){const c=this.s[this.i];if(quote){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c===quote)quote=null;continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')level++;else if(c==='}'&&--level===0){const raw=this.s.slice(start,this.i).trim();this.i++;try{return JSON.parse(raw);}catch{this.fail('중괄호 값은 JSON 리터럴만 사용할 수 있습니다 (임의 JS 금지)');}}}
    this.fail('닫는 중괄호가 없습니다');
  }
  node(){this.ws();const start=this.i;
    if(this.s[this.i++]!=='<')this.fail('태그 시작 < 가 필요합니다');
    if(this.s[this.i]==='/')this.fail('예상하지 못한 닫는 태그');
    const tag=this.identifier();const frameTag=Object.prototype.hasOwnProperty.call(FRAME_TAG_LAYOUT,tag);const normalizedTag=COMPONENT_ALIASES[tag]||tag;if(!frameTag&&tag!=='Use'&&!COMPONENT_TYPES.includes(normalizedTag))this.fail(`지원하지 않는 요소 <${tag}>. Page/Column/Row/Grid/Wrap/Overlay/Frame 또는 등록된 UI 컴포넌트를 사용하세요`);
    const attrs=Object.create(null);let self=false;
    while(true){this.ws();if(this.s.startsWith('/>',this.i)){this.i+=2;self=true;break;}if(this.s[this.i]==='>'){this.i++;break;}if(this.i>=this.s.length)this.fail('태그를 닫지 않았습니다');
      const key=this.identifier();if(Object.prototype.hasOwnProperty.call(attrs,key))this.fail(`중복 속성 ${key}`);this.ws();if(this.s[this.i++]!=='=')this.fail('속성에는 =값이 필요합니다');this.ws();const c=this.s[this.i];if(c==='"'||c==="'")attrs[key]=this.string();else if(c==='{')attrs[key]=this.brace();else this.fail('속성 값은 문자열 또는 {JSON 리터럴}로 작성하세요');
    }
    const openEnd=this.i;
    // Users can paste short JSX-like snippets without internal nodeId attributes.
    // Stable sequential IDs avoid re-creating every node on each keystroke.
    if(attrs.nodeId===undefined&&attrs.id===undefined)attrs.nodeId=`dsl_${(++this.autoId).toString(36)}`;
    const node=this.create(tag,attrs);
    if(this.ids.has(node.id))this.fail(`중복 nodeId: ${node.id}`);this.ids.add(node.id);
    if(frameTag){
      if(self){node.children=[];}
      else {this.depth++;if(this.depth>22)this.fail('중첩 깊이 초과');node.children=[];
        while(true){this.ws();if(this.s.startsWith('</',this.i)){this.i+=2;const close=this.identifier();this.ws();if(this.s[this.i++]!=='>')this.fail('닫는 태그에 >가 필요합니다');if(close!==tag)this.fail(`</${tag}>가 필요합니다`);break;}
          if(this.i>=this.s.length)this.fail(`</${tag}>가 없습니다`);
          node.children.push(this.node());
        }this.depth--;}
    }else if(!self){
      const startText=this.i;const end=this.s.indexOf(`</${tag}>`,this.i);if(end<0)this.fail(`</${tag}>가 없습니다`);
      const content=this.s.slice(startText,end).trim();if(content){if(!['Text','Button','Tag','Checkbox'].includes(tag))this.fail('이 컴포넌트는 텍스트 자식을 지원하지 않습니다');if(Object.prototype.hasOwnProperty.call(attrs,'text'))this.fail('text 속성과 텍스트 자식을 동시에 사용할 수 없습니다');if(content.includes('<')||content.includes('{'))this.fail('컴포넌트 내용에는 일반 텍스트만 허용합니다');node.props.text=content;}
      this.i=end+tag.length+3;
    }
    this.ranges[node.id]={start,end:this.i,openEnd};return node;
  }
  create(tag,a){const frameTag=Object.prototype.hasOwnProperty.call(FRAME_TAG_LAYOUT,tag);const normalizedTag=COMPONENT_ALIASES[tag]||tag;
    if(a.id!==undefined&&a.nodeId!==undefined)this.fail('id와 nodeId를 동시에 지정하지 마세요');
    const nodeId=a.nodeId??a.id; if(nodeId!==undefined&&(typeof nodeId!=='string'||!/^[-a-zA-Z0-9_]{1,100}$/.test(nodeId)))this.fail('nodeId는 안전한 문자열이어야 합니다');
    const node=frameTag?createNode('Frame'):tag==='Use'?{id:'',kind:'instance',name:'Module',moduleId:'',width:'fill',widthPx:280}:createNode(normalizedTag);
    if(frameTag&&FRAME_TAG_LAYOUT[tag]){node.layout=FRAME_TAG_LAYOUT[tag];node.wrap=tag==='Wrap';node.name=tag==='Page'?'Page':`${tag} Layout`;} 
    if(nodeId)node.id=nodeId;
    const keys=frameTag?new Set([...FRAME_KEYS,'id']):tag==='Use'?new Set([...NODE_KEYS,'moduleId','id']):null;
    if(frameTag&&tag!=='Frame'&&tag!=='Page'){
      const expected=FRAME_TAG_LAYOUT[tag];
      if(a.layout!==undefined&&a.layout!==expected)this.fail(`<${tag}>의 layout 속성이 태그 종류와 충돌합니다`);
      if(tag==='Wrap'&&a.wrap===false)this.fail('<Wrap>은 wrap={false}를 사용할 수 없습니다');
      if(tag==='Overlay'&&a.wrap===true)this.fail('<Overlay>는 wrap={true}를 사용할 수 없습니다');
    }
    for(const [key,value] of Object.entries(a)){
      if(key==='nodeId'||key==='id')continue;
      if(frameTag||tag==='Use'){
        if(!keys.has(key))this.fail(`알 수 없는 ${tag} 속성: ${key}`);
        node[key]=value;
      }else if(key==='name'||key==='width'||key==='widthPx')node[key]=value;
      else {
        if(key==='onClick'||key==='onChange')this.fail(`${key}는 JavaScript 이벤트가 아니라 action={JSON 객체}로 지정하세요`);
        if(key==='children'||key==='id'||key==='kind'||key==='component'||key==='__proto__'||key==='constructor')this.fail(`예약 속성: ${key}`);
        const mappedKey=normalizedTag==='Input'&&key==='value'?'valueBinding':normalizedTag==='Text'&&key==='value'?'valueBinding':normalizedTag==='Table'&&key==='data'?'rowsBinding':key;
        node.props[mappedKey]=value;
      }
    }
    if(tag==='Use'&&!node.moduleId)this.fail('Use에는 moduleId가 필요합니다');
    return node;
  }
}
export function parseDsl(source){if(typeof source!=='string'||source.length>250000)throw Error('DSL 최대 길이는 250KB입니다');const p=new Reader(source);const root=p.node();p.ws();if(p.i!==source.length)p.fail('루트 요소 뒤의 예상하지 못한 내용');if(root.kind!=='frame')throw new DslError('루트는 Frame이어야 합니다',0,source);return {root,ranges:p.ranges};}
function validateDslTypes(node){
  if(typeof node.name!=='string'||!['hug','fill','fixed'].includes(node.width)||!Number.isFinite(node.widthPx)||node.widthPx<0)throw Error(`잘못된 공통 속성: ${node.id}`);
  if(node.kind==='frame'){
    if(!['column','row','grid'].includes(node.layout)||!['stretch','start','center','end'].includes(node.align)||typeof node.wrap!=='boolean'||typeof node.background!=='string'||![node.gap,node.padding,node.minHeight].every(v=>typeof v==='number'&&Number.isFinite(v)&&v>=0)||!Number.isInteger(node.columns)||node.columns<1||node.columns>24)throw Error(`Frame 레이아웃 값이 잘못되었습니다: ${node.id}`);
    for(const c of node.children)validateDslTypes(c);
  }else if(node.kind==='component'){
    for(const key of ['valueBinding','rowsBinding','filterBinding']){
      const v=node.props[key];if(v!==undefined && (typeof v!=='string'||(v.includes('{{')&&!isBinding(v))))throw Error(`${node.id}.${key}: {{state.path}} 또는 {{sources.path}} 형식만 지원합니다`);
    }
    const a=node.props.action;if(a!==undefined&&(a===null||typeof a!=='object'||Array.isArray(a)||!['message','clear'].includes(a.type)))throw Error(`지원하지 않는 액션: ${node.id}`);
  }
}
export function applyDsl(project,target,source){
  const {root,ranges}=parseDsl(source);
  validateDslTypes(root);
  const next=setTargetRoot(project,target,root);
  if(!validateProject(next))throw Error('DSL의 속성 또는 모듈 참조가 프로젝트 스키마와 맞지 않습니다.');
  return {project:next,ranges};
}
export function nodeAtOffset(ranges,offset){const items=Object.entries(ranges).filter(([,r])=>r.start<=offset&&offset<r.end);items.sort((a,b)=>(a[1].end-a[1].start)-(b[1].end-b[1].start));return items[0]?.[0]||null;}

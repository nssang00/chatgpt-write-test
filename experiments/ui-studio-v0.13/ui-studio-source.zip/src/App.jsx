import React, { useEffect, useRef, useState } from 'react';
import { Button, Input, InputNumber, Select, Segmented, Tag, Tooltip, Typography, Modal, ConfigProvider, message } from 'antd';
import { createProject,createNode,deepCopy,findLocation,isFrame,addChild,moveChild,removeChild,changeNode,duplicateChild,switchLayout,createComponentModule,getTargetRoot,setTargetRoot,parseProjectJson,validateProject,labelOf,resolveBinding,isBinding,COMPONENT_TYPES,layoutLabel } from './model.js';
import { VisualElement, RuntimeNode } from './runtime.jsx';
import { layoutStyle, generateDsl, generateTsx } from './generator.js';
import { parseImportedProject } from './legacy.js';
import { printDsl, applyDsl, parseDsl, nodeAtOffset } from './dsl.js';
import { pointMoved, insertionIndex, mayDrop, dropGuide, gridInsertion, nextFixedWidth, nextFrameHeight } from './interaction.js';
import './styles.css';
import { UnifiedStudio } from './framework/UnifiedStudio.jsx';
import './framework/framework.css';
const GROUPS=[{title:'LAYOUT',subtitle:'Frame의 배치 방식 선택',items:[['Column','Column · 세로'],['Row','Row · 가로'],['Grid','Grid · 격자'],['Wrap','Wrap · 자동 줄바꿈'],['Overlay','Overlay · 겹치기']]},{title:'BASIC',subtitle:'Ant Design 컴포넌트',items:[['Text','Text'],['Button','Button'],['Input','Input'],['Select','Select'],['Checkbox','Checkbox'],['Tag','Tag']]},{title:'DATA & DISPLAY',subtitle:'화면 표시',items:[['Table','Table'],['Card','Card'],['Divider','Divider']]}];
const SEARCH_ALIASES={Input:'TextBox TextField QLineEdit',Select:'ComboBox Picker Dropdown',Table:'DataGrid QTableView',Column:'VStack StackPanel VBox',Row:'HStack HBox',Card:'Panel GroupBox'};
const GLYPHS={Frame:'▦',Column:'↕',Row:'↔',Grid:'▦',Wrap:'↪',Overlay:'▣',Text:'T',Button:'▰',Input:'▭',Select:'⌄',Checkbox:'☑',Table:'▤',Card:'▣',Divider:'━',Tag:'◇'};
const ICONS={play:'▶',design:'◫',layers:'☷',code:'</>',json:'{}',export:'↥',import:'↧',undo:'↶',redo:'↷',trash:'⌫',copy:'⧉',save:'▣',plus:'+',zoom:'⊕'};
const isEditableTarget=el=>['INPUT','TEXTAREA','SELECT'].includes(el?.tagName)||el?.isContentEditable;
const downloadable=(text,filename,mime='text/plain')=>{const url=URL.createObjectURL(new Blob([text],{type:mime}));const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);};
const fmtName=v=>String(v||'Component').replace(/[^\w-]+/g,'-');

function ToolBox({onAdd,onPointerStart}){
  const [filter,setFilter]=useState('');
  const query=filter.trim().toLowerCase();
  const groups=GROUPS.map(group=>({...group,items:group.items.filter(([type,label])=>`${type} ${label} ${SEARCH_ALIASES[type]||''}`.toLowerCase().includes(query))})).filter(g=>g.items.length);
  return <div className="toolbox">
    <div className="toolbox-search"><Input size="small" autoFocus placeholder="컴포넌트 검색 · Input, TextBox..." aria-label="컴포넌트 검색" value={filter} onChange={e=>setFilter(e.target.value)} allowClear/></div>
    <div className="toolbox-instructions">클릭하면 선택한 컨테이너에 추가 · 드래그하면 원하는 위치에 배치</div>
    {groups.map(g=><section className="tool-group" key={g.title}><div className="tool-group-name">{g.title}<small>{g.subtitle}</small></div><div className="tool-list">{g.items.map(([type,label])=><button key={type} className={'tool-item '+(['Frame','Column','Row','Grid','Wrap','Overlay'].includes(type)?'tool-frame':'')} onPointerDown={e=>onPointerStart(e,{kind:'new',type},label)} onClick={()=>onAdd(type)} title={`${label} 추가`}><span className="tool-icon">{GLYPHS[type]}</span><span>{label}</span><span className="tool-grip">⠿</span></button>)}</div></section>)}
    {!groups.length&&<div className="palette-empty">검색 결과가 없습니다.</div>}
    <div className="help-note">Row·Column·Grid·Wrap·Overlay는 모두 Frame입니다. 내부 IR에서는 Frame의 레이아웃 속성으로 저장됩니다.</div>
  </div>;
}
function ComponentTree({node,selected,onSelect,depth=0,expanded,onToggle,project,onPointerStart,drop}){
  const children=node.kind==='frame'?node.children:[];
  const instance=node.kind==='instance',isContainer=node.kind==='frame';
  return <>
    <div data-layer-id={node.id} role="treeitem" aria-level={depth+1} aria-selected={selected===node.id} aria-expanded={isContainer?expanded[node.id]!==false:undefined} tabIndex={selected===node.id?0:-1} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelect(node.id);}else if(isContainer&&e.key==='ArrowRight'&&expanded[node.id]===false){e.preventDefault();onToggle(node.id);}else if(isContainer&&e.key==='ArrowLeft'&&expanded[node.id]!==false){e.preventDefault();onToggle(node.id);}}} className={'layer-row '+(selected===node.id?'active':'')+' '+(drop?.layerId===node.id?'layer-drop-'+drop.edge:'')} style={{paddingLeft:12+depth*16}} onClick={()=>onSelect(node.id)} title={node.name} onPointerDown={e=>{if(depth>0&&!e.target.closest('.tree-chevron'))onPointerStart(e,{kind:'move',id:node.id},node.name);}}>
      <span className="tree-chevron" onClick={e=>{e.stopPropagation();onToggle(node.id);}}>{children.length?(expanded[node.id]!==false?'▾':'▸'):'·'}</span>
      <span className={'layer-icon '+(isContainer?'layer-icon-frame':instance?'layer-icon-instance':'')}>{isContainer?'▦':instance?'◇':GLYPHS[node.component]||'□'}</span>
      <span className="layer-name">{isContainer&&<b className="layer-layout-kind">{layoutLabel(node)}</b>}{labelOf(node)}</span>
      {isContainer&&<span className="layer-meta">{node.layout==='column'?'↓':node.layout==='row'?(node.wrap?'↪':'→'):node.layout==='overlay'?'◈':'▦'}</span>}
    </div>
    {isContainer&&expanded[node.id]!==false&&children.map(child=><ComponentTree key={child.id} node={child} selected={selected} onSelect={onSelect} depth={depth+1} expanded={expanded} onToggle={onToggle} project={project} onPointerStart={onPointerStart} drop={drop}/>)}
  </>;
}
/** The Canvas contains only actual IR children. Drop feedback is a separate fixed overlay. */
function GhostPreview({drag}){
  const type=drag.data.kind==='new'?drag.data.type:drag.label;
  if(type==='Button')return <Button size="small" type="primary" disabled>버튼</Button>;
  if(type==='Input')return <Input size="small" placeholder="Input" disabled style={{width:140}}/>;
  if(type==='Select')return <Select size="small" placeholder="Select" disabled style={{width:120}}/>;
  if(type==='Checkbox')return <span>☑ Checkbox</span>;
  if(['Column','Row','Grid','Wrap','Overlay'].includes(type))return <span className="ghost-layout">▦ {type}</span>;
  return <strong>{drag.label}</strong>;
}
function CanvasNode({node,project,selected,onSelect,onPointerStart,drop,ctx,onResize,root=false}){
  const active=selected===node.id;
  const nRef=useRef(null);
  const layout=isFrame(node);
  const beingTarget=layout&&drop?.ownerId===node.id;
  const nodeWidth=node.width==='fill'?'100%':node.width==='fixed'?`${node.widthPx}px`:'fit-content';
  const style=layout?{...layoutStyle(node),position:'relative'}:{width:nodeWidth,minWidth:0};
  const begin=e=>{
    if(root||e.button!==0||e.target.closest('.studio-resize-handle'))return;
    e.stopPropagation();onSelect(node.id);
    onPointerStart(e,{kind:'move',id:node.id},node.name);
  };
  const resize=e=>{e.preventDefault();e.stopPropagation();onSelect(node.id);onResize(e,node.id,nRef.current,e.currentTarget.dataset.axis);};
  const handles=active&&!root?<>
    <span className="studio-resize-handle resize-right" data-axis="width" onPointerDown={resize} title="너비 조절" />
    {layout&&<><span className="studio-resize-handle resize-bottom" data-axis="height" onPointerDown={resize} title="Frame 높이 조절"/><span className="studio-resize-handle resize-corner" data-axis="both" onPointerDown={resize} title="너비 · 높이 조절"/></>}
  </>:null;
  if(node.kind==='instance'){
    const m=project.modules[node.moduleId];
    return <div ref={nRef} data-node-id={node.id} className={'canvas-node canvas-instance '+(active?'node-selected':'')} onPointerDown={begin} onClick={e=>{e.stopPropagation();onSelect(node.id);}} style={{width:nodeWidth}}>
      <div className="canvas-node-chip instance-chip">◇ {node.name} · instance</div>
      <div className="instance-inner">{m?<RuntimeNode node={m.root} project={project} ctx={ctx}/>:<div>컴포넌트를 찾을 수 없음</div>}</div>
      <div className="hit-shield"/>{handles}
    </div>;
  }
  return <div ref={nRef} data-node-id={node.id} data-frame-id={layout?node.id:undefined} className={'canvas-node '+(layout?'canvas-frame frame-'+(node.layout==='row'&&node.wrap?'wrap':node.layout):'canvas-component')+' '+(active?'node-selected':'')+' '+(root?'canvas-root':'')+' '+(beingTarget?'drop-frame-active':'')} style={style} onPointerDown={begin} onClick={e=>{e.stopPropagation();onSelect(node.id);}}>
    <div className={'canvas-node-chip '+(layout?'frame-chip':'element-chip')}><span>{layout?'▦':'□'}</span> {layout?`${layoutLabel(node)} · ${node.name}`:node.name}<small>{layout?'FRAME':node.component}</small></div>
    {layout?(
      <>{node.children.length===0&&<div className="frame-empty">+ 여기에 컴포넌트 배치</div>}
        {node.children.map(child=><CanvasNode key={child.id} node={child} project={project} selected={selected} onSelect={onSelect} onPointerStart={onPointerStart} drop={drop} ctx={ctx} onResize={onResize}/>)}
      </>
    ):<><div className="actual-component"><VisualElement node={node} project={project} ctx={ctx} editing/></div><div className="hit-shield"/></>}
    {handles}
  </div>;
}
const previewValue=(v)=>{if(v===undefined)return '⚠ 경로에 값이 없습니다';if(Array.isArray(v))return `Array(${v.length}): ${JSON.stringify(v.slice(0,2)).slice(0,170)}`;if(v&&typeof v==='object')return JSON.stringify(v).slice(0,190);return String(v);};
function bindingPaths(data){
  const result=[];
  function walk(value,path,depth){if(depth>3||result.length>90)return;result.push({path,value});if(value&&typeof value==='object'){for(const [k,v] of Object.entries(value)){if(!/^[A-Za-z_$][\w$]*$/.test(k))continue;walk(v,`${path}.${k}`,depth+1);}}}
  for(const [k,v] of Object.entries(data.state||{}))walk(v,`state.${k}`,0);
  for(const [k,v] of Object.entries(data.sources||{}))walk(v,`sources.${k}`,0);
  return result;
}
function BindingInput({label,value,onChange,data}){
  const ctx={state:data.state,sources:data.sources},paths=bindingPaths(data);
  const bind=v=>onChange(`{{${v}}}`);
  const valid=!String(value||'').includes('{{')||isBinding(value);
  return <div className="property-field binding-field" onDragOver={e=>{if(e.dataTransfer.types.includes('application/x-ui-binding'))e.preventDefault();}} onDrop={e=>{const path=e.dataTransfer.getData('application/x-ui-binding');if(path){e.preventDefault();bind(path);}}}>
    <label>{label} <span className="bind-hint">◎ 데이터 경로를 이곳에 놓으세요</span></label>
    <Input size="small" value={value||''} status={valid?'':'error'} onChange={e=>onChange(e.target.value)} placeholder="{{state.keyword}}" list={`paths-${label.replace(/\W/g,'')}`}/>
    <datalist id={`paths-${label.replace(/\W/g,'')}`}>{paths.map(p=><option key={p.path} value={`{{${p.path}}}`}/>)}</datalist>
    <div className={'binding-evaluation '+(!valid?'bind-invalid':'')}><strong>{!valid?'지원하지 않는 바인딩 문법':'현재 평가값'}</strong><span>{valid?previewValue(resolveBinding(value,ctx)):'{{state.key}} 또는 {{sources.name}} 형식만 지원'}</span></div>
  </div>;
}
function DataTree({project,onBind}){
  return <div className="data-tree"><div className="sidebar-title">Data <span className="subtitle-mini">끌어다 연결</span></div>
    <p className="data-instructions">오른쪽 Binding 속성에 끌어 놓거나 경로를 클릭해 선택된 요소에 연결할 수 있습니다.</p>
    {['state','sources'].map(group=><section key={group}><div className="tool-group-name">{group.toUpperCase()}</div>
      {bindingPaths({state:group==='state'?project.data.state:{},sources:group==='sources'?project.data.sources:{}}).filter(({path})=>path.split('.').length<=3).map(({path,value})=><button key={path} className="data-path" draggable onDragStart={e=>{e.dataTransfer.setData('application/x-ui-binding',path);e.dataTransfer.setData('text/plain',`{{${path}}}`);}} onClick={()=>onBind(path)} title="클릭: 선택된 요소에 바인딩"><span>⠿</span><span>{path}</span><small>{Array.isArray(value)?`[${value.length}]`:typeof value}</small></button>)}
    </section>)}
  </div>;
}
function CodeEditor({draft,error,onChange,onCaret,codeRef,ranges,selected,onExport}){
  const gutterRef=useRef(null);
  const lines=draft.split('\n');const r=ranges?.[selected];const highlighted=r?draft.slice(0,r.start).split('\n').length:0;
  return <div className="dsl-editor"><div className="dsl-editor-label"><strong>JSX-style UI DSL</strong><span className="dsl-status">{error?<span className="dsl-error" title={error}>⚠ {error}</span>:<span className="dsl-ok">● 동기화됨</span>} <button className="dsl-export" onClick={onExport}>DSL 저장</button></span></div>
    <div className="dsl-editor-body"><div ref={gutterRef} className="dsl-lines" aria-hidden="true">{lines.map((_,i)=><div key={i} className={highlighted===i+1?'code-current-line':''}>{i+1}</div>)}</div>
    <textarea ref={codeRef} className="dsl-textarea" value={draft} spellCheck={false} onChange={e=>onChange(e.target.value,e.target.selectionStart)} onClick={onCaret} onKeyUp={onCaret} onScroll={e=>{if(gutterRef.current)gutterRef.current.scrollTop=e.currentTarget.scrollTop;}} aria-label="JSX 스타일 UI DSL 편집"/></div>
    {error&&<div className="dsl-error-details" role="alert"><strong>DSL 적용 실패 — 디자이너는 마지막 정상 상태를 유지합니다.</strong><span>{error}</span></div>}
    <div className="dsl-editor-footer">Page · Column · Row · Grid · Wrap · Overlay 레이아웃을 지원합니다. JS 함수 실행은 지원하지 않습니다.</div>
  </div>;
}
function PropertyPanel({node,rootId,project,onPatch,onDelete,onDuplicate,onModule,onEditModule,target}){
  const layout=node?.kind==='frame',instance=node?.kind==='instance',p=node?.props||{};
  const patch=(key,value)=>onPatch(n=>{n[key]=value;});
  const prop=(key,value)=>onPatch(n=>{n.props={...n.props,[key]:value};});
  const field=(label,content,hint)=> <div className="property-field"><label>{label}</label>{content}{hint&&<small className="prop-hint">{hint}</small>}</div>;
  const text=(label,key,valueSetter=prop)=>field(label,<Input size="small" value={valueSetter===patch?node[key]??'':p[key]??''} onChange={e=>valueSetter(key,e.target.value)}/>);
  const number=(label,key,min=0,max=1500)=>field(label,<InputNumber size="small" style={{width:'100%'}} min={min} max={max} value={node[key]||0} onChange={v=>patch(key,v??0)}/>);
  const select=(label,value,items,cb)=>field(label,<Select size="small" style={{width:'100%'}} value={value} options={items.map(x=>({label:x[1],value:x[0]}))} onChange={cb}/>);
  if(!node)return <div className="properties"><div className="sidebar-title">Inspector</div><div className="prop-empty">캔버스 또는 Component Tree에서 요소를 선택하세요.</div></div>;
  const module=instance?project.modules[node.moduleId]:null;
  return <div className="properties"><div className="sidebar-title">Inspector <span className="subtitle-mini">속성 편집</span></div>
    <div className={'inspector-type '+(layout?'inspect-frame':'inspect-control')}><span>{layout?'▦ LAYOUT FRAME':instance?'◇ INSTANCE':'□ COMPONENT'}</span><strong>{layout?layoutLabel(node):instance?module?.name||'Module':node.component}</strong></div>
    <div className="prop-section-title">GENERAL</div>
    {field('Name',<Input size="small" value={node.name} onChange={e=>patch('name',e.target.value)}/>)}
    {select('Width',node.width,[['hug','Hug contents'],['fill','Fill available'],['fixed','Fixed (px)']],v=>patch('width',v))}
    {node.width==='fixed'&&number('Width(px)','widthPx',60,2000)}
    {layout&&<>
      <div className="prop-section-title">AUTO LAYOUT</div>
      {field('Layout mode',<Select size="small" style={{width:'100%'}} value={node.layout==='row'&&node.wrap?'wrap':node.layout} onChange={v=>onPatch(n=>{n.layout=v==='wrap'?'row':v;n.wrap=v==='wrap';})} options={[{value:'column',label:'↓ Column — 세로'},{value:'row',label:'→ Row — 가로'},{value:'grid',label:'▦ Grid — 격자'},{value:'wrap',label:'↪ Wrap — 자동 줄바꿈'},{value:'overlay',label:'◈ Overlay — 겹침'}]}/>,'레이아웃 태그만 변경됩니다. 기존 자식과 nodeId는 유지됩니다.')}
      {node.layout==='grid'&&number('Grid columns','columns',1,8)}
      {number('Gap (px)','gap',0,96)}{number('Padding (px)','padding',0,120)}
      {select('Alignment',node.align,[['stretch','Stretch'],['start','Start'],['center','Center'],['end','End']],v=>patch('align',v))}
      {node.layout==='overlay'&&field('Overlay',<small className="prop-hint">모든 자식은 동일한 Grid 셀에 겹쳐집니다. 고급 좌표 배치는 지원하지 않습니다.</small>)}
      {number('Min height (px)','minHeight',0,2000)}
      {field('Background',<div className="color-pick"><input type="color" value={/^#[0-9a-fA-F]{6}$/.test(node.background)?node.background:'#ffffff'} onChange={e=>patch('background',e.target.value)}/><Input size="small" value={node.background} onChange={e=>patch('background',e.target.value)} /></div>)}
    </>}
    {node.kind==='component'&&<>
      <div className="prop-section-title">COMPONENT</div>
      {['Text','Button','Tag','Checkbox'].includes(node.component)&&text('Text','text')}
      {['Input','Select'].includes(node.component)&&text('Label','label')}
      {node.component==='Input'&&text('Placeholder','placeholder')}
      {node.component==='Text'&&select('Typography',p.weight,[['normal','Body'],['heading','Heading']],v=>prop('weight',v))}
      {node.component==='Button'&&select('Variant',p.variant,[['default','Default'],['primary','Primary']],v=>prop('variant',v))}
      {node.component==='Select'&&text('Options (comma-separated)','options')}
      {['Table','Card'].includes(node.component)&&text('Title','title')}
      {node.component==='Table'&&text('Columns (comma-separated)','columns')}
      {node.component==='Card'&&text('Description','description')}
      {node.component==='Tag'&&select('Color',p.color,[['blue','Blue'],['green','Green'],['orange','Orange'],['red','Red']],v=>prop('color',v))}
      {['Input','Table','Text'].includes(node.component)&&<>
        <div className="prop-section-title">BINDING</div>
        {node.component==='Input'&&<BindingInput label="Value expression" value={p.valueBinding} onChange={v=>prop('valueBinding',v)} data={project.data}/>}
        {node.component==='Text'&&<BindingInput label="Text binding (optional)" value={p.valueBinding} onChange={v=>prop('valueBinding',v)} data={project.data}/>}
        {node.component==='Table'&&<><BindingInput label="Rows" value={p.rowsBinding} onChange={v=>prop('rowsBinding',v)} data={project.data}/><BindingInput label="Filter" value={p.filterBinding} onChange={v=>prop('filterBinding',v)} data={project.data}/></>}
      </>}
      {node.component==='Button'&&<><div className="prop-section-title">EVENT</div>{select('On click',p.action?.type||'message',[['message','Show message'],['clear','Clear state']],v=>prop('action',{type:v,target:'keyword',message:'버튼을 클릭했습니다.'}))}{p.action?.type==='clear'?field('State key',<Input size="small" value={p.action.target||''} onChange={e=>prop('action',{...p.action,target:e.target.value})}/>):field('Message',<Input size="small" value={p.action?.message||''} onChange={e=>prop('action',{...p.action,message:e.target.value})}/>)}</>}
    </>}
    {instance&&<div className="property-field"><p className="prop-hint">공유 정의를 참조하는 인스턴스입니다. 내부 요소는 모듈 편집 모드에서 수정하세요.</p><Button size="small" block onClick={()=>onEditModule(node.moduleId)}>공유 컴포넌트 편집 ↗</Button></div>}
    <div className="inspector-bottom">
      {layout&&target!=='page'&&<div className="prop-hint">현재 공유 컴포넌트를 편집하는 중입니다.</div>}
      {layout&&node.id!==rootId&&<Button block size="small" onClick={onModule}>◇ 공유 컴포넌트로 만들기</Button>}
      <div className="prop-actions"><Button size="small" onClick={onDuplicate} disabled={node.id===rootId}>⧉ 복제</Button><Button size="small" danger onClick={onDelete} disabled={node.id===rootId}>⌫ 삭제</Button></div>
    </div>
  </div>;
}
function App(){
  const [project,setProject]=useState(()=>{
    try{const saved=(localStorage.getItem('ui-studio-v06')||localStorage.getItem('ui-studio-v05'));return saved?parseProjectJson(saved):createProject();}catch{return createProject();}
  });
  const [target,setTarget]=useState('page');
  const [selected,setSelected]=useState('search-row');
  const [activeTab,setActiveTab]=useState('core');
  const [codeDraft,setCodeDraft]=useState(()=>printDsl(project.root).text);
  const [codeRanges,setCodeRanges]=useState(()=>printDsl(project.root).ranges);
  const [codeError,setCodeError]=useState(null);
  const codeEditorRef=useRef(null);
  const changeFromCodeRef=useRef(false);
  const selectionFromCodeRef=useRef(false);
  const [auxPanel,setAuxPanel]=useState(null);
  const [panelPinned,setPanelPinned]=useState(false);
  const [dragging,setDragging]=useState(null);
  const [drop,setDrop]=useState(null);
  const [dragSnapshot,setDragSnapshot]=useState(null);
  const pointerRef=useRef(null);
  const suppressClickUntil=useRef(0);
  const [expanded,setExpanded]=useState({});
  const [zoom,setZoom]=useState(75);
  const [device,setDevice]=useState('desktop');
  const [runtimeState,setRuntimeState]=useState(()=>deepCopy(project.data.state));
  const [notice,noticeContext]=message.useMessage();
  const uploadRef=useRef(null);
  const history=useRef({past:[],future:[]});
  const root=getTargetRoot(project,target)||project.root;
  const selectedNode=findLocation(root,selected)?.node || root;
  const ctx={state:activeTab==='preview'?runtimeState:project.data.state,sources:project.data.sources};
  useEffect(()=>{try{localStorage.setItem('ui-studio-v06',JSON.stringify(project));}catch{}},[project]);
  useEffect(()=>{if(changeFromCodeRef.current){changeFromCodeRef.current=false;return;}const result=printDsl(getTargetRoot(project,target)||project.root);setCodeDraft(result.text);setCodeRanges(result.ranges);setCodeError(null);},[project,target]);
  useEffect(()=>{if(activeTab!=='code'||!codeEditorRef.current)return;if(selectionFromCodeRef.current){selectionFromCodeRef.current=false;return;}const range=codeRanges[selected];if(!range)return;const el=codeEditorRef.current;el.setSelectionRange(range.start,range.openEnd);const line=codeDraft.slice(0,range.start).split('\n').length;el.scrollTop=Math.max(0,(line-4)*20);},[selected,activeTab,codeRanges]);
  function commit(next,chosen,fromCode=false){
    if(JSON.stringify(project)===JSON.stringify(next))return;
    if(!validateProject(next)){notice.error('프로젝트 스키마가 유효하지 않습니다.');return;}
    history.current.past.push(project);if(history.current.past.length>60)history.current.past.shift();history.current.future=[];
    if(fromCode)changeFromCodeRef.current=true;
    setProject(next);if(chosen!==undefined)setSelected(chosen);
  }
  function onCodeEdit(value,offset){
    setCodeDraft(value);
    try{
      const {project:next,ranges}=applyDsl(project,target,value);
      setCodeRanges(ranges);setCodeError(null);
      const id=nodeAtOffset(ranges,offset);
      if(id){selectionFromCodeRef.current=true;setSelected(id);}
      commit(next,id||undefined,true);
    }catch(e){setCodeError(e.message||'문법 오류');}
  }
  function onCodeCaret(e){
    try{const {ranges}=parseDsl(codeDraft);const id=nodeAtOffset(ranges,e.target.selectionStart);if(id&&id!==selected){selectionFromCodeRef.current=true;setSelected(id);}}catch{}
  }
  function chooseDataBinding(path){
    if(selectedNode.kind!=='component')return notice.info('Input, Text, Table 컴포넌트를 먼저 선택하세요.');
    const field=selectedNode.component==='Input'||selectedNode.component==='Text'?'valueBinding':selectedNode.component==='Table'?'rowsBinding':null;
    if(!field)return notice.info('이 요소는 데이터 바인딩 속성이 없습니다.');
    patchSelected(n=>{n.props={...n.props,[field]:`{{${path}}}`};});
    notice.success(`${selectedNode.name}에 ${path} 연결`);
  }
  function editRoot(op,chosen){
    try{const result=op(root);const next=setTargetRoot(project,target,result);commit(next,chosen);}catch(e){notice.warning(e.message||'작업 실패');}
  }
  function chooseTarget(v){if(v==='page'||project.modules[v]){setTarget(v);setSelected(getTargetRoot(project,v)?.id||'page-root');setActiveTab('design');}}
  function add(type){
    if(performance.now()<suppressClickUntil.current)return;
    const chosen=isFrame(selectedNode)?selectedNode.id:(findLocation(root,selectedNode.id)?.parent?.id||root.id);
    const node=createNode(type);
    editRoot(r=>addChild(r,chosen,node),node.id);
    if(!panelPinned)setAuxPanel(null);
  }
  function onDropAt(data,ownerId,index){
    setDragging(null);setDrop(null);setDragSnapshot(null);
    if(!data)return;
    if(data.kind==='new'){
      try{const node=createNode(data.type);editRoot(r=>addChild(r,ownerId,node,index),node.id);if(!panelPinned)setAuxPanel(null);}catch(e){notice.warning(e.message);}return;
    }
    if(data.kind==='module'){
      const mod=project.modules[data.moduleId];if(!mod)return;
      const id=`instance_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,7)}`;
      const instance={id,kind:'instance',name:mod.name,moduleId:mod.id,width:'fill',widthPx:360};
      editRoot(r=>addChild(r,ownerId,instance,index),id);return;
    }
    if(data.kind==='move')editRoot(r=>moveChild(r,data.id,ownerId,index),data.id);
  }
  function patchSelected(fn){editRoot(r=>changeNode(r,selectedNode.id,fn));}
  function erase(){if(selectedNode.id===root.id)return;const loc=findLocation(root,selectedNode.id);editRoot(r=>removeChild(r,selectedNode.id),loc?.parent?.id||root.id);}
  function duplicate(){try{const r=duplicateChild(root,selectedNode.id);editRoot(()=>r.root,r.id);}catch(e){notice.warning(e.message);}}
  /** Single drop-intent resolver for Insert, Canvas moves, and Component Tree reorder. */
  function resolveDropAt(x,y,data){
    const pointer={x,y};
    const hits=document.elementsFromPoint(x,y);
    // The layer tree supports before / after / nest placement.
    const layer=hits.map(el=>el.closest?.('[data-layer-id]')).find(Boolean);
    if(layer){
      const nodeId=layer.dataset.layerId;
      const loc=findLocation(root,nodeId);
      if(!loc)return null;
      const r=layer.getBoundingClientRect();
      const fraction=(y-r.top)/Math.max(1,r.height);
      const intoFrame=isFrame(loc.node)&&fraction>0.25&&fraction<0.75;
      const ownerId=intoFrame?nodeId:loc.parent?.id;
      if(!ownerId||!mayDrop(root,data,ownerId,findLocation))return null;
      const index=intoFrame?loc.node.children.length:loc.index+(fraction>=0.5?1:0);
      return {ownerId,index,layerId:nodeId,edge:intoFrame?'inside':fraction>=0.5?'after':'before',description:`${intoFrame?'내부':'형제 위치'} · ${loc.node.name}`};
    }
    const artboard=hits.find(el=>el.classList?.contains('artboard'));
    if(!artboard)return null;
    const frameEls=[...new Set(hits.map(el=>el.closest?.('[data-frame-id]')).filter(Boolean))];
    for(const frameEl of frameEls){
      const id=frameEl.dataset.frameId;
      const loc=findLocation(root,id);
      if(!loc||!isFrame(loc.node)||!mayDrop(root,data,id,findLocation))continue;
      const childEls=Array.from(frameEl.children).filter(el=>el.dataset?.nodeId&&el.dataset.nodeId!==data.id);
      // During a self-move compute the index against original child order.
      const pairs=childEls.map(el=>({el,idx:loc.node.children.findIndex(c=>c.id===el.dataset.nodeId)})).filter(x=>x.idx>=0);
      pairs.sort((a,b)=>a.idx-b.idx);
      const rects=pairs.map(p=>p.el.getBoundingClientRect());
      const mode=loc.node.layout;
      const grid=mode==='grid'?gridInsertion(rects,frameEl.getBoundingClientRect(),pointer,loc.node.columns||2,loc.node.gap||0,loc.node.padding||0,zoom/100):null;
      const raw=grid?grid.index:insertionIndex(rects,pointer,mode,!!loc.node.wrap);
      const index=raw>=pairs.length?loc.node.children.length:pairs[raw].idx;
      const guide=grid?.guide||dropGuide(rects,raw,mode,frameEl.getBoundingClientRect());
      return {ownerId:id,index,guide,description:`${layoutLabel(loc.node)} · ${loc.node.name} · ${index+1}번째 위치`};
    }
    // An empty root artboard is still a valid target.
    if(mayDrop(root,data,root.id,findLocation))return {ownerId:root.id,index:root.children.length,description:'페이지 마지막에 추가'};
    return null;
  }
  function startPointerDrag(e,data,label){
    if(e.button!==0||activeTab==='preview')return;
    if(pointerRef.current?.cleanup)pointerRef.current.cleanup();
    const pointerId=e.pointerId,initial={x:e.clientX,y:e.clientY};
    const session={data,label,initial,last:initial,active:false,cleanup:null};
    pointerRef.current=session;
    let frameId=0;
    const refresh=()=>{
      const scroll=document.querySelector('.canvas-workspace');
      if(!scroll||!session.active)return;
      const r=scroll.getBoundingClientRect();const p=session.last;
      if(p.x>=r.left&&p.x<=r.right&&p.y>=r.top&&p.y<=r.bottom){
        const margin=42;
        const sx=p.x<r.left+margin?-9:p.x>r.right-margin?9:0;
        const sy=p.y<r.top+margin?-9:p.y>r.bottom-margin?9:0;
        if(sx||sy){scroll.scrollBy(sx,sy);setDrop(resolveDropAt(p.x,p.y,data));}
      }
      frameId=requestAnimationFrame(refresh);
    };
    const move=ev=>{
      if(ev.pointerId!==pointerId)return;
      session.last={x:ev.clientX,y:ev.clientY};
      if(!session.active){
        if(!pointMoved(initial,session.last))return;
        session.active=true;setDragging(data.kind);
        document.body.classList.add('studio-actively-dragging');
        frameId=requestAnimationFrame(refresh);
      }
      ev.preventDefault();
      setDragSnapshot({data,label,x:ev.clientX,y:ev.clientY});
      setDrop(resolveDropAt(ev.clientX,ev.clientY,data));
    };
    const cleanup=()=>{
      window.removeEventListener('pointermove',move);
      window.removeEventListener('pointerup',up);
      window.removeEventListener('pointercancel',cancel);
      window.removeEventListener('keydown',escape);
      cancelAnimationFrame(frameId);
      document.body.classList.remove('studio-actively-dragging');
      pointerRef.current=null;
      setDragSnapshot(null);setDragging(null);setDrop(null);
    };
    const cancel=()=>cleanup();
    const escape=ev=>{if(ev.key==='Escape'){ev.preventDefault();cleanup();}};
    const up=ev=>{
      if(ev.pointerId!==pointerId)return;
      const valid=session.active?resolveDropAt(ev.clientX,ev.clientY,data):null;
      cleanup();
      if(session.active)suppressClickUntil.current=performance.now()+350;
      if(valid)onDropAt(data,valid.ownerId,valid.index);
    };
    session.cleanup=cleanup;
    window.addEventListener('pointermove',move,{passive:false});
    window.addEventListener('pointerup',up);
    window.addEventListener('pointercancel',cancel);
    window.addEventListener('keydown',escape,true);
  }
  function resize(e,id,element,axis){
    if(!element||e.button!==0)return;
    const zoomScale=zoom/100,box=element.getBoundingClientRect(),startX=e.clientX,startY=e.clientY;
    const original={width:element.style.width,minHeight:element.style.minHeight};
    const node=findLocation(root,id)?.node;
    const initialHeight=node?.minHeight||Math.round(box.height/zoomScale);
    let w=node?.widthPx||Math.round(box.width/zoomScale),h=initialHeight;
    const update=ev=>{
      w=nextFixedWidth(box.width/zoomScale,startX,ev.clientX,zoomScale);
      h=nextFrameHeight(initialHeight,startY,ev.clientY,zoomScale);
      if(axis==='width'||axis==='both')element.style.width=`${w}px`;
      if(axis==='height'||axis==='both')element.style.minHeight=`${h}px`;
    };
    const cleanup=()=>{window.removeEventListener('pointermove',update);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',cancel);window.removeEventListener('keydown',escape,true);document.body.classList.remove('studio-resizing');};
    const cancel=()=>{cleanup();element.style.width=original.width;element.style.minHeight=original.minHeight;};
    const escape=ev=>{if(ev.key==='Escape'){ev.preventDefault();cancel();}};
    const finish=ev=>{update(ev);cleanup();editRoot(r=>changeNode(r,id,n=>{if(axis==='width'||axis==='both'){n.width='fixed';n.widthPx=w;}if((axis==='height'||axis==='both')&&isFrame(n))n.minHeight=h;}));};
    document.body.classList.add('studio-resizing');
    window.addEventListener('pointermove',update,{passive:false});
    window.addEventListener('pointerup',finish,{once:true});
    window.addEventListener('pointercancel',cancel,{once:true});
    window.addEventListener('keydown',escape,true);
  }
  function saveModule(){
    const name=window.prompt('새 공유 컴포넌트 이름',selectedNode.name||'MyComponent');if(name===null)return;
    try{const result=createComponentModule(project,target,selectedNode.id,name);
      if(!validateProject(result.project))throw Error('모듈 순환 참조 또는 스키마 오류');
      commit(result.project,result.instanceId);notice.success(`${name||selectedNode.name} 컴포넌트를 저장했습니다.`);
    }catch(e){notice.warning(e.message);}
  }
  function undo(){const h=history.current;if(!h.past.length)return;h.future.push(project);const prev=h.past.pop();setProject(prev);if(target!=='page'&&!prev.modules[target])setTarget('page');setSelected(null);}
  function redo(){const h=history.current;if(!h.future.length)return;h.past.push(project);const next=h.future.pop();setProject(next);setSelected(null);}
  useEffect(()=>{
    const handle=e=>{
      if(e.key==='Escape'&&auxPanel){setAuxPanel(null);setPanelPinned(false);return;}
      if(isEditableTarget(e.target))return;
      if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();if(e.shiftKey)redo();else undo();}
      else if((e.key==='Backspace'||e.key==='Delete')&&activeTab==='design'&&selectedNode.id!==root.id){e.preventDefault();erase();}
      else if(e.key==='Escape'){if(auxPanel){setAuxPanel(null);setPanelPinned(false);}else setSelected(root.id);}
    };
    window.addEventListener('keydown',handle);return()=>window.removeEventListener('keydown',handle);
  });
  async function importFile(e){
    const file=e.target.files?.[0];if(!file)return;
    try{const p=parseImportedProject(await file.text());commit(p,p.root.id);setTarget('page');setRuntimeState(deepCopy(p.data.state));notice.success('프로젝트를 가져왔습니다.');}
    catch(err){Modal.error({title:'불러오기 실패',content:err.message});}finally{e.target.value='';}
  }
  const toggleAux=kind=>{if(auxPanel===kind){setAuxPanel(null);setPanelPinned(false);}else setAuxPanel(kind);};
  const width={desktop:980,tablet:768,mobile:390}[device];
  const activePath=(()=>{let path=[];if(selected){const loc=findLocation(root,selected);if(loc)path=[...loc.ancestors,selected];}return path;})();
  const trail=activePath.map(id=>findLocation(root,id)?.node).filter(Boolean);
  const counts=(()=>{let c=0,f=0;const walk=n=>{if(isFrame(n))f++;else c++;for(const ch of n.children||[])walk(ch);};walk(root);return {controls:c,frames:f};})();
  return <ConfigProvider theme={{token:{colorPrimary:'#3764df',borderRadius:7,fontFamily:'Inter, Pretendard, system-ui, sans-serif'}}}>
    {noticeContext}
    <div className="studio">
      <header className="topbar">
        <div className="brand"><span className="brand-mark">◈</span><span><strong>UI Studio</strong><small>Design + Code <b>0.9</b></small></span></div>
        <div className="project-dropdown"><span>PROJECT</span><strong>{activeTab==='core'?'Unified v6 Project':project.title}</strong><span className="crumb-caret">⌄</span></div>
        <div className="top-center">One IR <span className="top-dot">·</span> Canonical v6 · Design + JSX DSL</div>
        <div className="top-actions">
          {activeTab==='core'?<span className="readonly-marker">v6 저장·DSL 내보내기는 Studio v6 내부에서 실행</span>:<>
          <Tooltip title="Ctrl+Z"><button className="icon-button" onClick={undo}>{ICONS.undo}</button></Tooltip>
          <Tooltip title="Ctrl+Shift+Z"><button className="icon-button" onClick={redo}>{ICONS.redo}</button></Tooltip>
          <span className="toolbar-sep"/>
          <button className="secondary-btn" onClick={()=>uploadRef.current?.click()}>↧ v5 가져오기</button>
          <button className="secondary-btn" onClick={()=>downloadable(JSON.stringify(project,null,2),'ui-studio-v5-project.json','application/json')}>v5 JSON 저장</button>
          <button className="primary-btn" onClick={()=>downloadable(generateTsx(project),'GeneratedPage-v5.tsx','text/typescript')}>↥ v5 React TSX</button></>}
          <input type="file" ref={uploadRef} accept="application/json,.json" hidden onChange={importFile}/>
        </div>
      </header>
      <div className={'workspace '+(activeTab==='core'?'workspace-core':auxPanel&&panelPinned?'workspace-with-pinned-panel':'')}>
        <aside className="left-sidebar" aria-label="Component Tree">
          <div className="tree-toolbar">
            <div className="tree-toolbar-title"><span className="tree-heading-icon">☷</span> Component Tree</div>
            <div className="tree-toolbar-actions">
              <button type="button" className={'panel-toggle '+(auxPanel==='insert'?'on':'')} aria-expanded={auxPanel==='insert'} aria-label="Insert 열기" title="Insert — 컴포넌트 추가" onClick={()=>toggleAux('insert')}>＋ Insert</button>
              <button type="button" className={'panel-toggle '+(auxPanel==='data'?'on':'')} aria-expanded={auxPanel==='data'} aria-label="Data 열기" title="Data — 데이터 바인딩" onClick={()=>toggleAux('data')}>◎</button>
            </div>
          </div>
          <div className="page-picker"><span>EDITING</span><Select size="small" style={{width:'100%'}} value={target} onChange={chooseTarget} options={[{value:'page',label:'▣ Main Page'},...Object.values(project.modules).map(m=>({value:m.id,label:`◇ ${m.name}`}))]}/></div>
          <div className="sidebar-title side-label">HIERARCHY <span className="sidebar-mini">{counts.frames} Frames · {counts.controls} nodes</span></div>
          <div className="layer-scroll" role="tree" aria-label="UI 컴포넌트 계층">
            <ComponentTree node={root} selected={selected} onSelect={setSelected} expanded={expanded} onToggle={id=>setExpanded(s=>({...s,[id]:s[id]===false?true:false}))} project={project} onPointerStart={startPointerDrag} drop={drop}/>
          </div>
          <div className="left-bottom"><button className="add-layer-button" onClick={()=>setAuxPanel('insert')}>＋ 컴포넌트 추가</button><div className="sidebar-title module-title">◇ My Components</div>
            {Object.values(project.modules).length===0?<p className="module-empty">Frame 선택 → 컴포넌트로 만들기</p>:Object.values(project.modules).map(m=><div key={m.id} className="saved-component"><span title="드래그해서 배치 / 클릭해서 모듈 편집" onPointerDown={e=>startPointerDrag(e,{kind:'module',moduleId:m.id},m.name)} onClick={()=>chooseTarget(m.id)}>◇ {m.name}<small>v{m.version}</small></span><button title="선택한 Frame에 추가" onClick={()=>{const parent=isFrame(selectedNode)?selectedNode.id:findLocation(root,selectedNode.id)?.parent?.id||root.id;onDropAt({kind:'module',moduleId:m.id},parent);}}>＋</button></div>)}
          </div>
        </aside>
        {auxPanel&&<aside className={'component-flyout '+(panelPinned?'flyout-pinned':'')} aria-label={auxPanel==='insert'?'Insert 컴포넌트 목록':'Data 바인딩'}>
          <div className="flyout-toolbar"><strong>{auxPanel==='insert'?'⊞ Insert':'◎ Data'}</strong><span className="flyout-spacer"/><button type="button" className={'flyout-action '+(panelPinned?'active':'')} aria-label={panelPinned?'패널 고정 해제':'패널 고정'} aria-pressed={panelPinned} title={panelPinned?'고정 해제':'옆에 고정'} onClick={()=>setPanelPinned(v=>!v)}>📌 {panelPinned?'고정됨':'고정'}</button><button type="button" className="flyout-action flyout-close" aria-label="패널 닫기" title="닫기 (Esc)" onClick={()=>{setAuxPanel(null);setPanelPinned(false);}}>×</button></div>
          {auxPanel==='insert'?<ToolBox onAdd={add} onPointerStart={startPointerDrag}/>:<DataTree project={project} onBind={chooseDataBinding}/>}
        </aside>}
        <main className="main-pane" onPointerDown={()=>{if(auxPanel&&!panelPinned)setAuxPanel(null);}}>
          <div className="pane-toolbar">
            <div className="view-tabs"><button className={activeTab==='design'?'active':''} onClick={()=>setActiveTab('design')}>Legacy Design</button><button className={activeTab==='code'?'active':''} onClick={()=>setActiveTab('code')}>Legacy Design / Code</button><button className={activeTab==='preview'?'active':''} onClick={()=>{setRuntimeState(deepCopy(project.data.state));setActiveTab('preview');}}>Legacy Preview</button><button className={activeTab==='core'?'active':''} onClick={()=>{setAuxPanel(null);setActiveTab('core');}}>◈ Studio v6</button></div>
            <div className="view-controls"><span className="readonly-marker">{activeTab==='code'?'실시간 IR 동기화 · 유효한 DSL만 적용':'LIVE ANT DESIGN'}</span></div>
          </div>
          {activeTab==='core'&&<UnifiedStudio legacyProject={project}/>}
          {['design','preview','code'].includes(activeTab)?<div className={activeTab==='code'?'split-workspace':'single-workspace'}><div className="design-workspace">
            <div className="canvas-header">
              <div className="breadcrumbs">{trail.map((n,i)=><React.Fragment key={n.id}>{i>0&&<span className="crumb-arrow">›</span>}<button className={i===trail.length-1?'crumb-active':''} onClick={()=>setSelected(n.id)}>{n.name}</button></React.Fragment>)}{!trail.length&&<span>{root.name}</span>}</div>
              <div className="canvas-size-controls"><Segmented size="small" value={device} onChange={setDevice} options={[{label:'Desktop',value:'desktop'},{label:'Tablet',value:'tablet'},{label:'Mobile',value:'mobile'}]}/><span className="control-divider"/><button onClick={()=>setZoom(v=>Math.max(35,v-10))}>−</button><strong>{zoom}%</strong><button onClick={()=>setZoom(v=>Math.min(125,v+10))}>+</button></div>
            </div>
            <div className={"canvas-workspace "+(dragging?"workspace-dragging":"")} onClick={()=>activeTab==='design'&&setSelected(root.id)}>
              <div className="artboard-dimensions" style={{width:Math.min(width*zoom/100,1100)}}>{width} px · {activeTab==='preview'?'Interactive preview':'Design Canvas'}</div>
              <div className="artboard-container" style={{width:width*zoom/100,minHeight:Math.min(500*zoom/100,500)}}>
                <div className={'artboard '+(activeTab==='preview'?'artboard-preview':'')} style={{width,transform:`scale(${zoom/100})`,transformOrigin:'top left'}} onClick={e=>e.stopPropagation()}>
                  {activeTab!=='preview'?<CanvasNode root node={root} project={project} selected={selected} onSelect={setSelected} onPointerStart={startPointerDrag} drop={drop} ctx={ctx} onResize={resize}/>:<RuntimeNode node={root} project={project} ctx={ctx} onStateChange={(key,v)=>setRuntimeState(s=>({...s,[key]:v}))}/>}
                </div>
              </div>
              {activeTab!=='preview'&&<div className="canvas-tip">포인터로 요소를 끌어 이동 · 프레임 청록색 · 컴포넌트 파란색 · 삽입선 또는 Grid 셀 확인 후 놓기 · Esc 취소</div>}
            </div>
          </div>{activeTab==='code'&&<CodeEditor draft={codeDraft} error={codeError} onChange={onCodeEdit} onCaret={onCodeCaret} codeRef={codeEditorRef} ranges={codeRanges} selected={selected} onExport={()=>downloadable(codeDraft,'ui-studio.dsl.jsx','text/plain')}/>}</div>:null}
          <div className="statusbar"><span>● {activeTab==='core'?'Schema v6 · Canonical Editor':'Schema v5 · Legacy Editor'} · Studio v0.9</span><span>{activeTab==='core'?'Unified Component Tree / IR':`${Object.keys(project.modules).length} legacy modules`}</span><span>React + Ant Design</span><span>{activeTab==='core'?'Unified Studio':'Legacy Designer'}</span></div>
        </main>
        <aside className="right-sidebar">
          <PropertyPanel node={selectedNode} rootId={root.id} project={project} onPatch={patchSelected} onDelete={erase} onDuplicate={duplicate} onModule={saveModule} onEditModule={chooseTarget} target={target}/>
        </aside>
      </div>
    </div>
    {dragSnapshot&&<div className={'studio-drag-ghost '+(drop?'valid':'invalid')} style={{left:dragSnapshot.x+18,top:dragSnapshot.y+18}}>
      <span className="ghost-symbol">{dragSnapshot.data.kind==='move'?'↔':'+'}</span>
      <GhostPreview drag={dragSnapshot}/><small>{drop?'놓으면 추가 / 이동':'놓을 Frame을 찾으세요'}</small>
    </div>}
    {dragSnapshot&&drop?.guide&&<div className={'studio-drop-guide '+(drop.guide.kind==='cell'?'guide-cell':'guide-line')} style={{left:drop.guide.left,top:drop.guide.top,width:drop.guide.width,height:drop.guide.height}}><span>{drop.description}</span></div>}
  </ConfigProvider>;
}
export default App;

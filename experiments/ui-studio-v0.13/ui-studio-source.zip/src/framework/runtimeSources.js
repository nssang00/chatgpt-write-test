/** Sources packed into exported React components by Vite raw imports. */
import source0 from '../../packages/schema/index.js?raw';
import source1 from '../../packages/runtime-react/Runtime.jsx?raw';
import source2 from '../../packages/renderer-antd/index.jsx?raw';
import source3 from '../../packages/core/index.js?raw';
import source4 from '../../packages/core/binding.js?raw';
import source5 from '../../packages/core/components.js?raw';
import source6 from '../../packages/core/document.js?raw';
import source7 from '../../packages/core/editor.js?raw';
import source8 from '../../packages/core/events.js?raw';
import source9 from '../../packages/core/layout.js?raw';
import source10 from '../../packages/core/properties.js?raw';
import source11 from '../../packages/core/registry.js?raw';
import source12 from '../../packages/core/session.js?raw';
import source13 from '../../packages/core/store.js?raw';
import source14 from '../../packages/core/workspace.js?raw';
import source15 from '../../packages/core/slots.js?raw';
import source16 from '../../packages/core/dynamic.js?raw';
export const runtimeSources={
  'packages/schema/index.js':source0,
  'packages/runtime-react/Runtime.jsx':source1,
  'packages/renderer-antd/index.jsx':source2,
  'packages/core/index.js':source3,
  'packages/core/binding.js':source4,
  'packages/core/components.js':source5,
  'packages/core/document.js':source6,
  'packages/core/editor.js':source7,
  'packages/core/events.js':source8,
  'packages/core/layout.js':source9,
  'packages/core/properties.js':source10,
  'packages/core/registry.js':source11,
  'packages/core/session.js':source12,
  'packages/core/store.js':source13,
  'packages/core/workspace.js':source14,
  'packages/core/slots.js':source15,
  'packages/core/dynamic.js':source16,
};

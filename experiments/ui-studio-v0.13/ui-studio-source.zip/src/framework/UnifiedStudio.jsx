import React, {useEffect,useMemo,useRef,useState,useSyncExternalStore} from 'react';
import {Button,Input,InputNumber,Select,Segmented,Alert,Tag,Divider,Modal} from 'antd';
import {createSearchBoxDocument,literal,binding,serializeDocument,parseDocument,migrateV5ToV6,findNode,validateDocument} from '../../packages/schema/index.js';
import {createDefaultRegistry,RuntimeSession,patchDefinitionProperty,patchInstanceBinding,patchInstanceOverride,patchInstanceProp,FRAME_TYPES,createEditorNode,insertEditorNode,moveEditorNode,removeEditorNode,extractDefinition,exposeDefinitionProperty,exposeDefinitionEvent,allowInstanceOverride,patchEditorNode,setEditorProperty,setEditorLayout,pageRoot,locateNode,geometryInsertion,bindableFields,createComponentDefinition,createBlankComponentWorkspace,addComponentToPreview,componentUsage,createDefinitionPreviewDocument,createLegoExampleDocument,createSlotExampleDocument,createDynamicExampleDocument,addDefinitionProperty,instancePropertyProviders,exposeDefinitionSlot,insertSlotChild,removeSlotChildren,resetSlotChildren} from '../../packages/core/index.js';
import {RuntimeView,RuntimeNode} from '../../packages/runtime-react/Runtime.jsx';
import {createAntdRenderer} from '../../packages/renderer-antd/index.jsx';
import {frameStyle} from '../../packages/core/layout.js';
import {printV6Dsl,parseV6Dsl} from '../../packages/format-dsl/index.js';
import {generateRuntimeTsx} from '../../packages/exporter-react/index.js';
import {createPortablePackageFiles} from '../../packages/exporter-react/component-package.js';
import {encodeZip} from '../../packages/exporter-react/zip.js';
import {runtimeSources} from './runtimeSources.js';
import './unified.css';
const registry=createDefaultRegistry(),renderer=createAntdRenderer();
const ICONS={column:'↓',row:'→',grid:'▦',wrap:'↪',overlay:'◈'};
const ALIASES={Input:'TextBox TextField QLineEdit',Select:'ComboBox Picker Dropdown',Table:'DataGrid QTableView',Card:'Panel GroupBox',row:'HStack HorizontalStack',column:'VStack StackPanel',grid:'GridPanel'};
const label=n=>`${n.repeat?'↻ ':''}${n.when?'◉ ':''}`+(n.kind==='frame'?`${ICONS[n.layout.type]} ${n.layout.type}`:n.kind==='instance'?`◇ ${n.definitionId}`:registry.get(n.typeId)?.displayName||n.typeId);
function downloadBytes(bytes,name){const url=URL.createObjectURL(new Blob([bytes],{type:'application/zip'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function download(text,name,mime='text/plain'){const url=URL.createObjectURL(new Blob([text],{type:mime}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function TreeNode({node,depth=0,selected,onSelect,onPointerDown,definitions}){
  return <><button type="button" data-v6-tree-id={node.id} className={'v6-tree-row '+(selected===node.id?'is-selected':'')} style={{paddingLeft:10+depth*16}} onClick={()=>onSelect(node.id)} onPointerDown={e=>onPointerDown(e,{kind:'move',id:node.id},label(node))}>
    <span>{label(node)}</span><small>{node.name||node.id}</small>
  </button>{node.kind==='frame'&&node.children.map(c=><TreeNode key={c.id} node={c} depth={depth+1} selected={selected} onSelect={onSelect} onPointerDown={onPointerDown} definitions={definitions}/>)}{node.kind==='instance'&&Object.entries(node.slots||{}).flatMap(([name,children])=>children.map(c=><TreeNode key={`${name}/${c.id}`} node={c} depth={depth+1} selected={selected} onSelect={onSelect} onPointerDown={onPointerDown} definitions={definitions}/>))}</>;
}
function DesignerNode({node,doc,session,selected,onSelect,onPointerDown,root=false,rootLabel='Page',designScope,designOverrides,onResize,overlayChild=false}){
  const active=selected===node.id;
  const scope=designScope||session.rootScope();
  const common={ 'data-v6-canvas-id':node.id, onClick:e=>{e.stopPropagation();onSelect(node.id);}, onPointerDown:e=>{if(!root){e.stopPropagation();onPointerDown(e,{kind:'move',id:node.id},label(node));}}};
  if(node.kind==='frame')return <div {...common} data-v6-frame-id={node.id} className={'v6-canvas-frame '+(active?'selected':'')} style={{...frameStyle(node.layout),position:'relative',minHeight:node.children.length?45:90,...(root?{minHeight:300}:{}),...node.size,...(overlayChild?{gridArea:'1 / 1'}:{})}}>
    <span className="v6-canvas-chip">{root?rootLabel:label(node)} · {node.name||node.id}</span>
    {!node.children.length&&<div className="v6-empty">+ 여기에 드래그하거나 Insert에서 클릭</div>}
    {node.children.map(child=><DesignerNode key={child.id} node={child} doc={doc} session={session} selected={selected} onSelect={onSelect} onPointerDown={onPointerDown} designScope={scope} designOverrides={designOverrides} onResize={onResize} overlayChild={node.layout.type==='overlay'}/>)}
    {active&&!root&&onResize&&<span className="v6-resize-handle" onPointerDown={e=>{e.preventDefault();e.stopPropagation();onResize(e,node);}} title="너비·높이 조절"/>}
  </div>;
  return <div {...common} className={'v6-canvas-control '+(active?'selected':'')} style={{...node.size,...(overlayChild?{gridArea:'1 / 1'}:{})}}>
    <span className="v6-canvas-control-label">{label(node)} · {node.name||node.id}</span>
    <div className="v6-canvas-control-ui"><RuntimeNode node={node} document={doc} session={session} registry={registry} renderer={renderer} scope={scope} overrides={designOverrides} path={`designer/${node.id}`} /></div>
    <div className="v6-canvas-hit"/>
    {active&&onResize&&<span className="v6-resize-handle" onPointerDown={e=>{e.preventDefault();e.stopPropagation();onResize(e,node);}} title="너비·높이 조절"/>}
  </div>;
}
function StoreValue({session,path}){
  const key=path.join('.');
  const subscribe=React.useCallback(fn=>session.state.subscribe(path,fn),[session,key]);
  const snapshot=React.useCallback(()=>session.state.get(path),[session,key]);
  const value=useSyncExternalStore(subscribe,snapshot,snapshot);
  return <code>{JSON.stringify(value??'')}</code>;
}
function PropertyEditor({node,metaKey,meta,provider,paths,onApply}){
  const isBound=provider?.kind==='binding';const actual=provider?.kind==='literal'?provider.value:meta.defaultValue;
  const value=actual??(meta.type==='boolean'?false:'');
  const setLiteral=v=>onApply(literal(v));
  const setBindingKey=v=>{const [source,...segments]=v.split('.');onApply(binding(source,segments,meta.twoWay?'TwoWay':'OneWay'));};
  return <div className="v6-property-field"><div className="v6-property-label"><label>{metaKey}</label><small>{meta.type}</small></div>
    <div className="v6-property-source"><Select size="small" value={isBound?'binding':provider?.kind==='resource'?'resource':'literal'} options={[{label:'Literal',value:'literal'},...(meta.bindable?[{label:'Binding',value:'binding'}]:[]),{label:'Resource',value:'resource'}]} onChange={v=>v==='binding'?onApply(binding('state',paths[0]?.path||['value'],meta.twoWay?'TwoWay':'OneWay')):v==='resource'?onApply({kind:'resource',key:'primary'}):setLiteral(meta.defaultValue)}/></div>
    {isBound?<><Select size="small" showSearch optionFilterProp="label" value={`${provider.source}.${provider.path.join('.')}`} options={paths.map(p=>({label:`state.${p.path.join('.')}`,value:`state.${p.path.join('.')}`}))} onChange={setBindingKey}/>
      {meta.twoWay&&<Select size="small" value={provider.mode} options={[{label:'OneWay',value:'OneWay'},{label:'TwoWay',value:'TwoWay'}]} onChange={v=>onApply({...provider,mode:v})}/>}</>
    :provider?.kind==='resource'?<Input size="small" value={provider.key} onChange={e=>onApply({kind:'resource',key:e.target.value})}/>
    :meta.type==='boolean'?<input type="checkbox" checked={!!value} onChange={e=>setLiteral(e.target.checked)}/>
    :meta.type==='number'?<InputNumber size="small" style={{width:'100%'}} value={value} onChange={v=>setLiteral(v??0)}/>
    :meta.type==='enum'?<Select size="small" value={value} options={meta.options.map(v=>({label:v,value:v}))} onChange={setLiteral}/>
    :meta.type==='color'?<input type="color" value={/^#[a-f\d]{6}$/i.test(value)?value:'#3764df'} onChange={e=>setLiteral(e.target.value)}/>
    :meta.type==='array'||meta.type==='object'?<textarea value={JSON.stringify(value)} rows={3} onChange={e=>{try{const v=JSON.parse(e.target.value);if((meta.type==='array'&&Array.isArray(v))||(meta.type==='object'&&v&&!Array.isArray(v)&&typeof v==='object'))setLiteral(v);}catch{}}}/>
    :<Input size="small" value={value} onChange={e=>setLiteral(e.target.value)}/>}
  </div>;
}
function Inspector({node,doc,paths,onPatch,onRemove,onInstanceBinding,onInstanceProp,onOverride,selectedDefinition,rootId,onExtract,onExpose,onExposeEvent,onAllowOverride,onExposeSlot,onAddSlot,onClearSlot,onResetSlot,onAddPublicProp,onOpenDefinition}){
  if(!node)return <p className="v6-muted">Component Tree나 Canvas에서 노드를 선택하세요.</p>;
  const [publicName,setPublicName]=useState('value');
  const [publicField,setPublicField]=useState('value');
  const [eventName,setEventName]=useState('search');
  const [eventField,setEventField]=useState('click');
  const [slotName,setSlotName]=useState('content');
  const [newPropName,setNewPropName]=useState('items');
  const [newPropType,setNewPropType]=useState('array');
  const [jsonPropError,setJsonPropError]=useState('');
  const [slotChoice,setSlotChoice]=useState('core/Text');
  const def=node.kind==='instance'?doc.definitions[node.definitionId]:null;
  const meta=node.kind==='component'?registry.get(node.typeId):node.kind==='instance'?{properties:def?.publicProps||{},events:def?.publicEvents||{}}:null;
  return <div className="v6-inspector-content"><h3>{label(node)}</h3><div className="v6-node-id">{node.id}</div>
    <div className="v6-property-field"><label>이름</label><Input size="small" value={node.name||''} onChange={e=>onPatch(n=>({...n,name:e.target.value}))}/></div>
    <h4>Size · Mouse Resize</h4>
    {['width','height'].map(dim=><div className="v6-property-field" key={dim}><label>{dim} (px, 비워두면 자동)</label><InputNumber size="small" style={{width:'100%'}} min={24} max={5000} value={node.size?.[dim]??null} placeholder="Auto" onChange={v=>onPatch(n=>{const size={...n.size};if(v==null)delete size[dim];else size[dim]=v;return {...n,...(Object.keys(size).length?{size}:{size:undefined})};})}/></div>)}
    <h4>Dynamic · 조건 / 반복</h4>
    <div className="v6-property-field"><label>Condition · when</label>
      <Select size="small" value={!node.when?'none':node.when.kind==='binding'?'binding':node.when.value?'true':'false'} options={[{label:'항상 표시',value:'none'},{label:'항상 표시 (true)',value:'true'},{label:'숨김 (false)',value:'false'},{label:'데이터 조건 (OneWay)',value:'binding'}]} onChange={v=>onPatch(n=>({...n,when:v==='none'?undefined:v==='binding'?binding('state',['visible']):literal(v==='true')}))}/>
      {node.when?.kind==='binding'&&<><label>Binding 경로 · 예: props.showTitle</label><Input size="small" key={`when:${node.id}:${node.when.source}.${node.when.path.join('.')}`} defaultValue={`${node.when.source}.${node.when.path.join('.')}`} onBlur={e=>{const segments=e.target.value.trim().split('.');if(segments.length>=2)onPatch(n=>({...n,when:binding(segments[0],segments.slice(1))}));}}/></>}
    </div>
    <div className="v6-property-field"><label>Repeat · 목록을 항목별 렌더링</label>
      <Select size="small" value={node.repeat?'binding':'none'} options={[{label:'반복 안 함',value:'none'},{label:'배열 바인딩',value:'binding'}]} onChange={v=>onPatch(n=>({...n,repeat:v==='none'?undefined:{items:binding('state',['items']),keyPath:['id']}}))}/>
      {node.repeat&&<><label>배열 경로 · 예: props.items</label><Input size="small" key={`repeat:${node.id}:${node.repeat.items.source}.${node.repeat.items.path.join('.')}`} defaultValue={`${node.repeat.items.source}.${node.repeat.items.path.join('.')}`} onBlur={e=>{const segments=e.target.value.trim().split('.');if(segments.length>=2)onPatch(n=>({...n,repeat:{...n.repeat,items:binding(segments[0],segments.slice(1))}}));}}/>
      <label>Stable item key · 예: id (선택)</label><Input size="small" key={`key:${node.id}:${(node.repeat.keyPath||[]).join('.')}`} defaultValue={(node.repeat.keyPath||[]).join('.')} onBlur={e=>onPatch(n=>({...n,repeat:{...n.repeat,keyPath:e.target.value.trim()?e.target.value.trim().split('.'):undefined}}))}/>
      <small>자식에서 context.item / context.index 사용. Repeat 먼저, Condition은 항목마다 적용합니다.</small></>}
    </div>
    {selectedDefinition&&node.id===rootId&&<div className="v6-property-field"><h4>Definition 공개 Props · 직접 등록</h4><label>Prop 이름</label><Input size="small" value={newPropName} onChange={e=>setNewPropName(e.target.value)}/><label>Prop 타입</label><Select size="small" value={newPropType} options={['array','boolean','string','number','object'].map(v=>({label:v,value:v}))} onChange={setNewPropType}/><Button size="small" onClick={()=>onAddPublicProp(newPropName,newPropType)}>＋ 공개 Prop 등록</Button><small>동적 Repeat/Condition 등에서 props.이름으로 참조합니다.</small></div>}
    {node.kind==='frame'&&<><h4>Layout</h4><Select size="small" style={{width:'100%'}} value={node.layout.type} options={FRAME_TYPES.map(v=>({value:v,label:v}))} onChange={v=>onPatch(n=>({...n,layout:{...n.layout,type:v}}))}/>
      {['gap','padding',...(node.layout.type==='grid'?['columns']:[])].map(key=><div className="v6-property-field" key={key}><label>{key}</label><InputNumber style={{width:'100%'}} size="small" min={key==='columns'?1:0} max={key==='columns'?24:undefined} value={node.layout[key]??(key==='columns'?2:0)} onChange={v=>onPatch(n=>({...n,layout:{...n.layout,[key]:v??0}}))}/></div>)}
    </>}
    {meta&&node.kind==='component'&&<><h4>Registry Properties</h4>{Object.entries(meta.properties).map(([key,p])=><PropertyEditor key={`${node.id}/${key}`} node={node} metaKey={key} meta={p} provider={node.props?.[key]||literal(p.defaultValue)} paths={paths} onApply={val=>onPatch(n=>({...n,props:{...n.props,[key]:val}}))}/>)}</>}
    {def&&<><Button block type="primary" size="small" onClick={()=>onOpenDefinition(node.definitionId)}>↗ 원본 Definition 편집 · {node.definitionId}</Button><h4>Public Properties · {node.definitionId}</h4>{Object.entries(def.publicProps||{}).map(([key,p])=>{
      const current=node.bindings?.[key]||node.props?.[key];return <div className="v6-property-field" key={key}><label>{key}</label>
        {p.bindable&&<Select size="small" value={current?.kind==='binding'?'binding':'literal'} options={[{label:'Literal',value:'literal'},{label:'Binding',value:'binding'}]} onChange={v=>v==='binding'?onInstanceBinding(key,binding('state',paths[0]?.path||['value'],p.twoWay?'TwoWay':'OneWay')):onInstanceProp(key,literal(p.defaultValue))}/>}
        {current?.kind==='binding'?<><Select size="small" value={`${current.source}.${current.path.join('.')}`} options={paths.map(x=>({value:`state.${x.path.join('.')}`,label:`state.${x.path.join('.')}`}))} onChange={v=>onInstanceBinding(key,binding('state',v.split('.').slice(1),p.twoWay?'TwoWay':'OneWay'))}/>
          {p.twoWay&&<Select size="small" value={current.mode} options={[{label:'OneWay',value:'OneWay'},{label:'TwoWay',value:'TwoWay'}]} onChange={v=>onInstanceBinding(key,{...current,mode:v})}/>}</>
        :p.type==='array'||p.type==='object'?<><textarea key={`${node.id}/${key}`} rows={3} defaultValue={JSON.stringify(current?.value??p.defaultValue??(p.type==='array'?[]:{}),null,2)} onBlur={e=>{try{const value=JSON.parse(e.target.value);if((p.type==='array'&&!Array.isArray(value))||(p.type==='object'&&(!value||typeof value!=='object'||Array.isArray(value))))throw Error(`${p.type} 타입이 필요합니다`);onInstanceProp(key,literal(value));setJsonPropError('');}catch(err){setJsonPropError(`${key}: ${err.message}`);}}}/>{jsonPropError&&<small style={{color:'#b91c1c'}}>{jsonPropError}</small>}</>
        :p.type==='boolean'?<input type="checkbox" checked={current?.value??p.defaultValue??false} onChange={e=>onInstanceProp(key,literal(e.target.checked))}/>
        :p.type==='number'?<InputNumber size="small" value={current?.value??p.defaultValue??0} onChange={v=>onInstanceProp(key,literal(v??0))}/>
        :<Input size="small" value={current?.value??p.defaultValue??''} onChange={e=>onInstanceProp(key,literal(e.target.value))}/>}</div>;})}
      <h4>Instance Overrides</h4>{Object.entries(def.overridePolicy||{}).flatMap(([nodeId,keys])=>keys.map(key=>{const inner=findNode(def.root,nodeId);const propMeta=registry.get(inner?.typeId)?.properties[key];if(!propMeta)return null;return <div className="v6-property-field" key={`${nodeId}/${key}`}><label>{nodeId}.{key}</label><div className="v6-inline">{propMeta.type==='color'?<input type="color" value={node.overrides?.[nodeId]?.[key]?.value||inner.props?.[key]?.value||'#3764df'} onChange={e=>onOverride(nodeId,key,literal(e.target.value))}/>:<Input size="small" value={node.overrides?.[nodeId]?.[key]?.value??inner.props?.[key]?.value??''} onChange={e=>onOverride(nodeId,key,literal(e.target.value))}/>}<Button size="small" onClick={()=>onOverride(nodeId,key,null)}>Reset</Button></div></div>;}))}
    </>}
    {selectedDefinition&&node.kind==='frame'&&<div className="v6-property-field"><h4>Named Slot · 재사용 콘텐츠 영역</h4><label>Slot 이름</label><Input size="small" value={slotName} onChange={e=>setSlotName(e.target.value)}/><Button size="small" block onClick={()=>onExposeSlot(slotName)}>＋ 이 Frame을 Slot으로 공개</Button><small>비어 있는 인스턴스는 Frame의 기존 자식을 기본 콘텐츠로 사용합니다.</small></div>}
    {def&&Object.entries(def.slots||{}).map(([name,spec])=><div key={name} className="v6-property-field"><h4>Slot · {name}</h4><small>Frame: {spec.nodeId} · {node.slots?.[name]?.length??0}개 추가됨</small>
      <Select size="small" value={slotChoice} options={[...FRAME_TYPES.map(type=>({label:`Layout / ${type}`,value:`layout/${type}`})),...registry.list().map(c=>({label:c.displayName,value:c.typeId})),...Object.keys(doc.definitions).filter(id=>id!==node.definitionId).map(id=>({label:`UserControl / ${id}`,value:`module/${id}`}))]} onChange={setSlotChoice}/>
      <div className="v6-inline"><Button size="small" onClick={()=>onAddSlot(name,slotChoice)}>＋ Slot에 추가</Button><Button size="small" danger onClick={()=>onClearSlot(name)}>비우기</Button><Button size="small" onClick={()=>onResetSlot(name)}>원본 복원</Button></div>
      {(node.slots?.[name]||[]).map(child=><small key={child.id}>· {label(child)} / {child.id} (Component Tree에서 선택·삭제 가능)</small>)}
    </div>)}
    {node.kind==='frame'&&node.id!==rootId&&<Button block type="dashed" size="small" onClick={onExtract}>◇ 선택 Frame을 UserControl로 만들기</Button>}
    {selectedDefinition&&(node.kind==='component'||node.kind==='instance')&&<>
      <h4>Public API · Definition</h4>
      <div className="v6-property-field"><label>공개 속성 이름</label><Input size="small" value={publicName} onChange={e=>setPublicName(e.target.value)}/>
        <label>내부 Property</label><Select size="small" value={publicField} options={Object.keys(meta?.properties||{}).map(k=>({label:k,value:k}))} onChange={setPublicField}/>
        <Button block size="small" onClick={()=>onExpose(publicField,publicName)}>Expose Property</Button></div>
      {!!Object.keys(meta?.events||{}).length&&<div className="v6-property-field"><label>공개 이벤트 이름</label><Input size="small" value={eventName} onChange={e=>setEventName(e.target.value)}/>
        <Select size="small" value={eventField} options={Object.keys(meta.events).map(k=>({label:k,value:k}))} onChange={setEventField}/><Button size="small" block onClick={()=>onExposeEvent(eventField,eventName)}>Expose Event</Button></div>}
      <div className="v6-property-field"><label>Instance Override 허용</label><Select size="small" value={publicField} options={Object.keys(meta?.properties||{}).map(k=>({label:k,value:k}))} onChange={setPublicField}/><Button block size="small" onClick={()=>onAllowOverride(publicField)}>Allow Override</Button></div>
      <p className="v6-muted">Definition: {selectedDefinition} · 공개 Property / Event와 허용된 Override는 모든 인스턴스의 Inspector에 반영됩니다.</p>
    </>}
    {node.id!==rootId&&<Button size="small" danger block onClick={onRemove}>선택 요소 삭제</Button>}
  </div>;
}
export function UnifiedStudio({legacyProject}){
  const [doc,setDoc]=useState(createSearchBoxDocument);
  const [session,setSession]=useState(()=>new RuntimeSession(createSearchBoxDocument()));
  const [selected,setSelected]=useState('searchRoot');
  const [view,setView]=useState('design');
  const [editingDef,setEditingDef]=useState('SearchBox');
  const [insertOpen,setInsertOpen]=useState(false);
  const [insertSearch,setInsertSearch]=useState('');
  const [createOpen,setCreateOpen]=useState(false);
  const [createName,setCreateName]=useState('MyComponent');
  const [jsonOpen,setJsonOpen]=useState(false);
  const [error,setError]=useState('');
  const [code,setCode]=useState(()=>printV6Dsl(createSearchBoxDocument().definitions.SearchBox.root).text);
  const [jsonDraft,setJsonDraft]=useState(()=>serializeDocument(createSearchBoxDocument(),registry));
  const [drag,setDrag]=useState(null),[drop,setDrop]=useState(null);
  const pointer=useRef(null),ignoreClick=useRef(false);
  const history=useRef({past:[],future:[]});
  const [resizePreview,setResizePreview]=useState(null);
  const [log,setLog]=useState([]);
  const uploadRef=useRef(null);
  const codeRef=useRef(null),codeRanges=useRef(printV6Dsl(createSearchBoxDocument().definitions.SearchBox.root).ranges),selectingByCaret=useRef(false);
  const activeScope=editingDef?`definition:${editingDef}`:'main';
  const treeRoot=editingDef?doc.definitions[editingDef]?.root:pageRoot(doc);
  const location=locateNode(treeRoot,selected),node=location?.node||treeRoot;
  const paths=bindableFields(doc);
  const matchesInsert=(label)=>`${label} ${ALIASES[label]||''}`.toLowerCase().includes(insertSearch.trim().toLowerCase());
  session.document=doc;
  const selectedId=node.id;
  const sync=(next,{resetState=false,record=true}={})=>{const checked=validateDocument(next,registry);if(record){history.current.past.push(doc);if(history.current.past.length>100)history.current.past.shift();history.current.future=[];}else history.current={past:[],future:[]};setDoc(checked);if(resetState)setSession(new RuntimeSession(checked));{const printed=printV6Dsl(editingDef&&checked.definitions[editingDef]?checked.definitions[editingDef].root:checked.pages.main.root);setCode(printed.text);codeRanges.current=printed.ranges;}setJsonDraft(serializeDocument(checked,registry));setError('');};
  const mutate=(fn)=>{try{sync(fn(doc));}catch(e){setError(e.message);}};
  const putNode=(updated)=>{if(editingDef){mutate(d=>{const next=structuredClone(d);const entry=locateNode(next.definitions[editingDef].root,selectedId);if(!entry)throw Error('Definition에서 노드 없음');if(entry.parent)(entry.slotChildren||entry.parent.children)[entry.index]=updated;else next.definitions[editingDef].root=updated;next.definitions[editingDef].revision++;return next;});}
    else mutate(d=>patchEditorNode(d,selectedId,()=>updated,registry));};
  const patch=(fn)=>putNode(fn(structuredClone(node)));
  const targetFrame=()=>node.kind==='frame'?node.id:location?.parent?.id||treeRoot.id;
  const add=(typeId,ownerId=targetFrame(),index=undefined)=>{
    try{const created=createEditorNode(doc,typeId,registry);sync(insertEditorNode(doc,ownerId,index??locateNode(treeRoot,ownerId).node.children.length,created,registry,activeScope));setSelected(created.id);setInsertOpen(false);}catch(e){setError(e.message);}};
  const remove=()=>{if(node.id===treeRoot.id)return;mutate(d=>removeEditorNode(d,node.id,registry,activeScope));setSelected(location?.parent?.id||treeRoot.id);};
  const chooseDefinition=id=>{setEditingDef(id);setSelected(doc.definitions[id].root.id);{const printed=printV6Dsl(doc.definitions[id].root);setCode(printed.text);codeRanges.current=printed.ranges;}setView('design');};
  const goPage=()=>{setEditingDef(null);setSelected(pageRoot(doc).id);{const printed=printV6Dsl(pageRoot(doc));setCode(printed.text);codeRanges.current=printed.ranges;}};
  const extract=()=>{try{const result=extractDefinition(doc,node.id,registry,activeScope);sync(result.document);setSelected(result.instanceId);setError('');}catch(e){setError(e.message);}};
  const createNew=(fresh=false)=>{const name=createName.trim();try{
    const next=fresh?createBlankComponentWorkspace(name,registry):createComponentDefinition(doc,name,registry);
    sync(next,{resetState:fresh,record:!fresh});setEditingDef(name);setSelected(next.definitions[name].root.id);
    const printed=printV6Dsl(next.definitions[name].root);setCode(printed.text);codeRanges.current=printed.ranges;
    setView('design');setCreateOpen(false);setInsertOpen(false);
  }catch(e){setError(e.message);}};
  const previewAdd=()=>{try{if(!editingDef)throw Error('컴포넌트를 선택하세요');sync(addComponentToPreview(doc,editingDef,registry));goPage();setView('design');}catch(e){setError(e.message);}};
  const exportPackage=()=>{const id=editingDef;try{if(!id)throw Error('Component Tree에서 내보낼 컴포넌트를 먼저 선택하세요');const files=createPortablePackageFiles(doc,registry,id,runtimeSources);downloadBytes(encodeZip(files),`${id}-react-component.zip`);}catch(e){setError(`React 패키지 내보내기: ${e.message}`);}};
  const addPublicProp=(name,type)=>{const defaults={array:[],object:{},boolean:false,number:0,string:''};mutate(d=>addDefinitionProperty(d,editingDef,name,type,defaults[type],registry));};
  const expose=(property,key)=>mutate(d=>exposeDefinitionProperty(d,editingDef,node.id,property,key,registry));
  const exposeEvent=(event,key)=>mutate(d=>exposeDefinitionEvent(d,editingDef,node.id,event,key,registry));
  const exposeSlot=name=>mutate(d=>exposeDefinitionSlot(d,editingDef,node.id,name,registry));
  const addSlot=(name,type)=>{try{const created=createEditorNode(doc,type,registry);const current=node.slots?.[name]||[];sync(insertSlotChild(doc,node.id,name,current.length,created,registry,activeScope));setSelected(created.id);}catch(e){setError(e.message);}};
  const clearSlot=name=>mutate(d=>removeSlotChildren(d,node.id,name,registry,activeScope));
  const resetSlot=name=>mutate(d=>resetSlotChildren(d,node.id,name,registry,activeScope));
  const allowOverride=property=>mutate(d=>allowInstanceOverride(d,editingDef,node.id,property,registry));
  const setBinding=(key,val)=>mutate(d=>patchInstanceBinding(d,node.id,key,val,registry,activeScope));
  const setProp=(key,val)=>mutate(d=>patchInstanceProp(d,node.id,key,val,registry,activeScope));
  const setOverride=(nodeId,key,val)=>mutate(d=>patchInstanceOverride(d,node.id,nodeId,key,val,registry,activeScope));
  const reset=()=>{const next=createSearchBoxDocument();sync(next,{resetState:true,record:false});setSelected('searchRoot');setEditingDef('SearchBox');const printed=printV6Dsl(next.definitions.SearchBox.root);setCode(printed.text);codeRanges.current=printed.ranges;setLog([]);setView('design');};
  const legoExample=()=>{try{const next=createLegoExampleDocument(registry);sync(next,{resetState:true,record:false});setEditingDef('CustomerBrowser');setSelected(next.definitions.CustomerBrowser.root.id);const printed=printV6Dsl(next.definitions.CustomerBrowser.root);setCode(printed.text);codeRanges.current=printed.ranges;setView('design');setLog([]);}catch(e){setError(e.message);}};
  const dynamicExample=()=>{try{const next=createDynamicExampleDocument(registry);sync(next,{resetState:true,record:false});setEditingDef('ItemList');setSelected(next.definitions.ItemList.root.id);const printed=printV6Dsl(next.definitions.ItemList.root);setCode(printed.text);codeRanges.current=printed.ranges;setView('design');setLog([]);}catch(e){setError(e.message);}};
  const slotsExample=()=>{try{const next=createSlotExampleDocument(registry);sync(next,{resetState:true,record:false});setEditingDef('SearchCard');setSelected(next.definitions.SearchCard.root.id);const printed=printV6Dsl(next.definitions.SearchCard.root);setCode(printed.text);codeRanges.current=printed.ranges;setView('design');setLog([]);}catch(e){setError(e.message);}};
  const importV5=()=>{try{const next=migrateV5ToV6(legacyProject);sync(next,{resetState:true,record:false});setSelected(next.pages.main.root.id);setEditingDef(null);}catch(e){setError(`v5 가져오기 실패: ${e.message}`);}};
  const changeCode=value=>{setCode(value);try{const parsed=parseV6Dsl(value,doc,registry,'main',editingDef);codeRanges.current=parsed.ranges;history.current.past.push(doc);if(history.current.past.length>100)history.current.past.shift();history.current.future=[];setDoc(parsed.document);setJsonDraft(serializeDocument(parsed.document,registry));setError('');if(!locateNode(editingDef?parsed.document.definitions[editingDef].root:parsed.document.pages.main.root,selected))setSelected(editingDef?parsed.document.definitions[editingDef].root.id:parsed.document.pages.main.root.id);}catch(e){setError(`DSL: ${e.message}`);}};
  const applyJson=()=>{try{const next=parseDocument(jsonDraft,registry);sync(next,{resetState:true,record:false});setSelected(pageRoot(next).id);setEditingDef(null);setJsonOpen(false);}catch(e){setError(`JSON: ${e.message}`);}};
  const restoreHistory=next=>{setDoc(next);session.document=next;{const printed=printV6Dsl(editingDef&&next.definitions[editingDef]?next.definitions[editingDef].root:pageRoot(next));setCode(printed.text);codeRanges.current=printed.ranges;}setJsonDraft(serializeDocument(next,registry));const available=editingDef&&next.definitions[editingDef]?next.definitions[editingDef].root:pageRoot(next);if(editingDef&&!next.definitions[editingDef])setEditingDef(null);if(!locateNode(available,selected))setSelected(available.id);setError('');};
  const undo=()=>{const entry=history.current.past.pop();if(!entry)return;history.current.future.push(doc);restoreHistory(entry);};
  const redo=()=>{const entry=history.current.future.pop();if(!entry)return;history.current.past.push(doc);restoreHistory(entry);};
  const resizeStart=(e,chosen)=>{
    const el=e.currentTarget.closest('[data-v6-canvas-id]'),rect=el?.getBoundingClientRect();if(!rect)return;
    const x=e.clientX,y=e.clientY,origW=chosen.size?.width??Math.round(rect.width),origH=chosen.size?.height??Math.round(rect.height);
    const motion=ev=>{setResizePreview({id:chosen.id,width:Math.max(24,Math.round(origW+ev.clientX-x)),height:Math.max(24,Math.round(origH+ev.clientY-y)),x:ev.clientX,y:ev.clientY});};
    const stop=ev=>{window.removeEventListener('pointermove',motion);window.removeEventListener('pointerup',stop);window.removeEventListener('pointercancel',cancel);setResizePreview(null);
      const width=Math.max(24,Math.round(origW+ev.clientX-x)),height=Math.max(24,Math.round(origH+ev.clientY-y));
      if(Math.abs(ev.clientX-x)+Math.abs(ev.clientY-y)<3)return;
      try{sync(patchEditorNode(doc,chosen.id,n=>({...n,size:{...n.size,width,height}}),registry,activeScope));setSelected(chosen.id);}catch(err){setError(err.message);}
    };
    const cancel=()=>{window.removeEventListener('pointermove',motion);window.removeEventListener('pointerup',stop);window.removeEventListener('pointercancel',cancel);setResizePreview(null);};
    window.addEventListener('pointermove',motion);window.addEventListener('pointerup',stop);window.addEventListener('pointercancel',cancel);
  };
  // The same drop resolution is used by palette, canvas and the Component Tree.
  const resolveDrop=(x,y,data)=>{
    const target=document.elementFromPoint(x,y);if(!target)return null;
    const row=target.closest('[data-v6-tree-id]');
    if(row){const id=row.dataset.v6TreeId,loc=locateNode(treeRoot,id);if(!loc)return null;
      const r=row.getBoundingClientRect(),ratio=(y-r.top)/r.height;
      const inside=loc.node.kind==='frame'&&ratio>0.25&&ratio<0.75;
      const parentId=inside?id:loc.parent?.id;
      if(!parentId)return null;
      return {parentId,index:inside?loc.node.children.length:loc.index+(ratio>=0.5?1:0),targetId:id,edge:inside?'inside':ratio>=0.5?'after':'before',description:inside?'Frame 안에 삽입':'Component Tree에서 순서 변경'};
    }
    const frame=target.closest('[data-v6-frame-id]');if(!frame)return null;
    const parentId=frame.dataset.v6FrameId,loc=locateNode(treeRoot,parentId);
    if(loc?.node.kind!=='frame')return null;
    const elements=[...frame.children].filter(el=>el.dataset?.v6CanvasId&&el.dataset.v6CanvasId!==data.id);
    const rects=elements.map(el=>el.getBoundingClientRect());
    const result=geometryInsertion(rects,{x,y},loc.node.layout.type,loc.node.layout.columns);
    const childId=elements[result.index]?.dataset.v6CanvasId;
    const index=childId?loc.node.children.findIndex(c=>c.id===childId):loc.node.children.length;
    const refRect=(elements[result.index]||elements.at(-1)||frame).getBoundingClientRect();
    const horizontal=loc.node.layout.type==='column';
    const guide=loc.node.layout.type==='grid'?{left:refRect.left,top:refRect.top,width:refRect.width,height:refRect.height}:
      horizontal?{left:refRect.left,top:result.edge==='before'?refRect.top:refRect.bottom,width:refRect.width,height:3}:{left:result.edge==='before'?refRect.left:refRect.right,top:refRect.top,width:3,height:refRect.height};
    return {parentId,index,targetId:parentId,edge:'inside',guide,description:`${loc.node.layout.type}: ${index+1}번째 위치`};
  };
  const pointerDown=(e,data,labelText)=>{
    if(e.button!==0||view==='preview'||view==='code'||jsonOpen)return;
    const start={x:e.clientX,y:e.clientY};const current={data,labelText,start,active:false,last:start};pointer.current=current;
    const move=ev=>{if(pointer.current!==current)return;current.last={x:ev.clientX,y:ev.clientY};if(!current.active&&Math.hypot(ev.clientX-start.x,ev.clientY-start.y)<6)return;current.active=true;
      const at=resolveDrop(ev.clientX,ev.clientY,data);setDrag({x:ev.clientX,y:ev.clientY,labelText});setDrop(at);};
    const finish=ev=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',cancel);pointer.current=null;
      if(!current.active)return;ignoreClick.current=true;setTimeout(()=>ignoreClick.current=false,80);
      setDrag(null);setDrop(null);const at=resolveDrop(ev.clientX,ev.clientY,data);if(!at)return;
      try{const created=data.kind==='new'?createEditorNode(doc,data.typeId,registry):null;
        const next=data.kind==='new'?insertEditorNode(doc,at.parentId,at.index,created,registry,activeScope):moveEditorNode(doc,data.id,at.parentId,at.index,registry,activeScope);
        sync(next);const picked=data.kind==='new'?created.id:data.id;setSelected(picked);setInsertOpen(false);
      }catch(ex){setError(ex.message);}
    };
    const cancel=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',cancel);pointer.current=null;setDrag(null);setDrop(null);};
    window.addEventListener('pointermove',move);window.addEventListener('pointerup',finish);window.addEventListener('pointercancel',cancel);
  };
  const codeCaret=()=>{
    const offset=codeRef.current?.selectionStart;if(offset===undefined)return;
    const entries=Object.entries(codeRanges.current||{}).filter(([,range])=>range.start<=offset&&offset<=range.end);
    entries.sort((a,b)=>(a[1].end-a[1].start)-(b[1].end-b[1].start));
    if(entries.length&&entries[0][0]!==selected){selectingByCaret.current=true;setSelected(entries[0][0]);}
  };
  useEffect(()=>{
    if(view!=='code'||!codeRef.current)return;
    if(selectingByCaret.current){selectingByCaret.current=false;return;}
    const range=codeRanges.current[selected];if(!range)return;
    const field=codeRef.current;const last=code.indexOf('>',range.start);
    field.setSelectionRange(range.start,last>range.start?Math.min(last+1,range.end):range.start);
  },[selected,view,editingDef]);
  useEffect(()=>{
    const keydown=e=>{
      if(!(e.ctrlKey||e.metaKey)||e.key.toLowerCase()!=='z'||e.altKey)return;
      if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)||document.activeElement?.isContentEditable)return;
      e.preventDefault();if(e.shiftKey)redo();else undo();
    };
    window.addEventListener('keydown',keydown);return()=>window.removeEventListener('keydown',keydown);
  });
  const previewRoot=editingDef?createDefinitionPreviewDocument(doc,editingDef,registry):doc;
  const designOverrides=editingDef?instancePropertyProviders(doc.definitions[editingDef],{overrides:{}}):{};
  const designScope=editingDef?session.rootScope().child({props:{
    get:path=>path.length===1?doc.definitions[editingDef]?.publicProps?.[path[0]]?.defaultValue:undefined,
    set:()=>{throw Error('Design에서는 값을 편집할 수 없습니다');},subscribe:()=>()=>{}
  }}):session.rootScope();
  return <div className="v6-studio">
    <input hidden type="file" accept="application/json,.json" ref={uploadRef} onChange={async e=>{const file=e.target.files?.[0];if(!file)return;try{const content=await file.text();const raw=JSON.parse(content);const next=raw.schemaVersion===5?migrateV5ToV6(raw):parseDocument(content,registry);sync(next,{resetState:true,record:false});setSelected(next.pages.main.root.id);setEditingDef(null);setView('design');setError('');}catch(err){setError(`파일 불러오기 실패: ${err.message}`);}finally{e.target.value='';}}}/>
    <div className="v6-header"><div><strong>UI Studio v0.13 · Component-First IDE</strong><small>부품 조합 → UserControl → 재사용 → React 패키지 내보내기</small></div>
      <div className="v6-actions"><Button size="small" onClick={undo}>↶ Undo</Button><Button size="small" onClick={redo}>↷ Redo</Button><Button size="small" type="primary" onClick={()=>{setCreateName('MyComponent');setCreateOpen(true);}}>＋ New Component</Button><Button size="small" onClick={previewAdd} disabled={!editingDef}>＋ Preview Instance</Button><Button size="small" onClick={reset}>SearchBox 예제</Button><Button size="small" onClick={legoExample}>🧱 LEGO 재사용 예제</Button><Button size="small" onClick={slotsExample}>▣ Slots 예제</Button><Button size="small" onClick={dynamicExample}>↻ Dynamic 예제</Button><Button size="small" onClick={importV5}>Legacy v5 가져오기</Button><Button size="small" onClick={()=>uploadRef.current?.click()}>JSON 불러오기</Button><Button size="small" onClick={()=>{setJsonOpen(v=>!v);setJsonDraft(serializeDocument(doc,registry));}}>JSON 편집</Button><Button size="small" onClick={()=>download(code,'ui-studio-v6.dsl.jsx')}>DSL 저장</Button><Button size="small" onClick={exportPackage}>📦 React Component ZIP</Button><Button size="small" onClick={()=>download(generateRuntimeTsx(doc,registry),'GeneratedPageV6.tsx','text/typescript')}>Page TSX (Legacy)</Button><Button size="small" type="primary" onClick={()=>download(serializeDocument(doc,registry),'ui-studio-v6.json','application/json')}>JSON 저장</Button></div>
    </div>
    {error&&<Alert className="v6-error" type="warning" showIcon message={error} closable onClose={()=>setError('')}/>}
    {jsonOpen?<div className="v6-json"><div className="v6-inline"><strong>Canonical JSON v6</strong><span>정의·바인딩·Override 포함 · 유효한 문서만 적용</span><Button type="primary" onClick={applyJson}>JSON 검증 및 적용</Button></div><textarea aria-label="v6 JSON 문서" value={jsonDraft} onChange={e=>setJsonDraft(e.target.value)} spellCheck={false}/></div>:
    <div className="v6-columns">
      <aside className="v6-left"><div className="v6-left-head"><strong>Component Tree</strong><Button size="small" onClick={()=>setInsertOpen(v=>!v)}>＋ Insert</Button></div>
        <div className="v6-component-library">
          <div className="v6-library-head"><strong>Component Library</strong><small>사용자가 만든 재사용 부품</small></div>
          <div className="v6-tree-actions"><Button size="small" type={!editingDef?'primary':'default'} onClick={goPage}>Preview Harness</Button></div>
          <div className="v6-library-items" data-testid="component-library">{Object.keys(doc.definitions).map(id=><div className="v6-library-row" data-testid={`component-library-${id}`} key={id}>
            <Button size="small" type={editingDef===id?'primary':'default'} onClick={()=>chooseDefinition(id)}>◇ {id}</Button>
            <small>사용 {componentUsage(doc,id,registry).length}회</small>
          </div>)}</div>
        </div>
        {insertOpen?<div className="v6-insert"><div className="v6-pane-heading">Insert · 클릭 / 드래그 <Button size="small" onClick={()=>setInsertOpen(false)}>×</Button></div><Input size="small" placeholder="검색 · Input, TextBox, Table..." aria-label="v6 컴포넌트 검색" value={insertSearch} onChange={e=>setInsertSearch(e.target.value)}/><div className="v6-insert-items">
          {FRAME_TYPES.filter(matchesInsert).map(type=><button key={type} onPointerDown={e=>pointerDown(e,{kind:'new',typeId:`layout/${type}`},type)} onClick={()=>!ignoreClick.current&&add(`layout/${type}`)}>{ICONS[type]} {type}</button>)}
          {registry.list().filter(item=>matchesInsert(item.displayName)).map(item=><button key={item.typeId} onPointerDown={e=>pointerDown(e,{kind:'new',typeId:item.typeId},item.displayName)} onClick={()=>!ignoreClick.current&&add(item.typeId)}>{item.displayName}</button>)}
          {Object.keys(doc.definitions).filter(matchesInsert).map(id=><button key={id} onPointerDown={e=>pointerDown(e,{kind:'new',typeId:`module/${id}`},id)} onClick={()=>!ignoreClick.current&&add(`module/${id}`)}>◇ {id}</button>)}
        </div></div>:null}
        <div className="v6-tree" role="tree"><TreeNode node={treeRoot} selected={selected} onSelect={setSelected} onPointerDown={pointerDown} definitions={doc.definitions}/></div>
        <div className="v6-help">트리 항목을 끌어 순서·부모 변경 · Canvas 드롭도 같은 IR 명령을 사용합니다.</div>
      </aside>
      <main className="v6-center"><div className="v6-center-head"><Segmented size="small" options={[{label:'◫ Design',value:'design'},{label:'〈/〉 Code',value:'code'},{label:'▶ Preview',value:'preview'}]} value={view} onChange={v=>{if(v==='code'){const printed=printV6Dsl(treeRoot);setCode(printed.text);codeRanges.current=printed.ranges;}setView(v);}}/><span>Schema v6 · {editingDef?`Component: ${editingDef}`:'Preview / Page: main'}</span></div>
        <div className={'v6-design-code '+(view==='code'?'is-split':'')}>
          <div className="v6-artboard-space"><div className="v6-stage-title">{view==='preview'?'Runtime Preview':'Design Canvas'} · 실제 React / AntD</div><div className="v6-artboard">
            {view==='preview'?<RuntimeView document={previewRoot} session={session} registry={registry} renderer={renderer} onPublicEvent={(instanceId,event,payload)=>setLog(items=>[`${instanceId}.${event}: ${JSON.stringify(payload.value)}`,...items].slice(0,5))}/>:
              <DesignerNode root rootLabel={editingDef?'Component':'Page'} designScope={designScope} designOverrides={designOverrides} node={treeRoot} doc={doc} session={session} selected={selected} onSelect={setSelected} onPointerDown={pointerDown} onResize={resizeStart}/>}</div>
            {view==='preview'?<div className="v6-preview-log"><strong>공개 이벤트</strong>{log.length?log.map((entry,i)=><code key={i}>{entry}</code>):<span>SearchBox 버튼을 누르면 여기에 표시됩니다.</span>}
              <strong>State</strong>{paths.filter(x=>x.path.length>0).slice(0,12).map(x=><div key={x.path.join('.')} className="v6-state-line"><span>{x.path.join('.')}</span><StoreValue session={session} path={x.path}/></div>)}</div>:<div className="v6-design-help">컴포넌트 클릭: 선택 · 드래그: 이동 · 부모 Frame 강조와 삽입 가이드를 보고 놓으세요 · 입력은 Preview에서 활성화</div>}
          </div>
          {view==='code'&&<div className="v6-code-pane"><div className="v6-pane-heading">v6 JSX DSL · {editingDef?`Definition: ${editingDef}`:'현재 페이지'} <small>유효한 변경은 즉시 Design에 반영</small></div><textarea ref={codeRef} aria-label="v6 JSX DSL" spellCheck={false} value={code} onChange={e=>changeCode(e.target.value)} onClick={codeCaret} onKeyUp={codeCaret}/><div>Code와 Design은 현재 선택한 Page 또는 Definition을 편집합니다. 공개 API와 Override 정책은 Properties/JSON에서 편집합니다.</div></div>}
        </div>
      </main>
      <aside className="v6-right"><div className="v6-pane-heading">Properties <small>Control Registry 기반</small></div>{editingDef&&<div className="v6-component-api"><strong>◇ {editingDef}</strong><small>Public Props: {Object.keys(doc.definitions[editingDef].publicProps).join(', ')||'없음'}<br/>Events: {Object.keys(doc.definitions[editingDef].publicEvents).join(', ')||'없음'}</small></div>}<Inspector key={`${editingDef||'page'}:${node.id}`} node={node} doc={doc} paths={paths} onPatch={patch} onRemove={remove} onInstanceBinding={setBinding} onInstanceProp={setProp} onOverride={setOverride} selectedDefinition={editingDef} rootId={treeRoot.id} onExtract={extract} onExpose={expose} onExposeEvent={exposeEvent} onAllowOverride={allowOverride} onExposeSlot={exposeSlot} onAddSlot={addSlot} onClearSlot={clearSlot} onResetSlot={resetSlot} onAddPublicProp={addPublicProp} onOpenDefinition={chooseDefinition}/></aside>
    </div>}
    <Modal title="새 재사용 컴포넌트" open={createOpen} onCancel={()=>setCreateOpen(false)} onOk={()=>createNew(false)} okText="컴포넌트 생성" destroyOnHidden>
      <label htmlFor="v13-component-name">Component name · PascalCase</label>
      <Input id="v13-component-name" aria-label="New component name" value={createName} onChange={e=>setCreateName(e.target.value)} onPressEnter={()=>createNew(false)} autoFocus/>
      <p>생성 즉시 라이브러리에 등록되며 다른 컴포넌트에 삽입할 수 있습니다.</p>
      <Button onClick={()=>createNew(true)}>새 컴포넌트 프로젝트로 시작 (Preview Harness만 유지)</Button>
    </Modal>
    <div className="v6-footer">Component-first Workspace · Definition / Instance 재사용 · Preview Harness · 독립 React 패키지 Export</div>
    {drag&&<div className="v6-drag-ghost" style={{left:drag.x+18,top:drag.y+18}}>{drag.labelText}<small>{drop?drop.description:'유효한 Frame으로 이동하세요'}</small></div>}
    {drag&&drop?.guide&&<div className="v6-drop-line" style={{left:drop.guide.left,top:drop.guide.top,width:drop.guide.width,height:drop.guide.height}}/>}
    {resizePreview&&<div className="v6-drop-tip" style={{left:resizePreview.x+12,top:resizePreview.y-22}}>{resizePreview.width} × {resizePreview.height} px</div>}
    {drag&&drop?.targetId&&<div className="v6-drop-tip" style={{left:drag.x+16,top:drag.y-26}}>{drop.description}</div>}
  </div>;
}

/** Browser native HTML5 DnD negotiation. Pure helpers shared by the editor and tests. */
export const STUDIO_DRAG_TYPE = 'application/x-ui-studio';
export function isStudioDrag(dataTransfer, currentKind) {
  if (currentKind === 'new' || currentKind === 'move' || currentKind === 'module') return true;
  return Array.from(dataTransfer?.types || []).includes(STUDIO_DRAG_TYPE);
}
export function getDropEffect(currentKind, dataTransfer) {
  // A newly created toolbox element is a COPY operation; relocating a layer is MOVE.
  // Asking for "move" from a copy-only source produces a forbidden-drop cursor.
  if (currentKind === 'new' || dataTransfer?.effectAllowed === 'copy') return 'copy';
  return 'move';
}
export function readStudioDrag(dataTransfer) {
  try {
    const data = JSON.parse(dataTransfer?.getData(STUDIO_DRAG_TYPE) || 'null');
    return data && ['new','move','module'].includes(data.kind) ? data : null;
  } catch { return null; }
}

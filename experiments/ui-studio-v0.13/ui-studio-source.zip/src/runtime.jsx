import React from 'react';
import { Button, Input, Select, Checkbox, Table, Card, Divider, Tag, Typography, message } from 'antd';
import { layoutStyle } from './generator.js';
import { resolveBinding, isBinding } from './model.js';

export function VisualElement({node,project,editing=false,ctx,onStateChange}){
  const p=node.props||{};
  const width=node.width==='fixed'?`${node.widthPx}px`:node.width==='fill'?'100%':undefined;
  const style={width,minWidth:0};
  const value=resolveBinding(p.valueBinding,ctx);
  const label=t=><label className="control-label">{t}</label>;
  const runAction=()=>{
    const a=p.action||{};
    if(a.type==='clear')onStateChange?.(a.target,'');
    if(a.type==='message')message.info(a.message||'완료');
  };
  switch(node.component){
    case 'Text':return <Typography.Text style={{fontSize:p.weight==='heading'?26:14,fontWeight:p.weight==='heading'?730:400,display:'block',width}}>{isBinding(p.valueBinding)?String(resolveBinding(p.valueBinding,ctx)??''):p.text||'텍스트'}</Typography.Text>;
    case 'Button':return <Button type={p.variant==='primary'?'primary':'default'} onClick={editing?undefined:runAction}>{p.text||'버튼'}</Button>;
    case 'Input':return <div style={style}>{label(p.label)}<Input placeholder={p.placeholder} value={typeof value==='string'?value:''} onChange={e=>{if(!editing){const m=p.valueBinding?.match(/^\{\{\s*state\.([A-Za-z_$][\w$]*)\s*\}\}$/);if(m)onStateChange?.(m[1],e.target.value);}}}/></div>;
    case 'Select':return <div style={style}>{label(p.label)}<Select placeholder="선택" style={{width:'100%'}} options={String(p.options||'').split(',').filter(Boolean).map(v=>({value:v,label:v}))}/></div>;
    case 'Checkbox':return <Checkbox>{p.text||'확인'}</Checkbox>;
    case 'Table':{
      let rows=resolveBinding(p.rowsBinding,ctx);
      const q=String(resolveBinding(p.filterBinding,ctx)||'').trim().toLowerCase();
      if(!Array.isArray(rows))rows=[];
      if(q)rows=rows.filter(r=>Object.values(r||{}).some(v=>String(v??'').toLowerCase().includes(q)));
      const cols=String(p.columns||'id,name').split(',').map(v=>v.trim()).filter(Boolean).map(k=>({key:k,dataIndex:k,title:k.toUpperCase(),render:(v)=>k==='status'?<Tag color={v==='활성'?'green':'default'}>{String(v??'')}</Tag>:String(v??'')}));
      return <div style={{width:'100%',minWidth:0}}><Typography.Title level={5} style={{margin:'0 0 14px'}}>{p.title}</Typography.Title><Table size="small" dataSource={rows} columns={cols} rowKey={(r)=>r.id||JSON.stringify(r)} pagination={{pageSize:5,size:'small'}} scroll={{x:'max-content'}}/></div>;
    }
    case 'Card':return <Card size="small" title={p.title} style={style}><Typography.Text type="secondary">{p.description}</Typography.Text></Card>;
    case 'Divider':return <Divider style={{margin:'9px 0'}}/>;
    case 'Tag':return <Tag color={p.color||'blue'}>{p.text}</Tag>;
    default:return <div>Unsupported: {node.component}</div>;
  }
}
export function RuntimeNode({node,project,ctx,onStateChange,depth=0}){
  if(depth>20)return <div>모듈 중첩 깊이 초과</div>;
  if(node.kind==='instance'){
    const mod=project.modules[node.moduleId];return mod?<RuntimeNode node={mod.root} project={project} ctx={ctx} onStateChange={onStateChange} depth={depth+1}/>:<div>모듈을 찾지 못했습니다.</div>;
  }
  if(node.kind==='frame')return <div style={layoutStyle(node)}>{node.children.map(c=>node.layout==='overlay'?<div key={c.id} style={{gridArea:'1 / 1'}}><RuntimeNode node={c} project={project} ctx={ctx} onStateChange={onStateChange} depth={depth+1}/></div>:<RuntimeNode key={c.id} node={c} project={project} ctx={ctx} onStateChange={onStateChange} depth={depth+1}/>)}</div>;
  return <VisualElement node={node} project={project} ctx={ctx} onStateChange={onStateChange}/>;
}

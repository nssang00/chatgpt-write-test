/** Static syntax check of JS/JSX/TS/TSX sources and generated React TSX. Requires TypeScript. */
import {readFileSync,readdirSync,realpathSync} from 'node:fs';
import {join,dirname,resolve} from 'node:path';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
import {createDefaultRegistry,createLegoExampleDocument,createSlotExampleDocument} from '../packages/core/index.js';
import {generateComponentSource} from '../packages/exporter-react/component-package.js';
let ts;try{ts=createRequire(import.meta.url)('typescript');}
catch{const bin=realpathSync(execFileSync('which',['tsc'],{encoding:'utf8'}).trim());ts=createRequire(import.meta.url)(resolve(dirname(bin),'../lib/typescript.js'));}
const files=[];function scan(dir){for(const ent of readdirSync(dir,{withFileTypes:true})){const name=join(dir,ent.name);if(ent.isDirectory())scan(name);else if(/\.(jsx?|tsx?)$/.test(name))files.push(name);}}
for(const dir of ['src','packages','tests','tools'])scan(dir);
let errors=0;const check=(name,code)=>{const kind=name.endsWith('.tsx')?ts.ScriptKind.TSX:name.endsWith('.jsx')?ts.ScriptKind.JSX:name.endsWith('.ts')?ts.ScriptKind.TS:ts.ScriptKind.JS;
const parsed=ts.createSourceFile(name,code,ts.ScriptTarget.Latest,true,kind);
for(const diagnostic of parsed.parseDiagnostics){console.error(`${name}: ${ts.flattenDiagnosticMessageText(diagnostic.messageText,' ')}`);errors++;}};
for(const file of files)check(file,readFileSync(file,'utf8'));
const r=createDefaultRegistry(),lego=createLegoExampleDocument(r),slots=createSlotExampleDocument(r);
for(const [name,doc] of [['CustomerBrowser',lego],['SearchCard',slots],['SlotPanel',slots]])check(`generated/${name}.tsx`,generateComponentSource(doc,r,name));
console.log(`Syntax: ${files.length} source files + 3 generated TSX; errors=${errors}`);
if(errors)process.exitCode=1;

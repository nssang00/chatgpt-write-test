/** JSX runtime integration test without browser or AntD; requires TypeScript transpiler.
 * It executes the actual packages/runtime-react/Runtime.jsx with a deterministic test renderer.
 */
import {readFileSync,realpathSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {literal} from '../packages/schema/index.js';
import {repeatEntries,iterationScope,readProperty,subscribeProperty} from '../packages/core/dynamic.js';
import {createDefaultRegistry,createSlotExampleDocument,createDynamicExampleDocument,exposeDefinitionProperty,createComponentExportDocument,createComponentDefinition,createEditorNode,insertEditorNode,RuntimeSession,instancePropertyProviders,projectNestedInstance,slotNodes,frameStyle,matchesPublicEvent,controlProperty,setControlProperty} from '../packages/core/index.js';
let ts;
try {ts=createRequire(import.meta.url)('typescript');}
catch {
  try {const tsc=realpathSync(execFileSync('which',['tsc'],{encoding:'utf8'}).trim());ts=createRequire(import.meta.url)(resolve(dirname(tsc),'../lib/typescript.js'));}
  catch {throw Error('TypeScript가 필요합니다: npm install 후 실행하세요');}
}
const src=readFileSync(new URL('../packages/runtime-react/Runtime.jsx',import.meta.url),'utf8');
const compiled=ts.transpileModule(src,{compilerOptions:{jsx:ts.JsxEmit.React,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
const body=compiled.replace(/^import .*?;\s*$/gm,'').replace(/^export /gm,'');
const React={Fragment:'fragment',useCallback:fn=>fn,useSyncExternalStore:(_subscribe,snapshot)=>snapshot(),createElement:(type,props,...children)=>{const all={...props,children:children.flat().filter(x=>x!==null&&x!==undefined&&x!==false)};return typeof type==='function'?type(all):{type,props:all};}};
const {RuntimeView}=Function('React','frameStyle','matchesPublicEvent','instancePropertyProviders','projectNestedInstance','slotNodes','literal','repeatEntries','iterationScope','readProperty','subscribeProperty',body+'\nreturn {RuntimeView}')(React,frameStyle,matchesPublicEvent,instancePropertyProviders,projectNestedInstance,slotNodes,literal,repeatEntries,iterationScope,readProperty,subscribeProperty);
const registry=createDefaultRegistry(),doc=createSlotExampleDocument(registry),session=new RuntimeSession(doc),logs=[];
const renderer={get:type=>props=>({type:'mock-control',props:{...props,type,text:type==='core/Text'?controlProperty(props.node,'text',registry,props.scope,props.overrides,{}):null,value:type==='core/Input'?controlProperty(props.node,'value',registry,props.scope,props.overrides,{}):null,color:type==='core/Button'?controlProperty(props.node,'color',registry,props.scope,props.overrides,{}):null}})};
function mount(){const tree=RuntimeView({document:doc,session,registry,renderer,onPublicEvent:(...args)=>logs.push(args)}),inputs=[],buttons=[];
  const walk=n=>{if(!n||typeof n!=='object')return;if(n.type==='mock-control'){
    if(n.props.type==='core/Input')inputs.push(n.props);
    if(n.props.type==='core/Button')buttons.push(n.props);
  }for(const c of n.props?.children||[])walk(c);};walk(tree);return {inputs,buttons};}
let {inputs,buttons}=mount();assert.equal(inputs.length,2);assert.equal(buttons.length,2);
setControlProperty(inputs[0].node,'value','CUSTOMER',registry,inputs[0].scope,inputs[0].overrides);
assert.equal(session.state.get(['customer','keyword']),'CUSTOMER');assert.equal(session.state.get(['product','keyword']),'');
({inputs,buttons}=mount());assert.equal(inputs[0].value,'CUSTOMER');assert.equal(inputs[1].value,'');
setControlProperty(inputs[1].node,'value','PRODUCT',registry,inputs[1].scope,inputs[1].overrides);
assert.equal(session.state.get(['customer','keyword']),'CUSTOMER');assert.equal(session.state.get(['product','keyword']),'PRODUCT');
buttons[0].onEmit('click',{});
assert.equal(logs.filter(([id,event])=>id==='slotCustomer'&&event==='search').length,1);
console.log('PASS JSX Runtime + mock controls: two independent slotted SearchCard instances, TwoWay state, one public event');
console.log(JSON.stringify({customer:session.state.get(['customer','keyword']),product:session.state.get(['product','keyword']),events:logs.filter(([id])=>id==='slotCustomer').length}));

const isolated=createComponentExportDocument(doc,'SlotPanel',registry);
const fallback=RuntimeView({document:isolated,session:new RuntimeSession(isolated),registry,renderer});
let fallbackCount=0;function tally(node){if(!node||typeof node!=='object')return;if(node.type==='mock-control')fallbackCount++;for(const child of node.props?.children||[])tally(child);}
tally(fallback);assert.equal(fallbackCount,1,'unfilled slots must show Definition fallback');
const injected={type:'external-user-child',props:{name:'customReactNode'}};
const external=RuntimeView({document:isolated,session:new RuntimeSession(isolated),registry,renderer,externalSlots:{content:injected}});
let externalCount=0;function tallyExternal(node){if(!node||typeof node!=='object')return;if(node.type==='external-user-child')externalCount++;for(const child of node.props?.children||[])tallyExternal(child);}
tallyExternal(external);assert.equal(externalCount,1,'exported component must accept React children slot');
console.log('PASS React export slot: fallback content and external React children both render');

let colorDoc=createComponentDefinition(doc,'ColorPanel',registry);
const buttonNode=createEditorNode(colorDoc,'core/Button',registry);
colorDoc=insertEditorNode(colorDoc,colorDoc.definitions.ColorPanel.root.id,0,buttonNode,registry,'definition:ColorPanel');
colorDoc=exposeDefinitionProperty(colorDoc,'ColorPanel',buttonNode.id,'color','color',registry);
const colorExport=createComponentExportDocument(colorDoc,'ColorPanel',registry);
const changed=RuntimeView({document:colorExport,session:new RuntimeSession(colorExport),registry,renderer,externalProps:{color:'#ff00aa'}});
let colors=[];function colorsOf(n){if(!n||typeof n!=='object')return;if(n.type==='mock-control'&&n.props.type==='core/Button')colors.push(n.props.color);for(const c of n.props?.children||[])colorsOf(c);}
colorsOf(changed);assert.deepEqual(colors,['#ff00aa']);
console.log('PASS non-bindable public React prop: external color replaces Definition default');

// Conditional + Repeat through actual JSX Runtime, including React useSyncExternalStore
// subscription path and a parent-state list update across deterministic renders.
const dynamicDoc=createDynamicExampleDocument(registry);
function renderedText(dynamic,runSession){
  const view=RuntimeView({document:dynamic,session:runSession,registry,renderer});
  const result=[];
  const visit=n=>{if(!n||typeof n!=='object')return;if(n.type==='mock-control'&&n.props.type==='core/Text')result.push(n.props.text);
    for(const child of n.props?.children||[])visit(child);};
  visit(view);return result;
}
assert.deepEqual(renderedText(dynamicDoc,new RuntimeSession(dynamicDoc)),['Reusable items','Customer A','Product B']);
// State-driven Repeat is the same behavior the portable React public array prop uses.
const stateDoc=structuredClone(dynamicDoc);
delete stateDoc.pages.main.root.children[0].props.items;
stateDoc.pages.main.root.children[0].bindings={items:{kind:'binding',source:'state',path:['runtime','items'],mode:'OneWay'}};
stateDoc.data.state.runtime={items:[{id:'one',label:'First',visible:true}]};
const liveSession=new RuntimeSession(stateDoc);
assert.deepEqual(renderedText(stateDoc,liveSession),['Reusable items','First','Product B']);
liveSession.state.set(['runtime','items'],[{id:'two',label:'Updated',visible:true},{id:'three',label:'Hidden',visible:false}]);
assert.deepEqual(renderedText(stateDoc,liveSession),['Reusable items','Updated','Product B']);
console.log('PASS dynamic JSX Runtime: two reusable ItemList instances, per-item when, reactive Repeat state update');

// A Definition containing another dynamic UserControl can republish its array
// without copying children or exposing internal Control paths.
let galleryDoc=createComponentDefinition(dynamicDoc,'ItemGallery',registry);
const galleryItem=createEditorNode(galleryDoc,'module/ItemList',registry);
galleryDoc=insertEditorNode(galleryDoc,galleryDoc.definitions.ItemGallery.root.id,0,galleryItem,registry,'definition:ItemGallery');
galleryDoc=exposeDefinitionProperty(galleryDoc,'ItemGallery',galleryItem.id,'items','entries',registry);
galleryDoc.pages.main.root.children=[{id:'galleryHost',kind:'instance',definitionId:'ItemGallery',
  props:{entries:literal([{id:'nested',label:'Nested UserControl',visible:true}])},bindings:{},overrides:{}}];
assert.deepEqual(renderedText(galleryDoc,new RuntimeSession(galleryDoc)),['Reusable items','Nested UserControl']);
console.log('PASS nested lego UserControl: published array forwarded from ItemGallery to ItemList to dynamic Text');

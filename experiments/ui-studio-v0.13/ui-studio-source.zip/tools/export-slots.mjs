/** Standalone named-slot assembly export without npm or browser dependencies. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createDefaultRegistry,createSlotExampleDocument,componentDependencies} from '../packages/core/index.js';
import {createPortablePackageFiles} from '../packages/exporter-react/component-package.js';
import {encodeZip} from '../packages/exporter-react/zip.js';
import {serializeDocument} from '../packages/schema/index.js';
const names=['schema/index.js','runtime-react/Runtime.jsx','renderer-antd/index.jsx',
  ...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic'].map(n=>'core/'+n+'.js')];
const sources=Object.fromEntries(names.map(n=>['packages/'+n,readFileSync('packages/'+n,'utf8')]));
const registry=createDefaultRegistry(),doc=createSlotExampleDocument(registry),id='SearchCard';
const closure=componentDependencies(doc,id,registry);
if(closure.length!==3||!['SearchBox','SlotPanel','SearchCard'].every(n=>closure.includes(n)))throw Error('잘못된 Definition 의존 관계');
mkdirSync('examples',{recursive:true});
writeFileSync('examples/slot-composition-v0.11.json',serializeDocument(doc,registry)+'\n');
const files=createPortablePackageFiles(doc,registry,id,sources);
writeFileSync('examples/SearchCard-component.zip',encodeZip(files));
const panelFiles=createPortablePackageFiles(doc,registry,'SlotPanel',sources);
writeFileSync('examples/SlotPanel-component.zip',encodeZip(panelFiles));
writeFileSync('examples/SlotPanel-usage.tsx',`import { SlotPanel } from 'ui-studio-slot-panel';
export default function Demo(){return <SlotPanel><button onClick={()=>alert('clicked')}>사용자 버튼</button></SlotPanel>;}
`);
console.log(`Exported ${id} with ${closure.join(', ')}; ${Object.keys(files).length} ZIP entries`);
console.log(`Exported SlotPanel (public children ReactNode slot); ${Object.keys(panelFiles).length} ZIP entries`);

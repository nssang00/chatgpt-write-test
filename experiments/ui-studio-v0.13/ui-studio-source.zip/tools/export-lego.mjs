/** Reproducible offline component export without a browser. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createDefaultRegistry,createLegoExampleDocument} from '../packages/core/index.js';
import {createPortablePackageFiles} from '../packages/exporter-react/component-package.js';
import {encodeZip} from '../packages/exporter-react/zip.js';
const names=['schema/index.js','runtime-react/Runtime.jsx','renderer-antd/index.jsx',
  ...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic'].map(x=>'core/'+x+'.js')];
const sources=Object.fromEntries(names.map(n=>['packages/'+n,readFileSync('packages/'+n,'utf8')]));
const registry=createDefaultRegistry(),doc=createLegoExampleDocument(registry),id='CustomerBrowser';
mkdirSync('examples',{recursive:true});
writeFileSync('examples/lego-component-v0.10.json',JSON.stringify(doc,null,2)+'\n');
const files=createPortablePackageFiles(doc,registry,id,sources);
writeFileSync('examples/CustomerBrowser-component.zip',encodeZip(files));
console.log(`Exported ${Object.keys(files).length} source files / ${id}`);

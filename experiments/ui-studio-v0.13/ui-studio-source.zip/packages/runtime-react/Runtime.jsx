import React from 'react';
import {frameStyle} from '../core/layout.js';
import {matchesPublicEvent} from '../core/events.js';
import {instancePropertyProviders,projectNestedInstance} from '../core/components.js';
import {slotNodes} from '../core/slots.js';
import {literal} from '../schema/index.js';
import {repeatEntries,iterationScope,readProperty,subscribeProperty} from '../core/dynamic.js';

/** Structural behaviors are separate React components, so hooks are unconditional
 * within each hook-owning component, even when users change node kinds. */
function useDynamicProvider(provider,scope,resources){
  const subscribe=React.useCallback(fn=>subscribeProperty(provider,scope,fn),[provider,scope]);
  const snapshot=React.useCallback(()=>readProperty(provider,scope,resources),[provider,scope,resources]);
  return React.useSyncExternalStore(subscribe,snapshot,snapshot);
}
function ConditionalNode(props){
  const visible=useDynamicProvider(props.node.when,props.scope,props.document.resources||{});
  return visible===true?<RuntimeNode {...props} node={{...props.node,when:undefined}}/>:null;
}
function RepeatNode(props){
  const items=useDynamicProvider(props.node.repeat.items,props.scope,props.document.resources||{});
  const entries=repeatEntries(items,props.node.repeat.keyPath||[]);
  return <React.Fragment>{entries.map(({item,index,key})=><RuntimeNode
    {...props} key={key} node={{...props.node,repeat:undefined}}
    scope={iterationScope(props.scope,item,index)}
    path={`${props.path||'main'}/repeat:${encodeURIComponent(key)}`}
    depth={(props.depth||0)+1}/>)}</React.Fragment>;
}
/** React is the thin host; runtime behavior stays in Core. */
export function RuntimeNode({node,document,session,registry,renderer,scope,onPublicEvent,path='main',overrides={},slotFills={},externalSlots=null,externalProps=null,onEmit=()=>{},depth=0}){
  if(depth>32)return <span>Maximum module depth exceeded</span>;
  if(node.repeat)return <RepeatNode {...{node,document,session,registry,renderer,scope,onPublicEvent,path,overrides,slotFills,externalSlots,externalProps,onEmit,depth}}/>;
  if(node.when)return <ConditionalNode {...{node,document,session,registry,renderer,scope,onPublicEvent,path,overrides,slotFills,externalSlots,externalProps,onEmit,depth}}/>;
  if(node.kind==='frame'){
    const fill=slotFills[node.id];
    if(fill?.hasExternalContent)return <div data-core-node={node.id} style={{...frameStyle(node.layout),...node.size}}>{fill.externalContent}</div>;
    const children=fill?fill.nodes:node.children;
    const childScope=fill?fill.scope:scope;
    const childEmit=fill?fill.onEmit:onEmit;
    const childOverrides=fill?fill.overrides:overrides;
    const childFills=fill?{}:slotFills;
    return <div data-core-node={node.id} style={{...frameStyle(node.layout),...node.size}}>{children.map(child=>{
      const rendered=<RuntimeNode key={child.id} node={child} document={document} session={session} registry={registry} renderer={renderer} scope={childScope} onPublicEvent={onPublicEvent} path={`${path}/${fill?'slot:'+fill.name+'/':''}${child.id}`} overrides={childOverrides} slotFills={childFills} externalSlots={externalSlots} externalProps={externalProps} onEmit={childEmit} depth={depth+1}/>;
      return node.layout.type==='overlay'?<div key={child.id} style={{gridArea:'1 / 1'}}>{rendered}</div>:rendered;
    })}</div>;
  }
  if(node.kind==='instance'){
    const definition=document.definitions[node.definitionId];
    if(!definition)return <span>Missing Definition: {node.definitionId}</span>;
    let effective=projectNestedInstance(node,overrides);
    // A non-bindable public property is still a valid ordinary React prop.
    // Its value is delivered as an Instance literal instead of a Store binding.
    if(node.id==='exportInstance'&&externalProps){
      const props={...effective.props};
      for(const [name,value] of Object.entries(externalProps)){
        if(Object.hasOwn(definition.publicProps||{},name)&&!definition.publicProps[name].bindable)props[name]=literal(value);
      }
      effective={...effective,props};
    }
    const {scope:childScope,propsStore}=session.instanceScope(effective,definition,scope,path);
    const emit=(name,payload,sourceNodeId,sourceEvent)=>{
      if(!matchesPublicEvent(definition,name,sourceNodeId,sourceEvent))return;
      const details={...payload,value:propsStore.get(['value'])};
      onPublicEvent?.(node.id,name,details);
      onEmit(name,details,node.id,name);
    };
    const childSlotFills={};
    for(const [name,spec] of Object.entries(definition.slots||{})){
      const resolved=slotNodes(definition,effective,spec.nodeId);
      if(node.id==='exportInstance'&&externalSlots&&Object.hasOwn(externalSlots,name))childSlotFills[spec.nodeId]={name,hasExternalContent:true,externalContent:externalSlots[name]};
      else if(resolved.filled)childSlotFills[spec.nodeId]={name,nodes:resolved.nodes,scope,onEmit,overrides};
    }
    return <div data-core-instance={node.id} style={{minWidth:0,...node.size}}><RuntimeNode node={definition.root} document={document} session={session} registry={registry} renderer={renderer} scope={childScope} onPublicEvent={onPublicEvent} path={`${path}/${definition.id}`} overrides={instancePropertyProviders(definition,effective)} slotFills={childSlotFills} onEmit={emit} depth={depth+1}/></div>;
  }
  const Control=renderer.get(node.typeId);
  if(!Control)return <div className="core-unknown">미지원 렌더러: {node.typeId}</div>;
  const control=<Control node={node} registry={registry} scope={scope} overrides={overrides} resources={document.resources||{}} onEmit={(event,payload)=>{
    const action=node.events?.[event];if(action?.kind==='emit')onEmit(action.event,payload,node.id,event);
  }}/>;
  return node.size?<div style={{...node.size,minWidth:0}}>{control}</div>:control;
}
export function RuntimeView({document,pageId='main',session,registry,renderer,onPublicEvent,externalSlots=null,externalProps=null}){
  const page=document.pages[pageId];if(!page)return <div>Page not found: {pageId}</div>;
  return <RuntimeNode node={page.root} document={document} session={session} registry={registry} renderer={renderer} scope={session.rootScope()} onPublicEvent={onPublicEvent} externalSlots={externalSlots} externalProps={externalProps}/>;
}

import React, {useCallback, useSyncExternalStore, useState} from 'react';
import {Input, Button, Checkbox, Typography, Select, Table, Card, Divider, Tag} from 'antd';
import {controlProperty,subscribeControlProperty,propertyProvider,setControlProperty} from '../core/properties.js';
/** UI framework details exist only in the adapter. */
export class ReactRendererRegistry {
  #renderers=new Map();
  register(typeId,control){if(this.#renderers.has(typeId))throw Error(`Duplicate renderer: ${typeId}`);this.#renderers.set(typeId,control);}
  get(typeId){return this.#renderers.get(typeId);}
}
function useValue({node,registry,scope,overrides,resources},key){
  const subscribe=useCallback(fn=>subscribeControlProperty(node,key,registry,scope,overrides,fn),[node,key,registry,scope,overrides]);
  const snapshot=useCallback(()=>controlProperty(node,key,registry,scope,overrides,resources),[node,key,registry,scope,overrides,resources]);
  return useSyncExternalStore(subscribe,snapshot,snapshot);
}
function InputControl(props){
  const {node,registry,scope,overrides}=props;
  const value=useValue(props,'value'),placeholder=useValue(props,'placeholder'),disabled=useValue(props,'disabled');
  const provider=propertyProvider(node,'value',registry,overrides);
  const deferred=provider.kind==='binding' && provider.updateOn==='blur';
  const [draft,setDraft]=useState(null);
  const change=v=>{if(deferred){setDraft(v);return;}if(provider.kind==='binding'&&provider.mode==='TwoWay')setControlProperty(node,'value',v,registry,scope,overrides);else if(provider.kind!=='binding')setDraft(v);};
  return <Input data-control-id={node.id} aria-label={placeholder||'Input'} placeholder={placeholder||''} disabled={!!disabled} readOnly={provider.kind==='binding'&&provider.mode==='OneWay'} value={draft===null?String(value??''):draft} onChange={e=>change(e.target.value)} onBlur={()=>{if(deferred&&draft!==null){setControlProperty(node,'value',draft,registry,scope,overrides,'blur');setDraft(null);}}}/>;
}
function ButtonControl(props){
  const text=useValue(props,'text'),variant=useValue(props,'variant'),color=useValue(props,'color'),disabled=useValue(props,'disabled');
  return <Button data-control-id={props.node.id} type={variant==='primary'?'primary':'default'} disabled={!!disabled} style={variant==='primary'?{backgroundColor:color,borderColor:color}:undefined} onClick={()=>props.onEmit('click',{})}>{String(text??'버튼')}</Button>;
}
function TextControl(props){const text=useValue(props,'text'),weight=useValue(props,'weight');return weight==='heading'?<Typography.Title level={4} data-control-id={props.node.id}>{String(text??'')}</Typography.Title>:<Typography.Text data-control-id={props.node.id}>{String(text??'')}</Typography.Text>;}
function CheckboxControl(props){
  const checked=useValue(props,'checked'),text=useValue(props,'text'),disabled=useValue(props,'disabled');
  const {node,registry,scope,overrides}=props;
  const provider=propertyProvider(node,'checked',registry,overrides);
  const [draft,setDraft]=useState(null);
  return <Checkbox data-control-id={node.id} disabled={!!disabled||(provider.kind==='binding'&&provider.mode==='OneWay')} checked={draft??!!checked} onChange={e=>{if(provider.kind==='binding')setControlProperty(node,'checked',e.target.checked,registry,scope,overrides);else setDraft(e.target.checked);}}>{String(text??'')}</Checkbox>;
}
function SelectControl(props){
  const optionsText=useValue(props,'options'),value=useValue(props,'value'),label=useValue(props,'label');
  const {node,registry,scope,overrides}=props;
  const provider=propertyProvider(node,'value',registry,overrides);
  const [draft,setDraft]=useState(undefined);
  let options=[];
  try {const parsed=JSON.parse(optionsText||'[]');if(Array.isArray(parsed))options=parsed.map(x=>typeof x==='string'?{label:x,value:x}:x).filter(x=>x&&Object.hasOwn(x,'value'));}
  catch {options=String(optionsText||'').split(',').map(v=>v.trim()).filter(Boolean).map(v=>({label:v,value:v}));}
  return <Select data-control-id={node.id} style={{minWidth:125,width:'100%'}} aria-label={label||'Select'} placeholder={label||'선택'} options={options} value={draft??value??undefined} disabled={provider.kind==='binding'&&provider.mode==='OneWay'} onChange={v=>{if(provider.kind==='binding')setControlProperty(node,'value',v,registry,scope,overrides);else setDraft(v);}}/>;
}
function TableControl(props){
  const title=useValue(props,'title'),rows=useValue(props,'dataSource'),columnsText=useValue(props,'columns');
  const safeRows=Array.isArray(rows)?rows:[];
  let cols=[];
  try {const parsed=JSON.parse(columnsText||'[]');if(Array.isArray(parsed))cols=parsed.filter(x=>typeof x?.dataIndex==='string'&&typeof x?.title==='string');}catch{}
  if(!cols.length&&safeRows.length&&safeRows[0]&&typeof safeRows[0]==='object')cols=Object.keys(safeRows[0]).slice(0,12).map(k=>({title:k,dataIndex:k,key:k}));
  return <div data-control-id={props.node.id} style={{minWidth:180,width:'100%'}}>{title&&<Typography.Text strong>{title}</Typography.Text>}<Table size="small" pagination={false} rowKey={(_,i)=>i} dataSource={safeRows} columns={cols}/></div>;
}
function CardControl(props){const title=useValue(props,'title'),description=useValue(props,'description');return <Card data-control-id={props.node.id} title={title||undefined} size="small">{String(description??'')}</Card>;}
function DividerControl(props){return <Divider data-control-id={props.node.id}/>;}
function TagControl(props){const text=useValue(props,'text'),color=useValue(props,'color');return <Tag data-control-id={props.node.id} color={color}>{String(text??'')}</Tag>;}
export function createAntdRenderer(){
  const renderer=new ReactRendererRegistry();
  renderer.register('core/Input',InputControl);renderer.register('core/Button',ButtonControl);
  renderer.register('core/Text',TextControl);renderer.register('core/Checkbox',CheckboxControl);
  renderer.register('core/Select',SelectControl);renderer.register('core/Table',TableControl);renderer.register('core/Card',CardControl);renderer.register('core/Divider',DividerControl);renderer.register('core/Tag',TagControl);
  return renderer;
}

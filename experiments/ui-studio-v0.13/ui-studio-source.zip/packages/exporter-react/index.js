/** Runtime-backed TSX output. Imports the same Core/Renderer as Studio Preview.
 * For the standalone generated file, place it at the project root alongside packages/.
 */
import {serializeDocument} from '../schema/index.js';
export function generateRuntimeTsx(document,registry,{runtimePrefix='./packages',exportName='GeneratedPageV6'}={}){
  if(!/^\.[./A-Za-z0-9_-]+$/.test(runtimePrefix))throw Error('안전한 상대 경로가 필요합니다');
  if(!/^[A-Z][A-Za-z0-9_]*$/.test(exportName))throw Error('올바른 React 컴포넌트 이름이 필요합니다');
  const encoded=JSON.stringify(serializeDocument(document,registry));
  return `/** UI Studio · Canonical JSON IR v6 · Runtime-backed React/AntD export.
 * Requires the packages/schema, packages/core, packages/runtime-react and
 * packages/renderer-antd directories from this UI Studio source project.
 * This export uses the exact same binding and component semantics as Preview.
 */
import React, { useState } from 'react';
import { RuntimeSession, createDefaultRegistry } from '${runtimePrefix}/core/index.js';
import { RuntimeView } from '${runtimePrefix}/runtime-react/Runtime.jsx';
import { createAntdRenderer } from '${runtimePrefix}/renderer-antd/index.jsx';

const document = JSON.parse(${encoded});
const registry = createDefaultRegistry();
const renderer = createAntdRenderer();

export default function ${exportName}() {
  const [session] = useState(() => new RuntimeSession(document));
  return <RuntimeView document={document} session={session} registry={registry} renderer={renderer} />;
}
`;
}

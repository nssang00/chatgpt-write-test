/** Declarative structural behavior shared by Runtime and tests. No React dependency. */
import {getPath} from './store.js';
import {readProperty,subscribeProperty} from './binding.js';

/** The binding to a repeated collection is always read-only. Each iteration gets
 * its own context.item/context.index, with context.parent for nested loops.
 * When a user-supplied key is missing or repeated, fall back to its index.
 */
export function repeatEntries(items,keyPath=[]){
  if(!Array.isArray(items))return [];
  const seen=new Set();
  return items.map((item,index)=>{
    let raw;
    if(keyPath.length && item!==null && typeof item==='object')raw=getPath(item,keyPath);
    const valid=typeof raw==='string'||typeof raw==='number';
    const candidate=valid?`${typeof raw}:${raw}`:null;
    const key=candidate&&!seen.has(candidate)?candidate:`index:${index}`;
    seen.add(key);if(candidate)seen.add(candidate);
    return {item,index,key};
  });
}
export function iterationScope(parent,item,index){
  const previous=parent.resolve('context')?.get(['item']);
  const data={item,index,parent:previous};
  const contextStore={
    get:path=>getPath(data,path),
    set:()=>{throw Error('반복 항목 context는 읽기 전용입니다. 원본 상태를 변경하세요.');},
    subscribe:()=>()=>{}
  };
  return parent.child({context:contextStore});
}
export {readProperty,subscribeProperty};

import {validateDocument, literal, binding, walkNodes,createSearchBoxDocument} from '../schema/index.js';
import {allocateNodeId,createEditorNode,insertEditorNode,exposeDefinitionProperty,exposeDefinitionEvent,addDefinitionProperty} from './editor.js';
import {exposeDefinitionSlot,insertSlotChild} from './slots.js';

const COMPONENT_ID=/^[A-Z][a-zA-Z0-9_]{0,63}$/;
/** Make a blank reusable component; the page is only a test harness. */
export function createComponentDefinition(doc,name,registry){
  if(!COMPONENT_ID.test(name))throw Error('컴포넌트 이름은 영문 대문자로 시작해야 합니다');
  if(Object.hasOwn(doc.definitions,name))throw Error(`이미 있는 컴포넌트: ${name}`);
  const next=structuredClone(doc);
  const id=allocateNodeId(next,'componentRoot');
  next.definitions[name]={id:name,name,version:'1.0.0',revision:1,
    root:{id,kind:'frame',name,layout:{type:'column',gap:8,padding:8},children:[]},
    publicProps:{},publicEvents:{},overridePolicy:{}};
  return validateDocument(next,registry);
}
/** Component-first document: an empty component is the project, and Page is only a preview harness. */
export function createBlankComponentWorkspace(name,registry){
  const seed=createSearchBoxDocument();
  const doc={...seed,title:`${name} · Component Workspace`,definitions:{},pages:{
    main:{id:'main',name:'Preview Harness',root:{id:'previewWorkspaceRoot',kind:'frame',name:'Preview Harness',layout:{type:'column',gap:12,padding:12},children:[]}}
  },data:{state:{},sources:{}},resources:{}};
  return createComponentDefinition(doc,name,registry);
}
/** Add a Definition by reference to a Page preview, without duplicating its tree. */
export function addComponentToPreview(doc,definitionId,registry){
  if(!doc.definitions[definitionId])throw Error(`없는 컴포넌트: ${definitionId}`);
  const next=structuredClone(doc);
  const def=next.definitions[definitionId];
  const instance={id:allocateNodeId(next,'preview'),kind:'instance',name:definitionId,definitionId,
    props:Object.fromEntries(Object.entries(def.publicProps||{}).map(([key,spec])=>[key,literal(structuredClone(spec.defaultValue??null))])),
    bindings:{},overrides:{}};
  next.pages.main.root.children.push(instance);
  return validateDocument(next,registry);
}
/** Reverse references are useful when navigating Lego components in the designer. */
export function componentUsage(doc,definitionId,registry){
  validateDocument(doc,registry);
  if(!doc.definitions[definitionId])throw Error('없는 사용자 컴포넌트');
  const usage=[];
  for(const [owner,def] of Object.entries(doc.definitions))walkNodes(def.root,node=>{
    if(node.kind==='instance'&&node.definitionId===definitionId)usage.push({owner:`definition:${owner}`,instanceId:node.id});
  });
  for(const [owner,page] of Object.entries(doc.pages))walkNodes(page.root,node=>{
    if(node.kind==='instance'&&node.definitionId===definitionId)usage.push({owner:`page:${owner}`,instanceId:node.id});
  });
  return usage;
}
/** Return referenced definitions in dependency-first order; never copy per instance. */
export function componentDependencies(doc,entryId,registry){
  validateDocument(doc,registry);
  if(!Object.hasOwn(doc.definitions,entryId))throw Error(`없는 컴포넌트: ${entryId}`);
  const output=[],visited=new Set();
  function visit(id){
    if(visited.has(id))return;
    visited.add(id);
    walkNodes(doc.definitions[id].root,node=>{if(node.kind==='instance')visit(node.definitionId);});
    output.push(id);
  }
  visit(entryId);return output;
}
/** Isolate a component and its transitive subcomponents from unrelated demo pages. */
export function createComponentExportDocument(doc,entryId,registry){
  const deps=componentDependencies(doc,entryId,registry),definition=doc.definitions[entryId];
  const providers={},values={},staticProps={};
  for(const [key,spec] of Object.entries(definition.publicProps||{})){
    if(spec.bindable){
      providers[key]=binding('state',['__component',key],spec.twoWay?'TwoWay':'OneWay');
      values[key]=structuredClone(spec.defaultValue??null);
    }else staticProps[key]=literal(structuredClone(spec.defaultValue??null));
  }
  const exported={format:'ui-studio',schemaVersion:6,title:entryId,
    pages:{main:{id:'main',name:`${entryId} preview`,root:{id:'exportRoot',kind:'frame',layout:{type:'column',gap:0,padding:0},children:[
      {id:'exportInstance',kind:'instance',definitionId:entryId,name:entryId,props:staticProps,bindings:providers,overrides:{}}
    ]}}},definitions:Object.fromEntries(deps.map(id=>[id,structuredClone(doc.definitions[id])])),
    data:{state:{__component:values},sources:{}},resources:structuredClone(doc.resources||{})};
  // Do not silently turn demo/host state or API bindings into external dependencies.
  for(const id of deps){
    walkNodes(doc.definitions[id].root,node=>{
      if(node.dataContext?.source && ['state','sources','context'].includes(node.dataContext.source)){
        throw Error(`${id}: 외부 DataContext 참조가 있습니다. 공개 Props/local로 전환하세요.`);
      }
      const allProviders=[node.when,node.repeat?.items,...Object.values(node.props||{}),...Object.values(node.bindings||{}),
        ...Object.values(node.overrides||{}).flatMap(item=>Object.values(item||{}))];
      if(allProviders.some(p=>p?.kind==='binding'&&['state','sources'].includes(p.source) || p?.kind==='binding'&&p.source==='context'&&p.path[0]!=='item'&&p.path[0]!=='index'&&p.path[0]!=='parent')){
        throw Error(`${id}: 외부 state/sources/context 참조가 있습니다. 컴포넌트 공개 Props/local 바인딩으로 변환하세요.`);
      }
    });
  }
  return validateDocument(exported,registry);
}
/** Embed a preview instance with its public defaults, never a cloned definition tree. */
export function createDefinitionPreviewDocument(doc,entryId,registry){
  const next=structuredClone(doc),def=next.definitions[entryId];
  if(!def)throw Error(`없는 컴포넌트: ${entryId}`);
  next.pages.main.root={id:'previewRoot',kind:'frame',name:`${entryId} Preview`,layout:{type:'column',gap:0,padding:16},children:[
    {id:'previewInstance',kind:'instance',name:entryId,definitionId:entryId,props:Object.fromEntries(Object.entries(def.publicProps||{}).map(([key,p])=>[key,literal(p.defaultValue??null)])),bindings:{},overrides:{}}
  ]};
  return validateDocument(next,registry);
}

/** Ready-to-edit Lego demo: each level is a separate, referenced Definition. */
export function createLegoExampleDocument(registry){
  // Late bindings are only used for sample assembly; Core remains independent from React.
  let doc=createSearchBoxDocument();
  doc=createComponentDefinition(doc,'FilterBar',registry);
  const filterRoot=doc.definitions.FilterBar.root.id;
  const search=createEditorNode(doc,'module/SearchBox',registry);
  doc=insertEditorNode(doc,filterRoot,0,search,registry,'definition:FilterBar');
  const select=createEditorNode(doc,'core/Select',registry);
  doc=insertEditorNode(doc,filterRoot,1,select,registry,'definition:FilterBar');
  doc=exposeDefinitionProperty(doc,'FilterBar',search.id,'value','keyword',registry);
  doc=exposeDefinitionProperty(doc,'FilterBar',search.id,'placeholder','placeholder',registry);
  doc=exposeDefinitionEvent(doc,'FilterBar',search.id,'search','search',registry);
  doc=createComponentDefinition(doc,'CustomerBrowser',registry);
  const browserRoot=doc.definitions.CustomerBrowser.root.id;
  const filter=createEditorNode(doc,'module/FilterBar',registry);
  doc=insertEditorNode(doc,browserRoot,0,filter,registry,'definition:CustomerBrowser');
  const table=createEditorNode(doc,'core/Table',registry);
  doc=insertEditorNode(doc,browserRoot,1,table,registry,'definition:CustomerBrowser');
  doc=exposeDefinitionProperty(doc,'CustomerBrowser',filter.id,'keyword','value',registry);
  doc=exposeDefinitionProperty(doc,'CustomerBrowser',filter.id,'placeholder','placeholder',registry);
  doc=exposeDefinitionEvent(doc,'CustomerBrowser',filter.id,'search','search',registry);
  const next=structuredClone(doc);
  next.title='LEGO · SearchBox → FilterBar → CustomerBrowser';
  next.pages.main.root.children=[
    {id:'browserCustomer',kind:'instance',name:'고객 검색 브라우저',definitionId:'CustomerBrowser',props:{placeholder:literal('고객명 검색')},bindings:{value:binding('state',['customer','keyword'],'TwoWay')},overrides:{}},
    {id:'browserProduct',kind:'instance',name:'상품 검색 브라우저',definitionId:'CustomerBrowser',props:{placeholder:literal('상품명 검색')},bindings:{value:binding('state',['product','keyword'],'TwoWay')},overrides:{}}
  ];
  return validateDocument(next,registry);
}

/** Slot composition example: SearchBox is inserted into SlotPanel through SearchCard.
 * SearchCard re-exports the slotted SearchBox's public API without copying its Definition.
 */
export function createSlotExampleDocument(registry){
  let doc=createSearchBoxDocument();
  doc=createComponentDefinition(doc,'SlotPanel',registry);
  const target=createEditorNode(doc,'layout/column',registry);
  doc=insertEditorNode(doc,doc.definitions.SlotPanel.root.id,0,target,registry,'definition:SlotPanel');
  const fallback=createEditorNode(doc,'core/Text',registry);
  fallback.props.text=literal('여기에 컴포넌트를 삽입하세요');
  doc=insertEditorNode(doc,target.id,0,fallback,registry,'definition:SlotPanel');
  doc=exposeDefinitionSlot(doc,'SlotPanel',target.id,'content',registry);
  doc=createComponentDefinition(doc,'SearchCard',registry);
  const panel=createEditorNode(doc,'module/SlotPanel',registry);
  doc=insertEditorNode(doc,doc.definitions.SearchCard.root.id,0,panel,registry,'definition:SearchCard');
  const search=createEditorNode(doc,'module/SearchBox',registry);
  doc=insertSlotChild(doc,panel.id,'content',0,search,registry,'definition:SearchCard');
  doc=exposeDefinitionProperty(doc,'SearchCard',search.id,'value','value',registry);
  doc=exposeDefinitionProperty(doc,'SearchCard',search.id,'placeholder','placeholder',registry);
  doc=exposeDefinitionEvent(doc,'SearchCard',search.id,'search','search',registry);
  const next=structuredClone(doc);next.title='Slots · SearchBox inside SlotPanel';
  next.pages.main.root.children=[
    {id:'slotCustomer',kind:'instance',definitionId:'SearchCard',name:'고객 SearchCard',props:{placeholder:literal('고객명')},bindings:{value:binding('state',['customer','keyword'],'TwoWay')},overrides:{}},
    {id:'slotProduct',kind:'instance',definitionId:'SearchCard',name:'상품 SearchCard',props:{placeholder:literal('상품명')},bindings:{value:binding('state',['product','keyword'],'TwoWay')},overrides:{}}
  ];
  return validateDocument(next,registry);
}

/** Dynamic composition acceptance fixture: reusable List UserControl exposes
 * array and boolean public Props consumed by Repeat/Condition behavior.
 * Two instances demonstrate isolation without cloning the Definition tree.
 */
export function createDynamicExampleDocument(registry){
  let doc=createSearchBoxDocument();
  doc=createComponentDefinition(doc,'ItemList',registry);
  doc=addDefinitionProperty(doc,'ItemList','items','array',[],registry);
  doc=addDefinitionProperty(doc,'ItemList','showTitle','boolean',true,registry);
  const defId='definition:ItemList',root=doc.definitions.ItemList.root.id;
  const heading=createEditorNode(doc,'core/Text',registry);
  heading.props.text=literal('Reusable items');
  heading.when=binding('props',['showTitle']);
  doc=insertEditorNode(doc,root,0,heading,registry,defId);
  const row=createEditorNode(doc,'layout/row',registry);
  row.name='Repeated Item';
  row.repeat={items:binding('props',['items']),keyPath:['id']};
  row.when=binding('context',['item','visible']);
  doc=insertEditorNode(doc,root,1,row,registry,defId);
  const label=createEditorNode(doc,'core/Text',registry);
  label.props.text=binding('context',['item','label']);
  doc=insertEditorNode(doc,row.id,0,label,registry,defId);
  const next=structuredClone(doc),page=next.pages.main.root;
  page.children=[
    {id:'listA',kind:'instance',definitionId:'ItemList',props:{items:literal([{id:'a',label:'Customer A',visible:true},{id:'hidden',label:'hidden',visible:false}])},bindings:{},overrides:{}},
    {id:'listB',kind:'instance',definitionId:'ItemList',props:{items:literal([{id:'b',label:'Product B',visible:true}]),showTitle:literal(false)},bindings:{},overrides:{}}
  ];
  next.title='v0.12 · Dynamic Composition';
  return validateDocument(next,registry);
}

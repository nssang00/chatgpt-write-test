import {ReactiveStore,scopedStore} from './store.js';
import {DataContext,readProperty,subscribeProperty,writeBinding} from './binding.js';
/** Preview/runtime data is never serialized into a Definition. */
export class RuntimeSession {
  #locals=new Map();
  constructor(document){this.document=document;this.state=new ReactiveStore(document.data.state);this.sources=new ReactiveStore(document.data.sources,true);}
  rootScope(){return new DataContext({state:this.state,sources:this.sources});}
  localStore(path){if(!this.#locals.has(path))this.#locals.set(path,new ReactiveStore({}));return this.#locals.get(path);}
  instanceScope(instance,definition,parent,path){
    const local=this.localStore(path);
    const outer=parent;
    const findValue=key=>instance.bindings?.[key]||instance.props?.[key];
    const getValue=key=>{
      const stored=local.get([key]);if(stored!==undefined)return stored;
      const provider=findValue(key);
      return provider?readProperty(provider,outer,this.document.resources):definition.publicProps[key]?.defaultValue;
    };
    const propsStore={
      get:(segments)=>segments.length===1?getValue(segments[0]):undefined,
      set:(segments,value)=>{
        if(segments.length!==1)throw Error('공개 속성의 중첩 경로 쓰기는 지원하지 않습니다');
        const key=segments[0];
        const spec=definition.publicProps[key];
        if(!spec?.twoWay)throw Error(`TwoWay 미지원 공개 속성: ${key}`);
        const provider=findValue(key);
        if(provider?.kind==='binding')writeBinding(provider,outer,value);
        else local.set([key],value);
      },
      subscribe:(segments,fn)=>{
        if(segments.length!==1)return()=>{};
        const key=segments[0],provider=findValue(key);
        const off1=provider?subscribeProperty(provider,outer,fn):()=>{};
        const off2=local.subscribe([key],fn);
        return()=>{off1();off2();};
      }
    };
    const stores={props:propsStore,local};
    if(instance.dataContext?.source && instance.dataContext?.path){
      const parentStore=outer.resolve(instance.dataContext.source);
      if(parentStore)stores.context=scopedStore(parentStore,instance.dataContext.path);
    }
    return {scope:outer.child(stores),propsStore};
  }
}

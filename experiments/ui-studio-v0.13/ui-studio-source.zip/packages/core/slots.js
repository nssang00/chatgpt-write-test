import {validateDocument,findNode,walkNodes} from '../schema/index.js';
import {pageRoot,locateNode} from './editor.js';
const NAME=/^[a-zA-Z_][a-zA-Z0-9_]{0,63}$/;

/** Publish one existing Frame as a named insertion point. Children remain fallback content. */
export function exposeDefinitionSlot(doc,definitionId,frameId,name,registry){
  if(!NAME.test(name))throw Error('Slot 이름은 영문/숫자/밑줄만 사용할 수 있습니다');
  const next=structuredClone(doc),def=next.definitions[definitionId];
  if(!def)throw Error('없는 Definition');
  if(findNode(def.root,frameId)?.kind!=='frame')throw Error('Slot은 내부 Frame에만 설정할 수 있습니다');
  if(Object.hasOwn(def.slots||{},name))throw Error(`Slot 이름 중복: ${name}`);
  if(Object.values(def.slots||{}).some(spec=>spec.nodeId===frameId))throw Error('하나의 Frame에는 하나의 Slot만 지정할 수 있습니다');
  def.slots={...def.slots,[name]:{nodeId:frameId}};
  def.revision=(def.revision||0)+1;
  return validateDocument(next,registry);
}
/** Fill nodes are retained on the Instance, not copied into its Definition. */
export function insertSlotChild(doc,instanceId,slotName,index,node,registry,scope='main'){
  const next=structuredClone(doc),instance=locateNode(pageRoot(next,scope),instanceId)?.node;
  if(instance?.kind!=='instance')throw Error('현재 편집 범위의 UserControl 인스턴스를 선택하세요');
  const definition=next.definitions[instance.definitionId];
  if(!Object.hasOwn(definition.slots||{},slotName))throw Error(`공개되지 않은 Slot: ${slotName}`);
  const used=new Set();for(const page of Object.values(next.pages))walkNodes(page.root,n=>used.add(n.id));
  for(const def of Object.values(next.definitions))walkNodes(def.root,n=>used.add(n.id));
  if(used.has(node.id))throw Error(`중복 노드 ID: ${node.id}`);
  const children=instance.slots?.[slotName]||[];
  const at=Math.min(children.length,Math.max(0,Number.isInteger(index)?index:children.length));
  instance.slots={...instance.slots,[slotName]:[...children.slice(0,at),structuredClone(node),...children.slice(at)]};
  if(scope.startsWith('definition:'))next.definitions[scope.slice(11)].revision++;
  return validateDocument(next,registry);
}
export function resetSlotChildren(doc,instanceId,slotName,registry,scope='main'){
  const next=structuredClone(doc),instance=locateNode(pageRoot(next,scope),instanceId)?.node;
  if(instance?.kind!=='instance')throw Error('현재 편집 범위의 인스턴스를 찾을 수 없습니다');
  if(!Object.hasOwn(next.definitions[instance.definitionId].slots||{},slotName))throw Error('없는 Slot');
  if(instance.slots)delete instance.slots[slotName];
  if(scope.startsWith('definition:'))next.definitions[scope.slice(11)].revision++;
  return validateDocument(next,registry);
}
export function removeSlotChildren(doc,instanceId,slotName,registry,scope='main'){
  const next=structuredClone(doc),instance=locateNode(pageRoot(next,scope),instanceId)?.node;
  if(instance?.kind!=='instance')throw Error('현재 편집 범위의 UserControl 인스턴스를 선택하세요');
  if(!Object.hasOwn(next.definitions[instance.definitionId].slots||{},slotName))throw Error('없는 Slot');
  instance.slots={...instance.slots,[slotName]:[]};
  if(scope.startsWith('definition:'))next.definitions[scope.slice(11)].revision++;
  return validateDocument(next,registry);
}
/** Used by runtime and test harness. A missing fill means use Definition fallback. */
export function slotNodes(definition,instance,frameId,fallback=[]){
  const found=Object.entries(definition.slots||{}).find(([,spec])=>spec.nodeId===frameId);
  if(!found)return {name:null,nodes:fallback,filled:false};
  const [name]=found;
  return Object.hasOwn(instance.slots||{},name)
    ?{name,nodes:instance.slots[name],filled:true}
    :{name,nodes:fallback,filled:false};
}

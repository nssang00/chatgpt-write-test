/** Pure editor commands. Every command produces a validated v6 document. */
import {literal, validateDocument} from '../schema/index.js';
export const FRAME_TYPES=['column','row','grid','wrap','overlay'];
export function pageRoot(doc,pageId='main'){
  if(pageId.startsWith('definition:')){const id=pageId.slice('definition:'.length);if(!doc.definitions[id])throw Error(`없는 Definition: ${id}`);return doc.definitions[id].root;}
  const page=doc.pages[pageId];if(!page)throw Error(`없는 페이지: ${pageId}`);return page.root;
}
export function locateNode(root,id,parent=null){
  if(root.id===id)return {node:root,parent,index:-1};
  for(let i=0;i<(root.children||[]).length;i++){
    const child=root.children[i];if(child.id===id)return {node:child,parent:root,index:i};
    const found=locateNode(child,id,root);if(found)return found;
  }
  for(const children of Object.values(root.slots||{})){
    for(let i=0;i<children.length;i++){
      const child=children[i];if(child.id===id)return {node:child,parent:root,index:i,slotChildren:children};
      const found=locateNode(child,id,root);if(found)return found;
    }
  }
  return null;
}
// IDs are not derived from array indexes; moving nodes preserves ID and runtime binding addresses.
export function allocateNodeId(doc,prefix='node'){
  const used=new Set();const visit=node=>{used.add(node.id);for(const child of node.children||[])visit(child);for(const fill of Object.values(node.slots||{}))for(const child of fill)visit(child);};
  for(const page of Object.values(doc.pages))visit(page.root);
  for(const def of Object.values(doc.definitions))visit(def.root);
  for(let i=1;i<100000;i++){const id=`${prefix}_${i}`;if(!used.has(id))return id;}
  throw Error('노드 ID 공간이 부족합니다');
}
export function createEditorNode(doc,typeId,registry){
  const id=allocateNodeId(doc);
  if(typeId.startsWith('layout/')){
    const type=typeId.slice(7);if(!FRAME_TYPES.includes(type))throw Error(`지원하지 않는 레이아웃: ${type}`);
    return {id,kind:'frame',name:type[0].toUpperCase()+type.slice(1),layout:{type,gap:8,padding:8,...(type==='grid'?{columns:2}:{})},children:[]};
  }
  if(typeId.startsWith('module/')){
    const definitionId=typeId.slice(7);if(!doc.definitions[definitionId])throw Error('없는 사용자 컴포넌트');
    return {id,kind:'instance',name:definitionId,definitionId,props:{},bindings:{},overrides:{}};
  }
  const control=registry.get(typeId);if(!control)throw Error(`등록되지 않은 컨트롤: ${typeId}`);
  // Default values are resolved by Property System, not stored redundantly.
  return {id,kind:'component',name:control.displayName,typeId,props:{}};
}
function touchDefinition(doc,scope){if(scope.startsWith('definition:'))doc.definitions[scope.slice('definition:'.length)].revision=(doc.definitions[scope.slice('definition:'.length)].revision||0)+1;}
export function insertEditorNode(doc,parentId,index,node,registry,pageId='main'){
  const next=structuredClone(doc),root=pageRoot(next,pageId),location=locateNode(root,parentId);
  if(!location||location.node.kind!=='frame')throw Error('대상은 Frame이어야 합니다');
  if(locateNode(root,node.id))throw Error('중복 노드 ID');
  const children=location.node.children;
  children.splice(Math.max(0,Math.min(children.length,index)),0,structuredClone(node));
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function removeEditorNode(doc,id,registry,pageId='main'){
  const next=structuredClone(doc),location=locateNode(pageRoot(next,pageId),id);
  if(!location?.parent)throw Error('루트는 삭제할 수 없습니다');
  (location.slotChildren||location.parent.children).splice(location.index,1);
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function moveEditorNode(doc,id,parentId,index,registry,pageId='main'){
  const next=structuredClone(doc),root=pageRoot(next,pageId);
  const source=locateNode(root,id),target=locateNode(root,parentId);
  if(!source?.parent)throw Error('루트는 이동할 수 없습니다');
  if(!target||target.node.kind!=='frame')throw Error('대상은 Frame이어야 합니다');
  if(id===parentId||source.node.kind==='frame'&&locateNode(source.node,parentId))throw Error('자기 자신 또는 자손으로 이동할 수 없습니다');
  (source.slotChildren||source.parent.children).splice(source.index,1);
  const actual=source.parent===target.node&&source.index<index?index-1:index;
  target.node.children.splice(Math.max(0,Math.min(target.node.children.length,actual)),0,source.node);
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function patchEditorNode(doc,id,patch,registry,pageId='main'){
  const next=structuredClone(doc),location=locateNode(pageRoot(next,pageId),id);
  if(!location)throw Error('노드 없음');
  const updated=patch(structuredClone(location.node));
  if(!updated||updated.id!==id||updated.kind!==location.node.kind)throw Error('노드 ID / 종류 변경 불가');
  if(location.parent)(location.slotChildren||location.parent.children)[location.index]=updated;
  else if(pageId.startsWith('definition:'))next.definitions[pageId.slice('definition:'.length)].root=updated;
  else next.pages[pageId].root=updated;
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function setEditorProperty(doc,id,key,provider,registry,pageId='main'){
  return patchEditorNode(doc,id,node=>{
    if(node.kind!=='component')throw Error('Control 속성만 변경할 수 있습니다');
    node.props={...node.props,[key]:provider};return node;
  },registry,pageId);
}
export function setEditorLayout(doc,id,layoutPatch,registry,pageId='main'){
  return patchEditorNode(doc,id,node=>{
    if(node.kind!=='frame')throw Error('Frame에만 적용되는 속성입니다');
    node.layout={...node.layout,...layoutPatch};return node;
  },registry,pageId);
}
/** Layout-independent geometric insertion model, shared by canvas/tree pointer UI. */
export function geometryInsertion(children,pointer,mode,columns=2){
  if(!children.length)return {index:0,edge:'empty'};
  if(mode==='grid'){
    // Use geometric child centres; this respects responsive CSS Grid positions.
    for(let i=0;i<children.length;i++){
      const r=children[i];if(pointer.y<r.top+r.height/2||(pointer.y<r.bottom&&pointer.x<r.left+r.width/2))return {index:i,edge:'before'};
    }
    return {index:children.length,edge:'after'};
  }
  const axis=mode==='column'?'y':'x';
  if(mode==='wrap'){
    for(let i=0;i<children.length;i++){
      const r=children[i];if(pointer.y<r.top+r.height/2||(pointer.y<r.bottom&&pointer.x<r.left+r.width/2))return {index:i,edge:'before'};
    }
    return {index:children.length,edge:'after'};
  }
  for(let i=0;i<children.length;i++){
    const r=children[i];if((axis==='y'?pointer.y<r.top+r.height/2:pointer.x<r.left+r.width/2))return {index:i,edge:'before'};
  }
  return {index:children.length,edge:'after'};
}
export function bindableFields(doc){
  const found=[];
  function walk(value,path,depth){if(depth>5||found.length>120)return;if(value!==null&&typeof value==='object'&&!Array.isArray(value)){for(const [key,v] of Object.entries(value)){if(['__proto__','constructor','prototype'].includes(key))continue;walk(v,[...path,key],depth+1);}return;}
    found.push({path,value});}
  walk(doc.data.state,[],0);return found;
}
/** Converts one Frame into a reusable reference without flattening its internal tree. */
export function extractDefinition(doc,frameId,registry,pageId='main'){
  const next=structuredClone(doc),location=locateNode(pageRoot(next,pageId),frameId);
  if(!location?.parent||location.node.kind!=='frame')throw Error('하위 Frame을 선택하세요');
  if(location.slotChildren)throw Error('Slot 내부 Frame은 먼저 밖으로 이동해야 합니다');
  const cleaned=String(location.node.name||'Component').replace(/[^a-zA-Z0-9_]/g,'_').replace(/^_+|_+$/g,'');
  const suggested=cleaned&&/^[a-zA-Z]/.test(cleaned)?cleaned[0].toUpperCase()+cleaned.slice(1):'Component'+(cleaned||'');
  let definitionId=suggested,idx=2;while(Object.hasOwn(next.definitions,definitionId))definitionId=`${suggested}_${idx++}`;
  const instanceId=allocateNodeId(next,'instance');
  const root=structuredClone(location.node);
  next.definitions[definitionId]={id:definitionId,name:location.node.name||definitionId,version:'1.0.0',revision:1,root,publicProps:{},publicEvents:{},overridePolicy:{}};
  location.parent.children[location.index]={id:instanceId,kind:'instance',name:location.node.name||definitionId,definitionId,props:{},bindings:{},overrides:{}};
  touchDefinition(next,pageId);return {document:validateDocument(next,registry),definitionId,instanceId};
}
/** Defines a public API contract. Existing internal literal becomes the public default. */
export function exposeDefinitionProperty(doc,definitionId,nodeId,property,publicName,registry){
  const next=structuredClone(doc),def=next.definitions[definitionId];if(!def)throw Error('없는 Definition');
  const node=locateNode(def.root,nodeId)?.node,meta=node?.kind==='component'?registry.get(node.typeId)?.properties[property]:node?.kind==='instance'?next.definitions[node.definitionId]?.publicProps?.[property]:null;
  if(!meta)throw Error('등록되지 않은 공개 속성');
  if(!/^[a-zA-Z_][a-zA-Z0-9_]{0,63}$/.test(publicName)||def.publicProps?.[publicName])throw Error('공개 Property 이름이 중복이거나 유효하지 않습니다');
  if(Object.values(def.publicProps||{}).some(x=>x.target?.nodeId===nodeId&&x.target?.property===property))throw Error('이미 공개된 속성입니다');
  const configured=node.bindings?.[property]||node.props?.[property];
  def.publicProps[publicName]={type:meta.type,defaultValue:configured?.kind==='literal'?configured.value:meta.defaultValue,bindable:!!meta.bindable,twoWay:!!meta.twoWay,target:{nodeId,property}};
  def.revision=(def.revision||0)+1;
  return validateDocument(next,registry);
}
export function exposeDefinitionEvent(doc,definitionId,nodeId,event,publicName,registry){
  const next=structuredClone(doc),def=next.definitions[definitionId];if(!def)throw Error('없는 Definition');
  const node=locateNode(def.root,nodeId)?.node,meta=node?.kind==='component'?registry.get(node.typeId)?.events[event]:node?.kind==='instance'?next.definitions[node.definitionId]?.publicEvents?.[event]:null;
  if(!meta)throw Error('등록되지 않은 이벤트');
  if(!/^[a-zA-Z_][a-zA-Z0-9_]{0,63}$/.test(publicName)||def.publicEvents?.[publicName])throw Error('공개 이벤트 이름이 중복이거나 유효하지 않습니다');
  def.publicEvents[publicName]={nodeId,event};if(node.kind==='component')node.events={...node.events,[event]:{kind:'emit',event:publicName}};
  def.revision=(def.revision||0)+1;
  return validateDocument(next,registry);
}
export function allowInstanceOverride(doc,definitionId,nodeId,property,registry){
  const next=structuredClone(doc),def=next.definitions[definitionId];if(!def)throw Error('없는 Definition');
  const node=locateNode(def.root,nodeId)?.node;
  if(!node||node.kind!=='component'||!registry.get(node.typeId)?.properties[property])throw Error('속성을 찾을 수 없습니다');
  if(Object.values(def.publicProps||{}).some(x=>x.target?.nodeId===nodeId&&x.target?.property===property))throw Error('공개 속성에 Override를 허용할 수 없습니다');
  const keys=new Set(def.overridePolicy[nodeId]||[]);keys.add(property);def.overridePolicy[nodeId]=[...keys];
  def.revision=(def.revision||0)+1;return validateDocument(next,registry);
}

/** Publish a Definition-scoped property used by dynamic repeat/condition/graphics.
 * Unlike a mapped property, this has no internal Control target. Controls and
 * behaviors can refer to it as props.<name> through the existing Binding Engine.
 */
export function addDefinitionProperty(doc,definitionId,name,type,defaultValue,registry){
  if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name))throw Error('공개 속성 이름이 유효하지 않습니다');
  if(!['string','number','boolean','array','object'].includes(type))throw Error('지원하지 않는 공개 속성 타입');
  const next=structuredClone(doc),definition=next.definitions[definitionId];
  if(!definition)throw Error('Definition을 찾을 수 없습니다');
  if(Object.hasOwn(definition.publicProps||{},name))throw Error('공개 속성 이름이 중복됩니다');
  definition.publicProps={...definition.publicProps,[name]:{type,defaultValue:structuredClone(defaultValue),bindable:true,twoWay:false}};
  definition.revision=(definition.revision||0)+1;
  return validateDocument(next,registry);
}

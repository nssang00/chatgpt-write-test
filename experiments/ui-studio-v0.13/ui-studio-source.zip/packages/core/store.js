import {safePath} from '../schema/index.js';
const intersects=(a,b)=>a.every((x,i)=>i>=b.length||x===b[i])||b.every((x,i)=>i>=a.length||x===a[i]);
export function getPath(data,path){
  if(!safePath(path))throw Error('안전하지 않은 데이터 경로');
  let item=data;for(const segment of path){if(item===null||typeof item!=='object'||!Object.hasOwn(item,segment))return undefined;item=item[segment];}return item;
}
function copySet(value,path,newValue,depth=0){
  if(depth===path.length)return newValue;
  const k=path[depth],object=value&&typeof value==='object'?value:typeof k==='number'?[]:{};
  const next=Array.isArray(object)?object.slice():{...object};next[k]=copySet(object[k],path,newValue,depth+1);return next;
}
export class ReactiveStore {
  #data;#listeners=new Set();
  constructor(data={},readOnly=false){this.#data=structuredClone(data);this.readOnly=readOnly;}
  snapshot(){return structuredClone(this.#data);}
  get(path){return getPath(this.#data,path);}
  set(path,value){
    if(this.readOnly)throw Error('읽기 전용 데이터 소스입니다');
    if(!safePath(path))throw Error('안전하지 않은 데이터 경로');
    if(Object.is(this.get(path),value))return;
    this.#data=copySet(this.#data,path,structuredClone(value));
    for(const entry of [...this.#listeners])if(intersects(entry.path,path))entry.fn();
  }
  subscribe(path,fn){if(!safePath(path))throw Error('안전하지 않은 데이터 경로');const entry={path,fn};this.#listeners.add(entry);return()=>this.#listeners.delete(entry);}
}
export function scopedStore(store,prefix){
  if(!safePath(prefix))throw Error('안전하지 않은 컨텍스트 경로');
  return {get:path=>store.get([...prefix,...path]),set:(path,value)=>store.set([...prefix,...path],value),subscribe:(path,fn)=>store.subscribe([...prefix,...path],fn)};
}

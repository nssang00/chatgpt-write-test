/** Registry definitions contain metadata only; no React / AntD dependencies. */
const TYPES = new Set(['string','number','boolean','enum','color','object','array']);
export class ControlRegistry {
  #controls=new Map();
  register(def){
    if(!def || typeof def.typeId!=='string' || !/^[a-zA-Z_][a-zA-Z0-9_:/.-]*$/.test(def.typeId))throw Error('잘못된 컨트롤 typeId');
    if(this.#controls.has(def.typeId))throw Error(`중복 컨트롤: ${def.typeId}`);
    for(const [key,prop] of Object.entries(def.properties||{})){
      if(!TYPES.has(prop.type))throw Error(`${def.typeId}.${key}: 잘못된 속성 타입`);
      if(prop.twoWay && !prop.bindable)throw Error(`${def.typeId}.${key}: TwoWay는 bindable이 필요합니다`);
    }
    const registered=Object.freeze({...def,properties:Object.freeze({...def.properties}),events:Object.freeze({...def.events})});
    this.#controls.set(def.typeId,registered);return registered;
  }
  get(id){return this.#controls.get(id);}
  has(id){return this.#controls.has(id);}
  list(){return [...this.#controls.values()];}
}
export function createDefaultRegistry(){
  const registry=new ControlRegistry();
  const prop=(type,defaultValue,extra={})=>({type,defaultValue,...extra});
  registry.register({typeId:'core/Input',displayName:'Input',category:'Inputs',properties:{
    value:prop('string','',{bindable:true,twoWay:true,editor:'text'}),
    placeholder:prop('string','',{bindable:true,editor:'text'}),
    disabled:prop('boolean',false,{bindable:true,editor:'switch'}),
    label:prop('string','',{editor:'text'})
  },events:{change:{payloadType:'string'}}});
  registry.register({typeId:'core/Button',displayName:'Button',category:'Actions',properties:{
    text:prop('string','버튼',{bindable:true,editor:'text'}),
    variant:prop('enum','default',{options:['primary','default'],editor:'select'}),
    color:prop('color','#3764df',{editor:'color'}),
    disabled:prop('boolean',false,{bindable:true,editor:'switch'}),
    action:prop('object',{})
  },events:{click:{payloadType:'void'}}});
  registry.register({typeId:'core/Text',displayName:'Text',category:'Display',properties:{text:prop('string','',{bindable:true,editor:'text'}),value:prop('string','',{bindable:true}),weight:prop('enum','normal',{options:['normal','heading']})},events:{}});
  registry.register({typeId:'core/Checkbox',displayName:'Checkbox',category:'Inputs',properties:{checked:prop('boolean',false,{bindable:true,twoWay:true,editor:'switch'}),text:prop('string','확인'),disabled:prop('boolean',false,{bindable:true})},events:{change:{payloadType:'boolean'}}});
  // Old controls retain their semantic metadata even if a renderer adapter is not yet available.
  registry.register({typeId:'core/Select',displayName:'Select',category:'Inputs',properties:{label:prop('string',''),options:prop('string',''),value:prop('string','',{bindable:true,twoWay:true})},events:{change:{payloadType:'string'}}});
  registry.register({typeId:'core/Table',displayName:'Table',category:'Data',properties:{title:prop('string',''),columns:prop('string',''),dataSource:prop('array',[],{bindable:true}),filter:prop('string','',{bindable:true})},events:{}});
  registry.register({typeId:'core/Card',displayName:'Card',category:'Display',properties:{title:prop('string',''),description:prop('string','')},events:{}});
  registry.register({typeId:'core/Divider',displayName:'Divider',category:'Display',properties:{},events:{}});
  registry.register({typeId:'core/Tag',displayName:'Tag',category:'Display',properties:{text:prop('string',''),color:prop('color','blue')},events:{}});
  return registry;
}

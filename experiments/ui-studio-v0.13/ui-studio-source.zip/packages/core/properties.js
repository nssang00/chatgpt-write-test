import {literal} from '../schema/index.js';
import {readProperty,subscribeProperty,writeBinding} from './binding.js';
export function propertyProvider(node,key,registry,overrides){
  const control=registry.get(node.typeId);if(!control)throw Error(`미등록 컨트롤: ${node.typeId}`);
  if(!Object.hasOwn(control.properties,key))throw Error(`정의되지 않은 속성: ${node.typeId}.${key}`);
  const override=overrides?.[node.id]?.[key];
  if(override)return override;
  return node.props?.[key]||literal(control.properties[key].defaultValue);
}
export function controlProperty(node,key,registry,scope,overrides,resources){
  return readProperty(propertyProvider(node,key,registry,overrides),scope,resources);
}
export function subscribeControlProperty(node,key,registry,scope,overrides,fn){
  return subscribeProperty(propertyProvider(node,key,registry,overrides),scope,fn);
}
export function setControlProperty(node,key,value,registry,scope,overrides,phase='change'){
  const meta=registry.get(node.typeId)?.properties[key];
  if(!meta?.twoWay)throw Error(`${node.typeId}.${key}: TwoWay 쓰기 불가`);
  if(typeof value!==meta.type)throw Error(`${node.typeId}.${key}: ${meta.type} 타입이 필요합니다`);
  const provider=propertyProvider(node,key,registry,overrides);
  if(provider.kind!=='binding')throw Error('현재 속성은 TwoWay 바인딩이 아닙니다');
  return writeBinding(provider,scope,value,phase);
}

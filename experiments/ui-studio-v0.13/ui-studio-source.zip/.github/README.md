# GitHub Actions · Chromium E2E

`browser-e2e.yml` runs on push/PR to main/master and via **Actions → UI Studio — Chromium E2E → Run workflow**.

**Precondition:** Put the full UI Studio v0.12 project at the *root* of a GitHub repository (including hidden `.github/` directory). A ZIP uploaded as a single GitHub attachment is not sufficient. This file does not submit work or trigger Actions by itself.

Stages: Node 22 → npm install → 165 core regression tests → runtime integration → syntax check → Vite production build → exported React package build → Chromium install → 7 real-browser Playwright E2E checks → HTML / JUnit / trace / screenshots / video artifacts.

The browser test runs against `vite preview` on `127.0.0.1:4173` after a real Vite build. A successful Node.js test alone does not count as E2E success. A GitHub Actions run URL and green `chromium-e2e` job are required to claim verification.

No lockfile was present in v0.12, so CI uses `npm install`, not `npm ci`. After network installation succeeds, create and commit `package-lock.json` and change the workflow to `npm ci`.

For a failed run, download the `ui-studio-chromium-e2e` artifact from its Actions run and open `playwright-report/index.html` or `test-results/.../trace.zip` via `npx playwright show-trace`.

**As delivered:** The workflow and tests are configured but not executed by GitHub Actions because no corresponding UI Studio repository was found among the linked GitHub accounts. Do not interpret local Node tests as GitHub Actions E2E.

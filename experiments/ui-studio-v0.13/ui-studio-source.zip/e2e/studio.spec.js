import { test, expect } from '@playwright/test';

const root = page => page.locator('.v6-studio');
const tree = page => root(page).locator('.v6-tree');
const canvas = page => root(page).locator('.v6-artboard');
const panel = page => root(page).locator('.v6-insert');
const insert = async (page, name) => {
  await root(page).getByRole('button', { name: /Insert/ }).first().click();
  await expect(panel(page)).toBeVisible();
  await panel(page).locator('.v6-insert-items button').filter({ hasText: name }).first().click();
};
const selectPage = async page => {
  await root(page).getByRole('button', { name: 'Preview Page' }).click();
  await expect(root(page).locator('.v6-center-head')).toContainText('Preview / Page: main');
};

// Every test starts with a fresh browser context and the v6 editor loaded.
test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await expect(root(page)).toBeVisible();
});

test('v6 starts in Component Tree + Design and renders real controls', async ({ page }) => {
  await expect(root(page).locator('.v6-left-head')).toContainText('Component Tree');
  await expect(tree(page).locator('[data-v6-tree-id]')).not.toHaveCount(0);
  await expect(canvas(page).locator('[data-v6-frame-id]')).not.toHaveCount(0);
  await expect(root(page).locator('.v6-right')).toContainText('Properties');
});

test('Insert click updates Component Tree, canvas and the canonical JSX DSL', async ({ page }) => {
  await selectPage(page);
  const before = await tree(page).locator('[data-v6-tree-id]').count();
  await insert(page, 'Input');
  await expect(tree(page).locator('[data-v6-tree-id]')).toHaveCount(before + 1);
  await expect(canvas(page).locator('.v6-canvas-control').last()).toContainText('Input');
  await root(page).locator('.v6-center-head .ant-segmented-item').filter({ hasText: 'Code' }).click();
  await expect(root(page).getByRole('textbox', { name: 'v6 JSX DSL' })).toHaveValue(/<Input/);
});

test('native pointer drag from Insert drops control into the canvas Frame', async ({ page }) => {
  await selectPage(page);
  const originalIds = await tree(page).locator('[data-v6-tree-id]').evaluateAll(nodes => nodes.map(node => node.getAttribute('data-v6-tree-id')));
  const before = originalIds.length;
  await root(page).getByRole('button', { name: /Insert/ }).first().click();
  const source = panel(page).locator('.v6-insert-items button').filter({ hasText: 'Button' }).first();
  const target = canvas(page).locator('[data-v6-frame-id]').first();
  await expect(source).toBeVisible();
  await expect(target).toBeVisible();
  // Playwright dragTo uses actual pointer movement, not synthetic HTML5 drop events.
  await source.dragTo(target, { targetPosition: { x: 125, y: 120 } });
  await expect(tree(page).locator('[data-v6-tree-id]')).toHaveCount(before + 1);
  const updatedIds = await tree(page).locator('[data-v6-tree-id]').evaluateAll(nodes => nodes.map(node => node.getAttribute('data-v6-tree-id')));
  const addedIds = updatedIds.filter(id => !originalIds.includes(id));
  expect(addedIds).toHaveLength(1);
  await expect(canvas(page).locator('[data-v6-canvas-id="' + addedIds[0] + '"]')).toContainText('Button');
});

test('Code edits update Design through the same v6 document', async ({ page }) => {
  await selectPage(page);
  await root(page).locator('.v6-center-head .ant-segmented-item').filter({ hasText: 'Code' }).click();
  const editor = root(page).getByRole('textbox', { name: 'v6 JSX DSL' });
  await expect(editor).toBeVisible();
  await editor.fill('<Page id="main" layout="column" gap={8}><Button id="buttonSmoke" text="E2E Button" /></Page>');
  await expect(root(page).locator('.v6-error')).toHaveCount(0);
  await expect(canvas(page).locator('[data-v6-canvas-id="buttonSmoke"]')).toBeVisible();
  await root(page).locator('.v6-center-head .ant-segmented-item').filter({ hasText: 'Design' }).click();
  await expect(tree(page).locator('[data-v6-tree-id="buttonSmoke"]')).toBeVisible();
  await expect(canvas(page).locator('[data-v6-canvas-id="buttonSmoke"]')).toContainText('Button');
});

test('dynamic composition example preserves two distinct user-control instances', async ({ page }) => {
  await root(page).getByRole('button', { name: /Dynamic 예제/ }).click();
  await expect(root(page).locator('.v6-component-api')).toContainText('ItemList');
  await selectPage(page);
  await expect(tree(page).locator('[data-v6-tree-id]')).toHaveCount(3); // page root + two ItemList instances
  await root(page).locator('.v6-center-head .ant-segmented-item').filter({ hasText: 'Preview' }).click();
  await expect(root(page).locator('.v6-artboard')).toBeVisible();
  await expect(root(page).locator('.v6-error')).toHaveCount(0);
});


test('SearchBox uses actual DOM inputs with independent TwoWay state and event', async ({ page }) => {
  await selectPage(page);
  await root(page).locator('.v6-center-head .ant-segmented-item').filter({ hasText: 'Preview' }).click();
  const customer = canvas(page).locator('[data-core-instance="customerSearch"] input[data-control-id="searchInput"]');
  const product = canvas(page).locator('[data-core-instance="productSearch"] input[data-control-id="searchInput"]');
  await expect(customer).toBeVisible();
  await expect(product).toBeVisible();
  await customer.fill('Customer E2E');
  await expect(customer).toHaveValue('Customer E2E');
  await expect(product).toHaveValue('');
  await expect(root(page).locator('.v6-state-line').filter({ hasText: 'customer.keyword' })).toContainText('Customer E2E');
  await product.fill('Product E2E');
  await expect(customer).toHaveValue('Customer E2E');
  await expect(root(page).locator('.v6-state-line').filter({ hasText: 'product.keyword' })).toContainText('Product E2E');
  await canvas(page).locator('[data-core-instance="customerSearch"] button[data-control-id="searchButton"]').click();
  await expect(root(page).locator('.v6-preview-log')).toContainText('customerSearch.search');
});

test('JSON save downloads v6 definitions, and exported component ZIP is nonempty', async ({ page }) => {
  const jsonPromise = page.waitForEvent('download');
  await root(page).getByRole('button', { name: 'JSON 저장' }).click();
  const jsonDownload = await jsonPromise;
  const stream = await jsonDownload.createReadStream();
  const chunks = [];
  for await (const part of stream) chunks.push(part);
  const doc = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  expect(doc.schemaVersion).toBe(6);
  expect(doc.definitions.SearchBox).toBeTruthy();
  expect(doc.pages.main).toBeTruthy();

  const zipPromise = page.waitForEvent('download');
  await root(page).getByRole('button', { name: /React Component ZIP/ }).click();
  const zipDownload = await zipPromise;
  expect(zipDownload.suggestedFilename()).toBe('SearchBox-react-component.zip');
  const zipStream = await zipDownload.createReadStream();
  const zipParts = [];
  for await (const part of zipStream) zipParts.push(part);
  const bytes = Buffer.concat(zipParts);
  expect(bytes.length).toBeGreaterThan(2_000);
  expect(bytes.subarray(0, 4).toString('hex')).toBe('504b0304');
});

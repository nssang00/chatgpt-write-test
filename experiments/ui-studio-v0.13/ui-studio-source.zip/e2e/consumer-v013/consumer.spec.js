import {test,expect} from '@playwright/test';
test('an independently installed CustomerBrowser renders two isolated instances, emits typed callbacks',async({page})=>{
 await page.goto('/');
 await expect(page.getByRole('heading',{name:'Independent React Consumer'})).toBeVisible();
 const a=page.getByTestId('consumer-A');const b=page.getByTestId('consumer-B');
 const inputA=a.locator('input[data-control-id="searchInput"]');
 const inputB=b.locator('input[data-control-id="searchInput"]');
 await expect(inputA).toBeVisible();await expect(inputB).toBeVisible();
 await inputA.fill('Alice');
 await expect(page.getByTestId('first-value')).toHaveText('Alice');
 await expect(inputB).toHaveValue('');
 await inputB.fill('Bob');
 await expect(page.getByTestId('second-value')).toHaveText('Bob');
 await expect(inputA).toHaveValue('Alice');
 await a.locator('button[data-control-id="searchButton"]').click();
 await expect(page.getByTestId('search-events')).toHaveText('1');
 await b.locator('button[data-control-id="searchButton"]').click();
 await expect(page.getByTestId('search-events')).toHaveText('2');
});

import { test, expect } from '@playwright/test';

const root=page=>page.locator('.v6-studio');
const library=page=>root(page).getByTestId('component-library');
const inspect=page=>root(page).locator('.v6-right .v6-inspector-content');
const selectDefinition=async(page,name)=>{
  await library(page).getByRole('button',{name:`◇ ${name}`,exact:true}).click();
  await expect(root(page).locator('.v6-center-head')).toContainText(`Component: ${name}`);
};
const createComponent=async(page,name)=>{
  await root(page).getByRole('button',{name:/New Component/}).click();
  await page.getByRole('textbox',{name:'New component name'}).fill(name);
  await page.getByRole('button',{name:'컴포넌트 생성'}).click();
  await selectDefinition(page,name);
};
const insert=async(page,name)=>{
  await root(page).getByRole('button',{name:/Insert/}).first().click();
  const menu=root(page).locator('.v6-insert');
  await expect(menu).toBeVisible();
  await menu.locator('.v6-insert-items button').filter({hasText:name}).first().click();
  await expect(menu).not.toBeVisible();
};
const publishProp=async(page,name,internal)=>{
  const field=inspect(page).locator('.v6-property-field').filter({has:page.locator('label:text-is("공개 속성 이름")')});
  await field.locator('input').first().fill(name);
  if(internal){await field.locator('.ant-select').click();await page.getByRole('option',{name:internal,exact:true}).click();}
  await field.getByRole('button',{name:'Expose Property'}).click();
  await expect(root(page).locator('.v6-error')).toHaveCount(0);
};
const publishEvent=async(page,name)=>{
  const field=inspect(page).locator('.v6-property-field').filter({has:page.locator('label:text-is("공개 이벤트 이름")')});
  await field.locator('input').first().fill(name);
  await field.getByRole('button',{name:'Expose Event'}).click();
  await expect(root(page).locator('.v6-error')).toHaveCount(0);
};

test('v0.13 Lego user journey: visually create 3 layered components, re-export and preview 2 instances',async({page})=>{
  await page.goto('/');
  await createComponent(page,'MiniSearch');
  await insert(page,'Input');
  await publishProp(page,'value');
  await insert(page,'Button');
  await publishEvent(page,'search');
  await expect(library(page).getByTestId('component-library-MiniSearch')).toBeVisible();

  await createComponent(page,'FilterBar');
  await insert(page,'MiniSearch');
  await publishProp(page,'keyword','value');
  await publishEvent(page,'search');
  await insert(page,'Select');

  await createComponent(page,'CustomerBrowser');
  await insert(page,'FilterBar');
  await publishProp(page,'value','keyword');
  await publishEvent(page,'search');
  await insert(page,'Table');
  await expect(root(page).locator('.v6-component-api')).toContainText('value');
  await expect(root(page).locator('.v6-component-api')).toContainText('search');
  await expect(root(page).getByTestId('component-library-CustomerBrowser')).toContainText('CustomerBrowser');

  const downloadEvent=page.waitForEvent('download');
  await root(page).getByRole('button',{name:/React Component ZIP/}).click();
  const exported=await downloadEvent;
  expect(exported.suggestedFilename()).toBe('CustomerBrowser-react-component.zip');
  const bytes=await exported.createReadStream();let count=0;for await(const block of bytes)count+=block.length;
  expect(count).toBeGreaterThan(3000);

  await root(page).getByRole('button',{name:/Preview Instance/}).click();
  await expect(root(page).locator('.v6-center-head')).toContainText('Preview / Page: main');
  await selectDefinition(page,'CustomerBrowser');
  await root(page).getByRole('button',{name:/Preview Instance/}).click();
  const ids=await root(page).locator('.v6-tree [data-v6-tree-id]').evaluateAll(nodes=>nodes.map(n=>n.getAttribute('data-v6-tree-id')));
  expect(new Set(ids).size).toBe(3); // preview root + 2 reused instance references
  await root(page).getByRole('button',{name:/Preview Page|Preview Harness/}).click();
  await root(page).locator('.v6-center-head .ant-segmented-item').filter({hasText:'Preview'}).click();
  await expect(root(page).locator('[data-core-instance^="preview_"]')).toHaveCount(2);
});

test('v0.13 a composed instance provides one-click navigation to the canonical child definition',async({page})=>{
  await page.goto('/');
  await root(page).getByRole('button',{name:/LEGO 재사용 예제/}).click();
  await selectDefinition(page,'CustomerBrowser');
  const instance=root(page).locator('.v6-tree [data-v6-tree-id]').nth(1);
  await instance.click();
  await expect(inspect(page).getByRole('button',{name:/원본 Definition 편집/})).toBeVisible();
  await inspect(page).getByRole('button',{name:/원본 Definition 편집/}).click();
  await expect(root(page).locator('.v6-center-head')).toContainText('Component: FilterBar');
  await expect(root(page).locator('.v6-tree')).toContainText('SearchBox');
});
